#!/usr/bin/env node
/**
 * siapkan-android.js — dipanggil oleh BUILDER APK-EXE.txt (alur APK) atau `npm run apk:sync`.
 *
 * Tugas:
 *  1) Menulis capacitor.config.json dengan server.url = http://<IP-LAN-PC>:3000 —
 *     APK adalah "jendela" yang memuat BugHunter ID dari server di PC (server sumber kebenaran:
 *     deteksi rule-based, AI, basis data, semua berjalan di PC).
 *  2) Memastikan folder out/ (webDir) berisi halaman cadangan agar `cap sync` tidak pernah gagal.
 *  3) Bila folder android/ sudah ada (hasil `npx cap add android`):
 *     - menambah izin INTERNET + usesCleartextTraffic di AndroidManifest.xml (idempoten),
 *     - menjalankan `npx cap copy android` agar konfigurasi terbaru masuk ke proyek Android.
 *
 * Env opsional: BUGHUNTER_APK_HOST (mis. 10.0.2.2 utk emulator), BUGHUNTER_PORT (default 3000).
 */
const fs = require('fs')
const path = require('path')
const os = require('os')
const { spawnSync } = require('child_process')

const root = __dirname
const port = process.env.BUGHUNTER_PORT || '3000'

/** Ambil IPv4 privat pertama (prioritas 192.168.* lalu 10.* lalu 172.*). */
function lanIp() {
  const kandidat = []
  const ifaces = os.networkInterfaces()
  for (const name of Object.keys(ifaces)) {
    for (const ni of ifaces[name] || []) {
      if (ni.family === 'IPv4' && !ni.internal) kandidat.push(ni.address)
    }
  }
  const rank = (ip) => (ip.startsWith('192.168.') ? 0 : ip.startsWith('10.') ? 1 : ip.startsWith('172.') ? 2 : 3)
  kandidat.sort((a, b) => rank(a) - rank(b))
  return kandidat[0] || '10.0.2.2' // fallback: host loopback emulator Android
}

// 1) capacitor.config.json dengan server.url
const host = process.env.BUGHUNTER_APK_HOST || lanIp()
const url = `http://${host}:${port}`
const config = {
  appId: 'id.bughunter.desktop',
  appName: 'BugHunter ID',
  webDir: 'out',
  server: { url, cleartext: true },
}
fs.writeFileSync(path.join(root, 'capacitor.config.json'), JSON.stringify(config, null, 2) + '\n')
console.log('[siapkan-android] capacitor.config.json ditulis — APK akan memuat aplikasi dari: ' + url)

// 2) webDir cadangan (agar cap add/sync tidak pernah gagal)
fs.mkdirSync(path.join(root, 'out'), { recursive: true })
const placeholder = path.join(root, 'out', 'index.html')
if (!fs.existsSync(placeholder)) {
  fs.writeFileSync(
    placeholder,
    `<!doctype html><html lang="id"><meta charset="utf-8"><title>BugHunter ID</title>
<body style="font-family:sans-serif;background:#0a0a0f;color:#e5e7eb;padding:24px">
<h2 style="color:#34d399">BugHunter ID (mode APK)</h2>
<p>Aplikasi ini memuat BugHunter ID dari server di PC. Jalankan <code>npm run start</code> di PC
dan pastikan HP satu jaringan Wi-Fi, lalu buka ulang aplikasi.</p></body></html>\n`
  )
  console.log('[siapkan-android] out/index.html (halaman cadangan) dibuat')
}

// 3) patch manifest + cap copy bila proyek android ada
const manifestPath = path.join(root, 'android', 'app', 'src', 'main', 'AndroidManifest.xml')
if (fs.existsSync(manifestPath)) {
  let xml = fs.readFileSync(manifestPath, 'utf8')
  let berubah = false
  if (!xml.includes('android.permission.INTERNET')) {
    xml = xml.replace(/(<manifest[^>]*>)/i, '$1\n    <uses-permission android:name="android.permission.INTERNET" />')
    berubah = true
  }
  if (!xml.includes('usesCleartextTraffic')) {
    xml = xml.replace(/<application\b/i, '<application\n        android:usesCleartextTraffic="true"')
    berubah = true
  }
  if (berubah) {
    fs.writeFileSync(manifestPath, xml)
    console.log('[siapkan-android] AndroidManifest.xml diperbarui (izin INTERNET + cleartext)')
  }
  const r = spawnSync('npx cap copy android', { shell: true, stdio: 'inherit', cwd: root })
  if (r.status !== 0) {
    console.error('[siapkan-android] GAGAL: npx cap copy android')
    process.exit(1)
  }
} else {
  console.log('[siapkan-android] Folder android/ belum ada — "npx cap add android" akan membuatnya (BUILDER APK-EXE.txt sudah melakukannya otomatis).')
}

console.log('[siapkan-android] Selesai. Langkah berikutnya:')
console.log('  1) Di PC      : npm run start   (server jalan di ' + url + ')')
console.log('  2) Di HP      : pastikan satu jaringan Wi-Fi dengan PC, lalu buka aplikasi BugHunter ID')
console.log('  3) Emulator   : set BUGHUNTER_APK_HOST=10.0.2.2 lalu jalankan ulang skrip ini')
