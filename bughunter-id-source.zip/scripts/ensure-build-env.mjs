/**
 * ensure-build-env.mjs — prasyarat sebelum `next build` (dipanggil otomatis via `prebuild`).
 * Lintas-platform (Windows CMD / Linux / macOS, tanpa cp/export khusus Unix).
 *
 * 1) Pastikan file .env ada — bila tidak, buat dengan DATABASE_URL absolut (aman utk Windows).
 * 2) `prisma db push` idempoten: pastikan file DB + tabel siap (TIDAK menghapus data).
 */
import fs from 'node:fs'
import path from 'node:path'
import { spawnSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const envPath = path.join(root, '.env')

// 1) .env
if (!fs.existsSync(envPath)) {
  const dbDir = path.join(root, 'db')
  fs.mkdirSync(dbDir, { recursive: true })
  const dbAbs = path.join(dbDir, 'custom.db').split(path.sep).join('/')
  fs.writeFileSync(
    envPath,
    `# Dibuat otomatis oleh scripts/ensure-build-env.mjs (prasyarat build)\nDATABASE_URL=file:${dbAbs}\n`
  )
  console.log(`[ensure-build-env] .env belum ada — dibuat otomatis: DATABASE_URL=file:${dbAbs}`)
} else {
  console.log('[ensure-build-env] .env ditemukan — dipakai apa adanya')
}

// 2) Sinkronkan skema SQLite (idempoten, tanpa --accept-data-loss supaya tidak menghapus data).
//    TANPA --skip-generate: sekaligus memastikan Prisma Client ter-generate.
const res = spawnSync('prisma db push', {
  shell: true,
  stdio: 'inherit',
  cwd: root,
})
if (res.status !== 0) {
  console.error('[ensure-build-env] GAGAL: prisma db push tidak sukses. Periksa DATABASE_URL di file .env')
  process.exit(1)
}
console.log('[ensure-build-env] OK — basis data siap')

// 3) Verifikasi Prisma Client benar-benar bisa dimuat.
//    Di mesin baru (mis. Windows hasil npm install), `prisma generate` dari postinstall
//    kadang tidak jalan → `@prisma/client` melempar error saat build → "Failed to collect
//    page data". Di sini diverifikasi eksplisit dan di-generate ulang bila perlu.
function prismaClientOk() {
  const check = spawnSync(
    process.execPath,
    ['-e', 'try { require("@prisma/client") } catch (e) { console.error(e.message); process.exit(1) }'],
    { cwd: root, stdio: 'pipe', shell: false }
  )
  return check.status === 0
}

if (!prismaClientOk()) {
  console.log('[ensure-build-env] Prisma Client belum siap — menjalankan `prisma generate` ...')
  const gen = spawnSync('prisma generate', { shell: true, stdio: 'inherit', cwd: root })
  if (gen.status !== 0 || !prismaClientOk()) {
    console.error('[ensure-build-env] GAGAL: Prisma Client tidak bisa dimuat.')
    console.error('  Jalankan manual di folder proyek:  npx prisma generate')
    console.error('  Bila tetap gagal: hapus folder node_modules lalu `npm install` ulang.')
    process.exit(1)
  }
}
console.log('[ensure-build-env] OK — Prisma Client siap')
