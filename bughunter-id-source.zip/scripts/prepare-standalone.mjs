/**
 * prepare-standalone.mjs — tahap pasca `next build` (dipanggil otomatis oleh script `build`).
 * Menggantikan `cp -r` khas Unix agar jalan di Windows CMD maupun Linux.
 *
 * 1) Salin .next/static  → .next/standalone/.next/static  (wajib utk mode standalone)
 * 2) Salin public       → .next/standalone/public
 * 3) Siapkan .next/exe/seed.db (skema kosong) — dibawa electron-builder ke dalam EXE
 *    agar aplikasi desktop langsung punya basis data di %APPDATA% saat pertama jalan.
 */
import fs from 'node:fs'
import path from 'node:path'
import { spawnSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const standalone = path.join(root, '.next', 'standalone')

if (!fs.existsSync(path.join(standalone, 'server.js'))) {
  console.error(
    '[prepare-standalone] GAGAL: .next/standalone/server.js tidak ditemukan.\n' +
      '  Pastikan `next build` sukses dan next.config.ts memakai output: "standalone".'
  )
  process.exit(1)
}

// 1) static
const srcStatic = path.join(root, '.next', 'static')
const dstStatic = path.join(standalone, '.next', 'static')
if (!fs.existsSync(srcStatic)) {
  console.error('[prepare-standalone] GAGAL: .next/static tidak ditemukan.')
  process.exit(1)
}
fs.rmSync(dstStatic, { recursive: true, force: true })
fs.cpSync(srcStatic, dstStatic, { recursive: true })
console.log('[prepare-standalone] static tersalin → .next/standalone/.next/static')

// 2) public
const srcPublic = path.join(root, 'public')
const dstPublic = path.join(standalone, 'public')
fs.rmSync(dstPublic, { recursive: true, force: true })
if (fs.existsSync(srcPublic)) {
  fs.cpSync(srcPublic, dstPublic, { recursive: true })
  console.log('[prepare-standalone] public tersalin → .next/standalone/public')
}

// 3) seed.db utk EXE
const exeDir = path.join(root, '.next', 'exe')
fs.mkdirSync(exeDir, { recursive: true })
const seedDb = path.join(exeDir, 'seed.db')
const res = spawnSync('prisma db push --skip-generate', {
  shell: true,
  stdio: 'inherit',
  cwd: root,
  env: { ...process.env, DATABASE_URL: 'file:' + seedDb.split(path.sep).join('/') },
})
if (res.status !== 0 || !fs.existsSync(seedDb)) {
  console.error('[prepare-standalone] GAGAL: prisma db push untuk seed.db tidak sukses.')
  process.exit(1)
}
const sizeKb = Math.max(1, Math.round(fs.statSync(seedDb).size / 1024))
console.log(`[prepare-standalone] seed.db siap (${sizeKb} KB) → .next/exe/seed.db`)
console.log('[prepare-standalone] OK — siap packaging EXE (postbuild) / `npm run start`')
