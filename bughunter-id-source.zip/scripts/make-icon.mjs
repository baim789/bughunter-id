/** make-icon.mjs — membuat build/icon.png (512×512) dari public/logo.svg utk ikon EXE. */
import sharp from 'sharp'
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const svg = path.join(root, 'public', 'logo.svg')
const out = path.join(root, 'build', 'icon.png')

if (!fs.existsSync(svg)) {
  console.error('[make-icon] public/logo.svg tidak ditemukan')
  process.exit(1)
}
fs.mkdirSync(path.dirname(out), { recursive: true })
await sharp(svg, { density: 512 }).resize(512, 512, { fit: 'contain', background: { r: 10, g: 10, b: 15, alpha: 1 } }).png().toFile(out)
console.log('[make-icon] build/icon.png dibuat (512×512)')
