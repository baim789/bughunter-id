/**
 * package-exe.mjs — dipanggil otomatis via `postbuild` setelah build sukses.
 * Di Windows: menjalankan electron-builder --win → menghasilkan EXE portabel + installer
 * di folder dist-exe/ (BugHunterID-Portable-<versi>.exe & BugHunterID-Setup-<versi>.exe).
 * Di platform lain (Linux/macOS): dilewati dengan pesan ramah, build web tetap dianggap sukses.
 */
import { spawnSync } from 'node:child_process'
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')

if (process.platform !== 'win32') {
  console.log(
    `[package-exe] Dilewati — pembuatan .exe hanya bisa di Windows (saat ini: ${process.platform}).\n` +
      '[package-exe] Build web selesai. Jalankan `npm run build` di Windows untuk menghasilkan EXE.'
  )
  process.exit(0)
}

const cfg = path.join(root, 'electron-builder.yml')
const standalone = path.join(root, '.next', 'standalone')
if (!fs.existsSync(cfg) || !fs.existsSync(path.join(standalone, 'server.js'))) {
  console.error('[package-exe] GAGAL: electron-builder.yml / .next/standalone tidak lengkap.')
  process.exit(1)
}

console.log('[package-exe] Menjalankan electron-builder --win (menit pertama bisa lama: mengunduh komponen NSIS/portable)...')

// Output electron-builder di-mirror ke layar DAN disimpan ke package-exe.log
// (log dari tool builder user sering terpotong — salinan lengkap memudahkan analisis).
const LOG_PATH = path.join(root, 'package-exe.log')
const res = spawnSync('electron-builder --win', {
  shell: true,
  cwd: root,
  env: { ...process.env, FORCE_COLOR: '0' },
  encoding: 'utf8',
  maxBuffer: 64 * 1024 * 1024,
})
const text = ((res.stdout || '') + (res.stderr || ''))
process.stdout.write(text)
try { fs.writeFileSync(LOG_PATH, text, 'utf8') } catch { /* tak boleh menggagalkan build */ }

if (res.status !== 0) {
  if (/node-gyp/i.test(text)) {
    console.error(
      '[package-exe] Terdeteksi kegagalan node-gyp (compile modul native).\n' +
        '  v0.12.3 sudah MENONAKTIFKAN compile-ulang (npmRebuild: false) — berarti Anda memakai\n' +
        '  source LAMA. Unduh ulang ZIP terbaru (v0.12.3) lalu build ulang.'
    )
  }
  console.error(
    '[package-exe] GAGAL: electron-builder selesai dengan kode ' + res.status + '.\n' +
      '  Log lengkap tersimpan di: package-exe.log (folder proyek).\n' +
      '  Tips: lihat PANDUAN-BUILD.md bagian "Masalah Umum" (mis. unduhan Electron/NSIS terblokir jaringan).'
  )
  process.exit(res.status ?? 1)
}
console.log('[package-exe] OK — EXE tersedia di folder dist-exe/')
