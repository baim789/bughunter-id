/**
 * run-build.mjs — orkestrator build produksi lintas-platform (Windows/Linux/macOS).
 * Dipanggil via `npm run build` (menggantikan rantai `next build && node scripts/prepare-standalone.mjs`).
 *
 * Mengapa script ini ada? Kasus nyata di Windows (tool builder pihak ketiga):
 *   "Build error occurred: Error: Failed to collect page data for /api/history/[id]"
 * Penyebab paling umum BUKAN bug kode, melainkan lingkungan build:
 *   (1) worker build Next.js kehabisan memori di mesin RAM kecil;
 *   (2) antivirus (Windows Defender) mengunci/berkas .next yang baru ditulis;
 *   (3) Prisma Client belum ter-generate di node_modules baru.
 * Script ini menanganan ketiganya:
 *   - Heap Node dinaikkan (NODE_OPTIONS=--max-old-space-size=4096) sebelum next build;
 *   - Output build lengkap MIRRORED ke build.log di akar proyek (log tool builder sering terpotong);
 *   - Bila pola "Failed to collect page data" terdeteksi → diagnosis bahasa Indonesia
 *     + SATU kali percobaan ulang otomatis dgn mode hemat RAM (experimental.cpus=1);
 *   - Prisma Client diverifikasi lebih dulu oleh scripts/ensure-build-env.mjs (auto generate).
 *
 * Urutan: ensure-build-env (.env + prisma db push + verifikasi client) → next build → prepare-standalone.
 * `postbuild` (packaging EXE) tetap berjalan otomatis via hook npm.
 */
import { spawn } from 'node:child_process'
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { createRequire } from 'node:module'

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const LOG_PATH = path.join(root, 'build.log')

// ---------------------------------------------------------------- output + log
const chunks = []
function mirror(chunk) {
  process.stdout.write(chunk)
  chunks.push(typeof chunk === 'string' ? chunk : chunk.toString())
}
function mirrorErr(chunk) {
  process.stderr.write(chunk)
  chunks.push(typeof chunk === 'string' ? chunk : chunk.toString())
}
function log(line = '') {
  console.log(line)
  chunks.push(line + '\n')
}
function writeLog(header) {
  try {
    fs.writeFileSync(LOG_PATH, header + chunks.join(''), 'utf8')
  } catch {
    /* log gagal ditulis tidak boleh menggagalkan build */
  }
}

// ------------------------------------------------------------- 0) guard folder
if (!fs.existsSync(path.join(root, 'package.json'))) {
  console.error('[run-build] GAGAL: package.json tidak ditemukan di: ' + root)
  console.error('  Jalankan `npm run build` dari folder proyek yang LANGSUNG berisi package.json.')
  process.exit(1)
}

// ------------------------------------------------------------- 1) guard Node
// Next.js 16 mensyaratkan Node >= 20.9 — cegah kegagalan samar di Node tua.
const [maj, min] = process.versions.node.split('.').map(Number)
if (maj < 20 || (maj === 20 && (min || 0) < 9)) {
  console.error(`[run-build] GAGAL: Node.js ${process.versions.node} terlalu tua untuk Next.js 16.`)
  console.error('  Install Node.js LTS (20.9 atau lebih baru) dari https://nodejs.org,')
  console.error('  lalu buka jendela CMD baru dan jalankan ulang `npm run build`.')
  process.exit(1)
}
log(`[run-build] Node ${process.versions.node} — OK`)
log(`[run-build] Folder proyek: ${root}`)

// ------------------------------------------------------------- 2) heap memory
// Worker build default bisa kehabisan memori di mesin dgn RAM kecil → gagal "collect page data".
if (!/max-old-space-size/.test(process.env.NODE_OPTIONS || '')) {
  process.env.NODE_OPTIONS = [process.env.NODE_OPTIONS, '--max-old-space-size=4096']
    .filter(Boolean)
    .join(' ')
  log('[run-build] NODE_OPTIONS ditingkatkan: ' + process.env.NODE_OPTIONS)
}

const stamp = new Date().toISOString()
const header =
  `# build.log — BugHunter ID (dibuat otomatis oleh scripts/run-build.mjs)\n` +
  `# Waktu : ${stamp}\n# Node  : ${process.versions.node}\n` +
  `# CWD   : ${root}\n# NODE_OPTIONS: ${process.env.NODE_OPTIONS || ''}\n\n`

// ---------------------------------------------------------------- util langkah
function runStep(label, args, extraEnv = {}) {
  return new Promise((resolve) => {
    log(`\n[run-build] ${label} ...`)
    const child = spawn(process.execPath, args, {
      cwd: root,
      env: { ...process.env, ...extraEnv },
      stdio: ['ignore', 'pipe', 'pipe'],
      windowsHide: true,
    })
    child.stdout.on('data', mirror)
    child.stderr.on('data', mirrorErr)
    child.on('error', (err) => {
      mirrorErr(`[run-build] Gagal menjalankan proses: ${err.message}\n`)
      resolve(1)
    })
    child.on('exit', (code, signal) => resolve(code === null ? (signal ? 1 : 0) : code))
  })
}

function nextBinPath() {
  const require = createRequire(import.meta.url)
  return require.resolve('next/dist/bin/next')
}

// --------------------------------------------------- 3) prasyarat (.env/prisma)
const envCode = await runStep('[1/3] Prasyarat build (.env + sinkron DB + Prisma Client)', [
  path.join(root, 'scripts', 'ensure-build-env.mjs'),
])
if (envCode !== 0) {
  writeLog(header)
  console.error('\n[run-build] GAGAL di tahap prasyarat — lihat pesan di atas. Log: build.log')
  process.exit(envCode)
}

// ------------------------------------------------------------- 4) next build
const DIAG_PAGE_DATA = [
  '',
  '  ===============================================================',
  '  [DIAGNOSIS] Build terhenti di "collecting page data".',
  '  Ini bukan bug kode aplikasi — worker build di Windows kehilangan',
  '  memori atau terganggu antivirus (Windows Defender).',
  '  Solusi (urut dari paling mudah):',
  '   1. Jalankan ulang `npm run build` (otomatis dicoba ulang di bawah dgn mode hemat RAM).',
  '   2. Tambahkan folder proyek ini ke PENGECUALIAN Windows Defender:',
  '      Windows Security → Virus & threat protection → Manage settings →',
  '      Exclusions → Add folder → pilih folder proyek ini.',
  '   3. Tutup aplikasi lain (siapkan RAM kosong minimal 4 GB) lalu ulangi.',
  '   4. Bila masih gagal, kirim isi file build.log (folder proyek) untuk analisis.',
  '  ===============================================================',
  '',
].join('\n')

let buildCode = await runStep('[2/3] next build', [nextBinPath(), 'build'])
let output = chunks.join('')

// --- deteksi kegagalan khas Windows → percobaan ulang dgn worker tunggal
if (buildCode !== 0 && /Failed to collect page data/i.test(output)) {
  mirrorErr(DIAG_PAGE_DATA)
  log('[run-build] Mencoba ulang otomatis dgn mode hemat RAM (worker build = 1) ...')
  // buang output percobaan pertama agar log file tidak dobel
  chunks.length = 0
  chunks.push('--- percobaan pertama GAGAL (lihat diagnosis di layar), mencoba ulang ---\n')
  buildCode = await runStep('[2/3] next build (percobaan ulang, mode hemat RAM)', [
    nextBinPath(),
    'build',
  ], { BUGHUNTER_BUILD_CPUS: '1' })
  output = chunks.join('')
}

if (buildCode !== 0) {
  writeLog(header)
  if (!/Failed to collect page data/i.test(output)) {
    console.error('\n[run-build] Build GAGAL — periksa pesan error di atas.')
    console.error('Log lengkap tersimpan di: build.log (folder proyek).')
    console.error('Solusi umum: PANDUAN-BUILD.md bagian "Masalah Umum".')
  }
  process.exit(buildCode)
}
log('[run-build] next build SUKSES')

// --------------------------------------------------- 5) siapkan standalone+EXE
const prepCode = await runStep('[3/3] Persiapan standalone + seed database EXE', [
  path.join(root, 'scripts', 'prepare-standalone.mjs'),
])
writeLog(header)
if (prepCode !== 0) {
  console.error('\n[run-build] GAGAL di tahap prepare-standalone — lihat pesan di atas. Log: build.log')
  process.exit(prepCode)
}

log('')
log('[run-build] SELESAI — lanjut otomatis ke packaging EXE (postbuild, di Windows).')
