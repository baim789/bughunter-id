/**
 * start-server.mjs — `npm run start` lintas-platform (Windows CMD / Linux / macOS).
 * Menjalankan server produksi Next.js standalone (hasil `npm run build`).
 *
 * - Mengambil DATABASE_URL dari .env (server standalone TIDAK memuat .env sendiri).
 * - Default mendengarkan di 0.0.0.0:3000 agar HP di Wi-Fi yang sama (mode APK) bisa mengakses.
 * - Log server ditulis ke server.log (pengganti `tee` khas Unix).
 */
import fs from 'node:fs'
import path from 'node:path'
import { spawn } from 'node:child_process'
import { fileURLToPath } from 'node:url'

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const serverJs = path.join(root, '.next', 'standalone', 'server.js')

if (!fs.existsSync(serverJs)) {
  console.error(
    '[start] GAGAL: .next/standalone/server.js tidak ditemukan.\n' +
      '  Jalankan "npm run build" terlebih dahulu untuk membangun aplikasi.'
  )
  process.exit(1)
}

/** Baca DATABASE_URL dari .env; path relatif `file:./x.db` dinormalisasi ke absolut (akar proyek). */
function readEnvDbUrl() {
  const envPath = path.join(root, '.env')
  if (!fs.existsSync(envPath)) return null
  const m = fs.readFileSync(envPath, 'utf8').match(/^\s*DATABASE_URL\s*=\s*(.+?)\s*$/m)
  if (!m) return null
  const v = m[1].trim().replace(/^["']|["']$/g, '')
  const f = v.match(/^file:(.+)$/)
  if (!f) return v
  let p = f[1]
  const isAbs = /^[a-zA-Z]:[\\/]/.test(p) || p.startsWith('/')
  if (!isAbs) p = path.resolve(root, p.replace(/^\.?[\\/]/, ''))
  return 'file:' + p.split(path.sep).join('/')
}

const port = process.env.PORT || '3000'
const host = process.env.HOSTNAME_OVERRIDE || '0.0.0.0'
const env = {
  ...process.env,
  NODE_ENV: 'production',
  PORT: port,
  HOSTNAME: host,
  NEXT_TELEMETRY_DISABLED: '1',
}
const dbUrl = readEnvDbUrl()
if (dbUrl) env.DATABASE_URL = dbUrl
else console.warn('[start] PERINGATAN: DATABASE_URL tidak ditemukan di .env — fitur basis data bisa gagal')

const logPath = path.join(root, 'server.log')
const log = fs.createWriteStream(logPath, { flags: 'a' })
console.log(`[start] BugHunter ID berjalan di http://localhost:${port}  (hentikan: Ctrl+C)`)
console.log(`[start] Log server → ${logPath}`)

const child = spawn(process.execPath, [serverJs], {
  cwd: path.dirname(serverJs),
  env,
  stdio: ['ignore', 'pipe', 'pipe'],
})
child.stdout.on('data', (d) => {
  process.stdout.write(d)
  log.write(d)
})
child.stderr.on('data', (d) => {
  process.stderr.write(d)
  log.write(d)
})
child.on('exit', (code) => {
  log.end()
  console.log(`[start] Server berhenti (kode ${code ?? 0})`)
  process.exit(code ?? 0)
})
for (const sig of ['SIGINT', 'SIGTERM']) {
  process.on(sig, () => {
    try {
      child.kill()
    } catch {}
  })
}
