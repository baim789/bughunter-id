# PANDUAN BUILD — BugHunter ID (EXE Windows & APK Android)

> Versi dokumen: **v0.12.3** — sejak v0.12.0 seluruh script build **lintas-platform** (aman dijalankan
> dari Windows CMD maupun Git Bash), dan `npm run build` di Windows **otomatis menghasilkan file EXE**.
> Sejak **v0.12.1**, isi ZIP berada langsung di akar arsip — hasil "Extract All" sudah berupa folder
> proyek yang siap dipilih oleh tool builder (ada `package.json` di tingkat atasnya).
> Sejak **v0.12.2**, build jauh lebih tahan banting di Windows: heap memori dinaikkan otomatis,
> log lengkap build tersimpan ke `build.log`, Prisma Client diverifikasi + di-generate otomatis,
> dan kegagalan "Failed to collect page data" otomatis dicoba ulang dengan mode hemat RAM.

---

## 0. Cara ekstrak ZIP yang benar

1. Unduh `bughunter-id-source.zip`, klik kanan → **Extract All…** → ekstrak.
2. Buka folder hasil ekstrak — pastikan Anda **langsung melihat `package.json`, `src`, `electron`,
   `BUILD-EXE.bat`, `PANDUAN-BUILD.md`** di dalamnya (bukan subfolder lagi).
3. **Folder itulah** yang dipilih di tool `BUILDER APK-EXE.txt` (mode EXE maupun APK).

> Gejala salah pilih folder: `npm error ENOENT … Could not read package.json` — artinya folder yang
> dipilih satu tingkat di atas folder proyek. Pilih folder yang berisi `package.json`.

---

## 1. Ringkasan

| Mode | Yang dihasilkan | Kebutuhan |
|------|-----------------|-----------|
| **EXE** | `dist-exe/BugHunterID-Portable-<versi>.exe` (tanpa instalasi) + `BugHunterID-Setup-<versi>.exe` (installer) | Windows + Node.js LTS + internet (unduhan pertama) |
| **APK** | Proyek Android siap build (dibuka di Android Studio) | Android Studio + Node.js LTS |

Kedua mode **sudah selaras dengan tool `BUILDER APK-EXE.txt`** Anda:
- Mode **EXE** pada tool tersebut menjalankan `npm install` → `npm run build` — di proyek ini, itu sudah cukup untuk menghasilkan EXE (packaging terjadi otomatis di tahap `postbuild`).
- Mode **APK** menjalankan `npx cap add android` → `npx cap sync android` → `node siapkan-android.js` → `npx cap open android` — semua file yang dibutuhkan (`capacitor.config.json`, `siapkan-android.js`, folder `out/`) sudah disediakan.

---

## 2. Prasyarat

1. **Node.js versi LTS** (unduh di <https://nodejs.org>) — cek dengan `node -v` (butuh ≥ 20).
2. Koneksi internet saat `npm install` pertama kali:
   - Electron (~110 MB) diunduh ke cache npm,
   - komponen NSIS/portable electron-builder (~20 MB) diunduh ke `%LOCALAPPDATA%\electron-builder\Cache`.
3. Untuk **APK**: Android Studio (dengan SDK Android) — <https://developer.android.com/studio>.

---

## 3. Build EXE (Windows)

### Cara 1 — lewat tool `BUILDER APK-EXE.txt` Anda (tanpa perubahan)
1. Jalankan tool, pilih menu **[1] Build EXE**.
2. Pilih folder proyek BugHunter ID (folder yang berisi `package.json`).
3. Tool menjalankan `npm install` + `npm run build` → di akhir build, packaging EXE berjalan otomatis.
4. Buka folder `dist-exe\` di dalam proyek → EXE siap dipakai.

### Cara 2 — dobel-klik `BUILD-EXE.bat`
Batch pembantu di akar proyek: `npm install` → `npm run build` → membuka folder `dist-exe\`.

### Cara 3 — manual di CMD
```bat
cd /d "C:\jalur\ke\bughunter-id"
npm install
npm run build
```

### Hasil build
| File | Keterangan |
|------|-----------|
| `dist-exe\BugHunterID-Portable-0.12.0.exe` | **Portabel** — satu file, klik 2× langsung jalan, tanpa instalasi. Saat dijalankan diekstrak ke folder sementara (mulai agak lambat 2–5 detik). |
| `dist-exe\BugHunterID-Setup-0.12.0.exe` | **Installer** — pasang seperti aplikasi Windows biasa (ada di Start Menu, uninstal lewat Control Panel). |

### Saat pertama dijalankan
- Aplikasi menyalakan server lokal di port bebas (mulai 3777) lalu membuka jendela aplikasi. Tidak ada
  jendela CMD yang perlu dibuka — semuanya otomatis.
- **Basis data** disalin ke `%APPDATA%\BugHunterID\bughunter-id.db` (riwayat scan tersimpan permanen di
  sana, tidak terpengaruh update EXE). Untuk reset total: hapus file tersebut, lalu buka ulang aplikasi.
- **Log server** (untuk diagnosis): `%APPDATA%\BugHunterID\server.log`.
- **Windows SmartScreen**: karena EXE tidak ditandatangani digital, Windows menampilkan peringatan
  "Windows protected your PC" → klik **More info** → **Run anyway**. Peringatan ini normal untuk
  aplikasi open-source tanpa sertifikat kode berbayar.

---

## 4. Build APK (Android)

> **Konsep penting**: APK BugHunter ID adalah *shell* (jendela) yang memuat aplikasi dari **server di PC**.
> Seluruh mesin (deteksi rule-based, AI, basis data, perbaikan berpandu) tetap berjalan di PC. Keuntungan:
> ukuran APK kecil dan tidak ada duplikasi mesin; syaratnya PC dan HP satu jaringan Wi-Fi.

### Langkah
1. Jalankan tool `BUILDER APK-EXE.txt` → **[2] Build APK** → pilih folder proyek
   (atau dobel-klik `BUILD-APK.bat`).
2. Android Studio terbuka otomatis → tekan **Run (Shift+F10)** → APK terpasang di HP/emulator.
3. **Di PC**, jalankan server:
   ```bat
   npm run start
   ```
   Server mendengarkan di `0.0.0.0:3000` (bisa diakses HP). Izinkan akses bila Windows Firewall bertanya
   (centang **Private networks**).
4. **Di HP**, buka aplikasi **BugHunter ID** — langsung tersambung ke PC.

### File kunci mode APK
| File | Peran |
|------|-------|
| `capacitor.config.json` | Identitas aplikasi + `server.url` yang ditulis otomatis oleh `siapkan-android.js` |
| `siapkan-android.js` | Mendeteksi IP LAN PC → menulis `server.url`, memastikan izin `INTERNET` + `usesCleartextTraffic`, menjalankan `npx cap copy android` |
| `out/index.html` | Halaman cadangan bila server PC tidak terjangkau (menampilkan instruksi) |

### Khusus emulator
Emulator Android memakai alamat khusus untuk PC host:
```bat
set BUGHUNTER_APK_HOST=10.0.2.2
node siapkan-android.js
```

### Mengganti IP / port
`siapkan-android.js` mendeteksi IP LAN otomatis. Bila ingin memaksa:
```bat
set BUGHUNTER_APK_HOST=192.168.1.50
set BUGHUNTER_PORT=3000
node siapkan-android.js
```

---

## 5. Struktur file build (baru di v0.12.0)

```
├─ BUILD-EXE.bat            ← dobel-klik: build + packaging EXE (Windows)
├─ BUILD-APK.bat            ← dobel-klik: alur lengkap APK (Windows + Android Studio)
├─ siapkan-android.js       ← dipanggil tool builder Anda (alur APK)
├─ capacitor.config.json    ← konfigurasi Capacitor (diperbarui otomatis oleh siapkan-android.js)
├─ out/index.html           ← webDir cadangan agar `cap sync` tidak pernah gagal
├─ electron/
│  └─ main.cjs              ← proses utama EXE: nyalakan server → buka jendela
├─ electron-builder.yml     ← resep packaging EXE (portable + NSIS installer)
├─ build/icon.png           ← ikon aplikasi (dari logo.svg, 512×512)
└─ scripts/
   ├─ run-build.mjs          ← orkestrator `npm run build`: prasyarat → next build → standalone
   │                           (heap 4 GB, log → build.log, retry otomatis dgn mode hemat RAM)
   ├─ ensure-build-env.mjs   ← prasyarat build: .env + prisma db push + verifikasi Prisma Client
   ├─ prepare-standalone.mjs← pasca `next build`: merge static/public + seed.db (pengganti `cp -r` Unix)
   ├─ package-exe.mjs       ← (postbuild) jalankan electron-builder --win di Windows
   ├─ start-server.mjs      ← `npm run start` lintas-platform (0.0.0.0:3000, log → server.log)
   └─ make-icon.mjs         ← pembuat build/icon.png dari logo.svg
```

### Alur `npm run build` (semua otomatis)
```
npm install          → postinstall: prisma generate (klien DB)
npm run build        → run-build.mjs:
                       → ensure-build-env (.env + prisma db push + cek Prisma Client)
                       → next build (output standalone, heap 4 GB, log → build.log;
                         gagal "collect page data" → retry otomatis dgn worker 1)
                     → prepare-standalone (static + public + seed.db)
                     → postbuild: package-exe → electron-builder --win (Windows saja)
hasil                → dist-exe\BugHunterID-Portable-*.exe + BugHunterID-Setup-*.exe
```

### Arsitektur EXE
```
┌────────────────────── BugHunterID.exe (Electron) ─────────────────────┐
│  Jendela aplikasi (BrowserWindow)                                     │
│      ↑ memuat http://127.0.0.1:<port>                                 │
│  Proses server: node .next/standalone/server.js                       │
│      (biner Electron dipakai sbg Node — ELECTRON_RUN_AS_NODE=1)       │
│      ↑ DATABASE_URL → %APPDATA%\BugHunterID\bughunter-id.db           │
└───────────────────────────────────────────────────────────────────────┘
```
Port dipilih otomatis (mulai 3777) sehingga tidak pernah bentrok dengan aplikasi lain.

---

## 6. Masalah Umum

| Gejala | Penyebab & solusi |
|--------|-------------------|
| `npm error ENOENT … Could not read package.json` | Folder yang dipilih di tool builder **satu tingkat terlalu tinggi**. Pilih folder hasil ekstrak yang **langsung berisi `package.json`** (lihat bagian 0 di atas). |
| `cp` bukan perintah internal... saat `npm run build` | Terjadi di versi **lama**. v0.12.0 sudah memakai script Node lintas-platform — pastikan Anda memakai source terbaru. |
| `Build error occurred: Failed to collect page data for /api/...` | **Bukan bug kode** — worker build di Windows kehabisan memori atau terganggu antivirus. **v0.12.2 otomatis mencoba ulang dengan mode hemat RAM** — jalankan ulang `npm run build`. Bila tetap gagal: (1) tambahkan folder proyek ke pengecualian **Windows Defender**; (2) tutup aplikasi lain (siapkan RAM kosong ±4 GB); (3) pastikan Node 20.9+ (`node -v`); (4) sekarang log lengkap build tersimpan otomatis di **`build.log`** (folder proyek) — kirim isi bagian akhirnya bila meminta bantuan. |
| `node-gyp failed to rebuild … @parcel/watcher` (saat packaging EXE) | electron-builder versi lama mencoba **compile modul native** — butuh Visual Studio Build Tools + Python. **v0.12.3 sudah menonaktifkannya** (`npmRebuild: false`) karena tidak diperlukan (semua modul native memakai binari prebuilt N-API). Gunakan source v0.12.3+; log lengkap tersimpan di `package-exe.log`. |
| SmartScreen memblokir EXE | Klik **More info → Run anyway**. Normal untuk EXE tanpa tanda tangan digital. |
| `npm install` lambat/gagal mengunduh Electron | Jaringan ke GitHub terganggu. Coba mirror: `set ELECTRON_MIRROR=https://npmmirror.com/mirrors/electron/` lalu ulangi `npm install`. |
| `electron-builder` gagal mengunduh NSIS/winCodeSign | Jalankan ulang `npm run build` (cache sebagian terpakai). Bila masih gagal, set `set ELECTRON_BUILDER_BINARIES_MIRROR=https://npmmirror.com/mirrors/electron-builder-binaries/`. |
| Antivirus menandai EXE | False positive umum untuk EXE tak bertanda tangan. Tambahkan pengecualian, atau bangun ulang di mesin Anda sendiri dari source. |
| Jendela aplikasi tidak muncul | Buka `%APPDATA%\BugHunterID\server.log` — lihat baris `===` terakhir. Penyebab umum: antivirus memblokir proses anak. |
| Fitur riwayat/tren kosong di EXE | Basis data baru dibuat dijalakan pertama. Reset lama: hapus `%APPDATA%\BugHunterID\bughunter-id.db`. |
| HP tidak bisa membuka aplikasi (mode APK) | (1) `npm run start` belum jalan di PC; (2) HP & PC beda jaringan; (3) Firewall Windows memblokir Node — izinkan untuk jaringan privat; (4) IP berubah — jalankan ulang `node siapkan-android.js` lalu `npx cap copy android`. |
| Port 3000 dipakai aplikasi lain (mode APK) | Jalankan `set PORT=3001 && npm run start`, lalu `set BUGHUNTER_PORT=3001 && node siapkan-android.js` dan `npx cap copy android`. |
| `npx cap sync android` gagal "web assets directory not found" | Folder `out/` hilang. Buat ulang: ada di repositori (`out/index.html`) — jangan dihapus. |

---

## 7. Catatan lain

- **Fitur AI** (analisis GLM, chat agen) memerlukan kredensial lingkungan sandbox; di EXE/APK mode,
  seluruh fitur inti — deteksi 60+ aturan, analisis lintas berkas, perbaikan berpandu, ekspor SARIF/JSON/PDF,
  tren kesehatan — **berjalan 100% lokal tanpa AI**.
- **Dev mode** (di lingkungan sandbox) tetap seperti biasa: `bun run dev` di port 3000.
  Di Windows, untuk mencoba hasil build tanpa EXE: `npm run start` lalu buka `http://localhost:3000`.
- `package-lock.json` disertakan agar `npm install` di mesin Anda memasang **versi dependensi yang sama
  persis** dengan yang diuji (Node.js ≥ 20 disarankan).
