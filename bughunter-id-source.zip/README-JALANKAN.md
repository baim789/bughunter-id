# BugHunter ID — Cara Menjalankan di Komputer Anda

Aplikasi web pendeteksi bug source code multi-bahasa (JavaScript/TypeScript, Python, Java, PHP, Go) dengan mesin deteksi 60+ aturan **plus analisis aliran data (taint)**, **auto-fix aman dengan undo**, workspace multi-file dengan **analisis lintas file untuk kelima bahasa**, **pemindaian dependensi CVE**, **impor repositori GitHub**, **ekspor SARIF/JSON untuk CI/CD**, **workflow GitHub Actions siap unduh**, **validasi import Java & arity dua arah**, **deteksi kredensial per-segmen**, **pemindaian berkas besar yang linier & cepat**,  **log terminal real-time**, **akun pengguna**, **tren kesehatan kode antar pemindaian**, **laporan PDF profesional**, editor kode, riwayat scan & statistik — plus **paket build desktop: EXE Windows (Electron) & APK Android (Capacitor)**.

## Fitur Baru v0.12

1. **Build EXE Windows otomatis** — `npm run build` di Windows kini menghasilkan **aplikasi desktop**: `dist-exe/BugHunterID-Portable-<versi>.exe` (klik 2× langsung jalan, tanpa instalasi) + `BugHunterID-Setup-<versi>.exe` (installer). Aplikasi menyalakan server lokal sendiri (port otomatis mulai 3777), membuka jendela aplikasi, basis data tersimpan permanen di `%APPDATA%\BugHunterID`, single-instance, log di `%APPDATA%\BugHunterID\server.log`. Selaras dengan tool `BUILDER APK-EXE.txt`: mode EXE tool itu (npm install + npm run build) sudah cukup untuk menghasilkan EXE. Batch pembantu `BUILD-EXE.bat` juga tersedia.
2. **Build APK Android (Capacitor 8)** — seluruh file yang dibutuhkan tool builder sudah disediakan: `capacitor.config.json`, `siapkan-android.js` (deteksi IP LAN PC otomatis → `server.url`, izin INTERNET + `usesCleartextTraffic`, lalu `npx cap copy android`), folder `out/` berisi halaman cadangan agar `npx cap sync` tidak pernah gagal, dan `BUILD-APK.bat`. APK adalah *shell* yang memuat aplikasi dari server PC (`npm run start` — kini lintas-platform, mendengarkan `0.0.0.0:3000` agar terjangkau HP satu Wi-Fi; emulator memakai `BUGHUNTER_APK_HOST=10.0.2.2`).
3. **Script build lintas-platform** — pengganti `cp -r`/`tee` khas Unix yang gagal di Windows CMD: `scripts/prepare-standalone.mjs` (merge static + public + seed.db), `prebuild` (`scripts/ensure-build-env.mjs` — membuat `.env` bila belum ada + `prisma db push` idempoten), `postbuild` (`scripts/package-exe.mjs` — packaging EXE di Windows, dilewati rapi di Linux/macOS), dan `npm run start` lintas-platform (`scripts/start-server.mjs`, log → `server.log`). `package-lock.json` disertakan (1.227 paket terkunci) agar `npm install` Anda mereplikasi versi dependensi yang persis diuji. `postinstall: prisma generate` menjamin klien DB terbentuk. Ikon aplikasi (`build/icon.png`, 512×512) dibuat dari logo.

**Panduan lengkap kedua mode (langkah, arsitektur, troubleshooting): lihat `PANDUAN-BUILD.md`.**


## Fitur Baru v0.11

1. **Kapasitas workspace naik 2,5×** — batas kini **200 berkas / 5 juta karakter** (sebelumnya 80 berkas / 2 juta). Proyek 200 berkas / 104 ribu baris / 4,4 MB dipindai ±0,7 detik. Gerbang payload (/api/workspace & agen) ikut dinaikkan ke 24 MB.
2. **Pemindaian paralel multi-thread (opsional, otomatis)** — pada proyek besar, analisis per-berkas (fase 1) dibagi ke beberapa worker thread CPU. Hasil deteksi dijamin identik dengan jalur serial (paritas sidik jari 12/12 payload identik byte-per-byte). Ambang aktivasi sadar-CPU: di mesin ≤2 core baru aktif untuk proyek ≥96 berkas & ≥1,2 juta karakter (di mesin ≥4 core: ≥32 berkas & ≥500 ribu) — di bawah ambang, scan serial yang sudah cepat dipakai tanpa biaya overhead. Kendali: env `BUGHUNTER_WORKERS=0` memaksa serial; deteksi jumlah core sadar-cgroup (Docker/K8s dengan kuota CPU tidak salah lagi membaca core host; env `BUGHUNTER_CPUS` untuk menimpa).
3. **Worker multi-runtime** — worker dikemas sebagai bundle JS murni (`src/lib/detector/scan-worker.bundle.mjs`, dibangun via `npm run worker:build`) sehingga paralel jalan di Node maupun Bun; bila bundle basi/tak ada, otomatis fallback serial tanpa gagal.
4. **Batas CI & impor diselaraskan** — template GitHub Actions dan impor GitHub memakai batas yang sama dengan aplikasi (200 berkas / 5 juta karakter).

## Fitur Baru v0.10

1. **Berkas besar kini dipindai lebih cepat hingga 66x** — tiga pemeriksa cerdas JavaScript (variabel tak terpakai, penugasan ulang `const`, jumlah argumen pemanggilan) semula memindai ulang seluruh berkas untuk SETIAP simbol (O(simbol x ukuran) ≈ kuadratik). Kini semuanya memakai **indeks identifier satu-pass** (O(ukuran) linier): berkas tunggal 190 KB turun dari ±5,3 detik menjadi ±80 ms, dan hasil deteksinya **identik byte-per-byte** (diverifikasi sidik jari 10 payload).
2. **Skala proyek penuh ikut terasa** — workspace 80 berkas / 1,76 MB dengan 38 ribu temuan turun dari ±7,9 detik menjadi ±0,8 detik. Pemindaian cache `export` antar lapisan dan masking sekali per berkas juga menghilangkan pekerjaan berulang pada proyek banyak-import.
3. **Tanpa perubahan perilaku** — aturan, severity, nomor baris, dan saran perbaikan persis sama seperti v0.9; seluruh 335 cek regresi (samples, guided, workspace, v2, security, v7, v8, agent, socket, probe) tetap hijau.

## Fitur Baru v0.9

1. **Deteksi kredensial jauh lebih luas** — nama variabel kini dianalisis **per segmen** (`DB_PASSWORD`, `dbPass`, `MY_API_KEY`, `passwordHash`, `authToken`, `user_token` semuanya dikenali), termasuk bentuk **PHP `define('DB_PASS', '...')`**. Nama yang kebetulan mengandung huruf kata kunci (`passed`, `tokenize`, `passwordless`, `bypass`) sengaja TIDAK ditandai — bebas false positive.
2. **Arity dua arah** — selain argumen berlebih, **argumen yang kekurangan** kini juga dideteksi lintas file: JavaScript (`ws-arity-few`, parameter hilang bernilai `undefined` diam-diam), Python (`ws-py-arity-few`, TypeError saat runtime — parameter ber-default dihitung opsional), dan Go (`ws-go-arity-few`, build gagal "not enough arguments"). Fungsi variadic (`...` di Go, `*args/**kwargs` di Python) otomatis dilewati agar tidak salah tanda.
3. **Validasi statement import Java** — `import com.perusahaan.Laporan;` kini diperiksa: paket milik proyek yang tidak punya class tersebut, berkas `Laporan.java` yang ternyata tidak mendeklarasikan class-nya, dan class yang hanya ada di paket default (tidak bisa diimpor eksplisit) — semuanya ditandai `ws-java-import-missing`. Import pustaka standar/eksternal (`java.*`, `javax.*`, dst.) tidak ikut diperiksa.
4. **PHP `require __DIR__ . '/x.php'` dikenali** — bentuk require/include yang paling umum di proyek PHP nyata (termasuk `dirname(__FILE__)`) kini diverifikasi keberadaan berkasnya; jalur berawalan `/` setelah `__DIR__` diperlakukan relatif dengan benar.

## Fitur Baru v0.8

1. **Integrasi CI/CD siap pakai** — menu unduhan workspace & perintah chat `workflow ci` kini menyediakan **file GitHub Actions siap pakai** (`bughunter-ci.yml`). Setiap push/PR di repositori Anda otomatis: mengumpulkan berkas kode (batas sama dengan aplikasi: 200 berkas / 5 juta karakter) → mengirim ke API BugHunter ID → mengunduh **SARIF 2.1.0** → mengunggahnya sebagai artefak & ke **GitHub Code Scanning**. Konfigurasi cukup satu secret `BUGHUNTER_URL`; opsional `BUGHUNTER_MAX_BUGS` agar job gagal bila temuan melewati batas.
2. **Tren kesehatan kode** — tombol **Tren** baru di header menampilkan grafik perkembangan **skor kesehatan vs jumlah temuan** dari riwayat pemindaian workspace (maks 40 titik terakhir) plus ringkasan: total pemindaian, skor terakhir dengan delta vs sebelumnya, rata-rata skor, dan temuan terakhir (lintas file & kritis). Saat masuk akun, tren hanya memakai pemindaian milik Anda; saat anonim, tren pemindaian anonim — terpisah dari data pengguna lain.

## Fitur Baru v0.7

1. **Analisis lintas file kelima bahasa** — Python kini memeriksa **argumen tak cocok lintas modul** (ws-py-arity) dan **pemanggilan fungsi tak terdefinisi di mana pun** (ws-py-undefined-call); Go memeriksa **import tak terpakai** (gagal build), **paket lokal yang tidak ada** (berdasar go.mod), dan **arity dalam & lintas paket**; PHP memeriksa **require/include ke berkas yang tidak ada** dan **deklarasi class duplikat**; Java memeriksa **class paket lain dipakai tanpa import** dan **class duplikat satu paket**. Semua temuan baru punya opsi perbaikan berpandu (hapus import, sisipkan import, buat stub, pangkas argumen, tambah parameter).
2. **Impor repositori GitHub** — ketik `impor github https://github.com/pemilik/repo` (boleh `/tree/branch`). Sistem mengunduh tarball publik, menyaring berkas teks (maks 200 berkas / 200 KB per berkas), melewati biner, lockfile & folder sampah, lalu mengisinya ke Workspace.
3. **Ekspor SARIF & JSON (CI/CD)** — ketik `ekspor sarif` untuk SARIF 2.1.0 (siap diunggah ke GitHub Code Scanning) atau `ekspor json` untuk dump terstruktur lengkap.
4. **Terminal real-time dari server** — progres pemindaian & auto-fix per berkas mengalir **langsung dari server** melalui socket.io (badge LIVE di header). Mini-service di `mini-services/agent-log/` (port 3003 socket + 3004 REST). Bila socket tidak tersambung, terminal otomatis memakai simulasi lokal (badge `lokal`) — seluruh fitur tetap bekerja.
5. **Akun pengguna** — tombol **Masuk** di header (email + sandi, hash scrypt). Sesi agen yang tersimpan menempel ke akun dan **tidak terlihat oleh pengguna lain**; tanpa masuk tetap bisa dipakai (sesi per browser).
6. **Pratinjau diff sebelum eksekusi** — setiap solusi berpandu kini ditampilkan dulu sebagai **diff per-berkas** (+/− hijau/merah) di chat. Tidak ada yang diubah sampai Anda klik "Setujui & eksekusi".
7. **Kapasitas proyek lebih besar** — batas workspace dinaikkan (saat ini **200 berkas / 5 juta karakter**) dengan progres per berkas ber-timing.

## Antarmuka Agen 3 Kolom (v0.5)

Mulai v0.5, tampilan aplikasi adalah workbench agen 3 kolom yang lebarnya bisa diperlebar/diperkecil sesuai kebutuhan (seret pegangan di antara kolom; posisi tersimpan otomatis):

1. **Kolom Chat** — Anda berperintah lewat teks ("pindai", "perbaiki", "unduh laporan pdf", "unduh zip", "contoh", "bantuan") atau mengunggah file (ikon klip / seret file & ZIP langsung ke panel chat). Sistem melaporkan setiap tahap pekerjaannya di chat, dan **setiap keputusan penting ditampilkan sebagai tombol opsi di dalam chat** — mis. "Perbaiki otomatis (N bug aman)" vs "Perbaiki bug lintas file (berpandu)" vs "Unduh laporan PDF". Opsi yang sudah dipilih terkunci.
2. **Kolom Workspace** — menerima semua file yang diunggah lewat chat; menampilkan ring skor kesehatan, badge jumlah temuan per berkas, pratinjau kode dengan **penanda baris bermasalah berwarna severity**, unduh per berkas, menu unduh **ZIP hasil kerja / ZIP asli / laporan PDF**.
3. **Kolom Terminal** — tempat sistem bekerja. **Jumlah terminal fleksibel mengikuti kompleksitas bug**: pemindaian membuka terminal `pemindai`, bug lintas file membuka **beberapa terminal paralel** (satu per berkas/solusi, mis. `fix:payment.js`, `guided:config.js`), dan setiap perbaikan ditutup terminal `verifikasi` yang memindai ulang. Tab terminal bisa ditutup/disaring.

Di layar sempit (<768px) ketiga kolom menjadi tab Chat / Workspace / Terminal.

## AI GLM di Kolom Chat & Riwayat Sesi (v0.6)

Dua kemampuan baru di workbench agen:

1. **Tanya jawab bebas dengan AI GLM** — tulis pertanyaan apa pun dalam bahasa sendiri (mis. "kenapa file config rawan bug?", "jelaskan temuan teratas", "bagaimana cara memperbaiki SQL injection di index.js?"). Agen meneruskan pertanyaan ke AI GLM **beserta konteksnya**: daftar file workspace, hasil pemindaian terakhir (skor + seluruh temuan), dan kutipan kode file yang Anda sebut namanya. Jawaban AI ditandai ikon ✨ GLM AI ungu, prosesnya tercatat di terminal `ai-glm`. Perintah cepat tetap berlaku: kata "pindai"/"perbaiki"/"unduh"/"contoh" tetap dieksekusi sebagai aksi, bukan pertanyaan. Bila layanan AI tidak tersedia, agen memberi tahu dengan sopan dan menawarkan perintah lokal (pemindaian & perbaikan tetap berjalan penuh tanpa AI).
2. **Riwayat sesi agen tersimpan otomatis** — setiap aksi penting (unggah file, pindai, perbaiki, jawaban AI) otomatis disimpan ke database (debounce ~1 detik, gagal senyap tanpa mengganggu). Saat halaman dibuka ulang, agen menawarkan di chat: **"Lanjutkan: <judul sesi>"** (badge RIWAYAT, berisi metadata file/temuan/skor) atau **"Mulai sesi baru"**. Melanjutkan memulihkan seluruh percakapan, semua file workspace, dan kondisi pemindaian terakhir — persis seperti ditinggalkan. Riwayat bisa juga diminta kapan saja lewat opsi yang muncul. Judul sesi diambil otomatis dari pesan Anda pertama. Batas penyimpanan mengikuti batas workspace (50 file, 200 KB/file, 1,2 MB total) plus batas pesan 600 KB.

Di belakang layar: endpoint `POST /api/agent/chat` (rate limit 10/menit, timeout, error disanitasi) dan endpoint sesi `POST /api/agent/session`, `GET /api/agent/sessions`, `GET`/`DELETE /api/agent/session/[id]` (validasi id, 404 vs 500, anti path traversal pada nama file).

## Kecerdasan Mesin (v0.3)

- **Analisis aliran data (taint analysis)**: variabel yang diisi dari input tidak terpercaya (`req.body/query/params`, `input()`, `sys.argv`, dll.) dilacak sampai tempat bahaya — SQL Injection, command/code injection (`eval`/`exec`), XSS (`innerHTML`). Query terparameter `db.query("... id = ?", [x])` otomatis dikenali sebagai aman — membedakan kode yang benar-benar berbahaya dari yang hanya sekilas mirip.
- **Cek cerdas in-file (JS/TS)**: variabel yang tidak pernah dipakai, penugasan ulang `const` (TypeError saat runtime), dan pemanggilan fungsi dengan jumlah argumen melebihi parameter deklarasinya.
- **Pengecualian baris**: tulis komentar `bughunter-ignore` di baris yang temuan ingin diabaikan, atau `bughunter-ignore-next-line` di baris sebelumnya.
- **Pengaturan aturan**: tombol "Aturan" di kanan atas — nonaktifkan aturan tertentu (mis. aturan gaya) per browser; pilihan ikut dipakai di kedua mode.

## Perbaikan Berpandu Lintas File (v0.4)

Temuan biru "LINTAS FILE" kini punya tombol **Perbaiki Berpandu** — klik, pilih salah satu solusi (bertanda AMAN / PERHATIAN), dan mesin mengeksekusi editnya secara deterministik lalu memindai ulang otomatis. Solusi yang tersedia:

- **Simbol tidak diekspor**: tambahkan `export` pada deklarasi di file tujuan, buat stub bertanda TODO, atau keluarkan simbol dari daftar import.
- **Import ke file yang tidak ada**: buat berkas stub lengkap dengan export yang diimpor, atau hapus baris import.
- **Import melingkar (JS & Python)**: putus satu sisi siklus dengan menghapus baris import (mesin memberi tanda AMAN bila simbolnya tidak dipakai).
- **Argumen pemanggilan tidak cocok**: pangkas argumen ekstra, atau perluas parameter fungsi tujuan (`arg3`, dst.).
- **Dead export**: lepas kata `export` tanpa menghapus kodenya.
- **Kredensial yang sama di banyak file**: ganti literal dengan `process.env.NAMA` / `os.environ["NAMA"]` (import `os` ditambahkan otomatis untuk Python). Tetap wajib rotasi kredensial lama.
- **Dependensi rentan (CVE)**: naikkan nomor versi di `package.json` / `requirements.txt` (operator rentang dipertahankan).

Setiap aksi divalidasi ulang terhadap isi file terkini — bila temuan sudah tidak ada (kode berubah), aksi ditolak dengan alasan yang jelas. Tombol "Kembalikan Kode Asli" tetap berlaku untuk perbaikan berpandu.

## Contoh Bug Bandel Siap Pakai (v0.4)

Di mode Workspace Multi-File tersedia tombol **Contoh Bug Bandel** dengan 3 proyek demo berisi bug lintas file yang dirancang pasti terdeteksi — cocok untuk mencoba analisis lintas file + perbaikan berpandu tanpa menyiapkan kode sendiri:

1. **Toko Online (JS) — 6 berkas**: siklus import, import file hilang, argumen tak cocok, kredensial bersama, SQL injection, dead export, CVE di `package.json`.
2. **Aplikasi Kasir (Python) — 4 berkas**: siklus import Python, simbol `from-import` tak ada, kredensial bersama, SQL injection dari request, CVE di `requirements.txt`.
3. **Blog CMS (JS) — 7 berkas**: import default tanpa export default, simbol tak diekspor, deklarasi global bentrok antar skrip, eval + XSS, CVE.

Di antarmuka v0.5 contoh-contoh ini bisa dimuat dari pesan sambutan di kolom Chat atau tombol di kolom Workspace saat kosong.

## Fitur Auto-Fix (Perbaiki Otomatis)

Bug yang terdeteksi bisa diperbaiki otomatis lewat tombol "Perbaiki" (per temuan) atau "Perbaiki Otomatis — Aman" (semua sekaligus). Prinsip keamanannya:

- **Hanya aturan terbukti aman** yang punya fixer: `==`→`===`, `var`→`let` (dengan verifikasi deklarasi ulang), hapus `debugger`, isi catch kosong dengan `console.error`, `except:`→`except Exception:`, `== None`→`is None`. Bug berbahaya (eval, secret, SQL concat, innerHTML, dll.) **tidak pernah** di-fix otomatis — hanya diberi saran.
- **Nomor baris tidak pernah bergeser** — perbaikan tidak menambah/menghapus baris.
- **Guard keamanan**: string literal tidak disentuh, kode yang berisiko error dilewati.
- **Undo kapan saja**: tombol "Kembalikan Kode Asli" memulihkan kode persis sebelum auto-fix (batal otomatis jika Anda mengedit manual).
- **Verifikasi otomatis**: setelah fix, kode langsung dipindai ulang agar terlihat skor kesehatan naik.

## Fitur Workspace Multi-File

Mode kedua di aplikasi (tombol **Workspace Multi-File** di bawah judul) untuk menguji proyek kecil yang terdiri dari banyak file sekaligus:

- **Masukkan file**: klik **Unggah ZIP** (struktur folder proyek terjaga — `src/`, `lib/`, dll.; berkas biner & sampah sistem seperti `__MACOSX`/`node_modules`/`.git` dilewati otomatis, folder akar umum dibuang), **Unggah File** (pilih banyak file sekaligus), atau "Tambah" + ketik nama file. Batas: 200 file, 200 ribu karakter/file, 5 juta karakter total, ZIP maksimal 6 MB.
- **Pindai Semua File**: setiap file diperiksa mesin 60+ aturan + taint, PLUS lapisan **analisis lintas file**:
  - import JS/TS ke simbol yang tidak ada di file tujuan (`import { x } from './utils'` padahal utils tidak mengekspor `x`) — tinggi;
  - import relatif ke file yang tidak ikut diunggah — sedang (resolusi sadar-folder: `../lib/x` ikut diikuti);
  - Python `from modul import simbol` yang tidak didefinisikan di modul — tinggi;
  - deklarasi global duplikat antar file skrip (saling menimpa) — sedang;
  - kredensial bernilai sama yang dipakai di beberapa file — tinggi;
  - **import melingkar** (a → b → a) yang membuat variabel undefined saat startup — sedang;
  - **export tak terpakai** (kode mati lintas file) — rendah;
  - **panggilan fungsi lintas file dengan jumlah argumen salah** — sedang;
  - **dependensi rentan**: `package.json` & `requirements.txt` diperiksa terhadap basis CVE lokal (lodash, axios, django, flask, pyyaml, dll.) lengkap dengan versi perbaikan — tinggi/kritis.
- **Perbaiki Semua (Aman)**: menerapkan semua auto-fix terbukti aman pada SETIAP file sekaligus, lalu memindai ulang. Temuan lintas file sengaja tidak diubah otomatis (menambah export/mengubah path adalah keputusan desain) — selalu disertai saran konkret.
- **Unduh ZIP**: "Unduh ZIP Hasil Perbaikan" (kode hasil fix + LAPORAN-PERBAIKAN.txt) atau "ZIP Asli" (sebelum perbaikan). Arsip dibuka normal di Windows Explorer/unzip.
- **Unduh Laporan PDF**: laporan profesional siap lampir (ringkasan skor, temuan per berkas dengan saran, daftar berkas bersih) — tersedia juga di mode Editor Tunggal (tombol PDF).
- **Muat ulang dari riwayat**: item riwayat bertanda Workspace yang masih menyimpan kode punya tombol **Muat** biru — file dikembalikan utuh ke workspace untuk dianalisis/diperbaiki lagi. (Workspace yang total kodenya melebihi ±256 ribu karakter tidak menyimpan kode, sehingga tombol Muat tidak muncul.)

---

## 1. Prasyarat (wajib dipasang dulu)

| Software | Versi | Cara cek | Unduh |
|----------|-------|----------|-------|
| **Node.js** | 20 atau lebih baru | buka terminal, ketik `node -v` | https://nodejs.org (pilih versi LTS) |

> Node.js sudah mencakup `npm`, jadi tidak perlu instal tambahan lain.
> Pengguna Visual Studio Code disarankan juga membuka terminal bawaan (menu Terminal → New Terminal).

## 2. Ekstrak & Masuk Folder Proyek

1. Ekstrak file ZIP ini ke folder mana saja, misalnya `D:\Proyek\bughunter-id`.
2. Buka terminal / command prompt, lalu masuk ke folder hasil ekstrak:

```bash
cd bughunter-id
```

## 3. Pasang Dependensi + Siapkan Database

```bash
npm install
```

Perintah ini akan:
- mengunduh semua library (Butuh koneksi internet, sekitar 2–5 menit),
- otomatis men-generate Prisma Client (`postinstall`).

Lalu siapkan database SQLite (file `db/custom.db` sudah disertakan beserta data demo; perintah ini memastikan strukturnya sinkron — file `.env` yang menunjuk ke database tersebut sudah ikut disertakan di paket):

```bash
npm run db:push
```

## 4. Jalankan Aplikasi

```bash
npm run dev
```

Buka browser dan akses:

```
http://localhost:3000
```

Selesai! Aplikasi berjalan dalam mode pengembangan (hot-reload aktif).
Tekan `Ctrl + C` di terminal untuk menghentikan.

## 5. (Opsional) Mode Produksi — Lebih Cepat & Stabil

```bash
npm run build
npm start
```

Lalu akses tetap di `http://localhost:3000`.

---

## Pertanyaan Umum

### Apakah fitur "Analisis AI" jalan di komputer saya?

- **Deteksi rule-based (utama): YA, 100% offline.** 60+ aturan untuk 5 bahasa, termasuk deteksi multi-baris (switch fallthrough, empty catch, except-pass, defer-in-loop) dan eskalasi severity (mis. `eval`/`exec` + input pengguna → kritis). Tidak butuh internet.
- **Toggle "Analisis AI":** memakai SDK Z.ai yang memerlukan kredensial platform. Di komputer lokal tanpa kredensial, tombol AI akan otomatis gagal dan aplikasi **fallback mulus** ke hasil rule-based — aplikasi tidak error, hanya analisis AI yang dilewati. Jadi aplikasi tetap berfungsi penuh tanpa API key.

### Port 3000 sudah dipakai aplikasi lain?

Jalankan di port lain, misalnya 4000:

```bash
npx next dev -p 4000
```

### Ingin menghapus data riwayat demo?

Buka aplikasi → panel **Riwayat** → klik ikon tempat sampah pada item, atau hapus file `db/custom.db` lalu jalankan ulang `npm run db:push`.

### Windows: `npm install` gagal / error permission?

- Jalankan terminal **sebagai Administrator**, atau
- Pastikan folder tidak berada di dalam OneDrive/lokasi tersinkron yang mengunci file, atau
- Hapus folder `node_modules` dan file `package-lock.json`, lalu ulangi `npm install`.

### macOS / Linux: error permission saat install?

Gunakan nvm agar tidak perlu sudo: https://github.com/nvm-sh/nvm — `nvm install --lts` lalu ulangi langkah 3.

### Pesan "Terlalu banyak permintaan" (429)?

Endpoint `/api/analyze` dibatasi 30 permintaan/menit dan `/api/autofix` 60 permintaan/menit per IP — pelindung bawaan dari audit keamanan. Untuk menaikkan batas, set variabel env di `.env` (mis. `RATE_LIMIT_ANALYZE_PER_MIN=100`) lalu restart.

---

## Struktur Proyek Penting

```
bughunter-id/
├── db/custom.db                  # Database SQLite (riwayat scan)
├── prisma/schema.prisma          # Skema database (model Scan)
├── src/lib/detector/rules.ts     # 60+ aturan deteksi bug (5 bahasa)
├── src/lib/detector/index.ts     # Mesin deteksi: auto-detect bahasa, skor kesehatan
├── src/lib/samples.ts            # Contoh kode bermasalah per bahasa
├── src/app/api/analyze/          # API analisis (rule-based + opsional AI)
├── src/app/api/history/          # API riwayat scan
├── src/app/api/stats/            # API statistik
└── src/components/bug-detector/  # UI: editor kode, panel hasil, riwayat/statistik
```

## Teknologi

Next.js 16 · React 19 · TypeScript · Tailwind CSS 4 · shadcn/ui · Prisma + SQLite · Framer Motion · z-ai-web-dev-sdk (opsional, untuk AI)
