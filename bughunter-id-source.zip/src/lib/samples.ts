export const SAMPLE_CODE: Record<string, string> = {
  javascript: `// Sistem manajemen pengguna sederhana
var API_KEY = "sk-prod-9912aabbccddeeff";

function getUserData(userId) {
  if (userId = null) {
    return;
  }
  var config = eval("({" + userId + "})");
  console.log("Mengambil data untuk: " + userId);
  document.getElementById("output").innerHTML = userId;

  switch (userId) {
    case "admin":
      console.log("Mode admin aktif");
    case "user":
      return fetch("/api/user/" + userId);
    default:
      return null;
  }
}

setTimeout("refreshDashboard()", 3000);

function loadProfile(raw) {
  try {
    var data = JSON.parse(raw);
    for (var key in data) {
      if (data[key] == "admin") {
        debugger;
      }
    }
    return data;
  } catch (err) {}
  return parseInt(raw);
}

getUserData("admin");
`,

  python: `import os
import pickle
import random
import hashlib

def load_config(path, cache={}):
    settings = eval(open(path).read())
    try:
        with open(path, 'rb') as f:
            return pickle.loads(f.read())
    except:
        pass
    cache[path] = settings
    return settings

password = "supersecret123"
db_host = "192.168.1.100"

def find_user(name):
    query = "SELECT * FROM users WHERE name = '%s'" % name
    cursor.execute(query)
    return cursor.fetchone()

def make_token(user_id):
    token = random.randint(100000, 999999)
    hashed = hashlib.md5(str(user_id).encode()).hexdigest()
    return token, hashed

def run_backup(target):
    os.system("tar -czf backup.tgz " + target)
    result = None
    if result == None:
        print("hasil kosong")
    list = [1, 2, 3]

def read_file(path):
    f = open(path)
    content = f.read()
    return content
`,

  java: `import java.util.*;
import java.sql.*;

public class UserController {
    public static String ADMIN_PASSWORD = "admin12345";
    public static List<String> activeSessions = new ArrayList<>();

    public boolean authenticate(String input) {
        if (input == ADMIN_PASSWORD) {
            System.out.println("Login berhasil untuk admin");
            return true;
        }
        return false;
    }

    public void connectDatabase(String userId) {
        String query = "SELECT * FROM users WHERE id = " + userId;
        try {
            Statement st = connection.createStatement();
            ResultSet rs = st.executeQuery(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String hashPassword(String password) throws Exception {
        MessageDigest md = MessageDigest.getInstance("MD5");
        md.update(password.getBytes());
        return new String(md.digest());
    }

    public void runCleanupJob() {
        Thread worker = new Thread();
        worker.run();
        Runtime.getRuntime().exec("rm -rf /tmp/cache " + userInput);
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {}
    }
}
`,

  php: `<?php
// Panel login legacy
$password = "admin_secret_99";
$hash = md5($password);

$id = $_GET['id'];
$query = "SELECT * FROM users WHERE id = " . $id;
$result = mysql_query($query);
$user = mysql_fetch_assoc($result);

echo $_POST['username'];
eval($_POST['action']);
extract($_REQUEST);

if ($user == "admin") {
    include($page . ".php");
    setcookie("token", mt_rand(), time() + 3600);
}

@file_get_contents($callback_url);
$content = split(",", $raw_data);
while (true) {
    if ($done) {
        die("selesai");
    }
}
?>
`,

  go: `package main

import (
        "database/sql"
        "fmt"
        "math/rand"
        "os/exec"
        "time"
)

func handler(userInput string) {
        query := "SELECT * FROM users WHERE name = '" + userInput + "'"
        fmt.Println(query)

        cmd := exec.Command("sh", "-c", userInput)
        out, _ := cmd.Output()
        fmt.Println(string(out))

        for i := 0; i < 5; i++ {
                defer fmt.Println("cleanup", i)
        }

        var token int
        token = rand.Int()
        fmt.Println("token:", token)

        mu.Lock()
        if userInput != "" {
                process(userInput)
        }
        mu.Unlock()

        time.Sleep(3 * time.Second)
}

func process(data interface{}) {
        if len(data) == 0 {
                panic("data kosong")
        }
}
`,
}

/* ============================================================
 *  CONTOH WORKSPACE "BUG BANDEL" — untuk uji cepat fitur
 *  analisis lintas file + perbaikan berpandu. Semua temuan
 *  dirancang deterministik (terjadi pasti saat dipindai).
 * ============================================================ */

export interface WorkspaceSample {
  label: string
  description: string
  files: { name: string; code: string }[]
}

export const WORKSPACE_SAMPLES: Record<string, WorkspaceSample> = {
  tokoOnlineJs: {
    label: 'Toko Online (JS) — 6 berkas',
    description:
      'Siklus import, import file hilang, simbol tak diekspor, argumen tak cocok, kredensial bersama, SQL injection, dead export, + CVE di package.json.',
    files: [
      {
        name: 'index.js',
        code: `// Titik masuk aplikasi toko online
import { hitungPajak } from './cart.js'
import { prosesBayar } from './payment.js'
import { prosesPesanan } from './config.js'

const nama = req.body.nama
const sql = "SELECT * FROM pesanan WHERE nama = '" + nama + "'"
db.query(sql)

const total = hitungPajak(100000, 0.1, "INV-2024")
console.log("total:", total)
prosesBayar(total)
prosesPesanan("pesanan-1")
`,
      },
      {
        name: 'config.js',
        code: `// Konfigurasi global
import { hitungPajak } from './cart.js'
import { formatRupiah } from './utils/format.js'

const API_KEY = "sk-live-77aa22bbcc99dd"

export function prosesPesanan(id) {
  console.log("memproses", id)
  return hitungPajak(1000, 0.1)
}
`,
      },
      {
        name: 'cart.js',
        code: `// Keranjang belanja
import { prosesPesanan } from './config.js'
import { hitungDiskon } from './diskon.js'

export function hitungPajak(subtotal, rate) {
  return subtotal * rate
}

export function addItem(cart, item) {
  cart.push(item)
  return cart
}
`,
      },
      {
        name: 'diskon.js',
        code: `// Utilitas diskon
export function hitungDiskon(jumlah, persen) {
  var sisa = jumlah * (1 - persen / 100)
  return sisa
}
`,
      },
      {
        name: 'payment.js',
        code: `// Modul pembayaran
const API_KEY = "sk-live-77aa22bbcc99dd"

export function prosesBayar(jumlah) {
  return { ok: true, jumlah }
}

export function refundInfo(id) {
  return "refund " + id
}
`,
      },
      {
        name: 'package.json',
        code: `{
  "name": "toko-online",
  "version": "1.0.0",
  "dependencies": {
    "lodash": "^4.17.15",
    "axios": "~0.18.0"
  }
}
`,
      },
    ],
  },

  kasirPython: {
    label: 'Aplikasi Kasir (Python) — 4 berkas',
    description:
      'Siklus import Python, simbol from-import tak ada, kredensial bersama, SQL injection dari request, + CVE di requirements.txt.',
    files: [
      {
        name: 'app.py',
        code: `import os
from auth import cek_login, hash_pw
from db import simpan_transaksi

def proses_transaksi(nama, jumlah):
    query = "SELECT * FROM produk WHERE nama = '%s'" % nama
    row = cursor.execute(query)
    simpan_transaksi(row)
    return row

if __name__ == "__main__":
    cek_login("admin", os.environ.get("PASS", ""))
`,
      },
      {
        name: 'auth.py',
        code: `import app

password = "rahasia-kasir-2024"

def cek_login(user, pw):
    return user == "admin" and pw == password

def log_aktivasi(pesan):
    print(pesan)
`,
      },
      {
        name: 'db.py',
        code: `password = "rahasia-kasir-2024"

def simpan_transaksi(row):
    try:
        koneksi.commit()
    except:
        pass
    return row
`,
      },
      {
        name: 'requirements.txt',
        code: `flask==2.0.0
requests==2.19.1
pyyaml==5.3
`,
      },
    ],
  },

  blogCmsJs: {
    label: 'Blog CMS (JS) — 7 berkas',
    description:
      'Import default tanpa export default, simbol tak diekspor, argumen tak cocok lintas modul, deklarasi global bentrok antar skrip, kredensial bersama, eval + XSS, + CVE.',
    files: [
      {
        name: 'blog.js',
        code: `// Modul utama blog
import tampilan from './theme.js'
import { renderPost } from './posts.js'
import { seoTitle } from './seo.js'

const judul = req.query.judul
document.getElementById("konten").innerHTML = judul

const slug = seoTitle(judul)
renderPost("halo", true, "ekstra")
console.log(tampilan, slug)
`,
      },
      {
        name: 'theme.js',
        code: `// Tema tampilan
export function renderHeader() {
  return "<header>Blog</header>"
}
`,
      },
      {
        name: 'posts.js',
        code: `// Manajemen posting (modul)
export function renderPost(judul, apakahDraft) {
  var isi = eval("({" + judul + "})")
  return isi
}
`,
      },
      {
        name: 'seo.js',
        code: `// Utilitas SEO (lupa diekspor)
function seoTitle(text) {
  return text.trim().toLowerCase()
}
`,
      },
      {
        name: 'legacy-a.js',
        code: `// Skrip lama A (non-modul)
var apiKey = "AKIA1234ABCD5678EF"

function slugify(text) {
  var isi = eval("({" + text + "})")
  return isi
}

setTimeout("muatUlang()", 3000)
`,
      },
      {
        name: 'legacy-b.js',
        code: `// Skrip lama B (non-modul)
var apiKey = "AKIA1234ABCD5678EF"

function slugify(text) {
  return "versi B: " + text
}
`,
      },
      {
        name: 'package.json',
        code: `{
  "name": "blog-cms",
  "version": "0.9.0",
  "dependencies": {
    "express": "^4.17.1",
    "ejs": "3.1.6",
    "moment": "^2.24.0"
  }
}
`,
      },
    ],
  },

  sekolahPython: {
    label: 'Portal Sekolah (Python) — 6 berkas',
    description:
      'Bug bandel lintas file Python: argumen tak cocok lintas modul (TypeError), pemanggilan fungsi tak terdefinisi di mana pun (NameError), from-import simbol tak tersedia, siklus import, kredensial bersama.',
    files: [
      {
        name: 'config.py',
        code: `# Konfigurasi global portal sekolah
password = "rahasia-sekolah-2024"

def nama_aplikasi():
    return "Portal Sekolah"
`,
      },
      {
        name: 'helpers.py',
        code: `# Utilitas bersama
import config

def hitung_diskon(subtotal, persen):
    return subtotal * (1 - persen / 100)

def format_uang(nilai):
    return "Rp" + str(nilai)
`,
      },
      {
        name: 'layanan.py',
        code: `# Layanan utama tagihan siswa
from helpers import hitung_diskon, format_rupiah
import pembayaran

def proses_tagihan(nis, nominal):
    potongan = hitung_diskon(nominal, 10, True)
    validasi_kupon("HEMAT2024")
    return pembayaran.proses(nis, nominal - potongan)
`,
      },
      {
        name: 'pembayaran.py',
        code: `# Modul pembayaran
import layanan

password = "rahasia-sekolah-2024"

def proses(nis, jumlah):
    return {"nis": nis, "jumlah": jumlah}
`,
      },
      {
        name: 'laporan.py',
        code: `# Laporan bulanan
from helpers import hitung_diskon

def buat_laporan(daftar_siswa):
    total = hitung_diskon(100000, 5)
    hasil = render_pdf(daftar_siswa, True)
    return total
`,
      },
      {
        name: 'main.py',
        code: `# Titik masuk
import layanan
from laporan import buat_laporan

def jalankan():
    layanan.proses_tagihan("2024-001", 250000)
    return buat_laporan(["2024-001"])
`,
      },
    ],
  },

  kasirGo: {
    label: 'Layanan Kasir (Go) — 5 berkas',
    description:
      'Bug bandel lintas file Go: import tak terpakai (gagal build), paket lokal yang tidak ada, argumen tak cocok dalam & lintas paket, kredensial bersama.',
    files: [
      {
        name: 'go.mod',
        code: `module kasirapp

go 1.21
`,
      },
      {
        name: 'main.go',
        code: `package main

import (
        "fmt"
        "os"
        "kasirapp/stok"
        "kasirapp/laporan"
)

func main() {
        daftar := map[string]int{"beras": 10, "gula": 5}
        total := stok.HitungStok(daftar)
        fmt.Println("total stok:", total)
}
`,
      },
      {
        name: 'stok/stok.go',
        code: `package stok

const password = "pg-pass-77123"

func HitungStok(barang map[string]int) int {
        total := 0
        for _, jml := range barang {
                total += jml
        }
        return total
}

func resetStok(nama string) string {
        b := bersihkanTeks(nama, 3)
        return "reset " + b
}
`,
      },
      {
        name: 'stok/util.go',
        code: `package stok

func bersihkanTeks(s string) string {
        return s
}

func muatCache(opsi map[string]string) bool {
        return len(opsi) > 0
}
`,
      },
      {
        name: 'handler/handler.go',
        code: `package handler

import (
        "fmt"
        "kasirapp/stok"
)

const password = "pg-pass-77123"

func SimpanTransaksi(nama string, jumlah int) string {
        stok.HitungStok(nil, jumlah)
        return fmt.Sprintf("%s: %d", nama, jumlah)
}
`,
      },
    ],
  },

  cmsPhp: {
    label: 'CMS Sederhana (PHP) — 4 berkas',
    description:
      'Bug bandel lintas file PHP: require ke berkas yang tidak ada (fatal error), deklarasi class duplikat antar berkas, kredensial bersama.',
    files: [
      {
        name: 'index.php',
        code: `<?php
// Titik masuk CMS
require 'lib/helper.php';
require 'config/database.php';

$db = new Database();
echo render_menu('beranda');
`,
      },
      {
        name: 'config/database.php',
        code: `<?php
class Database {
    public $password = 'mysql-pass-55231';
}
`,
      },
      {
        name: 'backup/Database.php',
        code: `<?php
// Salinan lama class Database
class Database {
    public $password = 'mysql-pass-55231';
}
`,
      },
      {
        name: 'lib/menu.php',
        code: `<?php
function render_menu($halaman) {
    include 'inc/' . $halaman . '.php';
    return '<nav>' . $halaman . '</nav>';
}
`,
      },
    ],
  },
}
