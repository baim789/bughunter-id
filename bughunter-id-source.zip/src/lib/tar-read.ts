import { gunzipSync } from 'node:zlib'
import type { WorkspaceFileInput } from './types'
import { MAX_FILES, MAX_FILE_CHARS, MAX_TOTAL_CHARS } from './workspace-validate'

/**
 * ============================================================
 *  PEMBACA TAR.GZ MINIMAL (tanpa dependensi eksternal)
 * ============================================================
 * Mem-parse arsip tar yang ter-gzip (format yang dikirim
 * codeload.github.com). Mendukung:
 *  - header ustar (magic "ustar") dan tar lama tanpa magic
 *  - GNU long name (typeflag 'L')
 *  - pax extended header (typeflag 'x') untuk key "path"
 *  - typeflag folder '5' & symlink '2' (di-skip)
 *
 * Hanya melayani berkas TEKS: biner, folder, dan sampah sistem
 * di-skip dengan alasan tercatat — batas sama dengan workspace.
 * ============================================================
 */

export interface TarReadResult {
  files: WorkspaceFileInput[]
  info: {
    totalEntries: number
    accepted: number
    skippedBinary: number
    skippedTooBig: number
    skippedJunk: number
    skippedOverLimit: number
    rootStripped: string | null
  }
}

/** Folder & berkas sampah yang tidak perlu dianalisis. */
function isJunkPath(name: string): boolean {
  const lower = name.toLowerCase()
  return (
    lower.startsWith('__macosx/') ||
    lower.includes('/__macosx/') ||
    lower.includes('/.git/') ||
    lower.startsWith('.git/') ||
    lower.includes('/node_modules/') ||
    lower.startsWith('node_modules/') ||
    lower.endsWith('/.ds_store') ||
    lower === '.ds_store' ||
    lower.endsWith('/thumbs.db') ||
    lower === 'thumbs.db' ||
    lower.includes('/.idea/') ||
    lower.startsWith('.idea/') ||
    lower.includes('/.vscode/') ||
    lower.startsWith('.vscode/') ||
    lower.includes('/dist/') ||
    lower.startsWith('dist/') ||
    lower.includes('/build/') ||
    lower.startsWith('build/') ||
    lower.includes('/coverage/') ||
    lower.startsWith('coverage/') ||
    lower.includes('/vendor/') ||
    lower.startsWith('vendor/') ||
    lower.includes('/.github/') ||
    lower.startsWith('.github/')
  )
}

/** Berkas lockfile / hasil minify: teks, tapi boros kuota & minim nilai analisis. */
function isLowValueFile(name: string): boolean {
  const lower = name.toLowerCase()
  const base = lower.split('/').pop() ?? lower
  return (
    base === 'package-lock.json' ||
    base === 'yarn.lock' ||
    base === 'pnpm-lock.yaml' ||
    base === 'composer.lock' ||
    base === 'poetry.lock' ||
    base === 'cargo.lock' ||
    base.endsWith('.min.js') ||
    base.endsWith('.min.css') ||
    base.endsWith('.map')
  )
}

const MAX_GUNZIP_BYTES = 40 * 1_000_000

/** Dekode sebagai teks UTF-8 ketat; return null bila biner. */
function decodeText(data: Buffer): string | null {
  if (data.length === 0) return ''
  if (data.includes(0)) return null
  try {
    return new TextDecoder('utf-8', { fatal: true }).decode(data)
  } catch {
    return null
  }
}

function octal(buf: Buffer, start: number, len: number): number {
  let s = ''
  for (let i = 0; i < len; i++) {
    const c = buf[start + i]
    if (c === 0 || c === 0x20) break
    s += String.fromCharCode(c)
  }
  if (!/^[0-7]+$/.test(s)) return 0
  return parseInt(s, 8)
}

function allZero(buf: Buffer, start: number): boolean {
  for (let i = start; i < start + 512; i++) if (buf[i] !== 0) return false
  return true
}

/** Parse pax records "<len> key=value\n" → Map. */
function parsePax(data: Buffer): Map<string, string> {
  const out = new Map<string, string>()
  let i = 0
  while (i < data.length) {
    const sp = data.indexOf(0x20, i)
    if (sp < 0) break
    const lenStr = data.slice(i, sp).toString('ascii')
    const len = parseInt(lenStr, 10)
    if (!Number.isFinite(len) || len <= 0 || i + len > data.length) break
    const record = data.slice(sp + 1, i + len).toString('utf8')
    const eq = record.indexOf('=')
    if (eq > 0) out.set(record.slice(0, eq), record.slice(eq + 1).replace(/\n$/, ''))
    i += len
  }
  return out
}

interface RawFile {
  name: string
  data: Buffer
}

/** Ekstrak seluruh entri berkas biasa dari buffer tar (sudah ter-gzip). */
function listTarEntries(buf: Buffer): RawFile[] {
  const out: RawFile[] = []
  let pos = 0
  let pendingLongName: string | null = null
  let pendingPaxPath: string | null = null

  while (pos + 512 <= buf.length) {
    if (allZero(buf, pos)) break // akhir arsip
    const name = buf.slice(pos, pos + 100).toString('utf8').replace(/\0.*$/, '')
    const size = octal(buf, pos + 124, 12)
    const typeflag = String.fromCharCode(buf[pos + 156] || 0x30)
    const magic = buf.slice(pos + 257, pos + 262).toString('utf8')
    if (magic !== 'ustar\0' && magic !== 'ustar ' && magic !== 'ustar') {
      // header tidak valid — coba lompat 512 (tahan korup ringan)
      pos += 512
      continue
    }
    const dataStart = pos + 512
    const padded = Math.ceil(size / 512) * 512
    if (dataStart + size > buf.length) break
    const data = buf.slice(dataStart, dataStart + size)

    if (typeflag === 'L') {
      pendingLongName = data.toString('utf8').replace(/\0.*$/, '')
    } else if (typeflag === 'x' || typeflag === 'X') {
      const pax = parsePax(data)
      if (pax.has('path')) pendingPaxPath = pax.get('path')!
    } else if (typeflag === '0' || typeflag === '\0') {
      const realName = pendingLongName ?? pendingPaxPath ?? name
      out.push({ name: realName, data })
      pendingLongName = null
      pendingPaxPath = null
    } else {
      // folder '5', symlink '2', hardlink '1', device, dll — abaikan
      pendingLongName = null
      pendingPaxPath = null
    }
    pos = dataStart + padded
  }
  return out
}

/** Buang satu folder akar umum (GitHub: "repo-ref/"). */
function stripCommonRoot(names: string[]): string | null {
  if (names.length === 0) return null
  const first = names[0].split('/')[0]
  if (!first) return null
  // semua entri harus berada di folder akar yang sama, dan folder itu benar-benar ada
  for (const n of names) {
    if (n.split('/')[0] !== first) return null
  }
  return names.some(n => n.includes('/')) ? first : null
}

export function readTarGzWorkspace(gz: Buffer): TarReadResult {
  const info: TarReadResult['info'] = {
    totalEntries: 0,
    accepted: 0,
    skippedBinary: 0,
    skippedTooBig: 0,
    skippedJunk: 0,
    skippedOverLimit: 0,
    rootStripped: null,
  }
  const files: WorkspaceFileInput[] = []
  let totalChars = 0

  let tar: Buffer
  try {
    tar = gunzipSync(gz, { maxOutputLength: MAX_GUNZIP_BYTES })
  } catch {
    throw new Error('Arsip tar.gz tidak bisa dibuka (bukan gzip atau rusak).')
  }

  const entries = listTarEntries(tar)
  info.totalEntries = entries.length
  const root = stripCommonRoot(entries.map(e => e.name))
  info.rootStripped = root

  const usedNames = new Set<string>()
  for (const e of entries) {
    let name = e.name.replace(/\\/g, '/')
    if (root && name.startsWith(`${root}/`)) name = name.slice(root.length + 1)
    if (!name || name.endsWith('/')) continue
    if (isJunkPath(name) || isLowValueFile(name)) {
      info.skippedJunk++
      continue
    }
    if (files.length >= MAX_FILES) {
      info.skippedOverLimit++
      continue
    }
    if (e.data.length > MAX_FILE_CHARS) {
      info.skippedTooBig++
      continue
    }
    const text = decodeText(e.data)
    if (text === null) {
      info.skippedBinary++
      continue
    }
    // dedupe nama
    let finalName = name
    let n = 2
    while (usedNames.has(finalName)) {
      const dot = finalName.lastIndexOf('.')
      finalName = dot > 0 ? `${finalName.slice(0, dot)}-${n}${finalName.slice(dot)}` : `${finalName}-${n}`
      n++
    }
    usedNames.add(finalName)
    if (totalChars + text.length > MAX_TOTAL_CHARS) {
      info.skippedOverLimit++
      continue
    }
    files.push({ name: finalName, code: text })
    totalChars += text.length
    info.accepted++
  }
  return { files, info }
}
