'use client'

/**
 * Pengaturan aturan yang dinonaktifkan pengguna — disimpan di
 * localStorage agar bertahan antar kunjungan (per browser).
 */

const KEY = 'bughunter-disabled-rules'

export function getDisabledRules(): string[] {
  if (typeof window === 'undefined') return []
  try {
    const raw = window.localStorage.getItem(KEY)
    if (!raw) return []
    const parsed = JSON.parse(raw)
    if (!Array.isArray(parsed)) return []
    return parsed.filter((r): r is string => typeof r === 'string' && r.length > 0).slice(0, 300)
  } catch {
    return []
  }
}

export function setDisabledRules(list: string[]): void {
  if (typeof window === 'undefined') return
  try {
    window.localStorage.setItem(KEY, JSON.stringify(list.slice(0, 300)))
  } catch {
    // storage penuh/blocked — abaikan diam-diam
  }
}
