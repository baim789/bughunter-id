export type Severity = 'critical' | 'high' | 'medium' | 'low'

export type SourceLang = 'javascript' | 'python' | 'java' | 'php' | 'go'

export const SUPPORTED_LANGUAGES: SourceLang[] = [
  'javascript',
  'python',
  'java',
  'php',
  'go',
]

export const LANGUAGE_LABELS: Record<string, string> = {
  auto: 'Otomatis (deteksi)',
  javascript: 'JavaScript / TypeScript',
  python: 'Python',
  java: 'Java',
  php: 'PHP',
  go: 'Go',
}

export interface Bug {
  id: string
  title: string
  description: string
  severity: Severity
  line: number
  suggestion: string
  category: string
  source: 'rule' | 'ai'
  /** ID aturan deteksi (hanya bug rule-based). Dipakai untuk cek dukungan auto-fix. */
  ruleId?: string
  /** Opsi perbaikan berpandu — hanya ada pada sebagian temuan lintas file. */
  guidedFixes?: GuidedFixOption[]
}

/** Aksi perbaikan berpandu: data lengkap agar server bisa mengeksekusi tanpa state. */
export interface GuidedFixAction {
  /** ID aturan temuan, mis. ws-js-import-symbol. */
  ruleId: string
  /** Berkas tempat temuan dilaporkan. */
  file: string
  /** Baris temuan saat analisis (untuk validasi anti-kadaluarsa). */
  line: number
  /** ID solusi terpilih, mis. add-export. */
  option: string
  /** Berkas pihak lain yang terlibat (target import, pemilik signature, dll). */
  targetFile?: string
  /** Simbol yang terlibat (nama fungsi/variabel/paket). */
  symbol?: string
  /** Spesifikasi import relatif, mis. "./d-utils.js". */
  spec?: string
  /** Nama paket (Java: paket class target; Go: nama paket pemanggilan berkualifikasi). */
  pkg?: string
  /** Arity: jumlah parameter deklarasi & jumlah argumen pemanggilan. */
  paramCount?: number
  callCount?: number
  /** Dependensi: versi perbaikan yang disarankan. */
  fixedIn?: string
}

/** Satu pilihan solusi pada perbaikan berpandu. */
export interface GuidedFixOption {
  id: string
  /** Label singkat untuk tombol, mis. "Tambahkan export di b.js". */
  label: string
  /** Penjelasan persis apa yang akan diubah. */
  detail: string
  /** true bila solusi tidak menghilangkan simbol yang sedang dipakai. */
  safe: boolean
  action: GuidedFixAction
}

export interface AutoFixChange {
  line: number
  ruleId: string
  fixerId: string
  before: string
  after: string
  description: string
  language: string
}

export interface AutoFixSkip {
  line: number
  ruleId: string
  reason: string
}

export interface AutoFixResponse {
  ok: boolean
  language: string
  fixedCode: string
  changes: AutoFixChange[]
  skipped: AutoFixSkip[]
  fixedCount: number
  totalFixable: number
}

export interface ScanResult {
  id: string
  language: string
  lineCount: number
  bugCount: number
  criticalCount: number
  highCount: number
  mediumCount: number
  lowCount: number
  healthScore: number
  source: string
  aiEnabled: boolean
  bugs: Bug[]
  createdAt: string
  codeSnippet?: string
}

export interface HistoryItem {
  id: string
  kind: 'single' | 'workspace'
  language: string
  preview: string
  bugCount: number
  criticalCount: number
  highCount: number
  mediumCount: number
  lowCount: number
  healthScore: number
  source: string
  aiEnabled: boolean
  createdAt: string
  fileCount?: number
  /** Workspace: file tersimpan lengkap sehingga bisa dimuat ulang ke editor. */
  restoreable?: boolean
}

/* ---------- workspace multi-file ---------- */

export interface WorkspaceFileInput {
  name: string
  code: string
}

export interface WorkspaceFileResult {
  name: string
  language: string
  supported: boolean
  lineCount: number
  bugCount: number
  criticalCount: number
  highCount: number
  mediumCount: number
  lowCount: number
  healthScore: number
  bugs: Bug[]
}

export interface WorkspaceScanResult {
  id: string
  fileCount: number
  supportedCount: number
  totalLines: number
  bugCount: number
  criticalCount: number
  highCount: number
  mediumCount: number
  lowCount: number
  healthScore: number
  crossFileCount: number
  files: WorkspaceFileResult[]
  createdAt: string
}

export interface WorkspaceFixChange extends AutoFixChange {
  file: string
}

export interface WorkspaceFixSkip extends AutoFixSkip {
  file: string
}

export interface WorkspaceFixFileResult {
  name: string
  supported: boolean
  fixedCode: string
  changes: WorkspaceFixChange[]
  skipped: WorkspaceFixSkip[]
}

export interface WorkspaceFixResponse {
  ok: boolean
  files: WorkspaceFixFileResult[]
  fixedCount: number
  skippedCount: number
}

export interface GuidedFixResultItem {
  ok: boolean
  option: string
  file: string
  targetFile?: string
  line?: number
  /** Penjelasan perubahan yang diterapkan (bila ok). */
  description?: string
  before?: string
  after?: string
  /** Alasan penolakan (bila gagal, mis. temuan sudah tidak ada). */
  reason?: string
}

export interface GuidedFixResponse {
  ok: boolean
  /** Daftar file LENGKAP pasca-aksi (termasuk file baru bila ada). */
  files: WorkspaceFileInput[]
  addedFiles: string[]
  appliedCount: number
  results: GuidedFixResultItem[]
}

export interface Stats {
  totalScans: number
  totalBugs: number
  avgHealth: number
  byLanguage: Record<string, number>
  bySeverity: Record<Severity, number>
}
