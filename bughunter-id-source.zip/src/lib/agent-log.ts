/* Pengirim log agen ke layanan socket (server-side, fire-and-forget).
 * Gagal kirim = senyap — log real-time adalah bonus, bukan jalur kritis. */

const EMIT_URL = process.env.AGENT_LOG_EMIT_URL || 'http://127.0.0.1:3004/emit'
const ROOM_RE = /^[A-Za-z0-9_-]{4,64}$/

export interface AgentLogEvent {
  kind: 'open' | 'line' | 'status'
  term: string
  title?: string
  subtitle?: string
  text?: string
  tone?: 'cmd' | 'ok' | 'warn' | 'err' | 'info' | 'dim'
  status?: 'running' | 'done' | 'error'
}

/** Kirim batch event ke room. room null/undefined/tak valid → no-op. */
export function emitAgentLog(room: string | null | undefined, events: AgentLogEvent[]): void {
  if (!room || !ROOM_RE.test(room) || events.length === 0) return
  void fetch(EMIT_URL, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ room, events: events.slice(0, 300) }),
    signal: AbortSignal.timeout(1500),
  }).catch(() => {})
}

/** Ambil room dari body (opsional) — hanya string yang valid yang diterima. */
export function parseLogRoom(raw: unknown): string | null {
  if (typeof raw !== 'string') return null
  const t = raw.trim()
  return ROOM_RE.test(t) ? t : null
}
