/**
 * PENULIS ZIP MINIMAL (store-only, tanpa kompresi, tanpa dependensi).
 * ---------------------------------------------------------------
 * Menghasilkan arsip ZIP standar yang bisa dibuka semua alat
 * (Windows Explorer, unzip, macOS Archive Utility):
 * - Metode penyimpanan 0 (store) — aman & cepat untuk kode sumber.
 * - Nama berkas UTF-8 (flag 0x0800) agar folder/nama ber-aksara apa pun valid.
 * - CRC32 dihitung dengan tabel standar IEEE 802.3.
 */

/* ---------- CRC32 ---------- */

const CRC_TABLE = (() => {
  const table = new Uint32Array(256)
  for (let n = 0; n < 256; n++) {
    let c = n
    for (let k = 0; k < 8; k++) {
      c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1
    }
    table[n] = c >>> 0
  }
  return table
})()

function crc32(data: Uint8Array): number {
  let crc = 0xffffffff
  for (let i = 0; i < data.length; i++) {
    crc = CRC_TABLE[(crc ^ data[i]) & 0xff] ^ (crc >>> 8)
  }
  return (crc ^ 0xffffffff) >>> 0
}

/* ---------- tanggal gaya DOS ---------- */

function dosDateTime(date: Date): { time: number; date: number } {
  // Tahun DOS mulai 1980; jepit agar header tetap valid.
  const year = Math.min(Math.max(date.getFullYear(), 1980), 2107)
  const time =
    (date.getHours() << 11) | (date.getMinutes() << 5) | (Math.floor(date.getSeconds() / 2) & 0x1f)
  const day =
    ((year - 1980) << 9) | ((date.getMonth() + 1) << 5) | date.getDate()
  return { time: time & 0xffff, date: day & 0xffff }
}

/* ---------- penulisan ---------- */

export interface ZipEntry {
  /** Jalur berkas di dalam arsip, mis. "src/app.js" (pakai "/" — bukan "\"). */
  name: string
  /** Isi berkas (teks di-encode UTF-8). */
  content: string | Uint8Array
}

/**
 * Bangun arsip ZIP dari daftar entri.
 * Melempar Error bila tidak ada entri, nama kosong/duplikat, atau total
 * ukuran melebihi batas aman format ZIP klasik (±4 GB).
 */
export function createZip(entries: ZipEntry[]): Uint8Array {
  if (entries.length === 0) throw new Error('ZIP tidak boleh kosong')

  const encoder = new TextEncoder()
  const now = dosDateTime(new Date())
  const chunks: Uint8Array[] = []
  const central: Uint8Array[] = []
  let offset = 0
  const seenNames = new Set<string>()

  for (const entry of entries) {
    const nameBytes = encoder.encode(entry.name)
    const data = typeof entry.content === 'string' ? encoder.encode(entry.content) : entry.content
    const crc = crc32(data)

    if (nameBytes.length === 0 || nameBytes.length > 0xffff) {
      throw new Error(`Nama berkas tidak valid di dalam arsip: "${entry.name}"`)
    }
    if (seenNames.has(entry.name)) {
      throw new Error(`Nama berkas duplikat di dalam arsip: "${entry.name}"`)
    }
    seenNames.add(entry.name)

    // --- local file header ---
    const local = new Uint8Array(30 + nameBytes.length)
    const lv = new DataView(local.buffer)
    lv.setUint32(0, 0x04034b50, true) // signature
    lv.setUint16(4, 20, true) // version needed
    lv.setUint16(6, 0x0800, true) // UTF-8 names
    lv.setUint16(8, 0, true) // method: store
    lv.setUint16(10, now.time, true)
    lv.setUint16(12, now.date, true)
    lv.setUint32(14, crc, true)
    lv.setUint32(18, data.length, true) // compressed (store: sama)
    lv.setUint32(22, data.length, true) // uncompressed
    lv.setUint16(26, nameBytes.length, true)
    lv.setUint16(28, 0, true) // extra len
    local.set(nameBytes, 30)

    chunks.push(local, data)

    // --- central directory entry ---
    const cd = new Uint8Array(46 + nameBytes.length)
    const cv = new DataView(cd.buffer)
    cv.setUint32(0, 0x02014b50, true)
    cv.setUint16(4, 20, true) // version made by
    cv.setUint16(6, 20, true) // version needed
    cv.setUint16(8, 0x0800, true)
    cv.setUint16(10, 0, true)
    cv.setUint16(12, now.time, true)
    cv.setUint16(14, now.date, true)
    cv.setUint32(16, crc, true)
    cv.setUint32(20, data.length, true)
    cv.setUint32(24, data.length, true)
    cv.setUint16(28, nameBytes.length, true)
    cv.setUint16(30, 0, true) // extra
    cv.setUint16(32, 0, true) // comment
    cv.setUint16(34, 0, true) // disk number
    cv.setUint16(36, 0, true) // internal attrs
    cv.setUint32(38, 0, true) // external attrs
    cv.setUint32(42, offset, true) // local header offset
    cd.set(nameBytes, 46)
    central.push(cd)

    offset += local.length + data.length
  }

  const centralSize = central.reduce((sum, c) => sum + c.length, 0)
  if (offset + centralSize > 0xffffffff) {
    throw new Error('Total ukuran arsip melebihi batas format ZIP klasik')
  }

  // --- end of central directory ---
  const eocd = new Uint8Array(22)
  const ev = new DataView(eocd.buffer)
  ev.setUint32(0, 0x06054b50, true)
  ev.setUint16(4, 0, true)
  ev.setUint16(6, 0, true)
  ev.setUint16(8, entries.length, true)
  ev.setUint16(10, entries.length, true)
  ev.setUint32(12, centralSize, true)
  ev.setUint32(16, offset, true)
  ev.setUint16(20, 0, true)

  const total = new Uint8Array(offset + centralSize + 22)
  let pos = 0
  for (const chunk of [...chunks, ...central, eocd]) {
    total.set(chunk, pos)
    pos += chunk.length
  }
  return total
}
