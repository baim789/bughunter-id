import type { NextRequest } from 'next/server'

/**
 * Rate limiter sederhana berbasis sliding window di memori.
 * Tujuan: melindungi endpoint berat (analisis kode, auto-fix, panggilan AI)
 * dari abusi/DoS murah tanpa menambah dependensi eksternal.
 *
 * - Satu proses dev/standalone Node = satu bucket Map (disimpan di globalThis
 *   agar tidak di-reset oleh hot-reload HMR).
 * - Kunci = rute + IP klien (x-forwarded-for dari reverse proxy, fallback
 *   x-real-ip, terakhir 'local').
 * - Limit dapat diubah via env: RATE_LIMIT_ANALYZE_PER_MIN,
 *   RATE_LIMIT_AUTOFIX_PER_MIN.
 */

const WINDOW_MS = 60_000
const MAX_KEYS = 10_000

const globalForRate = globalThis as unknown as {
  __bhRateBuckets?: Map<string, number[]>
}
const buckets = globalForRate.__bhRateBuckets ?? new Map<string, number[]>()
globalForRate.__bhRateBuckets = buckets

export interface RateLimitResult {
  ok: boolean
  retryAfter: number
}

export function rateLimit(key: string, limitPerMinute: number): RateLimitResult {
  const now = Date.now()
  const timestamps = (buckets.get(key) ?? []).filter(ts => now - ts < WINDOW_MS)

  if (timestamps.length >= limitPerMinute) {
    const retryAfter = Math.max(1, Math.ceil((WINDOW_MS - (now - timestamps[0])) / 1000))
    buckets.set(key, timestamps)
    return { ok: false, retryAfter }
  }

  timestamps.push(now)
  buckets.set(key, timestamps)

  // Cegah pertumbuhan memori tanpa batas: buang entri yang sudah kedaluwarsa.
  if (buckets.size > MAX_KEYS) {
    for (const [k, v] of buckets) {
      if (v.every(ts => now - ts >= WINDOW_MS)) buckets.delete(k)
    }
  }
  return { ok: true, retryAfter: 0 }
}

export function getClientIp(request: NextRequest): string {
  const forwarded = request.headers.get('x-forwarded-for')
  if (forwarded) return forwarded.split(',')[0].trim()
  return request.headers.get('x-real-ip') ?? 'local'
}
