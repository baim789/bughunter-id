import type { WorkspaceFileInput } from './types'
import { sanitizeFileName } from './detector/workspace'

/** Batas workspace: 200 file, 200 KB/file, 5 juta karakter total (proyek besar; v0.11). */
export const MAX_FILES = 200
export const MAX_FILE_CHARS = 200_000
export const MAX_TOTAL_CHARS = 5_000_000
/** Kode disimpan ke riwayat hanya bila totalnya muat (agar fitur Muat tetap ringan). */
export const MAX_STORABLE_CHARS = 262_144

export type WorkspaceValidation =
  | { ok: true; files: WorkspaceFileInput[]; totalChars: number }
  | { ok: false; error: string; status: number }

/**
 * Validasi & sanitasi daftar file workspace dari body JSON.
 * - files wajib array 1..MAX_FILES berisi {name, code} string
 * - nama disanitasi (anti path traversal) dan wajib unik
 * - ukuran per file dan total dibatasi
 */
export function validateWorkspaceFiles(body: unknown): WorkspaceValidation {
  const filesRaw = (body as { files?: unknown })?.files
  if (!Array.isArray(filesRaw) || filesRaw.length === 0) {
    return { ok: false, error: 'Sertakan minimal satu file: files: [{ name, code }].', status: 400 }
  }
  if (filesRaw.length > MAX_FILES) {
    return { ok: false, error: `Maksimal ${MAX_FILES} file per workspace.`, status: 400 }
  }

  const files: WorkspaceFileInput[] = []
  const seen = new Set<string>()
  let totalChars = 0

  for (const item of filesRaw) {
    const name = typeof (item as WorkspaceFileInput)?.name === 'string' ? (item as WorkspaceFileInput).name : ''
    const code = typeof (item as WorkspaceFileInput)?.code === 'string' ? (item as WorkspaceFileInput).code : ''
    const cleanName = sanitizeFileName(name)
    if (!cleanName) {
      return {
        ok: false,
        error: `Nama berkas tidak valid: "${String(name).slice(0, 60)}". Gunakan nama berkas biasa (boleh ber-foldner, tanpa "..").`,
        status: 400,
      }
    }
    if (seen.has(cleanName)) {
      return { ok: false, error: `Nama berkas duplikat: "${cleanName}".`, status: 400 }
    }
    seen.add(cleanName)
    if (code.length > MAX_FILE_CHARS) {
      return {
        ok: false,
        error: `"${cleanName}" melebihi ${(MAX_FILE_CHARS / 1000).toFixed(0)} ribu karakter.`,
        status: 400,
      }
    }
    totalChars += code.length
    if (totalChars > MAX_TOTAL_CHARS) {
      return {
        ok: false,
        error: `Total seluruh kode melebihi ${(MAX_TOTAL_CHARS / 1_000_000).toFixed(0)} juta karakter.`,
        status: 400,
      }
    }
    files.push({ name: cleanName, code })
  }
  return { ok: true, files, totalChars }
}

/** Guard content-type JSON untuk semua endpoint workspace. */
export function isJsonRequest(contentType: string | null): boolean {
  return (contentType ?? '').toLowerCase().includes('application/json')
}
