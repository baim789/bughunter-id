/**
 * Diff baris sederhana (LCS + pemangkasan prefiks/sufiks) untuk pratinjau
 * perbaikan berpandu. Tanpa dependensi; dipakai server & client.
 */

export interface DiffLine {
  type: 'add' | 'del' | 'ctx'
  text: string
  oldNo?: number
  newNo?: number
}

const MAX_LCS_LINES = 1200 // di atas ini: tampilkan blok utuh (hindari DP raksasa)

/** Diff dua teks per baris dengan konteks `context` baris. */
export function diffLines(before: string, after: string, context = 2): DiffLine[] {
  const a = before.split('\n')
  const b = after.split('\n')

  // pemangkasan prefiks/sufiks sama → region tengah kecil untuk edit terlokalisir
  let start = 0
  while (start < a.length && start < b.length && a[start] === b[start]) start++
  let endA = a.length
  let endB = b.length
  while (endA > start && endB > start && a[endA - 1] === b[endB - 1]) {
    endA--
    endB--
  }
  const midA = a.slice(start, endA)
  const midB = b.slice(start, endB)

  let ops: Array<{ type: 'same' | 'del' | 'add'; text: string }> = []
  if (midA.length === 0 && midB.length === 0) {
    return [] // identik
  } else if (midA.length > MAX_LCS_LINES || midB.length > MAX_LCS_LINES) {
    ops = [
      ...midA.map(t => ({ type: 'del' as const, text: t })),
      ...midB.map(t => ({ type: 'add' as const, text: t })),
    ]
  } else {
    ops = lcsOps(midA, midB)
  }

  // sisipkan konteks di sekitar perubahan
  const raw: DiffLine[] = []
  let oldNo = start
  let newNo = start
  for (const op of ops) {
    if (op.type === 'same') {
      oldNo++
      newNo++
      raw.push({ type: 'ctx', text: op.text, oldNo, newNo })
    } else if (op.type === 'del') {
      oldNo++
      raw.push({ type: 'del', text: op.text, oldNo })
    } else {
      newNo++
      raw.push({ type: 'add', text: op.text, newNo })
    }
  }

  // sembunyikan run konteks yang jauh dari perubahan (> context di kedua sisi)
  const keep = new Array<boolean>(raw.length).fill(false)
  raw.forEach((l, i) => {
    if (l.type !== 'ctx') {
      for (let k = Math.max(0, i - context); k <= Math.min(raw.length - 1, i + context); k++) keep[k] = true
    }
  })
  const out: DiffLine[] = []
  let skipped = false
  raw.forEach((l, i) => {
    if (keep[i]) {
      out.push(l)
      skipped = false
    } else if (!skipped) {
      out.push({ type: 'ctx', text: '…' })
      skipped = true
    }
  })
  return out
}

function lcsOps(a: string[], b: string[]): Array<{ type: 'same' | 'del' | 'add'; text: string }> {
  const n = a.length
  const m = b.length
  // DP LCS standar
  const dp: Uint32Array[] = Array.from({ length: n + 1 }, () => new Uint32Array(m + 1))
  for (let i = n - 1; i >= 0; i--) {
    for (let j = m - 1; j >= 0; j--) {
      dp[i][j] = a[i] === b[j] ? dp[i + 1][j + 1] + 1 : Math.max(dp[i + 1][j], dp[i][j + 1])
    }
  }
  const ops: Array<{ type: 'same' | 'del' | 'add'; text: string }> = []
  let i = 0
  let j = 0
  while (i < n && j < m) {
    if (a[i] === b[j]) {
      ops.push({ type: 'same', text: a[i] })
      i++
      j++
    } else if (dp[i + 1][j] >= dp[i][j + 1]) {
      ops.push({ type: 'del', text: a[i] })
      i++
    } else {
      ops.push({ type: 'add', text: b[j] })
      j++
    }
  }
  while (i < n) ops.push({ type: 'del', text: a[i++] })
  while (j < m) ops.push({ type: 'add', text: b[j++] })
  return ops
}

/** Ringkasan jumlah penambahan/penghapusan. */
export function diffStats(lines: DiffLine[]): { added: number; removed: number } {
  let added = 0
  let removed = 0
  for (const l of lines) {
    if (l.type === 'add') added++
    else if (l.type === 'del') removed++
  }
  return { added, removed }
}
