import type { Severity } from './types'

export const SEVERITY_ORDER: Record<Severity, number> = {
  critical: 0,
  high: 1,
  medium: 2,
  low: 3,
}

export interface SeverityMeta {
  label: string
  color: string
  bg: string
  border: string
  weight: number
}

export const SEVERITY_META: Record<Severity, SeverityMeta> = {
  critical: {
    label: 'Kritis',
    color: '#f85149',
    bg: 'rgba(248,81,73,0.12)',
    border: 'rgba(248,81,73,0.45)',
    weight: 25,
  },
  high: {
    label: 'Tinggi',
    color: '#f0883e',
    bg: 'rgba(240,136,62,0.12)',
    border: 'rgba(240,136,62,0.45)',
    weight: 12,
  },
  medium: {
    label: 'Sedang',
    color: '#e3b341',
    bg: 'rgba(227,179,65,0.12)',
    border: 'rgba(227,179,65,0.45)',
    weight: 5,
  },
  low: {
    label: 'Rendah',
    color: '#8b949e',
    bg: 'rgba(139,148,158,0.12)',
    border: 'rgba(139,148,158,0.45)',
    weight: 2,
  },
}

export function healthVerdict(score: number): { label: string; color: string } {
  if (score >= 90) return { label: 'Sangat Sehat', color: '#3fb950' }
  if (score >= 70) return { label: 'Cukup Sehat', color: '#e3b341' }
  if (score >= 40) return { label: 'Perlu Perbaikan', color: '#f0883e' }
  return { label: 'Kritis', color: '#f85149' }
}
