import type { NextAuthOptions } from 'next-auth'
import CredentialsProvider from 'next-auth/providers/credentials'
import { randomBytes, scryptSync, timingSafeEqual } from 'node:crypto'
import { db } from '@/lib/db'

/**
 * Autentikasi kredensial (email + sandi) untuk BugHunter ID.
 * - Hash sandi: scrypt (salt acak 16 byte + kunci 64 byte, hex) — tanpa dependensi baru.
 * - Sesi: JWT (tanpa state server), data user ringan di token.
 */

export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString('hex')
  const key = scryptSync(password, salt, 64).toString('hex')
  return `scrypt$${salt}$${key}`
}

export function verifyPassword(password: string, stored: string): boolean {
  try {
    const [scheme, salt, key] = stored.split('$')
    if (scheme !== 'scrypt' || !salt || !key) return false
    const candidate = scryptSync(password, salt, 64)
    const expected = Buffer.from(key, 'hex')
    return candidate.length === expected.length && timingSafeEqual(candidate, expected)
  } catch {
    return false
  }
}

export const authOptions: NextAuthOptions = {
  session: { strategy: 'jwt', maxAge: 30 * 24 * 3600 },
  secret: process.env.NEXTAUTH_SECRET || 'bughunter-id-dev-secret-ganti-di-produksi',
  pages: { signIn: '/' },
  providers: [
    CredentialsProvider({
      name: 'Email & Sandi',
      credentials: {
        email: { label: 'Email', type: 'email' },
        password: { label: 'Sandi', type: 'password' },
      },
      async authorize(credentials) {
        const email = (credentials?.email ?? '').trim().toLowerCase()
        const password = credentials?.password ?? ''
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || password.length < 8) return null
        const user = await db.user.findUnique({ where: { email } })
        if (!user || !verifyPassword(password, user.passwordHash)) return null
        return { id: user.id, email: user.email, name: user.name || user.email.split('@')[0] }
      },
    }),
  ],
  callbacks: {
    async jwt({ token, user }) {
      if (user && typeof user.id === 'string') {
        token.uid = user.id
        token.name = user.name ?? token.name
      }
      return token
    },
    async session({ session, token }) {
      if (typeof token.uid === 'string' && session.user) {
        ;(session.user as { id?: string }).id = token.uid
      }
      return session
    },
  },
}
