'use client'

import type { PdfReportPayload } from './pdf-report'

/** Kirim payload laporan ke server, terima PDF, dan picu unduhan di browser. */
export async function downloadPdfReport(payload: PdfReportPayload, filename: string): Promise<boolean> {
  const res = await fetch('/api/report/pdf', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  })
  if (!res.ok) {
    let msg = 'Gagal membuat laporan PDF.'
    try {
      const data = await res.json()
      if (data?.error) msg = data.error
    } catch {
      // abaikan
    }
    throw new Error(msg)
  }
  const blob = await res.blob()
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  document.body.appendChild(a)
  a.click()
  a.remove()
  URL.revokeObjectURL(url)
  return true
}
