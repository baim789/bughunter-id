/**
 * ============================================================
 *  PENULIS PDF LAPORAN — BugHunter ID (tanpa dependensi)
 * ============================================================
 * Menghasilkan PDF 1.4 (A4) dengan font bawaan Helvetica
 * (WinAnsi) — teks laporan berbahasa Indonesia aman ASCII.
 *
 * Struktur keluaran:
 *  - Header gelap dengan judul + tanggal
 *  - Ringkasan: skor kesehatan + 4 kotak severity
 *  - Per berkas: nama, bahasa, skor, daftar temuan berperingkat
 *  - Daftar berkas bersih, footer bernomor halaman
 * ============================================================
 */

import type { Severity } from './types'

/* ---------- palet warna (RGB 0..1) ---------- */

const C = {
  bgDark: [0.051, 0.067, 0.09] as const, // #0d1117
  panel: [0.086, 0.106, 0.133] as const, // #161b22
  border: [0.188, 0.212, 0.239] as const, // #30363d
  textLight: [0.902, 0.929, 0.953] as const, // #e6edf3
  textGray: [0.545, 0.58, 0.62] as const, // #8b949e
  textDim: [0.28, 0.31, 0.345] as const, // #484f58
  white: [1, 1, 1] as const,
  green: [0.247, 0.725, 0.314] as const, // #3fb950
  critical: [0.973, 0.318, 0.286] as const, // #f85149
  high: [0.941, 0.533, 0.243] as const, // #f0883e
  medium: [0.89, 0.702, 0.255] as const, // #e3b341
  low: [0.545, 0.58, 0.62] as const, // #8b949e
}

const SEV_COLOR: Record<Severity, readonly number[]> = {
  critical: C.critical,
  high: C.high,
  medium: C.medium,
  low: C.low,
}

const SEV_LABEL: Record<Severity, string> = {
  critical: 'KRITIS',
  high: 'TINGGI',
  medium: 'SEDANG',
  low: 'RENDAH',
}

/* ---------- payload ---------- */

export interface PdfBug {
  severity: Severity
  line: number
  category: string
  title: string
  description?: string
  suggestion?: string
  crossFile?: boolean
}

export interface PdfFileReport {
  name: string
  language: string
  healthScore: number
  bugCount: number
  bugs: PdfBug[]
}

export interface PdfReportPayload {
  kind: 'workspace' | 'single'
  title?: string
  createdAt?: string
  summary: {
    healthScore: number
    bugCount: number
    criticalCount: number
    highCount: number
    mediumCount: number
    lowCount: number
    crossFileCount?: number
    depCount?: number
    fileCount?: number
    totalLines?: number
  }
  files: PdfFileReport[]
}

/* ---------- utilitas teks ---------- */

const UNICODE_MAP: Array<[RegExp, string]> = [
  [/[—–]/g, '-'],
  [/[''']/g, "'"],
  [/["""]/g, '"'],
  [/…/g, '...'],
  [/·/g, '.'],
  [/×/g, 'x'],
  [/→/g, '->'],
  [/≥/g, '>='],
  [/≤/g, '<='],
  [/±/g, '+-'],
  [/•/g, '*'],
]

function pdfEscape(s: string): string {
  let out = s
  for (const [re, rep] of UNICODE_MAP) out = out.replace(re, rep)
  // buang aksen latin (é→e) lalu karakter non-ASCII apa pun
  out = out.normalize('NFD').replace(/[\u0300-\u036f]/g, '')
  out = out.replace(/[^\x20-\x7e]/g, '')
  return out.replace(/\\/g, '\\\\').replace(/\(/g, '\\(').replace(/\)/g, '\\)')
}

function fmtColor(c: readonly number[]): string {
  return `${c[0].toFixed(3)} ${c[1].toFixed(3)} ${c[2].toFixed(3)}`
}

/** Perkiraan lebar teks Helvetica (konservatif — memakai faktor 0.55 em). */
function textWidth(s: string, size: number): number {
  return s.length * size * 0.55
}

function wrapText(s: string, size: number, maxWidth: number, maxLines: number): string[] {
  const words = pdfEscape(s).split(/\s+/).filter(Boolean)
  const lines: string[] = []
  let cur = ''
  for (const w of words) {
    const candidate = cur ? `${cur} ${w}` : w
    if (textWidth(candidate, size) <= maxWidth) {
      cur = candidate
    } else {
      if (cur) lines.push(cur)
      // kata lebih panjang dari baris → potong keras
      if (textWidth(w, size) > maxWidth) {
        let chunk = ''
        for (const ch of w) {
          if (textWidth(chunk + ch, size) > maxWidth) {
            lines.push(chunk)
            chunk = ch
          } else {
            chunk += ch
          }
        }
        cur = chunk
      } else {
        cur = w
      }
      if (lines.length >= maxLines) break
    }
  }
  if (cur && lines.length < maxLines) lines.push(cur)
  if (lines.length > maxLines) lines.length = maxLines
  return lines
}

/* ---------- builder halaman ---------- */

class PdfPage {
  ops: string[] = []

  text(x: number, y: number, font: 'F1' | 'F2' | 'F3', size: number, color: readonly number[], str: string) {
    this.ops.push(
      `BT ${fmtColor(color)} rg /${font} ${size} Tf 1 0 0 1 ${x.toFixed(2)} ${y.toFixed(2)} Tm (${pdfEscape(str)}) Tj ET`,
    )
  }

  rect(x: number, y: number, w: number, h: number, color: readonly number[]) {
    this.ops.push(`${fmtColor(color)} rg ${x.toFixed(2)} ${y.toFixed(2)} ${w.toFixed(2)} ${h.toFixed(2)} re f`)
  }

  line(x1: number, y1: number, x2: number, y2: number, color: readonly number[], width = 0.7) {
    this.ops.push(
      `${fmtColor(color)} RG ${width} w ${x1.toFixed(2)} ${y1.toFixed(2)} m ${x2.toFixed(2)} ${y2.toFixed(2)} l S`,
    )
  }
}

/* ---------- data layout ---------- */

const PAGE_W = 595
const PAGE_H = 842
const M = 40 // margin
const CONTENT_W = PAGE_W - M * 2
const FOOTER_Y = 46

/* ---------- gambar konten ---------- */

function drawHeader(page: PdfPage, payload: PdfReportPayload, dateStr: string, isFirst: boolean) {
  if (isFirst) {
    page.rect(0, PAGE_H - 74, PAGE_W, 74, C.bgDark)
    page.rect(0, PAGE_H - 77, PAGE_W, 3, C.green)
    page.text(M, PAGE_H - 34, 'F1', 17, C.white, 'BugHunter ID')
    page.text(M, PAGE_H - 50, 'F2', 8.5, C.textGray, pdfEscape(`Laporan Pemindaian Kode — ${payload.kind === 'workspace' ? 'Workspace Multi-File' : 'Editor Tunggal'}`).replace(/\\/g, ''))
    if (payload.title) page.text(M, PAGE_H - 63, 'F3', 7.5, C.textDim, payload.title)
    const dw = textWidth(dateStr, 8)
    page.text(PAGE_W - M - dw, PAGE_H - 34, 'F2', 8, C.textGray, dateStr)
  } else {
    page.rect(0, PAGE_H - 40, PAGE_W, 40, C.bgDark)
    page.text(M, PAGE_H - 25, 'F1', 9, C.white, 'BugHunter ID — Laporan Pemindaian (lanjutan)')
    const dw = textWidth(dateStr, 7.5)
    page.text(PAGE_W - M - dw, PAGE_H - 25, 'F2', 7.5, C.textGray, dateStr)
  }
}

function drawFooter(page: PdfPage, pageNo: number, total: number, dateStr: string) {
  page.line(M, FOOTER_Y + 14, PAGE_W - M, FOOTER_Y + 14, C.border, 0.7)
  page.text(M, FOOTER_Y, 'F2', 7, C.textDim, `Dihasilkan otomatis oleh mesin rule-based BugHunter ID pada ${dateStr}`)
  const p = `Halaman ${pageNo} dari ${total}`
  const pw = textWidth(p, 7)
  page.text(PAGE_W - M - pw, FOOTER_Y, 'F2', 7, C.textDim, p)
}

function drawSummary(page: PdfPage, payload: PdfReportPayload) {
  const s = payload.summary
  const top = PAGE_H - 108
  const h = 62

  // kotak skor kesehatan
  const scoreColor =
    s.healthScore >= 80 ? C.green : s.healthScore >= 55 ? C.medium : C.critical
  page.rect(M, top, 104, h, C.panel)
  page.rect(M, top, 104, 2, scoreColor)
  page.text(M + 10, top - 14, 'F2', 6.5, C.textGray, 'SKOR KESEHATAN')
  page.text(M + 10, top - 40, 'F1', 24, scoreColor, String(s.healthScore))
  page.text(M + 62, top - 38, 'F2', 7, C.textDim, '/ 100')

  // 4 kotak severity
  const boxes: Array<{ label: string; value: number; color: readonly number[] }> = [
    { label: 'KRITIS', value: s.criticalCount, color: C.critical },
    { label: 'TINGGI', value: s.highCount, color: C.high },
    { label: 'SEDANG', value: s.mediumCount, color: C.medium },
    { label: 'RENDAH', value: s.lowCount, color: C.low },
  ]
  let bx = M + 114
  for (const b of boxes) {
    page.rect(bx, top, 100, h, C.panel)
    page.rect(bx, top, 100, 2, b.color)
    page.text(bx + 10, top - 14, 'F2', 6.5, b.color, b.label)
    page.text(bx + 10, top - 40, 'F1', 20, C.textLight, String(b.value))
    bx += 108
  }

  // baris meta
  const meta: string[] = []
  if (payload.kind === 'workspace') {
    meta.push(`${s.fileCount ?? payload.files.length} berkas`)
    if (s.totalLines) meta.push(`${s.totalLines} baris`)
  } else if (s.totalLines) {
    meta.push(`${s.totalLines} baris`)
  }
  if (s.crossFileCount) meta.push(`${s.crossFileCount} temuan lintas berkas`)
  if (s.depCount) meta.push(`${s.depCount} temuan dependensi`)
  meta.push(`total ${s.bugCount} temuan`)
  page.text(M, top - 34, 'F2', 8, C.textGray, meta.join('   |   '))

  return top - 34 // y awal konten berikutnya
}

function drawFileSection(
  page: PdfPage,
  file: PdfFileReport,
  startY: number,
  bugIdx: number,
): { y: number; drawn: number } {
  let y = startY

  // header bagian berkas
  const verdictColor = file.healthScore >= 80 ? C.green : file.healthScore >= 55 ? C.medium : C.critical
  page.rect(M, y - 14, 3, 16, verdictColor)
  page.text(M + 10, y - 12, 'F1', 10, C.textLight, file.name)
  const langLine = `bahasa: ${file.language}`
  page.text(M + 10 + textWidth(file.name, 10) + 12, y - 12, 'F2', 7.5, C.textDim, langLine)
  const rightText = `${file.bugCount} temuan - skor ${file.healthScore}`
  const rw = textWidth(rightText, 8)
  page.text(PAGE_W - M - rw, y - 12, 'F2', 8, verdictColor, rightText)
  y -= 26

  let drawn = 0
  for (let i = bugIdx; i < file.bugs.length; i++) {
    const bug = file.bugs[i]
    const color = SEV_COLOR[bug.severity] ?? C.low
    const descLines = bug.description ? wrapText(bug.description, 8, CONTENT_W - 20, 3) : []
    const sugLines = bug.suggestion ? wrapText(`Saran: ${bug.suggestion}`, 8, CONTENT_W - 20, 2) : []
    const titleLines = wrapText(bug.title, 9, CONTENT_W - 20, 2)
    const blockH = 16 + titleLines.length * 11 + descLines.length * 10 + sugLines.length * 10 + 10

    if (y - blockH < FOOTER_Y + 24) break // pindah halaman

    // chip severity
    page.rect(M, y - 6, 6, 6, color)
    page.text(M + 12, y - 6, 'F1', 7, color, SEV_LABEL[bug.severity])
    page.text(M + 52, y - 6, 'F2', 7, C.textGray, `Baris ${bug.line}`)
    page.text(M + 112, y - 6, 'F2', 7, C.textGray, bug.category)

    let ty = y - 17
    for (const t of titleLines) {
      page.text(M + 12, ty, 'F1', 9, C.textLight, t)
      ty -= 11
    }
    for (const d of descLines) {
      page.text(M + 12, ty, 'F2', 8, C.textGray, d)
      ty -= 10
    }
    for (const sg of sugLines) {
      page.text(M + 12, ty, 'F2', 8, C.green, sg)
      ty -= 10
    }

    page.line(M + 12, ty + 4, PAGE_W - M, ty + 4, C.border, 0.4)
    y = ty - 8
    drawn++
  }

  return { y, drawn }
}

function drawCleanList(page: PdfPage, cleanFiles: PdfFileReport[], startY: number): number {
  if (cleanFiles.length === 0) return startY
  const names = cleanFiles.map(f => f.name)
  const lines: string[] = []
  let cur = ''
  for (const n of names) {
    const cand = cur ? `${cur},  ${n}` : n
    if (textWidth(cand, 8) <= CONTENT_W - 10) cur = cand
    else {
      if (cur) lines.push(cur)
      cur = n
    }
  }
  if (cur) lines.push(cur)

  let y = startY
  page.rect(M, y - 12, 3, 13, C.green)
  page.text(M + 10, y - 10, 'F1', 9.5, C.green, `BERKAS BERSIH (${cleanFiles.length})`)
  y -= 26
  for (const l of lines) {
    if (y < FOOTER_Y + 24) break
    page.text(M + 10, y, 'F2', 8, C.textGray, l)
    y -= 12
  }
  return y
}

/* ---------- perakitan PDF ---------- */

function buildPdf(pages: PdfPage[]): Uint8Array {
  const objects: string[] = []
  const pageCount = pages.length

  // 1: catalog, 2: pages, 3-5: fonts, 6+: page & content pairs
  const pageObjIds = pages.map((_, i) => 6 + i * 2)

  objects[1] = `<< /Type /Catalog /Pages 2 0 R >>`
  objects[2] = `<< /Type /Pages /Kids [${pageObjIds.map(id => `${id} 0 R`).join(' ')}] /Count ${pageCount} >>`
  objects[3] = `<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>`
  objects[4] = `<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>`
  objects[5] = `<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Oblique /Encoding /WinAnsiEncoding >>`

  pages.forEach((p, i) => {
    const pageId = 6 + i * 2
    const contentId = pageId + 1
    const content = p.ops.join('\n')
    objects[pageId] =
      `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${PAGE_W} ${PAGE_H}] ` +
      `/Resources << /Font << /F1 3 0 R /F2 4 0 R /F3 5 0 R >> >> /Contents ${contentId} 0 R >>`
    objects[contentId] = `<< /Length ${content.length} >>\nstream\n${content}\nendstream`
  })

  let out = '%PDF-1.4\n'
  const offsets: number[] = []
  for (let i = 1; i < objects.length; i++) {
    offsets[i] = out.length
    out += `${i} 0 obj\n${objects[i]}\nendobj\n`
  }
  const xrefStart = out.length
  out += `xref\n0 ${objects.length}\n0000000000 65535 f \n`
  for (let i = 1; i < objects.length; i++) {
    out += `${String(offsets[i]).padStart(10, '0')} 00000 n \n`
  }
  out += `trailer\n<< /Size ${objects.length} /Root 1 0 R >>\nstartxref\n${xrefStart}\n%%EOF\n`

  const bytes = new Uint8Array(out.length)
  for (let i = 0; i < out.length; i++) bytes[i] = out.charCodeAt(i) & 0xff
  return bytes
}

/** Tanggal Indonesia: "13 Okt 2026 15:30". */
export function formatIndoDate(d = new Date()): string {
  const bulan = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des']
  const pad = (n: number) => String(n).padStart(2, '0')
  return `${pad(d.getDate())} ${bulan[d.getMonth()]} ${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}`
}

/**
 * Bangun PDF laporan dari payload hasil pemindaian.
 * Semua halaman diberi header + footer; konten mengalir dengan
 * pemenggalan halaman otomatis.
 */
export function buildPdfReport(payload: PdfReportPayload): Uint8Array {
  const dateStr = formatIndoDate()
  const pages: PdfPage[] = []
  let page = new PdfPage()
  pages.push(page)

  drawHeader(page, payload, dateStr, true)
  let y = drawSummary(page, payload)

  const newPage = () => {
    page = new PdfPage()
    pages.push(page)
    drawHeader(page, payload, dateStr, false)
    y = PAGE_H - 60
  }

  const withBugs = payload.files.filter(f => f.bugs.length > 0)
  const cleanFiles = payload.files.filter(f => f.bugs.length === 0)

  for (const file of withBugs) {
    let bugIdx = 0
    while (bugIdx < file.bugs.length) {
      if (y < FOOTER_Y + 90) newPage()
      const res = drawFileSection(page, file, y, bugIdx)
      if (res.drawn === 0) {
        // tidak muat sama sekali di halaman ini → pindah halaman dan ulangi
        newPage()
        const res2 = drawFileSection(page, file, y, bugIdx)
        if (res2.drawn === 0) break // guard anti loop abadi
        bugIdx += res2.drawn
        y = res2.y
      } else {
        bugIdx += res.drawn
        y = res.y
      }
      if (bugIdx < file.bugs.length) newPage()
    }
  }

  // daftar berkas bersih
  if (cleanFiles.length > 0) {
    if (y < FOOTER_Y + 80) newPage()
    drawCleanList(page, cleanFiles, y)
  }

  // catatan kaki laporan (di bawah garis footer, hanya halaman terakhir)
  page.text(
    M,
    FOOTER_Y - 9,
    'F3',
    7,
    C.textDim,
    'Catatan: hasil pemindaian bersifat otomatis (rule-based offline) dan bukan pengganti code review manusia. Auto-fix hanya menyentuh kelas bug yang terbukti aman.',
  )

  // footer
  pages.forEach((p, i) => drawFooter(p, i + 1, pages.length, dateStr))
  return buildPdf(pages)
}
