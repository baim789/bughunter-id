import type { Severity } from './types'

/**
 * ============================================================
 *  ADVISORY DEPENDENSI LOKAL (OFFLINE) — BugHunter ID
 * ============================================================
 * Basis data kecil kerentanan yang DIKETAHUI (CVE publik) untuk
 * paket yang paling sering dipakai. Ditanam di kode agar pemindaian
 * berjalan 100% offline — TIDAK menggantikan `npm audit` /
 * `pip-audit` yang selalu terbaru; ini lapisan cepat + edukatif.
 *
 * Format: paket → daftar ambang. "fixedIn" = versi pertama yang
 * sudah memuat perbaikan. Versi terpasang < fixedIn → rentan.
 * ============================================================
 */

export interface Advisory {
  fixedIn: string
  severity: Severity
  cve: string
  title: string
}

export const NPM_ADVISORIES: Record<string, Advisory[]> = {
  lodash: [
    { fixedIn: '4.17.21', severity: 'high', cve: 'CVE-2021-23337', title: 'Command injection via template' },
  ],
  axios: [
    { fixedIn: '0.21.4', severity: 'high', cve: 'CVE-2021-3749', title: 'ReDoS pada trim' },
    { fixedIn: '1.6.0', severity: 'high', cve: 'CVE-2023-45857', title: 'Kebocoran token XSRF ke host pihak ketiga' },
  ],
  express: [
    { fixedIn: '4.19.2', severity: 'medium', cve: 'CVE-2024-29041', title: 'Open redirect pada res.location/res.redirect' },
  ],
  jsonwebtoken: [
    { fixedIn: '9.0.0', severity: 'high', cve: 'CVE-2022-23529', title: 'Verifikasi token dapat ditipu (type confusion)' },
  ],
  'node-fetch': [
    { fixedIn: '2.6.7', severity: 'high', cve: 'CVE-2022-0235', title: 'Header Authorization bocor ke server lain saat redirect' },
  ],
  moment: [
    { fixedIn: '2.29.4', severity: 'medium', cve: 'CVE-2022-24785', title: 'Path traversal pada locale' },
  ],
  minimist: [
    { fixedIn: '1.2.6', severity: 'high', cve: 'CVE-2021-44906', title: 'Prototype pollution' },
  ],
  qs: [
    { fixedIn: '6.9.7', severity: 'high', cve: 'CVE-2022-24999', title: 'DoS melalui parse object' },
  ],
  ejs: [
    { fixedIn: '3.1.7', severity: 'critical', cve: 'CVE-2022-29078', title: 'RCE via settings[view options]' },
  ],
  'ansi-regex': [
    { fixedIn: '5.0.1', severity: 'medium', cve: 'CVE-2021-3807', title: 'ReDoS' },
  ],
  'glob-parent': [
    { fixedIn: '5.1.2', severity: 'medium', cve: 'CVE-2021-3507', title: 'ReDoS' },
  ],
  merge: [
    { fixedIn: '2.1.1', severity: 'high', cve: 'CVE-2020-28498', title: 'Prototype pollution' },
  ],
  ws: [
    { fixedIn: '7.5.10', severity: 'high', cve: 'CVE-2024-37890', title: 'DoS pada pemrosesan header DoS' },
  ],
  'follow-redirects': [
    { fixedIn: '1.15.6', severity: 'high', cve: 'CVE-2024-28849', title: 'Kebocoran header sensitif saat redirect' },
  ],
  'cross-spawn': [
    { fixedIn: '7.0.5', severity: 'high', cve: 'CVE-2024-21538', title: 'ReDoS' },
  ],
  micromatch: [
    { fixedIn: '4.0.8', severity: 'high', cve: 'CVE-2024-40689', title: 'NPM audit — brute-force/DoS' },
  ],
  braces: [
    { fixedIn: '3.0.3', severity: 'high', cve: 'CVE-2024-4068', title: 'ReDoS berkepanjangan' },
  ],
  'node-serialize': [
    { fixedIn: '0.0.4', severity: 'critical', cve: 'CVE-2017-5941', title: 'RCE via deserialize fungsi tak dipercaya' },
  ],
}

export const PYPI_ADVISORIES: Record<string, Advisory[]> = {
  django: [
    { fixedIn: '3.2.25', severity: 'high', cve: 'CVE-2024-27351', title: 'ReDoS pada django.utils.text.Truncator' },
  ],
  flask: [
    { fixedIn: '2.2.5', severity: 'high', cve: 'CVE-2023-30861', title: 'Cookie session bocor tanpa Vary: Cookie' },
  ],
  requests: [
    { fixedIn: '2.31.0', severity: 'medium', cve: 'CVE-2023-32681', title: 'Proxy-Authorization bocor saat redirect HTTPS' },
  ],
  jinja2: [
    { fixedIn: '3.1.3', severity: 'medium', cve: 'CVE-2023-30861', title: 'XSS via xmlattr filter' },
    { fixedIn: '3.1.5', severity: 'high', cve: 'CVE-2024-56201', title: 'Sandbox escape via filename template' },
  ],
  pyyaml: [
    { fixedIn: '5.4', severity: 'critical', cve: 'CVE-2020-14343', title: 'RCE via load() tanpa SafeLoader' },
  ],
  pillow: [
    { fixedIn: '10.0.1', severity: 'high', cve: 'CVE-2023-44271', title: 'Buffer overflow eksternal gambar' },
  ],
  werkzeug: [
    { fixedIn: '2.3.8', severity: 'high', cve: 'CVE-2023-25577', title: 'DoS multipart parser' },
  ],
  urllib3: [
    { fixedIn: '1.26.17', severity: 'high', cve: 'CVE-2023-43804', title: 'Cookie bocor saat redirect lintas-origin' },
  ],
  tornado: [
    { fixedIn: '6.3.3', severity: 'medium', cve: 'CVE-2023-28370', title: 'Open redirect pada static_url' },
  ],
  certifi: [
    { fixedIn: '2023.7.22', severity: 'high', cve: 'CVE-2023-37920', title: 'CA root e-Tugra tidak tepercaya' },
  ],
  sqlparse: [
    { fixedIn: '0.4.4', severity: 'high', cve: 'CVE-2023-30608', title: 'DoS pada parsing kolom' },
  ],
  paramiko: [
    { fixedIn: '3.4.0', severity: 'medium', cve: 'CVE-2024-34067', title: 'Bypass verifikasi hostkey di Transport' },
  ],
}

/* ---------- pembanding versi ---------- */

function splitVersion(v: string): { nums: number[]; prerelease: boolean } {
  const clean = v.trim().replace(/^v/i, '').split('+')[0]
  const [core, suffix] = clean.split('-')
  const nums = core
    .split('.')
    .map(s => parseInt(s.replace(/[^0-9].*$/, ''), 10) || 0)
  while (nums.length < 3) nums.push(0)
  const prerelease = Boolean(suffix) || /[a-zA-Z]/.test(core)
  return { nums, prerelease }
}

/** true bila a < b (pra-rilis dianggap lebih rendah dari rilis dengan nomor sama). */
export function versionLt(a: string, b: string): boolean {
  const A = splitVersion(a)
  const B = splitVersion(b)
  for (let i = 0; i < 3; i++) {
    if (A.nums[i] !== B.nums[i]) return A.nums[i] < B.nums[i]
  }
  if (A.prerelease !== B.prerelease) return A.prerelease
  return false
}

/* ---------- parser manifest ---------- */

export interface DepEntry {
  name: string
  version: string
  line: number
}

export function parsePackageJson(text: string): DepEntry[] {
  const out: DepEntry[] = []
  let json: unknown
  try {
    json = JSON.parse(text)
  } catch {
    return out
  }
  const obj = json as { dependencies?: Record<string, string>; devDependencies?: Record<string, string> }
  const lines = text.split('\n')
  const collect = (deps: Record<string, string> | undefined) => {
    if (!deps) return
    for (const [name, range] of Object.entries(deps)) {
      // ambil versi dari range: ^1.2.3 / ~2.0 / 3.1.4 / >=1.0 <2 — ambil angka pertama yang masuk akal
      const m = /(\d+\.\d+(?:\.\d+)?)/.exec(range)
      if (!m) continue
      let line = 1
      for (let i = 0; i < lines.length; i++) {
        if (lines[i].includes(`"${name}"`)) {
          line = i + 1
          break
        }
      }
      out.push({ name, version: m[1], line })
    }
  }
  collect(obj.dependencies)
  collect(obj.devDependencies)
  return out
}

export function parseRequirementsTxt(text: string): DepEntry[] {
  const out: DepEntry[] = []
  text.split('\n').forEach((line, idx) => {
    const bare = line.split('#')[0].trim()
    if (!bare || bare.startsWith('-')) return
    const m = /^([A-Za-z0-9_.-]+)\s*[=<>!~]+\s*([0-9][\w.*-]*)/.exec(bare)
    if (!m) return
    out.push({ name: m[1], version: m[2].replace(/\*$/, '0'), line: idx + 1 })
  })
  return out
}

/* ---------- pemindaian ---------- */

export interface DepFinding {
  pkg: string
  version: string
  fixedIn: string
  severity: Severity
  cve: string
  title: string
  line: number
}

function scanEntries(entries: DepEntry[], advisories: Record<string, Advisory[]>): DepFinding[] {
  const findings: DepFinding[] = []
  for (const e of entries) {
    const list = advisories[e.name.toLowerCase()]
    if (!list) continue
    for (const adv of list) {
      if (versionLt(e.version, adv.fixedIn)) {
        findings.push({
          pkg: e.name,
          version: e.version,
          fixedIn: adv.fixedIn,
          severity: adv.severity,
          cve: adv.cve,
          title: adv.title,
          line: e.line,
        })
      }
    }
  }
  return findings
}

/** Pindai package.json (npm) — return temuan CVE yang diketahui. */
export function scanPackageJson(text: string): DepFinding[] {
  return scanEntries(parsePackageJson(text), NPM_ADVISORIES)
}

/** Pindai requirements.txt (pip) — return temuan CVE yang diketahui. */
export function scanRequirementsTxt(text: string): DepFinding[] {
  return scanEntries(parseRequirementsTxt(text), PYPI_ADVISORIES)
}
