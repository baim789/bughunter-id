/* BugHunter ID — agent store untuk UI 3 kolom (Chat | Workspace | Terminal).
 *
 * Orkestrasi alur kerja agen:
 *   terima file → pindai (terminal) → ajukan opsi persetujuan di chat →
 *   eksekusi perbaikan (otomatis aman / berpandu lintas file) → verifikasi
 *   ulang → unduh hasil kerja (ZIP / PDF).
 *
 * Prinsip:
 *  - Semua log proses mengalir ke terminal; jumlah terminal menyesuaikan
 *    kompleksitas bug (bug lintas file → beberapa terminal paralel).
 *  - Semua keputusan penting lewat opsi tombol di chat (persetujuan pengguna).
 *  - Bug per-file aman → auto-fix massal; bug struktural lintas file →
 *    perbaikan berpandu per temuan (anti-kerusakan).
 */

import { create } from 'zustand'
import { toast } from '@/hooks/use-toast'
import { WORKSPACE_SAMPLES } from '@/lib/samples'
import { FIXABLE_RULE_IDS } from '@/lib/detector/fixers'
import { getDisabledRules } from '@/lib/rule-settings'
import { downloadPdfReport } from '@/lib/report-client'
import { agentRoom, connectAgentSocket, isSocketLive, type AgentSocketEvent } from '@/lib/agent-socket'
import type { DiffLine } from '@/lib/diff'
import type {
  GuidedFixOption,
  GuidedFixResponse,
  Severity,
  WorkspaceFileInput,
  WorkspaceFixResponse,
  WorkspaceScanResult,
} from '@/lib/types'

/* ============================ tipe publik ============================ */

export type Tone = 'cmd' | 'ok' | 'warn' | 'err' | 'info' | 'dim'

export interface TerminalLine {
  text: string
  tone: Tone
}

export interface AgentTerminal {
  id: string
  title: string
  subtitle: string
  lines: TerminalLine[]
  status: 'running' | 'done' | 'error'
  /** Terminal yang digerakkan server (log real-time via socket) — key dari server. */
  remoteId?: string
}

export type AgentAction =
  | { type: 'scan' }
  | { type: 'auto-fix' }
  | { type: 'guided'; option: GuidedFixOption; confirmed?: boolean }
  | { type: 'propose-guided' }
  | { type: 'pdf' }
  | { type: 'zip'; mode: 'fixed' | 'original' }
  | { type: 'export'; format: 'sarif' | 'json' }
  | { type: 'ci-workflow' }
  | { type: 'github'; url: string }
  | { type: 'sample'; key: string }
  | { type: 'help' }
  | { type: 'clear-workspace' }
  | { type: 'session-continue'; id: string }
  | { type: 'session-list' }
  | { type: 'session-fresh' }

export interface DiffPreview {
  file: string
  added: number
  removed: number
  isNew?: boolean
  lines: DiffLine[]
}

export interface ChatOption {
  id: string
  label: string
  detail?: string
  badge?: string
  badgeTone?: 'safe' | 'caution' | 'info'
  action: AgentAction
}

export interface ChatMessage {
  id: string
  role: 'user' | 'agent'
  kind: 'text' | 'options' | 'summary' | 'fix-summary' | 'diff'
  ts: number
  text?: string
  tone?: 'normal' | 'error'
  options?: ChatOption[]
  scan?: WorkspaceScanResult
  fix?: { applied: number; skipped: number; files: string[] }
  /** Pratinjau diff perbaikan berpandu (kind: 'diff'). */
  diffs?: DiffPreview[]
  /** Penanda jawaban dari AI GLM (ditampilkan dengan ikon berbeda). */
  via?: 'ai'
}

export type AgentPhase = 'idle' | 'scanning' | 'awaiting' | 'fixing' | 'thinking'

export const PHASE_LABEL: Record<AgentPhase, string> = {
  idle: 'Siaga',
  scanning: 'Memindai…',
  awaiting: 'Menunggu persetujuan',
  fixing: 'Memperbaiki…',
  thinking: 'GLM berpikir…',
}

export interface SessionMeta {
  id: string
  title: string
  messageCount: number
  fileCount: number
  bugCount: number
  healthScore: number
  createdAt: string
  updatedAt: string
}

/* ============================ konstanta ============================ */

const MAX_FILES = 200
const MAX_FILE_BYTES = 200_000

const HELP_TEXT = `Bantuan singkat — cara kerja saya:
• Unggah file: klik ikon klip di bawah, atau seret file/ZIP ke panel chat. File masuk ke kolom Workspace.
• Impor repositori: ketik "impor github https://github.com/pemilik/repo" — seluruh berkas teks proyek publik masuk ke workspace.
• Ketik "pindai": saya periksa semua file, termasuk analisis lintas file (import melingkar, argumen tak cocok, kredensial bersama, SQL injection, CVE dependensi) untuk JS/TS, Python, Go, PHP, dan Java.
• Ketik "perbaiki": bug per-file yang terbukti aman saya perbaiki otomatis di semua file (kode asli bisa dikembalikan).
• Bug bandel lintas file: saya ajukan pilihan solusi di chat lengkap dengan pratinjau diff — kamu setujui, saya eksekusi persis sesuai persetujuanmu.
• Ketik "ekspor sarif" atau "ekspor json" untuk hasil format CI/CD (GitHub Code Scanning mendukung SARIF).
• Ketik "workflow ci" — saya sediakan file GitHub Actions siap pakai: setiap push/PR repo kamu dipindai otomatis dan hasil SARIF diunggah ke Code Scanning.
• Tanya bebas: tulis pertanyaan apa pun — saya jawab lewat AI GLM dengan konteks file & hasil pemindaianmu.
• Ketik "unduh zip" atau "laporan pdf" untuk mengambil hasil kerja. Masuk lewat tombol Masuk agar riwayat sesi menempel ke akunmu.
• Jumlah terminal menyesuaikan kompleksitas: bug lintas file membuka beberapa terminal paralel — log progres datang LANGSUNG dari server.`

/* ============================ util ============================ */

let seq = 0
const uid = () => `${Date.now().toString(36)}-${(seq++).toString(36)}-${Math.random().toString(36).slice(2, 6)}`
const sleep = (ms: number) => new Promise<void>(r => setTimeout(r, ms))
const shortName = (p: string) => p.split('/').pop() ?? p

function mergeNames(existing: WorkspaceFileInput[], incoming: WorkspaceFileInput[]): WorkspaceFileInput[] {
  const taken = new Set(existing.map(f => f.name))
  const out: WorkspaceFileInput[] = []
  for (const f of incoming) {
    let name = f.name
    let n = 2
    while (taken.has(name)) {
      const dot = name.lastIndexOf('.')
      name = dot > 0 ? `${name.slice(0, dot)}-${n}${name.slice(dot)}` : `${name}-${n}`
      n++
    }
    taken.add(name)
    out.push({ name, code: f.code })
  }
  return out
}

async function apiJson(url: string, body: unknown): Promise<{ ok: boolean; data: Record<string, unknown> }> {
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  })
  const data = await res.json().catch(() => ({}))
  return { ok: res.ok, data: data as Record<string, unknown> }
}

function triggerDownload(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  document.body.appendChild(a)
  a.click()
  a.remove()
  URL.revokeObjectURL(url)
}

function countFixable(scan: WorkspaceScanResult): number {
  return scan.files.reduce(
    (n, f) => n + f.bugs.filter(b => b.ruleId && FIXABLE_RULE_IDS.has(b.ruleId)).length,
    0,
  )
}

function sampleOptions(): ChatOption[] {
  const opts: ChatOption[] = Object.entries(WORKSPACE_SAMPLES).map(([key, s]) => ({
    id: `sample-${key}`,
    label: `Muat contoh: ${s.label}`,
    detail: s.description,
    badge: 'DEMO',
    badgeTone: 'info' as const,
    action: { type: 'sample', key } as AgentAction,
  }))
  opts.push({ id: 'help', label: 'Bantuan cara kerja', action: { type: 'help' } })
  return opts
}

type Intent = 'scan' | 'fix' | 'pdf' | 'zip' | 'export' | 'ci' | 'github' | 'sample' | 'help' | 'sessions' | 'unknown'

function parseIntent(text: string): Intent {
  const t = text.toLowerCase()
  if (/github\.com|\bimpor\s+github\b|\bimport\s+github\b|\bdari\s+github\b/.test(t)) return 'github'
  if (/\bworkflow\b|github\s+actions/.test(t)) return 'ci'
  if (/\bsarif\b/.test(t)) return 'export'
  if (/(ekspor|export)\s+(json|hasil)/.test(t) || /\bci\s*\/\s*cd\b/.test(t)) return 'export'
  if (/(pindai|scan|analisis|analisa|periksa|cek\b)/.test(t)) return 'scan'
  if (/(perbaiki|benahi|fix)/.test(t)) return 'fix'
  if (/(laporan|pdf)/.test(t)) return 'pdf'
  if (/(unduh|download|\bzip\b)/.test(t)) return 'zip'
  if (/(contoh|sampel|sample|demo)/.test(t)) return 'sample'
  if (/^(riwayat|daftar sesi|sesi saya|sesi tersimpan)/.test(t)) return 'sessions'
  if (/(bantuan|help|halo|^hai|hallo)/.test(t)) return 'help'
  return 'unknown'
}

function deriveTitle(messages: ChatMessage[]): string {
  const firstUser = messages.find(m => m.role === 'user' && m.text)
  if (firstUser?.text) {
    // echo klik opsi diawali "✓ " — buang agar judul sesi bersih
    const clean = firstUser.text.replace(/^✓\s*/, '').replace(/\s+/g, ' ').trim().slice(0, 60)
    return clean || 'Sesi agen'
  }
  return 'Sesi agen'
}

/* ============================ store ============================ */

interface AgentState {
  messages: ChatMessage[]
  terminals: AgentTerminal[]
  activeTerminalId: string | null
  files: WorkspaceFileInput[]
  scan: WorkspaceScanResult | null
  phase: AgentPhase
  busy: boolean
  chosen: Record<string, string>
  mobileTab: 'chat' | 'workspace' | 'terminal'
  /** true bila log real-time dari server terhubung (socket.io). */
  socketLive: boolean
  /** id sesi tersimpan di DB (null = belum pernah tersimpan). */
  sessionId: string | null
  /** sudah mencoba memeriksa riwayat sesi saat halaman dibuka. */
  restoreChecked: boolean

  sendText: (text: string) => Promise<void>
  handleFiles: (list: File[]) => Promise<void>
  chooseOption: (msgId: string, optionId: string) => Promise<void>
  dispatch: (action: AgentAction) => Promise<void>

  runScan: () => Promise<void>
  runAutoFix: () => Promise<void>
  proposeGuided: () => void
  runGuided: (option: GuidedFixOption, confirmed?: boolean) => Promise<void>
  downloadZip: (mode: 'fixed' | 'original') => Promise<void>
  downloadPdf: () => Promise<void>
  downloadExport: (format: 'sarif' | 'json') => Promise<void>
  runGithubImport: (url: string) => Promise<void>
  loadSample: (key: string) => void
  addFiles: (incoming: WorkspaceFileInput[]) => void
  clearWorkspace: () => void

  /** Sambungkan log real-time (dipanggil dari client effect). */
  initLive: () => void
  /** Dipanggil sekali dari client saat halaman dibuka: tawarkan lanjutkan sesi terakhir. */
  initRestore: () => Promise<void>
  loadSession: (id: string) => Promise<void>
  /** Izinkan pemeriksaan riwayat lagi (mis. setelah login/logout). */
  resetRestoreCheck: () => void

  setActiveTerminal: (id: string) => void
  closeTerminal: (id: string) => void
  clearFinishedTerminals: () => void
  setMobileTab: (tab: 'chat' | 'workspace' | 'terminal') => void
}

export const useAgentStore = create<AgentState>()((set, get) => {
  /* ---------- helper internal ---------- */

  const pushMessage = (m: Omit<ChatMessage, 'id' | 'ts'>) => {
    const id = uid()
    set(s => ({ messages: [...s.messages, { ...m, id, ts: Date.now() }] }))
    return id
  }

  const addTerminal = (title: string, subtitle = '') => {
    const id = `t-${uid()}`
    set(s => ({
      terminals: [...s.terminals, { id, title, subtitle, lines: [], status: 'running' as const }],
      activeTerminalId: id,
    }))
    return id
  }

  const line = (id: string, text: string, tone: Tone = 'info') =>
    set(s => ({
      terminals: s.terminals.map(t =>
        t.id === id ? { ...t, lines: [...t.lines, { text, tone }] } : t,
      ),
    }))

  const finishTerminal = (id: string, status: 'done' | 'error' = 'done') =>
    set(s => ({
      terminals: s.terminals.map(t => (t.id === id ? { ...t, status } : t)),
    }))

  /* ---------- log real-time dari server (socket.io) ---------- */

  const applyRemoteEvent = (e: AgentSocketEvent) => {
    set(s => {
      const idx = s.terminals.findIndex(t => t.remoteId === e.term)
      if (e.kind === 'open') {
        if (idx >= 0) return {}
        const id = `t-${uid()}`
        return {
          terminals: [
            ...s.terminals,
            { id, remoteId: e.term, title: e.title ?? e.term, subtitle: e.subtitle ?? 'server', lines: [], status: 'running' as const },
          ],
          activeTerminalId: id,
        }
      }
      if (idx < 0) {
        // line/status tanpa open — buka terminal diam-diam agar tidak ada log hilang
        const id = `t-${uid()}`
        const terminals = [
          ...s.terminals,
          { id, remoteId: e.term, title: e.title ?? e.term, subtitle: 'server', lines: [], status: 'running' as const },
        ]
        if (e.kind === 'line' && e.text) {
          terminals[terminals.length - 1]!.lines.push({ text: e.text, tone: (e.tone ?? 'info') as Tone })
        }
        if (e.kind === 'status' && (e.status === 'done' || e.status === 'error')) {
          terminals[terminals.length - 1]!.status = e.status
        }
        return { terminals, activeTerminalId: id }
      }
      const terminals = [...s.terminals]
      const t = { ...terminals[idx]!, lines: [...terminals[idx]!.lines] }
      if (e.kind === 'line' && e.text) t.lines.push({ text: e.text, tone: (e.tone ?? 'info') as Tone })
      if (e.kind === 'status' && (e.status === 'done' || e.status === 'error')) t.status = e.status
      terminals[idx] = t
      return { terminals }
    })
  }

  const initLive = () => {
    if (typeof window === 'undefined') return
    connectAgentSocket(applyRemoteEvent, live => set({ socketLive: live }))
  }

  const rescanQuiet = async (): Promise<WorkspaceScanResult | null> => {
    const files = get().files
    if (files.length === 0) return null
    const live = isSocketLive()
    const t = live ? null : addTerminal('verifikasi', 'pindai ulang otomatis')
    if (t) {
      line(t, '$ bughunter scan --verifikasi', 'cmd')
      line(t, `> Memindai ulang ${files.length} file...`, 'dim')
    }
    const { ok, data } = await apiJson('/api/workspace/analyze', {
      files,
      disabledRules: getDisabledRules(),
      room: agentRoom(),
    })
    if (!ok) {
      if (t) {
        line(t, `✗ ${String(data.error ?? 'Gagal memindai ulang')}`, 'err')
        finishTerminal(t, 'error')
      }
      return null
    }
    const scan = data.scan as WorkspaceScanResult
    set({ scan })
    const sisa = scan.bugCount
      ? `${scan.bugCount} temuan tersisa${scan.crossFileCount ? ` (${scan.crossFileCount} lintas file)` : ''}`
      : 'tidak ada temuan tersisa'
    if (t) {
      line(t, `✓ Skor kesehatan ${scan.healthScore}/100 — ${sisa}`, 'ok')
      finishTerminal(t)
    }
    return scan
  }

  const scanOptions = (scan: WorkspaceScanResult): ChatOption[] => {
    const opts: ChatOption[] = []
    const fixable = countFixable(scan)
    if (fixable > 0) {
      opts.push({
        id: 'auto-fix',
        label: `Perbaiki otomatis (${fixable} bug aman)`,
        detail: 'Hanya kelas bug terbukti aman; diterapkan di semua file; kode asli bisa dikembalikan (undo).',
        badge: 'AMAN',
        badgeTone: 'safe',
        action: { type: 'auto-fix' },
      })
    }
    if (scan.crossFileCount > 0) {
      opts.push({
        id: 'guided',
        label: 'Perbaiki bug lintas file (berpandu)',
        detail: 'Sistem usulkan solusi per temuan dengan pratinjau diff; kamu setujui lewat chat, sistem eksekusi di terminal.',
        badge: 'PERLU PERSETUJUAN',
        badgeTone: 'caution',
        action: { type: 'propose-guided' },
      })
    }
    opts.push(
      { id: 'pdf', label: 'Unduh laporan PDF', detail: 'Ringkasan temuan lengkap per berkas untuk dokumentasi tim.', badgeTone: 'info', action: { type: 'pdf' } },
      { id: 'zip', label: 'Unduh ZIP kode (hasil kerja)', badgeTone: 'info', action: { type: 'zip', mode: 'fixed' } },
      { id: 'sarif', label: 'Ekspor SARIF (CI/CD)', detail: 'Format SARIF 2.1.0 — bisa diunggah ke GitHub Code Scanning / alat keamanan lain.', badgeTone: 'info', action: { type: 'export', format: 'sarif' } },
      { id: 'export-json', label: 'Ekspor JSON terstruktur', detail: 'Dump hasil pemindaian lengkap untuk pipeline otomatis.', badgeTone: 'info', action: { type: 'export', format: 'json' } },
    )
    return opts
  }

  const uploadZipOne = async (file: File): Promise<number | null> => {
    try {
      const form = new FormData()
      form.append('file', file)
      const res = await fetch('/api/workspace/upload-zip', { method: 'POST', body: form })
      const data = await res.json()
      if (!res.ok || !data.ok) {
        toast({ title: 'Gagal membuka ZIP', description: data.error, variant: 'destructive' })
        return null
      }
      const merged = mergeNames(get().files, data.files).slice(0, MAX_FILES)
      set({ files: merged, scan: null })
      return (data.files as WorkspaceFileInput[]).length
    } catch {
      toast({ title: 'Gagal terhubung ke server', variant: 'destructive' })
      return null
    }
  }

  const pushEmptyState = () => {
    pushMessage({
      role: 'agent',
      kind: 'options',
      text: 'Workspace masih kosong. Unggah file lewat ikon klip di bawah (atau seret file/ZIP ke panel chat), atau muat salah satu contoh proyek penuh bug di bawah ini.',
      options: sampleOptions(),
    })
  }

  /* ---------- penyimpanan sesi (riwayat agen) ---------- */

  let saveTimer: ReturnType<typeof setTimeout> | null = null

  /** Simpan sesi ke DB (debounce 900 ms; gagal = senyap, tak mengganggu alur kerja). */
  const scheduleSave = () => {
    if (typeof window === 'undefined') return
    if (saveTimer) clearTimeout(saveTimer)
    saveTimer = setTimeout(() => {
      saveTimer = null
      void saveSessionNow().catch(() => {})
    }, 900)
  }

  const saveSessionNow = async (): Promise<string | null> => {
    const { messages, files, scan, sessionId } = get()
    // Jangan simpan sesi yang masih kosong total (hanya sambutan).
    if (messages.length <= 1 && files.length === 0) return sessionId
    try {
      const { ok, data } = await apiJson('/api/agent/session', {
        id: sessionId,
        title: deriveTitle(messages),
        messages,
        files,
        scan,
      })
      if (ok && typeof data.id === 'string') {
        set({ sessionId: data.id })
        return data.id
      }
    } catch {
      // senyap — penyimpanan riwayat tidak boleh mengganggu pekerjaan utama
    }
    return null
  }

  const restoreOptions = (items: SessionMeta[]): ChatOption[] => {
    const opts: ChatOption[] = items.slice(0, 5).map(s => ({
      id: `session-${s.id}`,
      label: `Lanjutkan: ${s.title}`,
      detail: `${s.fileCount} file · ${s.bugCount} temuan · skor ${s.healthScore} · ${s.messageCount} pesan`,
      badge: 'RIWAYAT',
      badgeTone: 'info' as const,
      action: { type: 'session-continue', id: s.id } as AgentAction,
    }))
    opts.push({
      id: 'session-fresh',
      label: 'Mulai sesi baru',
      detail: 'Abaikan riwayat; workspace & chat mulai dari nol.',
      action: { type: 'session-fresh' },
    })
    return opts
  }

  const initRestore = async () => {
    if (get().restoreChecked || typeof window === 'undefined') return
    set({ restoreChecked: true })
    let items: SessionMeta[] = []
    try {
      const res = await fetch('/api/agent/sessions?limit=5')
      if (res.ok) {
        const data = await res.json()
        items = Array.isArray(data.sessions) ? (data.sessions as SessionMeta[]) : []
      }
    } catch {
      return // server belum siap / offline — abaikan
    }
    if (items.length === 0) return
    const latest = items[0]
    pushMessage({
      role: 'agent',
      kind: 'options',
      text: `💾 Saya menemukan ${items.length} sesi kerja tersimpan. Sesi terakhir: "${latest.title}" (${latest.fileCount} file, ${latest.bugCount} temuan, skor ${latest.healthScore}/100). Dilanjutkan?`,
      options: restoreOptions(items),
    })
  }

  const loadSession = async (id: string) => {
    if (get().busy) {
      toast({ title: 'Masih ada proses berjalan' })
      return
    }
    set({ busy: true, phase: 'scanning' })
    try {
      const res = await fetch(`/api/agent/session/${encodeURIComponent(id)}`)
      const data = await res.json().catch(() => ({}))
      if (!res.ok || !data.ok) throw new Error(String(data.error ?? 'Gagal memuat sesi'))
      const s = data.session as {
        id: string
        title: string
        messages: ChatMessage[]
        files: WorkspaceFileInput[]
        scan: WorkspaceScanResult | null
      }
      const messages = (s.messages ?? []).map(m => ({ ...m, id: m.id || uid(), ts: m.ts ?? 0 }))
      const t = addTerminal('riwayat', 'sesi dipulihkan')
      line(t, '$ bughunter session --restore', 'cmd')
      line(t, `> Memuat "${s.title}"...`, 'dim')
      line(t, `✓ ${s.files.length} file · ${messages.length} pesan${s.scan ? ` · skor ${s.scan.healthScore}/100` : ''}`, 'ok')
      finishTerminal(t)
      set({
        messages,
        files: s.files ?? [],
        scan: s.scan ?? null,
        sessionId: s.id,
        chosen: {},
        busy: false,
        phase: s.scan && s.scan.bugCount > 0 ? 'awaiting' : 'idle',
      })
      pushMessage({
        role: 'agent',
        kind: 'options',
        text: `✅ Sesi "${s.title}" dipulihkan — ${s.files.length} file kembali di kolom Workspace${s.scan ? `, kondisi terakhir: skor ${s.scan.healthScore}/100 dengan ${s.scan.bugCount} temuan` : ', belum dipindai'}.`,
        options:
          s.scan && s.scan.bugCount > 0
            ? scanOptions(s.scan)
            : s.files.length > 0
              ? [{ id: 'scan', label: 'Pindai sekarang', action: { type: 'scan' } as AgentAction }]
              : sampleOptions(),
      })
    } catch (e) {
      set({ busy: false, phase: 'idle' })
      pushMessage({
        role: 'agent',
        kind: 'text',
        tone: 'error',
        text: `Gagal memuat sesi: ${e instanceof Error ? e.message : 'kesalahan tak terduga'}.`,
      })
    }
  }

  const showSessionList = async () => {
    try {
      const res = await fetch('/api/agent/sessions?limit=6')
      const data = await res.json().catch(() => ({}))
      const items: SessionMeta[] = Array.isArray(data.sessions) ? data.sessions : []
      if (items.length === 0) {
        pushMessage({ role: 'agent', kind: 'text', text: 'Belum ada sesi tersimpan. Setiap aksi penting akan tersimpan otomatis mulai sekarang.' })
        return
      }
      pushMessage({
        role: 'agent',
        kind: 'options',
        text: `📚 ${items.length} sesi terakhir tersimpan. Pilih untuk melanjutkan:`,
        options: restoreOptions(items),
      })
    } catch {
      pushMessage({ role: 'agent', kind: 'text', tone: 'error', text: 'Gagal memuat daftar sesi dari server.' })
    }
  }

  /* ---------- AI GLM (tanya jawab bebas) ---------- */

  const runAiChat = async (text: string) => {
    if (get().busy) {
      toast({ title: 'Masih ada proses berjalan', description: 'Tunggu proses selesai, lalu tanya lagi.' })
      return
    }
    set({ busy: true, phase: 'thinking' })
    const t = addTerminal('ai-glm', 'tanya jawab GLM')
    line(t, '$ bughunter ask --ai', 'cmd')
    line(t, `> "${text.length > 90 ? `${text.slice(0, 90)}…` : text}"`, 'dim')
    line(t, '> Menyusun konteks workspace + hasil pemindaian...', 'dim')
    const { ok, data } = await apiJson('/api/agent/chat', {
      message: text,
      files: get().files,
      scan: get().scan,
    })
    if (!ok || typeof data.reply !== 'string' || !data.reply) {
      line(t, `✗ ${String(data.error ?? 'Layanan AI tidak merespons')}`, 'err')
      finishTerminal(t, 'error')
      pushMessage({
        role: 'agent',
        kind: 'options',
        tone: 'error',
        text: `🤖 Maaf, saya tidak bisa menjawab lewat AI sekarang: ${String(data.error ?? 'layanan tidak tersedia')}. Kamu tetap bisa memakai perintah langsung:`,
        options: get().files.length > 0
          ? [
              { id: 'scan', label: `Pindai ${get().files.length} file`, action: { type: 'scan' } as AgentAction },
              { id: 'help', label: 'Bantuan cara kerja', action: { type: 'help' } as AgentAction },
            ]
          : sampleOptions(),
      })
      set({ busy: false, phase: 'idle' })
      return
    }
    line(t, '✓ Jawaban GLM diterima', 'ok')
    finishTerminal(t)
    pushMessage({ role: 'agent', kind: 'text', via: 'ai', text: data.reply })
    // tindak lanjut praktis sesuai kondisi
    const follow: ChatOption[] = []
    const st = get()
    if (st.files.length > 0 && !st.scan) {
      follow.push({ id: 'scan', label: `Pindai ${st.files.length} file sekarang`, action: { type: 'scan' } })
    } else if (st.scan && countFixable(st.scan) > 0) {
      follow.push({
        id: 'auto-fix',
        label: `Perbaiki otomatis (${countFixable(st.scan)} bug aman)`,
        badge: 'AMAN',
        badgeTone: 'safe',
        action: { type: 'auto-fix' },
      })
    }
    follow.push({ id: 'help', label: 'Bantuan cara kerja', action: { type: 'help' } })
    pushMessage({ role: 'agent', kind: 'options', text: 'Ada lagi yang mau ditanyakan atau langsung dieksekusi?', options: follow })
    set({ busy: false, phase: 'idle' })
    scheduleSave()
  }


  /* ---------- aksi publik ---------- */

  const runScan = async () => {
    const st = get()
    if (st.busy) {
      toast({ title: 'Masih ada proses berjalan', description: 'Tunggu proses saat ini selesai dulu ya.' })
      return
    }
    if (st.files.length === 0) {
      pushEmptyState()
      return
    }
    set({ busy: true, phase: 'scanning' })
    const files = get().files
    const totalKb = Math.round((files.reduce((s, f) => s + f.code.length, 0) / 1024) * 10) / 10
    const live = isSocketLive()
    const t = addTerminal('pemindai', live ? `${files.length} file · lokal` : `${files.length} file`)
    line(t, '$ bughunter scan --workspace --lintas-file', 'cmd')
    line(t, `> Memuat ${files.length} file (${totalKb} KB)...`, 'info')
    const started = Date.now()
    const bg = live
      ? Promise.resolve() // progres per file datang dari server via socket
      : (async () => {
          for (const f of files) {
            await sleep(60 + Math.random() * 110)
            line(t, `> Memindai ${f.name} ...`, 'dim')
          }
          await sleep(160)
          line(t, '> Menganalisis graf import, taint, & dependensi lintas file...', 'dim')
        })()
    const { ok, data } = await apiJson('/api/workspace/analyze', {
      files,
      disabledRules: getDisabledRules(),
      room: agentRoom(),
    })
    await bg
    if (!ok) {
      line(t, `✗ ${String(data.error ?? 'Pemindaian gagal')}`, 'err')
      finishTerminal(t, 'error')
      pushMessage({
        role: 'agent',
        kind: 'text',
        tone: 'error',
        text: `Pemindaian gagal: ${String(data.error ?? 'kesalahan tak terduga')}. Coba lagi sebentar lagi.`,
      })
      set({ busy: false, phase: 'idle' })
      return
    }
    const scan = data.scan as WorkspaceScanResult
    set({ scan })
    line(
      t,
      scan.bugCount
        ? `⚠ ${scan.bugCount} temuan di ${scan.fileCount} file`
        : `✓ Bersih — tidak ada temuan di ${scan.fileCount} file`,
      scan.bugCount ? 'warn' : 'ok',
    )
    if (scan.crossFileCount > 0) {
      line(t, `⚠ ${scan.crossFileCount} temuan lintas file — butuh keputusanmu`, 'warn')
    }
    line(t, `✓ Selesai dalam ${Date.now() - started} ms — skor kesehatan ${scan.healthScore}/100`, 'ok')
    finishTerminal(t)

    if (scan.bugCount > 0) {
      pushMessage({
        role: 'agent',
        kind: 'summary',
        text: `Pemindaian selesai — skor kesehatan ${scan.healthScore}/100, ${scan.bugCount} temuan (${scan.crossFileCount} lintas file). Mau saya lanjutkan dengan apa?`,
        scan,
        options: scanOptions(scan),
      })
      set({ busy: false, phase: 'awaiting' })
    } else {
      pushMessage({
        role: 'agent',
        kind: 'text',
        text: `Semua file bersih — skor kesehatan ${scan.healthScore}/100. Kerja bagus! Mau saya kemas hasilnya?`,
        options: [
          { id: 'zip', label: 'Unduh ZIP kode', action: { type: 'zip', mode: 'fixed' } },
          { id: 'pdf', label: 'Unduh laporan PDF', action: { type: 'pdf' } },
        ],
      })
      set({ busy: false, phase: 'idle' })
    }
    scheduleSave()
  }

  const runAutoFix = async () => {
    const st = get()
    if (st.busy) {
      toast({ title: 'Masih ada proses berjalan' })
      return
    }
    if (!st.scan) {
      await runScan()
      return
    }
    set({ busy: true, phase: 'fixing' })
    const scan = st.scan
    const fixableFiles = scan.files.filter(f =>
      f.bugs.some(b => b.ruleId && FIXABLE_RULE_IDS.has(b.ruleId)),
    )
    if (fixableFiles.length === 0) {
      pushMessage({
        role: 'agent',
        kind: 'text',
        text: 'Tidak ada bug per-file yang didukung perbaikan otomatis. Temuan lintas file bisa dikerjakan lewat jalur berpandu.',
        options: scan.crossFileCount
          ? [{ id: 'guided', label: 'Perbaiki lintas file (berpandu)', action: { type: 'propose-guided' } }]
          : undefined,
      })
      set({ busy: false, phase: 'awaiting' })
      return
    }
    pushMessage({
      role: 'agent',
      kind: 'text',
      text: `Baik — saya memperbaiki bug aman di ${fixableFiles.length} file sekarang${live ? '. Progres per file mengalir langsung dari server ke terminal.' : ` dengan ${fixableFiles.length} terminal paralel.`}`,
    })
    // Saat socket live: terminal 'fix-server' dibuka oleh server; tanpa simulasi lokal
    const req = apiJson('/api/workspace/fix', { files: get().files, room: agentRoom() })
    const tidByName = new Map<string, string>()
    if (!live) {
      await Promise.all(
        fixableFiles.map(async (f, i) => {
          await sleep(i * 240)
          const tid = addTerminal(`fix:${shortName(f.name)}`, 'auto-fix aman')
          tidByName.set(f.name, tid)
          line(tid, '$ bughunter fix --aman', 'cmd')
          line(tid, `> Menganalisis ${f.name}...`, 'dim')
          await sleep(140 + Math.random() * 140)
          line(tid, '> Menyiapkan patch...', 'dim')
        }),
      )
    }
    const { ok, data } = await req
    if (!ok) {
      for (const tid of tidByName.values()) {
        line(tid, `✗ ${String(data.error ?? 'Auto-fix gagal')}`, 'err')
        finishTerminal(tid, 'error')
      }
      pushMessage({
        role: 'agent',
        kind: 'text',
        tone: 'error',
        text: `Auto-fix gagal: ${String(data.error ?? 'kesalahan tak terduga')}.`,
      })
      set({ busy: false, phase: 'awaiting' })
      return
    }
    const r = data as unknown as WorkspaceFixResponse
    set({ files: r.files.map(f => ({ name: f.name, code: f.fixedCode })) })
    for (const fr of r.files) {
      const tid = tidByName.get(fr.name)
      if (!tid) continue
      if (fr.changes.length === 0) {
        line(
          tid,
          fr.skipped.length
            ? `⚠ ${fr.skipped.length} temuan dilewati (butuh keputusan manusia)`
            : '— tidak ada perbaikan otomatis untuk file ini',
          'warn',
        )
        finishTerminal(tid)
        continue
      }
      for (const c of fr.changes.slice(0, 5)) {
        line(tid, `• baris ${c.line}: ${c.before.trim().slice(0, 52)} → ${c.after.trim().slice(0, 52)}`, 'info')
      }
      if (fr.changes.length > 5) line(tid, `  … +${fr.changes.length - 5} perbaikan lainnya`, 'dim')
      line(
        tid,
        `✓ ${fr.changes.length} perbaikan diterapkan${fr.skipped.length ? `, ${fr.skipped.length} dilewati` : ''}`,
        'ok',
      )
      finishTerminal(tid)
    }
    pushMessage({
      role: 'agent',
      kind: 'fix-summary',
      text: `Perbaikan otomatis selesai: ${r.fixedCount} perbaikan di ${r.files.filter(f => f.changes.length > 0).length} file.`,
      fix: {
        applied: r.fixedCount,
        skipped: r.skippedCount,
        files: r.files.filter(f => f.changes.length > 0).map(f => f.name),
      },
    })
    const scan2 = await rescanQuiet()
    pushMessage({
      role: 'agent',
      kind: 'text',
      text: scan2
        ? `Verifikasi selesai — skor kesehatan ${scan2.healthScore}/100, ${scan2.bugCount} temuan tersisa.`
        : 'Verifikasi selesai.',
      options: scan2 ? scanOptions(scan2) : [{ id: 'rescan', label: 'Pindai ulang', action: { type: 'scan' } }],
    })
    set({ busy: false, phase: scan2 && scan2.bugCount > 0 ? 'awaiting' : 'idle' })
    scheduleSave()
  }

  const proposeGuided = () => {
    const scan = get().scan
    if (!scan) return
    const findings = scan.files
      .flatMap(f => f.bugs.filter(b => b.guidedFixes && b.guidedFixes.length > 0).map(b => ({ file: f.name, bug: b })))
      .slice(0, 8)
    if (findings.length === 0) {
      pushMessage({
        role: 'agent',
        kind: 'text',
        text: 'Tidak ada solusi berpandu yang tersedia untuk temuan saat ini. Gunakan laporan PDF untuk saran perbaikan manual.',
        options: [{ id: 'pdf', label: 'Unduh laporan PDF', action: { type: 'pdf' } }],
      })
      return
    }
    pushMessage({
      role: 'agent',
      kind: 'text',
      text: `Ada ${findings.length} temuan lintas file yang butuh keputusanmu. Pilih solusi di bawah — begitu kamu setujui, saya eksekusi langsung di terminal (satu terminal per berkas yang disentuh).`,
    })
    for (const { file, bug } of findings) {
      pushMessage({
        role: 'agent',
        kind: 'options',
        text: `${file} · baris ${bug.line} — ${bug.title}`,
        options: (bug.guidedFixes ?? []).map(g => ({
          id: g.id,
          label: g.label,
          detail: g.detail,
          badge: g.safe ? 'AMAN' : 'PERHATIAN',
          badgeTone: (g.safe ? 'safe' : 'caution') as 'safe' | 'caution',
          action: { type: 'guided', option: g } as AgentAction,
        })),
      })
    }
  }

  const runGuided = async (option: GuidedFixOption, confirmed = false) => {
    if (get().busy) {
      toast({ title: 'Masih ada proses berjalan' })
      return
    }
    set({ busy: true, phase: 'fixing' })
    const a = option.action
    // ---- TAHAP 1: pratinjau diff (belum mengubah apa pun) ----
    if (!confirmed) {
      const tp = addTerminal(`guided:${shortName(a.file)}`, 'pratinjau diff')
      line(tp, '$ bughunter resolve --pratinjau', 'cmd')
      line(tp, `> Solusi: ${option.label}`, 'info')
      line(tp, '> Menyiapkan pratinjau perubahan (belum ada yang diubah)...', 'dim')
      const { ok, data } = await apiJson('/api/workspace/guided-fix', {
        files: get().files,
        actions: [a],
        dryRun: true,
      })
      if (!ok) {
        line(tp, `✗ ${String(data.error ?? 'Gagal menyiapkan pratinjau')}`, 'err')
        finishTerminal(tp, 'error')
        pushMessage({
          role: 'agent',
          kind: 'text',
          tone: 'error',
          text: `Pratinjau gagal: ${String(data.error ?? 'kesalahan tak terduga')}.`,
        })
        set({ busy: false, phase: 'awaiting' })
        return
      }
      const dr = data as unknown as {
        appliedCount: number
        addedFiles: string[]
        results: GuidedFixResponse['results']
        preview?: { diffs: DiffPreview[] }
      }
      if (dr.appliedCount === 0 || !dr.preview || dr.preview.diffs.length === 0) {
        const reason = dr.results[0]?.reason ?? 'temuan sudah tidak berlaku'
        line(tp, `✗ ${reason}`, 'err')
        finishTerminal(tp, 'error')
        pushMessage({
          role: 'agent',
          kind: 'text',
          text: `Solusi "${option.label}" tidak bisa diterapkan lagi: ${reason}. Pindai ulang untuk daftar temuan terkini.`,
          options: [{ id: 'rescan', label: 'Pindai ulang sekarang', action: { type: 'scan' } }],
        })
        set({ busy: false, phase: 'awaiting' })
        return
      }
      line(tp, '✓ Pratinjau siap — menunggu persetujuanmu di chat', 'ok')
      finishTerminal(tp)
      pushMessage({
        role: 'agent',
        kind: 'diff',
        text: `Pratinjau perubahan untuk "${option.label}" — ${dr.preview.diffs.length} berkas berubah, belum ada yang diubah sampai kamu setujui:`,
        diffs: dr.preview.diffs,
        options: [
          {
            id: 'execute',
            label: 'Setujui & eksekusi',
            detail: 'Terapkan perubahan persis seperti pratinjau di atas.',
            badge: 'SETUJUI',
            badgeTone: 'safe',
            action: { type: 'guided', option, confirmed: true },
          },
          { id: 'cancel', label: 'Batal — kembali ke daftar solusi', detail: 'Tidak ada yang diubah.', action: { type: 'propose-guided' } },
        ],
      })
      set({ busy: false, phase: 'awaiting' })
      return
    }
    // ---- TAHAP 2: eksekusi sungguhan setelah persetujuan ----
    const t = addTerminal(`guided:${shortName(a.file)}`, option.label)
    line(t, '$ bughunter resolve --berpandu', 'cmd')
    line(t, `> Solusi disetujui: ${option.label}`, 'info')
    await sleep(200)
    line(t, `> ${option.detail}`, 'dim')
    await sleep(160)
    line(t, '> Validasi ulang terhadap isi file terkini (anti-kedaluwarsa)...', 'dim')
    const { ok, data } = await apiJson('/api/workspace/guided-fix', {
      files: get().files,
      actions: [a],
    })
    if (!ok) {
      line(t, `✗ ${String(data.error ?? 'Gagal')}`, 'err')
      finishTerminal(t, 'error')
      pushMessage({
        role: 'agent',
        kind: 'text',
        tone: 'error',
        text: `Eksekusi solusi gagal: ${String(data.error ?? 'kesalahan tak terduga')}.`,
      })
      set({ busy: false, phase: 'awaiting' })
      return
    }
    const r = data as unknown as GuidedFixResponse
    set({ files: r.files })
    const item = r.results[0]
    if (item?.ok) {
      line(t, `✓ ${item.description ?? 'Perubahan diterapkan'}`, 'ok')
      if (item.before) line(t, `- ${item.before.slice(0, 90)}`, 'dim')
      if (item.after) line(t, `+ ${item.after.slice(0, 90)}`, 'ok')
      for (const nf of r.addedFiles) line(t, `+ File baru dibuat: ${nf}`, 'ok')
      finishTerminal(t)
      if (r.addedFiles.length > 0) {
        pushMessage({
          role: 'agent',
          kind: 'text',
          text: `File baru ditambahkan ke workspace: ${r.addedFiles.join(', ')}.`,
        })
      }
    } else {
      line(t, `✗ ${item?.reason ?? 'Aksi ditolak'}`, 'err')
      finishTerminal(t, 'error')
    }
    const scan = await rescanQuiet()
    const crossLeft = scan?.crossFileCount ?? 0
    const fixable = scan ? countFixable(scan) : 0
    const opts: ChatOption[] = []
    if (crossLeft > 0) {
      opts.push({
        id: 'guided',
        label: `Lanjutkan temuan lintas file (${crossLeft})`,
        action: { type: 'propose-guided' },
      })
    }
    if (fixable > 0) {
      opts.push({
        id: 'auto-fix',
        label: `Perbaiki otomatis (${fixable} bug aman)`,
        badge: 'AMAN',
        badgeTone: 'safe',
        action: { type: 'auto-fix' },
      })
    }
    opts.push(
      { id: 'pdf', label: 'Unduh laporan PDF', action: { type: 'pdf' } },
      { id: 'zip', label: 'Unduh ZIP kode (hasil kerja)', action: { type: 'zip', mode: 'fixed' } },
    )
    pushMessage({
      role: 'agent',
      kind: 'text',
      text: item?.ok
        ? scan
          ? `Solusi "${option.label}" selesai dieksekusi. Skor kesehatan kini ${scan.healthScore}/100 — ${scan.bugCount} temuan tersisa.`
          : `Solusi "${option.label}" selesai dieksekusi.`
        : `Solusi "${option.label}" ditolak: ${item?.reason ?? 'temuan sudah berubah'}. Pindai ulang untuk daftar terkini.`,
      options: opts,
    })
    set({ busy: false, phase: crossLeft > 0 ? 'awaiting' : 'idle' })
    scheduleSave()
  }

  const downloadZip = async (mode: 'fixed' | 'original') => {
    const files = get().files
    if (files.length === 0) {
      pushMessage({ role: 'agent', kind: 'text', text: 'Workspace masih kosong — tidak ada yang bisa diunduh.' })
      return
    }
    try {
      const res = await fetch('/api/workspace/download', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ files, mode }),
      })
      if (!res.ok) {
        const d = await res.json().catch(() => ({}))
        throw new Error(String(d.error ?? 'Gagal membuat arsip'))
      }
      const blob = await res.blob()
      triggerDownload(blob, `bughunter-workspace-${mode}.zip`)
      pushMessage({
        role: 'agent',
        kind: 'text',
        text: `📦 ZIP ${mode === 'fixed' ? 'hasil kerja (kode terbaru + laporan perbaikan)' : 'kode asli sebelum perbaikan'} — ${files.length} file — sudah diunduh.`,
      })
    } catch (e) {
      pushMessage({
        role: 'agent',
        kind: 'text',
        tone: 'error',
        text: `Gagal mengunduh ZIP: ${e instanceof Error ? e.message : 'kesalahan tak terduga'}.`,
      })
    }
  }

  const downloadPdf = async () => {
    const { scan, files } = get()
    if (!scan) {
      pushMessage({
        role: 'agent',
        kind: 'text',
        text: 'Belum ada hasil pemindaian — jalankan "pindai" dulu agar laporan PDF berisi temuan.',
        options: files.length > 0 ? [{ id: 'scan', label: 'Pindai sekarang', action: { type: 'scan' } }] : undefined,
      })
      return
    }
    try {
      await downloadPdfReport(
        {
          kind: 'workspace',
          title: `Workspace ${files.length} berkas — BugHunter ID`,
          summary: {
            healthScore: scan.healthScore,
            bugCount: scan.bugCount,
            criticalCount: scan.criticalCount,
            highCount: scan.highCount,
            mediumCount: scan.mediumCount,
            lowCount: scan.lowCount,
            crossFileCount: scan.crossFileCount,
            fileCount: scan.fileCount,
            totalLines: scan.totalLines,
          },
          files: scan.files.map(fr => ({
            name: fr.name,
            language: fr.language,
            healthScore: fr.healthScore,
            bugCount: fr.bugCount,
            bugs: fr.bugs.map(b => ({
              severity: b.severity as Severity,
              line: b.line,
              category: b.category,
              title: b.title,
              description: b.description,
              suggestion: b.suggestion,
              crossFile: b.category === 'Lintas File',
            })),
          })),
        },
        'bughunter-laporan-workspace.pdf',
      )
      pushMessage({ role: 'agent', kind: 'text', text: '📄 Laporan PDF sudah diunduh — berisi ringkasan skor dan seluruh temuan per berkas.' })
    } catch (e) {
      pushMessage({
        role: 'agent',
        kind: 'text',
        tone: 'error',
        text: `Gagal membuat PDF: ${e instanceof Error ? e.message : 'kesalahan tak terduga'}.`,
      })
    }
  }

  const runGithubImport = async (rawUrl: string) => {
    if (get().busy) {
      toast({ title: 'Masih ada proses berjalan' })
      return
    }
    set({ busy: true, phase: 'scanning' })
    const t = addTerminal('github', 'impor repositori')
    line(t, '$ bughunter github --impor', 'cmd')
    line(t, `> ${rawUrl.slice(0, 90)}`, 'dim')
    line(t, '> Mengunduh arsip repositori dari codeload.github.com...', 'dim')
    try {
      const { ok, data } = await apiJson('/api/github/import', { url: rawUrl })
      if (!ok) {
        line(t, `✗ ${String(data.error ?? 'Impor gagal')}`, 'err')
        finishTerminal(t, 'error')
        pushMessage({
          role: 'agent',
          kind: 'text',
          tone: 'error',
          text: `Impor GitHub gagal: ${String(data.error ?? 'kesalahan tak terduga')}`,
          options: [
            { id: 'retry-github', label: 'Coba lagi', action: { type: 'github', url: rawUrl } },
            { id: 'help', label: 'Bantuan cara kerja', action: { type: 'help' } },
          ],
        })
        set({ busy: false, phase: 'idle' })
        return
      }
      const info = (data.info ?? {}) as { repo?: string; branch?: string; accepted?: number; skippedJunk?: number; skippedBinary?: number; truncated?: boolean }
      const incoming = (data.files as WorkspaceFileInput[]) ?? []
      const merged = mergeNames(get().files, incoming).slice(0, MAX_FILES)
      set({ files: merged, scan: null })
      line(t, `✓ ${info.repo ?? ''}${info.branch ? ` (${info.branch})` : ''} — ${incoming.length} berkas teks diterima`, 'ok')
      if (info.skippedJunk) line(t, `> ${info.skippedJunk} berkas sampah/lockfile dilewati`, 'dim')
      if (info.skippedBinary) line(t, `> ${info.skippedBinary} berkas biner dilewati`, 'dim')
      if (info.truncated) line(t, '⚠ Repo lebih besar dari batas workspace — hanya sebagian yang diambil', 'warn')
      finishTerminal(t)
      const nama = incoming.slice(0, 8).map(f => f.name).join(', ')
      pushMessage({
        role: 'agent',
        kind: 'options',
        text: `🐙 Repositori ${info.repo ?? 'GitHub'} diimpor — ${incoming.length} berkas masuk ke Workspace${info.truncated ? ' (dipotong sesuai batas)' : ''}.${incoming.length > 8 ? `
Antara lain: ${nama}, dst.` : nama ? `
${nama}` : ''}
Lanjut saya pindai?`,
        options: [
          { id: 'scan', label: `Ya, pindai ${merged.length} file`, action: { type: 'scan' } },
          { id: 'github-more', label: 'Impor repo lain', action: { type: 'help' } },
        ],
      })
      scheduleSave()
    } catch {
      line(t, '✗ Gagal terhubung ke server', 'err')
      finishTerminal(t, 'error')
      pushMessage({ role: 'agent', kind: 'text', tone: 'error', text: 'Impor GitHub gagal: server tidak merespons.' })
      set({ busy: false, phase: 'idle' })
    }
  }

  const downloadExport = async (format: 'sarif' | 'json') => {
    const { scan, files } = get()
    if (!scan) {
      pushMessage({
        role: 'agent',
        kind: 'text',
        text: 'Belum ada hasil pemindaian — jalankan "pindai" dulu agar ekspor berisi temuan.',
        options: files.length > 0 ? [{ id: 'scan', label: 'Pindai sekarang', action: { type: 'scan' } }] : undefined,
      })
      return
    }
    try {
      const res = await fetch('/api/workspace/export', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ scan, format }),
      })
      if (!res.ok) {
        const d = await res.json().catch(() => ({}))
        throw new Error(String(d.error ?? 'Ekspor gagal'))
      }
      const blob = await res.blob()
      triggerDownload(blob, format === 'sarif' ? 'bughunter-results.sarif' : 'bughunter-results.json')
      pushMessage({
        role: 'agent',
        kind: 'text',
        text:
          format === 'sarif'
            ? '🧾 SARIF 2.1.0 sudah diunduh (bughunter-results.sarif) — siap diunggah ke GitHub Code Scanning / alat CI lainnya.'
            : '🧾 JSON terstruktur sudah diunduh (bughunter-results.json) — siap dipakai di pipeline otomatis.',
      })
    } catch (e) {
      pushMessage({
        role: 'agent',
        kind: 'text',
        tone: 'error',
        text: `Ekspor gagal: ${e instanceof Error ? e.message : 'kesalahan tak terduga'}.`,
      })
    }
  }

  /** Unduh workflow GitHub Actions siap pakai dari server (tanpa perlu hasil pemindaian). */
  const downloadCiWorkflow = async () => {
    try {
      const res = await fetch('/api/workspace/ci-workflow')
      if (!res.ok) {
        const d = await res.json().catch(() => ({}))
        throw new Error(String(d.error ?? 'Unduhan gagal'))
      }
      const blob = await res.blob()
      triggerDownload(blob, 'bughunter-ci.yml')
      pushMessage({
        role: 'agent',
        kind: 'text',
        text:
          '⚙️ Workflow CI/CD sudah diunduh (bughunter-ci.yml). Cara pakai:\n' +
          '1. Simpan sebagai .github/workflows/bughunter.yml di repositori kamu.\n' +
          '2. Tambahkan secret repo BUGHUNTER_URL berisi URL aplikasi BugHunter ID (Settings → Secrets and variables → Actions).\n' +
          '3. (Opsional) set variable BUGHUNTER_MAX_BUGS agar job gagal bila temuan melewati batas.\n' +
          'Setiap push/PR: kode dipindai → SARIF diunggah sebagai artefak & ke Code Scanning. Pasangkan dengan "ekspor sarif" untuk melihat contoh hasilnya.',
      })
    } catch (e) {
      pushMessage({
        role: 'agent',
        kind: 'text',
        tone: 'error',
        text: `Unduhan workflow CI gagal: ${e instanceof Error ? e.message : 'kesalahan tak terduga'}.`,
      })
    }
  }

  const loadSample = (key: string) => {
    if (get().busy) {
      toast({ title: 'Masih ada proses berjalan' })
      return
    }
    const s = WORKSPACE_SAMPLES[key]
    if (!s) return
    set({ files: s.files.map(f => ({ name: f.name, code: f.code })), scan: null, phase: 'idle' })
    pushMessage({
      role: 'agent',
      kind: 'options',
      text: `📦 Contoh "${s.label}" dimuat (${s.files.length} file) ke kolom Workspace.\n${s.description}`,
      options: [{ id: 'scan', label: 'Pindai sekarang', action: { type: 'scan' } }],
    })
    scheduleSave()
  }

  const showHelp = () => {
    pushMessage({ role: 'agent', kind: 'options', text: HELP_TEXT, options: sampleOptions() })
  }

  const sendText = async (raw: string) => {
    const text = raw.trim()
    if (!text) return
    pushMessage({ role: 'user', kind: 'text', text })
    const intent = parseIntent(text)
    const { files, scan } = get()
    if (intent === 'github') {
      // ekstrak URL/owner-repo dari teks
      const m = /((?:https?:\/\/)?(?:www\.)?github\.com\/[\w.-]+\/[\w.-]+(?:\/tree\/[^\s]+)?|\bimpor(?:\s+github)?\s+([\w-]+)\/([\w.-]+))/.exec(text)
      let url = m?.[1]?.replace(/^impor\s+github\s+/i, '') ?? ''
      if (!url && m) url = `${m[2]}/${m[3]}`
      if (!url) {
        pushMessage({
          role: 'agent',
          kind: 'text',
          text: 'Tuliskan alamat repositorinya, misalnya: "impor github https://github.com/expressjs/express" — atau cukup "impor github expressjs/express".',
        })
        return
      }
      await runGithubImport(url)
    } else if (intent === 'export') {
      const fmt = /\bsarif\b/.test(text.toLowerCase()) ? 'sarif' : 'json'
      await downloadExport(fmt)
    } else if (intent === 'ci') {
      await downloadCiWorkflow()
    } else if (intent === 'sessions') {
      await showSessionList()
    } else if (intent === 'scan') {
      if (files.length === 0) {
        pushEmptyState()
        return
      }
      pushMessage({
        role: 'agent',
        kind: 'text',
        text: `Baik — saya memindai ${files.length} file sekarang. Proses kerjanya saya catat di terminal.`,
      })
      await runScan()
    } else if (intent === 'fix') {
      if (!scan) {
        if (files.length === 0) {
          pushEmptyState()
          return
        }
        pushMessage({
          role: 'agent',
          kind: 'text',
          text: 'Belum ada hasil pemindaian. Saya pindai dulu untuk menemukan bugnya, lalu langsung perbaiki yang aman.',
        })
        await runScan()
        const s = get().scan
        if (s && countFixable(s) > 0) {
          pushMessage({ role: 'agent', kind: 'text', text: 'Sesuai permintaanmu, saya lanjut memperbaiki bug aman sekarang.' })
          await runAutoFix()
        }
        return
      }
      pushMessage({ role: 'agent', kind: 'text', text: 'Baik — saya perbaiki bug aman sekarang. Terminal agent saya buka paralel.' })
      await runAutoFix()
    } else if (intent === 'pdf') {
      await downloadPdf()
    } else if (intent === 'zip') {
      await downloadZip('fixed')
    } else if (intent === 'sample') {
      pushMessage({
        role: 'agent',
        kind: 'options',
        text: 'Pilih contoh proyek penuh bug bandel di bawah — file masuk ke Workspace, lalu kamu bisa langsung memerintahkan pemindaian.',
        options: sampleOptions(),
      })
    } else if (intent === 'help') {
      showHelp()
    } else {
      // Bukan perintah yang dikenal → teruskan ke AI GLM dengan konteks workspace.
      await runAiChat(text)
    }
  }

  const handleFiles = async (list: File[]) => {
    if (list.length === 0) return
    if (get().busy) {
      toast({ title: 'Agen sedang bekerja', description: 'Tunggu proses selesai, lalu unggah lagi.' })
      return
    }
    const accepted: WorkspaceFileInput[] = []
    let skipped = 0
    let zipLoaded = 0
    for (const f of Array.from(list)) {
      if (f.name.toLowerCase().endsWith('.zip')) {
        const n = await uploadZipOne(f)
        if (n === null) skipped++
        else zipLoaded += n
        continue
      }
      if (f.size > MAX_FILE_BYTES) {
        skipped++
        continue
      }
      try {
        const text = await f.text()
        if (text.includes('\u0000')) {
          skipped++
          continue
        }
        accepted.push({ name: f.name, code: text })
      } catch {
        skipped++
      }
    }
    if (accepted.length > 0) get().addFiles(accepted)
    const parts: string[] = []
    if (accepted.length > 0) parts.push(`${accepted.length} file`)
    if (zipLoaded > 0) parts.push(`${zipLoaded} file dari ZIP`)
    if (parts.length === 0) {
      pushMessage({
        role: 'agent',
        kind: 'text',
        tone: 'error',
        text: 'Tidak ada file yang bisa dimuat (file biner atau melebihi 200 KB per file).',
      })
      return
    }
    const names = accepted.map(f => f.name).join(', ')
    pushMessage({
      role: 'agent',
      kind: 'options',
      text: `📥 Diterima: ${parts.join(' + ')}${accepted.length ? ` — ${names}` : ''}${skipped ? ` (${skipped} dilewati)` : ''}.\nFile sudah masuk ke kolom Workspace. Lanjut saya pindai?`,
      options: [{ id: 'scan', label: 'Ya, pindai sekarang', action: { type: 'scan' } }],
    })
    scheduleSave()
  }

  const chooseOption = async (msgId: string, optionId: string) => {
    if (get().chosen[msgId]) return
    const msg = get().messages.find(m => m.id === msgId)
    const opt = msg?.options?.find(o => o.id === optionId)
    if (!opt) return
    set(s => ({ chosen: { ...s.chosen, [msgId]: optionId } }))
    pushMessage({ role: 'user', kind: 'text', text: `✓ ${opt.label}` })
    await get().dispatch(opt.action)
  }

  const dispatch = async (action: AgentAction) => {
    switch (action.type) {
      case 'scan':
        await runScan()
        break
      case 'auto-fix':
        await runAutoFix()
        break
      case 'guided':
        await runGuided(action.option, action.confirmed === true)
        break
      case 'propose-guided':
        proposeGuided()
        break
      case 'pdf':
        await downloadPdf()
        break
      case 'zip':
        await downloadZip(action.mode)
        break
      case 'export':
        await downloadExport(action.format)
        break
      case 'ci-workflow':
        await downloadCiWorkflow()
        break
      case 'github':
        await runGithubImport(action.url)
        break
      case 'sample':
        loadSample(action.key)
        break
      case 'help':
        showHelp()
        break
      case 'clear-workspace':
        clearWorkspace()
        break
      case 'session-continue':
        await loadSession(action.id)
        break
      case 'session-list':
        await showSessionList()
        break
      case 'session-fresh':
        pushMessage({
          role: 'agent',
          kind: 'text',
          text: 'Oke, kita mulai baru. Sesi lama tetap tersimpan di riwayat dan bisa dilanjutkan kapan saja lewat opsi yang muncul saat halaman dibuka.',
        })
        break
    }
  }

  function clearWorkspace() {
    if (get().busy) {
      toast({ title: 'Masih ada proses berjalan' })
      return
    }
    set({ files: [], scan: null, phase: 'idle' })
    pushMessage({ role: 'agent', kind: 'text', text: '🧹 Workspace dikosongkan. Unggah file kapan saja lewat klip 📎 di bawah.' })
    scheduleSave()
  }

  return {
    messages: [
      {
        id: 'welcome',
        role: 'agent',
        kind: 'options',
        ts: 0, // pesan sambutan statis — hindari mismatch hydratasi (Date.now() di modul scope)
        text: `👋 Selamat datang di BugHunter ID!\nSaya agen perbaikan bug kamu. Cara kerja:\n1️⃣ Unggah file kode (klip 📎 di bawah / seret file atau ZIP) — atau ketik "impor github https://github.com/pemilik/repo" untuk menarik seluruh repo publik.\n2️⃣ Perintahkan "pindai" — JS/TS, Python, Go, PHP, dan Java diperiksa lintas file; progres per file mengalir langsung dari server ke terminal.\n3️⃣ Bug aman saya perbaiki otomatis; bug bandel lintas file saya ajukan pilihan solusi lengkap dengan pratinjau diff — kamu setujui, saya eksekusi.\n4️⃣ Tanya apa saja dengan bahasa sendiri — saya di belakangi AI GLM dengan konteks file & hasil pemindaianmu.\n5️⃣ Hasil kerja: unduh ZIP / laporan PDF / ekspor SARIF & JSON untuk CI/CD, plus workflow GitHub Actions siap pakai ("workflow ci"). Tombol Tren di header menampilkan grafik perkembangan skor kesehatan dari waktu ke waktu. Masuk lewat tombol Masuk agar riwayat sesi & tren menempel ke akunmu.`,
        options: sampleOptions(),
      },
    ],
    terminals: [],
    activeTerminalId: null,
    files: [],
    scan: null,
    phase: 'idle',
    busy: false,
    chosen: {},
    mobileTab: 'chat',
    socketLive: false,
    sessionId: null,
    restoreChecked: false,

    sendText,
    handleFiles,
    chooseOption,
    dispatch,
    runScan,
    runAutoFix,
    proposeGuided,
    runGuided,
    downloadZip,
    downloadPdf,
    downloadExport,
    runGithubImport,
    loadSample,
    addFiles: (incoming: WorkspaceFileInput[]) => {
      if (incoming.length === 0) return
      const merged = mergeNames(get().files, incoming).slice(0, MAX_FILES)
      set({ files: merged, scan: null })
      scheduleSave()
    },
    clearWorkspace,
    initLive,
    initRestore,
    loadSession,
    resetRestoreCheck: () => set({ restoreChecked: false }),
    setActiveTerminal: (id: string) => set({ activeTerminalId: id }),
    closeTerminal: (id: string) =>
      set(s => {
        const terminals = s.terminals.filter(t => t.id !== id)
        const activeTerminalId =
          s.activeTerminalId === id ? terminals[terminals.length - 1]?.id ?? null : s.activeTerminalId
        return { terminals, activeTerminalId }
      }),
    clearFinishedTerminals: () =>
      set(s => {
        const terminals = s.terminals.filter(t => t.status === 'running')
        const activeTerminalId = terminals.some(t => t.id === s.activeTerminalId)
          ? s.activeTerminalId
          : terminals[terminals.length - 1]?.id ?? null
        return { terminals, activeTerminalId }
      }),
    setMobileTab: (tab: 'chat' | 'workspace' | 'terminal') => set({ mobileTab: tab }),
  }
})
