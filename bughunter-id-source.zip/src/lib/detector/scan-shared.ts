import type { WorkspaceFileInput, WorkspaceFileResult } from '@/lib/types'
import { analyzeCode, computeHealthScore, countBySeverity } from './index'
import { languageForFile } from './import-scan'

/**
 * Opsi analisis yang aman dikirim ke worker thread via postMessage
 * (structured clone). disabledRules dinormalisasi menjadi array string
 * sebelum dikirim (Iterable lain bisa saja tidak ter-clone dengan baik).
 */
export type ScanAnalyzeOptions = { disabledRules?: string[] }

/**
 * Fase 1 analisis workspace: analisis TUNGGAL per file memakai mesin
 * 60+ aturan yang sama. Fungsi ini MURNI (hanya tergantung satu file +
 * opsi) sehingga hasilnya identik entah dipanggil serial dari thread
 * utama maupun dari worker thread — prasyarat paritas deteksi v0.11.
 *
 * Lapisan lintas file TIDAK ada di sini (butuh seluruh workspace) dan
 * tetap berjalan serial di thread utama (analyzeWorkspaceFiles).
 */
export function analyzeFilePhase1(
  f: WorkspaceFileInput,
  analyzeOptions: ScanAnalyzeOptions,
): WorkspaceFileResult {
  const lang = languageForFile(f.name)
  const supported = lang !== null
  const bugs = supported ? analyzeCode(f.code, lang, { disabledRules: analyzeOptions.disabledRules }) : []
  const counts = countBySeverity(bugs)
  return {
    name: f.name,
    language: lang ?? 'tidak-dikenal',
    supported,
    lineCount: f.code.split('\n').length,
    bugCount: bugs.length,
    criticalCount: counts.critical,
    highCount: counts.high,
    mediumCount: counts.medium,
    lowCount: counts.low,
    healthScore: supported ? computeHealthScore(bugs) : 100,
    bugs,
  }
}
