import { parentPort } from 'node:worker_threads'
import { analyzeFilePhase1, type ScanAnalyzeOptions } from './scan-shared'
import type { WorkspaceFileResult } from '@/lib/types'

/**
 * Worker entry untuk pemindaian paralel workspace (v0.11).
 *
 * Protokol (satu permintaan → satu jawaban → worker di-terminate):
 *   masuk  : { files: [{ name, code }], analyzeOptions: { disabledRules?: string[] } }
 *   keluar : { ok: true,  results: WorkspaceFileResult[], elapsed: number[] }
 *          | { ok: false, error: string }
 *
 * Catatan runtime:
 * - Berkas ini dikemas menjadi scan-worker.bundle.mjs (JS murni) via
 *   scripts/build-scan-worker.sh — bundle itulah yang di-spawn oleh
 *   scan-parallel.ts sehingga jalan di Node MAUPUN Bun.
 * - Worker .ts ini hanya di-spawn langsung di runtime Bun (fallback).
 */
if (parentPort) {
  parentPort.on('message', (msg: { files?: { name: string; code: string }[]; analyzeOptions?: ScanAnalyzeOptions }) => {
    const files = Array.isArray(msg?.files) ? msg.files : []
    const analyzeOptions: ScanAnalyzeOptions = {
      disabledRules: Array.isArray(msg?.analyzeOptions?.disabledRules)
        ? msg.analyzeOptions.disabledRules
        : undefined,
    }
    try {
      const results: WorkspaceFileResult[] = []
      const elapsed: number[] = []
      for (const f of files) {
        const t0 = Date.now()
        results.push(analyzeFilePhase1(f, analyzeOptions))
        elapsed.push(Date.now() - t0)
      }
      parentPort!.postMessage({ ok: true, results, elapsed })
    } catch (err) {
      parentPort!.postMessage({ ok: false, error: err instanceof Error ? err.message : String(err) })
    }
  })
}
