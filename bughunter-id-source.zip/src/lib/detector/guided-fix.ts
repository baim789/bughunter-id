import type {
  GuidedFixAction,
  GuidedFixOption,
  WorkspaceFileInput,
} from '@/lib/types'
import { maskCode, countCallArgs } from './smart'
import {
  languageForFile,
  sanitizeFileName,
  resolveLocalImport,
  stubPathForImport,
  scanJsExports,
  scanJsImports,
  scanPyImports,
  scanSecretValues,
} from './import-scan'

/**
 * ============================================================
 *  PERBAIKAN BERPANDU (GUIDED FIX) — BugHunter ID
 * ============================================================
 *  Jembatan antara "temuan lintas file" dan "tindakan nyata":
 *  pengguna klik temuan → pilih solusi → mesin mengeksekusi edit
 *  secara DETERMINISTIK pada teks kode.
 *
 *  Prinsip keamanan:
 *  1. Setiap aksi DIVALIDASI ulang terhadap isi file terkini
 *     (anti-kadaluarsa): bila temuan sudah tidak ada, aksi ditolak.
 *  2. Semua edit berupa operasi teks terlokalisir — tidak pernah
 *     menambah/menghapus baris lain di luar target (kecuali stub
 *     yang jelas ditandai TODO).
 *  3. Simbol yang sedang dipakai tidak pernah dihapus diam-diam —
 *     opsi berisiko ditandai safe=false dan dijelaskan di detail.
 * ============================================================
 */

const esc = (s: string) => s.replace(/\$/g, '\\$')

/* ============================================================
 *  1) KATALOG OPSI — dipasang pada temuan saat analisis
 * ============================================================ */

export interface GuidedFixContext {
  file: string
  line: number
  targetFile?: string
  symbol?: string
  spec?: string
  pkg?: string
  targetCode?: string
  importerCode?: string
  paramCount?: number
  callCount?: number
  fixedIn?: string
}

/** Apakah simbol dipakai di file pengimpor SELAIN baris importnya sendiri? */
function symbolUsedInBody(importerCode: string, localName: string, importLine: number): boolean {
  const masked = maskCode(importerCode)
  const lines = masked.split('\n')
  for (let i = 0; i < lines.length; i++) {
    if (i + 1 === importLine) continue
    if (new RegExp(`(?<![.\\w$'"\`])${esc(localName)}\\b`).test(lines[i])) return true
  }
  return false
}

/** Cari baris deklarasi `export ... NAMA` di kode target (bentuk bisa di-unexport). */
function findExportDeclLine(targetCode: string, symbol: string): number | null {
  const re = new RegExp(`\\bexport\\s+(?:async\\s+)?(?:function\\*?|class|const|let|var|type|interface|enum)\\s+${esc(symbol)}\\b`)
  const lines = targetCode.split('\n')
  for (let i = 0; i < lines.length; i++) if (re.test(lines[i])) return i + 1
  return null
}

/** Cari baris deklarasi biasa NAMA (tanpa export) — dipakai opsi add-export. */
function findDeclLine(code: string, symbol: string): number | null {
  const re = new RegExp(`\\b(?:async\\s+)?(?:function\\*?|class|const|let|var|type|interface|enum)\\s+${esc(symbol)}\\b`)
  const lines = code.split('\n')
  for (let i = 0; i < lines.length; i++) if (re.test(lines[i])) return i + 1
  return null
}

/** Apakah target mendefinisikan simbol (tanpa export)? */
function symbolDefinedUnexported(targetCode: string, symbol: string): boolean {
  const re = new RegExp(`\\b(?:async\\s+)?(?:function\\*?|class|const|let|var|type|interface|enum)\\s+${esc(symbol)}\\b`)
  if (!re.test(targetCode)) return false
  return !scanJsExports(targetCode).named.has(symbol)
}

function actionFor(ruleId: string, option: string, ctx: GuidedFixContext): GuidedFixAction {
  return {
    ruleId,
    option,
    file: ctx.file,
    line: ctx.line,
    targetFile: ctx.targetFile,
    symbol: ctx.symbol,
    spec: ctx.spec,
    pkg: ctx.pkg,
    paramCount: ctx.paramCount,
    callCount: ctx.callCount,
    fixedIn: ctx.fixedIn,
  }
}

/**
 * Susun daftar opsi perbaikan berpandu untuk satu temuan lintas file.
 * Return undefined bila tidak ada solusi deterministik untuk aturan itu.
 */
export function buildGuidedFixes(ruleId: string, ctx: GuidedFixContext): GuidedFixOption[] | undefined {
  switch (ruleId) {
    case 'ws-js-import-symbol': {
      if (!ctx.targetFile || !ctx.symbol) return undefined
      const opts: GuidedFixOption[] = []
      const targetCode = ctx.targetCode ?? ''
      if (symbolDefinedUnexported(targetCode, ctx.symbol)) {
        opts.push({
          id: 'add-export',
          label: `Tambahkan export di ${ctx.targetFile}`,
          detail: `Kata kunci "export" ditambahkan pada deklarasi ${ctx.symbol} di ${ctx.targetFile}. Kode tidak berubah perilaku — simbol menjadi dapat diimpor.`,
          safe: true,
          action: actionFor(ruleId, 'add-export', ctx),
        })
      } else {
        opts.push({
          id: 'stub-export',
          label: `Buat stub ${ctx.symbol} di ${ctx.targetFile}`,
          detail: `Fungsi ${ctx.symbol} ditambahkan di akhir ${ctx.targetFile} dengan export dan penanda TODO — sengaja melempar error sampai diimplementasi, agar kelupaan terlihat jelas.`,
          safe: true,
          action: actionFor(ruleId, 'stub-export', ctx),
        })
      }
      // opsi kedua: hapus simbol dari daftar import (aman bila tidak dipakai)
      if (ctx.importerCode) {
        const used = symbolUsedInBody(ctx.importerCode, ctx.symbol, ctx.line)
        opts.push({
          id: 'remove-import-symbol',
          label: `Hapus ${ctx.symbol} dari import`,
          detail: used
            ? `Simbol ${ctx.symbol} dikeluarkan dari daftar import di ${ctx.file}. PERHATIAN: nama ini masih dipakai di badan file — pemakaian lain akan error, pastikan memang ingin dicabut.`
            : `Simbol ${ctx.symbol} dikeluarkan dari daftar import di ${ctx.file}. Aman: nama ini tidak dipakai di bagian lain file.`,
          safe: !used,
          action: actionFor(ruleId, 'remove-import-symbol', ctx),
        })
      }
      return opts
    }

    case 'ws-js-import-missing-file': {
      if (!ctx.spec) return undefined
      const opts: GuidedFixOption[] = [
        {
          id: 'create-stub-file',
          label: `Buat file ${stubPathForImport(ctx.file, ctx.spec)}`,
          detail: `Berkas baru dibuat berisi stub export untuk simbol yang diimpor (bertanda TODO), sehingga jalur import terpenuhi dan bisa segera dilengkapi.`,
          safe: true,
          action: actionFor(ruleId, 'create-stub-file', ctx),
        },
      ]
      if (ctx.importerCode) {
        const imp = scanJsImports(ctx.importerCode).find(i => i.line === ctx.line)
        const unusedAll =
          imp && imp.names.length > 0 && imp.names.every(n => !symbolUsedInBody(ctx.importerCode!, n.local, ctx.line))
        opts.push({
          id: 'remove-import-line',
          label: 'Hapus baris import ini',
          detail: unusedAll
            ? `Baris import dihapus karena simbol yang diimpornya tidak dipakai di bagian lain file.`
            : `Baris import dihapus. PERHATIAN: simbol yang diimpornya mungkin masih dipakai — periksa pemakaian lain setelah dihapus.`,
          safe: Boolean(unusedAll),
          action: actionFor(ruleId, 'remove-import-line', ctx),
        })
      }
      return opts
    }

    case 'ws-py-import-symbol': {
      if (!ctx.targetFile || !ctx.symbol) return undefined
      const opts: GuidedFixOption[] = [
        {
          id: 'stub-python',
          label: `Buat stub ${ctx.symbol} di ${ctx.targetFile}`,
          detail: `Fungsi ${ctx.symbol}() ditambahkan di akhir ${ctx.targetFile} yang melempar NotImplementedError bertanda TODO — ImportError berubah menjadi pesan yang jelas sampai diimplementasi.`,
          safe: true,
          action: actionFor(ruleId, 'stub-python', ctx),
        },
      ]
      if (ctx.importerCode) {
        const used = symbolUsedInBody(ctx.importerCode, ctx.symbol, ctx.line)
        opts.push({
          id: 'remove-py-symbol',
          label: `Hapus ${ctx.symbol} dari from-import`,
          detail: used
            ? `Simbol ${ctx.symbol} dikeluarkan dari baris from-import di ${ctx.file}. PERHATIAN: nama ini masih dipakai di badan file.`
            : `Simbol ${ctx.symbol} dikeluarkan dari baris from-import di ${ctx.file}. Aman: tidak dipakai di bagian lain.`,
          safe: !used,
          action: actionFor(ruleId, 'remove-py-symbol', ctx),
        })
      }
      return opts
    }

    case 'ws-shared-secret': {
      const lang = languageForFile(ctx.file)
      if (lang !== 'javascript' && lang !== 'python') return undefined
      return [
        {
          id: 'use-env-var',
          label: `Ganti dengan environment variable`,
          detail:
            lang === 'javascript'
              ? `Nilai literal di baris ini diganti process.env.NAMA (mengikuti nama variabel). JANGAN lupa: nilai lama dianggap terekspos — rotasi kredensialnya, lalu simpan nilai baru di .env yang di-gitignore.`
              : `Nilai literal di baris ini diganti os.environ["NAMA"] (import os ditambahkan bila belum ada). JANGAN lupa: rotasi kredensial lama, simpan nilai baru di .env yang di-gitignore.`,
          safe: true,
          action: actionFor(ruleId, 'use-env-var', ctx),
        },
      ]
    }

    case 'ws-circular-import': {
      if (!ctx.targetFile) return undefined
      const opts: GuidedFixOption[] = []
      if (ctx.importerCode) {
        const lang = languageForFile(ctx.file)
        let lineNo: number | null = null
        let names: string[] = []
        if (lang === 'javascript') {
          const imp = scanJsImports(ctx.importerCode).find(
            i => resolveLocalImport(ctx.file, i.spec, new Set([ctx.targetFile!])) === ctx.targetFile,
          )
          if (imp) {
            lineNo = imp.line
            names = imp.names.map(n => n.local)
          }
        } else if (lang === 'python') {
          const imp = scanPyImports(ctx.importerCode).find(
            i => `${i.module.split('.')[0]}.py` === ctx.targetFile,
          )
          if (imp) {
            lineNo = imp.line
            names = imp.symbols
          }
        }
        if (lineNo !== null) {
          const unused = names.length === 0 || names.every(n => !symbolUsedInBody(ctx.importerCode!, n, lineNo!))
          opts.push({
            id: 'cut-edge',
            label: `Putus siklus: hapus import dari ${ctx.targetFile}`,
            detail: unused
              ? `Baris import dari ${ctx.targetFile} dihapus di ${ctx.file} — sisi siklus ini terputus. Aman: simbol yang diimpornya tidak dipakai di bagian lain file.`
              : `Baris import dari ${ctx.targetFile} dihapus di ${ctx.file} — sisi siklus ini terputus. PERHATIAN: simbol yang diimpornya masih dipakai; pertimbangkan pindahkan simbol bersama ke modul utilitas independen.`,
            safe: unused,
            action: actionFor(ruleId, 'cut-edge', ctx),
          })
        }
      }
      return opts.length > 0 ? opts : undefined
    }

    case 'ws-dead-export': {
      if (!ctx.symbol) return undefined
      const declLine = ctx.targetCode ? findExportDeclLine(ctx.targetCode, ctx.symbol) : null
      if (declLine === null) return undefined // bentuk export { } — tanpa solusi otomatis
      return [
        {
          id: 'unexport',
          label: `Hapus kata "export" (kode tetap ada)`,
          detail: `Kata kunci "export" dilepas dari deklarasi ${ctx.symbol} di baris ${ctx.line}. Kode dan perilaku internal file tidak berubah — simbol tidak lagi terekspos keluar modul.`,
          safe: true,
          action: actionFor(ruleId, 'unexport', ctx),
        },
      ]
    }

    case 'ws-arity': {
      if (!ctx.targetFile || !ctx.symbol || !ctx.paramCount || !ctx.callCount) return undefined
      return [
        {
          id: 'trim-call-args',
          label: `Sisakan ${ctx.paramCount} argumen pemanggilan`,
          detail: `Pemanggilan di ${ctx.file} baris ${ctx.line} dipangkas menyisakan ${ctx.paramCount} argumen pertama agar cocok dengan signature ${ctx.symbol} di ${ctx.targetFile}. PASTIKAN argumen yang dibuang memang tidak diperlukan.`,
          safe: false,
          action: actionFor(ruleId, 'trim-call-args', ctx),
        },
        {
          id: 'expand-params',
          label: `Tambah ${ctx.callCount - ctx.paramCount} parameter di ${ctx.targetFile}`,
          detail: `Signature ${ctx.symbol} di ${ctx.targetFile} diperluas dengan parameter bernama arg${ctx.paramCount + 1}, dst (bertanda TODO untuk diberi nama yang bermakna). Pemanggilan tidak berubah.`,
          safe: true,
          action: actionFor(ruleId, 'expand-params', ctx),
        },
      ]
    }

    case 'ws-py-arity':
    case 'ws-go-arity': {
      if (!ctx.targetFile || !ctx.symbol || !ctx.paramCount || !ctx.callCount) return undefined
      const isGo = ruleId === 'ws-go-arity'
      return [
        {
          id: 'trim-call-args',
          label: `Sisakan ${ctx.paramCount} argumen pemanggilan`,
          detail: `Pemanggilan di ${ctx.file} baris ${ctx.line} dipangkas menyisakan ${ctx.paramCount} argumen pertama agar cocok dengan signature ${ctx.symbol} di ${ctx.targetFile}. PASTIKAN argumen yang dibuang memang tidak diperlukan.`,
          safe: false,
          action: actionFor(ruleId, 'trim-call-args', ctx),
        },
        {
          id: isGo ? 'expand-params-go' : 'expand-params-py',
          label: `Tambah ${ctx.callCount - ctx.paramCount} parameter di ${ctx.targetFile}`,
          detail: isGo
            ? `Signature ${ctx.symbol} di ${ctx.targetFile} diperluas dengan parameter arg${ctx.paramCount + 1} bertipe any (bertanda TODO). Pemanggilan tidak berubah.`
            : `Signature ${ctx.symbol} di ${ctx.targetFile} diperluas dengan parameter bernama arg${ctx.paramCount + 1}, dst (bertanda TODO). Pemanggilan tidak berubah.`,
          safe: true,
          action: actionFor(ruleId, isGo ? 'expand-params-go' : 'expand-params-py', ctx),
        },
      ]
    }

    case 'ws-go-unused-import': {
      if (!ctx.spec) return undefined
      return [
        {
          id: 'remove-import-line',
          label: `Hapus import "${ctx.spec}"`,
          detail: `Baris import "${ctx.spec}" dihapus dari ${ctx.file} sehingga build Go tidak lagi gagal karena "imported and not used". Tidak ada kode lain yang diubah.`,
          safe: true,
          action: actionFor(ruleId, 'remove-import-line', ctx),
        },
      ]
    }

    case 'ws-php-require-missing': {
      if (!ctx.spec) return undefined
      return [
        {
          id: 'create-stub-file',
          label: `Buat berkas stub ${ctx.spec}`,
          detail: `Berkas PHP baru dibuat di jalur yang di-require (berisi penanda TODO), sehingga fatal error "Failed opening required" tidak terjadi dan isi berkas bisa segera dilengkapi.`,
          safe: true,
          action: actionFor(ruleId, 'create-stub-file', ctx),
        },
      ]
    }

    case 'ws-java-missing-import': {
      if (!ctx.symbol || !ctx.pkg || !ctx.targetFile) return undefined
      return [
        {
          id: 'add-import',
          label: `Tambahkan import ${ctx.pkg}.${ctx.symbol}`,
          detail: `Baris "import ${ctx.pkg}.${ctx.symbol};" disisipkan di ${ctx.file} setelah import yang ada (atau setelah deklarasi package). Kompilasi gagal "cannot find symbol" menjadi beres.`,
          safe: true,
          action: actionFor(ruleId, 'add-import', ctx),
        },
      ]
    }

    case 'ws-dep-cve': {
      if (!ctx.symbol || !ctx.fixedIn) return undefined
      const isPkg = /package\.json$/i.test(ctx.file)
      if (!isPkg && !/requirements(\.[\w-]+)?\.txt$/i.test(ctx.file)) return undefined
      return [
        {
          id: 'bump-dep-version',
          label: `Naikkan ${ctx.symbol} ke >= ${ctx.fixedIn}`,
          detail: `Nomor versi ${ctx.symbol} di ${ctx.file} diganti ${ctx.fixedIn} (operator rentang dipertahankan). Setelah itu jalankan ${isPkg ? 'npm install' : 'pip install -r requirements.txt'} agar versi terpasang ikut terbarui.`,
          safe: true,
          action: actionFor(ruleId, 'bump-dep-version', ctx),
        },
      ]
    }

    default:
      return undefined
  }
}

/* ============================================================
 *  2) OPERASI TEKS PRIMITIF
 * ============================================================ */

function replaceLine(code: string, line: number, fn: (text: string) => string | null): { code: string; before: string; after: string } | null {
  const lines = code.split('\n')
  if (line < 1 || line > lines.length) return null
  const before = lines[line - 1]
  const after = fn(before)
  if (after === null) return null
  lines[line - 1] = after
  return { code: lines.join('\n'), before, after }
}

/** Hapus SATU baris penuh (import mati) — mengurangi jumlah baris. */
function removeLine(code: string, line: number): { code: string; before: string } | null {
  const lines = code.split('\n')
  if (line < 1 || line > lines.length) return null
  const before = lines[line - 1]
  lines.splice(line - 1, 1)
  return { code: lines.join('\n'), before }
}

/** Keluarkan satu simbol dari braces import. Return baris baru, atau null bila baris harus dihapus, atau lineText bila tidak berubah. */
function stripSymbolFromImportLine(lineText: string, symbol: string): string | null {
  const braceRe = /\{([^}]*)\}/
  const m = braceRe.exec(lineText)
  if (!m) return null // import default/namespace/require tanpa braces → tidak berubah
  const entries = m[1].split(',').map(s => s.trim()).filter(Boolean)
  const kept = entries.filter(seg => seg.split(/\s+as\s+/)[0].trim() !== symbol)
  if (kept.length === entries.length) return lineText // simbol tidak ada di daftar
  if (kept.length > 0) {
    const newBraces = `{ ${kept.join(', ')} }`
    // pertahankan default bila bentuknya `import x, { ... }`
    if (/^\s*(?:import|export)\s+[A-Za-z_$][\w$]*\s*,/.test(lineText)) {
      return lineText.replace(braceRe, `, ${newBraces}`)
    }
    return lineText.replace(braceRe, ` ${newBraces}`)
  }
  // braces jadi kosong
  if (/^\s*(?:import|export)\s+[A-Za-z_$][\w$]*\s*,/.test(lineText)) {
    // masih ada default: `import x, { }` → `import x`
    return lineText.replace(/\s*,\s*\{[^}]*\}/, '')
  }
  return null // seluruh baris dihapus
}

/**
 * Pangkas argumen pemanggilan pada satu baris agar tersisa `keep` argumen.
 * Bekerja pada kode ASLI dengan indeks dari hasil mask (panjang identik).
 */
function trimCallOnLine(code: string, lineNo: number, fnName: string, keep: number): string | null {
  const lines = code.split('\n')
  if (lineNo < 1 || lineNo > lines.length) return null
  const masked = maskCode(code)
  const maskedLines = masked.split('\n')
  const lineMasked = maskedLines[lineNo - 1]
  const callRe = new RegExp(`(?<![.\\w$'"\`])${esc(fnName)}\\s*\\(`)
  const cm = callRe.exec(lineMasked)
  if (!cm) return null
  // indeks absolut kurung buka dalam seluruh kode
  const openAbs = maskedLines.slice(0, lineNo - 1).reduce((s, l) => s + l.length + 1, 0) + cm.index + cm[0].lastIndexOf('(')
  const counted = countCallArgs(masked, openAbs)
  if (!counted || counted.hasSpread || counted.count <= keep) return null
  // petakan posisi koma level-atas (depth 1) dalam region argumen
  let depth = 0
  const commaAbs: number[] = []
  for (let i = openAbs; i < masked.length; i++) {
    const ch = masked[i]
    if (ch === '(') depth++
    else if (ch === ')') {
      depth--
      if (depth === 0) break
    } else if (ch === ',' && depth === 1) commaAbs.push(i)
  }
  if (commaAbs.length < counted.count - 1) return null
  const cutIdx = commaAbs[keep - 1] // koma ke-`keep` → argumen setelahnya dibuang
  // cari penutup absolut
  let closeAbs = -1
  depth = 0
  for (let i = openAbs; i < masked.length; i++) {
    if (masked[i] === '(') depth++
    else if (masked[i] === ')') {
      depth--
      if (depth === 0) {
        closeAbs = i
        break
      }
    }
  }
  if (closeAbs < 0) return null
  return code.slice(0, cutIdx) + code.slice(closeAbs)
}

/** Tambah parameter argN+1.. ke deklarasi fungsi/arrow di target. */
function expandParamsOnCode(targetCode: string, symbol: string, currentCount: number, addCount: number): { code: string; line: number } | null {
  const masked = maskCode(targetCode)
  const lines = masked.split('\n')
  const fnRe = new RegExp(`\\b(?:async\\s+)?function\\s+${esc(symbol)}\\s*\\(([^)]*)\\)`)
  const arrowRe = new RegExp(`\\bconst\\s+${esc(symbol)}\\s*=\\s*\\(([^)]*)\\)\\s*=>`)
  for (let i = 0; i < lines.length; i++) {
    const m = fnRe.exec(lines[i]) ?? arrowRe.exec(lines[i])
    if (!m) continue
    const extra = Array.from({ length: addCount }, (_, k) => `arg${currentCount + 1 + k}`).join(', ')
    const existing = m[1].trim()
    const insertRel = m.index + m[0].length - 1 // posisi ')' dalam baris masked
    const abs = lines.slice(0, i).reduce((s, l) => s + l.length + 1, 0) + insertRel
    const suffix = existing ? `, ${extra}` : extra
    const newCode = targetCode.slice(0, abs) + suffix + targetCode.slice(abs)
    return { code: newCode, line: i + 1 }
  }
  return null
}

/**
 * Pangkas argumen pemanggilan BERKUALIFIKASI `pkg.Name(` pada satu baris
 * agar tersisa `keep` argumen (untuk Go lintas paket).
 */
function trimQualifiedCallOnLine(code: string, lineNo: number, pkg: string, fnName: string, keep: number): string | null {
  const lines = code.split('\n')
  if (lineNo < 1 || lineNo > lines.length) return null
  const masked = maskCode(code)
  const maskedLines = masked.split('\n')
  const lineMasked = maskedLines[lineNo - 1]
  const callRe = new RegExp(`(?<![\\w$'"\`])${esc(pkg)}\\s*\\.\\s*${esc(fnName)}\\s*\\(`)
  const cm = callRe.exec(lineMasked)
  if (!cm) return null
  const openAbs = maskedLines.slice(0, lineNo - 1).reduce((s, l) => s + l.length + 1, 0) + cm.index + cm[0].lastIndexOf('(')
  const counted = countCallArgs(masked, openAbs)
  if (!counted || counted.hasSpread || counted.count <= keep) return null
  let depth = 0
  const commaAbs: number[] = []
  for (let i = openAbs; i < masked.length; i++) {
    const ch = masked[i]
    if (ch === '(') depth++
    else if (ch === ')') {
      depth--
      if (depth === 0) break
    } else if (ch === ',' && depth === 1) commaAbs.push(i)
  }
  if (commaAbs.length < counted.count - 1) return null
  const cutIdx = commaAbs[keep - 1]
  let closeAbs = -1
  depth = 0
  for (let i = openAbs; i < masked.length; i++) {
    if (masked[i] === '(') depth++
    else if (masked[i] === ')') {
      depth--
      if (depth === 0) {
        closeAbs = i
        break
      }
    }
  }
  if (closeAbs < 0) return null
  return code.slice(0, cutIdx) + code.slice(closeAbs)
}

/** Perluas parameter deklarasi `def name(...)` Python atau `func Name(...)` Go. */
function expandParamsDefLike(targetCode: string, symbol: string, currentCount: number, addCount: number, withType: boolean): { code: string; line: number } | null {
  const lines = targetCode.split('\n')
  const re = withType
    ? new RegExp(`^(func\\s+${esc(symbol)}\\s*\\()([^)]*)(\\))`)
    : new RegExp(`^((?:\\s*)(?:async\\s+)?def\\s+${esc(symbol)}\\s*\\()([^)]*)(\\))`)
  for (let i = 0; i < lines.length; i++) {
    const m = re.exec(lines[i])
    if (!m) continue
    const extra = Array.from({ length: addCount }, (_, k) =>
      withType ? `arg${currentCount + 1 + k} any /* TODO beri nama */` : `arg${currentCount + 1 + k} /* TODO beri nama */`,
    ).join(', ')
    const existing = m[2].trim()
    const inner = existing ? `${m[2]}, ${extra}` : extra
    lines[i] = `${m[1]}${inner}${m[3]}`
    return { code: lines.join('\n'), line: i + 1 }
  }
  return null
}

function envVarName(keyName: string): string {
  return keyName.replace(/[^A-Za-z0-9]/g, '_').toUpperCase()
}

/* ============================================================
 *  3) VALIDASI + EKSEKUSI SATU AKSI
 * ============================================================ */

export type GuidedFixOutcome =
  | { ok: true; files: WorkspaceFileInput[]; addedFiles: string[]; description: string; before?: string; after?: string }
  | { ok: false; reason: string }

function findFile(files: WorkspaceFileInput[], name: string | undefined): WorkspaceFileInput | null {
  if (!name) return null
  return files.find(f => f.name === name) ?? null
}

export function applyGuidedFix(files: WorkspaceFileInput[], action: GuidedFixAction): GuidedFixOutcome {
  const importer = findFile(files, action.file)
  if (!importer) return { ok: false, reason: `Berkas "${action.file}" tidak ada di workspace.` }

  switch (`${action.ruleId}:${action.option}`) {
    /* ---------- JS: simbol tidak diekspor ---------- */
    case 'ws-js-import-symbol:add-export':
    case 'ws-js-import-symbol:stub-export': {
      const target = findFile(files, action.targetFile)
      if (!target || !action.symbol) return { ok: false, reason: 'Target atau simbol tidak ditemukan.' }
      // validasi ulang: import masih ada & target tetap tidak mengekspor simbol
      const imp = scanJsImports(importer.code).find(
        i => action.targetFile && resolveLocalImport(action.file, i.spec, new Set(files.map(f => f.name))) === action.targetFile && i.names.some(n => n.imported === action.symbol),
      )
      if (!imp) return { ok: false, reason: `Import "${action.symbol}" dari ${action.targetFile} sudah tidak ada — temuan kadaluarsa.` }
      const exp = scanJsExports(target.code)
      if (exp.named.has(action.symbol) || exp.hasStarReexport) {
        return { ok: false, reason: `${action.targetFile} kini sudah mengekspor "${action.symbol}" — temuan kadaluarsa.` }
      }
      if (action.option === 'add-export') {
        const declLine = findDeclLine(target.code, action.symbol)
        if (declLine === null) return { ok: false, reason: `Deklarasi ${action.symbol} tidak ditemukan di ${target.name} — temuan kadaluarsa.` }
        const declRe = new RegExp(`^((?:\\s*)(?:async\\s+)?(?:function\\*?|class|const|let|var|type|interface|enum)\\s+${esc(action.symbol)}\\b)`)
        const res = replaceLine(target.code, declLine, t => t.replace(declRe, 'export $1'))
        if (!res || res.after === res.before) return { ok: false, reason: 'Deklarasi tidak bisa diubah (bentuk tidak dikenali).' }
        return {
          ok: true,
          files: files.map(f => (f.name === target.name ? { ...f, code: res.code } : f)),
          addedFiles: [],
          description: `export ditambahkan pada deklarasi ${action.symbol} di ${target.name} (baris ${declLine}).`,
          before: res.before.trim(),
          after: res.after.trim(),
        }
      }
      // stub-export
      const stub = `\n// TODO (bughunter): lengkapi implementasi\nexport function ${action.symbol}() {\n  throw new Error('${action.symbol} belum diimplementasi')\n}\n`
      return {
        ok: true,
        files: files.map(f => (f.name === target.name ? { ...f, code: target.code + stub } : f)),
        addedFiles: [],
        description: `stub export ${action.symbol}() ditambahkan di akhir ${target.name} (bertanda TODO, melempar error sampai diimplementasi).`,
      }
    }

    case 'ws-js-import-symbol:remove-import-symbol': {
      if (!action.symbol) return { ok: false, reason: 'Simbol tidak ada.' }
      // cari ulang import-nya (tahan pergeseran baris)
      const fileSet = new Set(files.map(f => f.name))
      const imp = scanJsImports(importer.code).find(
        i =>
          i.names.some(n => n.imported === action.symbol) &&
          (!action.targetFile || resolveLocalImport(action.file, i.spec, fileSet) === action.targetFile),
      )
      if (!imp) return { ok: false, reason: `Import "${action.symbol}" dari ${action.targetFile ?? '?'} sudah tidak ada — temuan kadaluarsa.` }
      const res = replaceLine(importer.code, imp.line, t => stripSymbolFromImportLine(t, action.symbol!))
      if (!res) return { ok: false, reason: `Baris import tidak bisa diubah (${importer.name}:${imp.line}).` }
      if (res.after === res.before) return { ok: false, reason: `Simbol "${action.symbol}" tidak ada di daftar import.` }
      return {
        ok: true,
        files: files.map(f => (f.name === importer.name ? { ...f, code: res.code } : f)),
        addedFiles: [],
        description: `"${action.symbol}" dikeluarkan dari import di ${importer.name} baris ${imp.line}.`,
        before: res.before.trim(),
        after: res.after.trim(),
      }
    }

    /* ---------- JS: file tujuan tidak ada ---------- */
    case 'ws-js-import-missing-file:create-stub-file': {
      if (!action.spec) return { ok: false, reason: 'Spesifikasi import tidak ada.' }
      // validasi ulang: spec tetap tidak ter-resolve
      if (resolveLocalImport(action.file, action.spec, new Set(files.map(f => f.name)))) {
        return { ok: false, reason: `"${action.spec}" kini sudah ter-resolve ke berkas yang ada — temuan kadaluarsa.` }
      }
      const path = stubPathForImport(action.file, action.spec)
      const clean = sanitizeFileName(path)
      if (!clean) return { ok: false, reason: `Jalur stub tidak valid: "${path}".` }
      if (files.some(f => f.name === clean)) return { ok: false, reason: `Berkas "${clean}" sudah ada.` }
      if (files.length >= 50) return { ok: false, reason: 'Workspace penuh (maks 50 file).' }
      const imp = scanJsImports(importer.code).find(i => i.spec === action.spec) ?? scanJsImports(importer.code).find(i => i.line === action.line)
      const parts: string[] = ['// TODO (bughunter): modul stub dibuat otomatis — lengkapi implementasinya.', '']
      if (imp && imp.names.length > 0) {
        for (const n of imp.names) {
          parts.push(`export function ${n.imported}() {`, `  throw new Error('${n.imported} belum diimplementasi')`, '}', '')
        }
      } else {
        parts.push('export default function stub() {', "  throw new Error('stub belum diimplementasi')", '}', '')
      }
      const files2 = [...files, { name: clean, code: parts.join('\n') }]
      return {
        ok: true,
        files: files2,
        addedFiles: [clean],
        description: `Berkas baru ${clean} dibuat berisi stub export bertanda TODO.`,
      }
    }

    case 'ws-js-import-missing-file:remove-import-line': {
      if (!action.spec) return { ok: false, reason: 'Spesifikasi import tidak ada.' }
      if (resolveLocalImport(action.file, action.spec, new Set(files.map(f => f.name)))) {
        return { ok: false, reason: `"${action.spec}" kini sudah ada di workspace — temuan kadaluarsa.` }
      }
      // cari ulang baris import-nya (tahan pergeseran baris)
      const imp = scanJsImports(importer.code).find(i => i.spec === action.spec) ?? scanJsImports(importer.code).find(i => i.line === action.line)
      if (!imp) return { ok: false, reason: `Import "${action.spec}" tidak ditemukan di ${importer.name} — temuan kadaluarsa.` }
      const res = removeLine(importer.code, imp.line)
      if (!res) return { ok: false, reason: 'Baris import tidak bisa dihapus.' }
      return {
        ok: true,
        files: files.map(f => (f.name === importer.name ? { ...f, code: res.code } : f)),
        addedFiles: [],
        description: `Baris import "${action.spec}" dihapus dari ${importer.name}.`,
        before: res.before.trim(),
      }
    }

    /* ---------- Python: simbol tidak tersedia ---------- */
    case 'ws-py-import-symbol:stub-python': {
      const target = findFile(files, action.targetFile)
      if (!target || !action.symbol) return { ok: false, reason: 'Target atau simbol tidak ditemukan.' }
      const definedRe = new RegExp(`^(?:def\\s+${esc(action.symbol)}\\b|class\\s+${esc(action.symbol)}\\b|${esc(action.symbol)}\\s*=)`, 'm')
      if (definedRe.test(target.code)) return { ok: false, reason: `${target.name} kini sudah mendefinisikan "${action.symbol}" — temuan kadaluarsa.` }
      const stub = `\n\n# TODO (bughunter): lengkapi implementasi\ndef ${action.symbol}(*args, **kwargs):\n    raise NotImplementedError("${action.symbol} belum diimplementasi")\n`
      return {
        ok: true,
        files: files.map(f => (f.name === target.name ? { ...f, code: target.code + stub } : f)),
        addedFiles: [],
        description: `stub ${action.symbol}() ditambahkan di akhir ${target.name} (NotImplementedError bertanda TODO).`,
      }
    }

    case 'ws-py-import-symbol:remove-py-symbol': {
      if (!action.symbol) return { ok: false, reason: 'Simbol tidak ada.' }
      // cari ulang baris from-import (tahan pergeseran baris)
      const imp = scanPyImports(importer.code).find(
        i => i.symbols.includes(action.symbol!) && (!action.targetFile || `${i.module.split('.')[0]}.py` === action.targetFile),
      ) ?? scanPyImports(importer.code).find(i => i.symbols.includes(action.symbol!) && i.line === action.line)
      if (!imp) return { ok: false, reason: `Import "${action.symbol}" tidak ditemukan — temuan kadaluarsa.` }
      const kept = imp.symbols.filter(s => s !== action.symbol)
      if (kept.length > 0) {
        const res = replaceLine(importer.code, imp.line, t =>
          t.replace(/^()(\s*from\s+[A-Za-z_][\w.]*\s+import\s+).+$/, (_all, _p, prefix) => `${prefix}${kept.join(', ')}`),
        )
        if (!res || res.after === res.before) return { ok: false, reason: 'Baris from-import tidak bisa diubah.' }
        return {
          ok: true,
          files: files.map(f => (f.name === importer.name ? { ...f, code: res.code } : f)),
          addedFiles: [],
          description: `"${action.symbol}" dikeluarkan dari from-import di ${importer.name}:${imp.line}.`,
          before: res.before.trim(),
          after: res.after.trim(),
        }
      }
      const res2 = removeLine(importer.code, imp.line)
      if (!res2) return { ok: false, reason: 'Baris from-import tidak bisa dihapus.' }
      return {
        ok: true,
        files: files.map(f => (f.name === importer.name ? { ...f, code: res2.code } : f)),
        addedFiles: [],
        description: `Baris from-import dihapus seluruhnya dari ${importer.name} (tidak ada simbol lain di baris itu).`,
        before: res2.before.trim(),
      }
    }

    /* ---------- kredensial → env var ---------- */
    case 'ws-shared-secret:use-env-var': {
      const lang = languageForFile(importer.name)
      if (lang !== 'javascript' && lang !== 'python') return { ok: false, reason: 'Dukungan env var hanya untuk JS/Python.' }
      // validasi ulang: baris masih memuat literal secret
      const sec = scanSecretValues(importer.code).find(s => s.line === action.line)
      if (!sec) return { ok: false, reason: `Kredensial tidak ada lagi di ${importer.name}:${action.line} — temuan kadaluarsa.` }
      const name = envVarName(sec.keyName)
      let newCode = importer.code
      let desc = ''
      if (lang === 'javascript') {
        const res = replaceLine(importer.code, action.line, t =>
          t.replace(
            new RegExp(`\\b${esc(sec.keyName)}\\b(\\s*[:=]\\s*)["'\`]${sec.value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}["'\`]`),
            `process.env.${name}`,
          ),
        )
        if (!res || res.after === res.before) return { ok: false, reason: 'Pola kredensial tidak bisa diganti (bentuk tidak dikenali).' }
        newCode = res.code
        desc = `Literal diganti process.env.${name} di ${importer.name}:${action.line}.`
      } else {
        const res = replaceLine(importer.code, action.line, t =>
          t.replace(
            new RegExp(`\\b${esc(sec.keyName)}\\b(\\s*[:=]\\s*)["']${sec.value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}["']`),
            `os.environ["${name}"]`,
          ),
        )
        if (!res || res.after === res.before) return { ok: false, reason: 'Pola kredensial tidak bisa diganti (bentuk tidak dikenali).' }
        newCode = res.code
        if (!/^import\s+os\b/m.test(newCode)) newCode = `import os\n` + newCode
        desc = `Literal diganti os.environ["${name}"] di ${importer.name}:${action.line}${newCode !== res.code ? ' (import os ditambahkan)' : ''}.`
      }
      return {
        ok: true,
        files: files.map(f => (f.name === importer.name ? { ...f, code: newCode } : f)),
        addedFiles: [],
        description: `${desc} JANGAN LUPA: rotasi kredensial lama — dianggap sudah terekspos.`,
      }
    }

    /* ---------- siklus: putus sisi ---------- */
    case 'ws-circular-import:cut-edge': {
      const targetFile = action.targetFile
      if (!targetFile) return { ok: false, reason: 'Target siklus tidak ada.' }
      // validasi ulang: masih ada import dari target yang ter-resolve
      const fileSet = new Set(files.map(f => f.name))
      const lang = languageForFile(importer.name)
      if (lang === 'javascript') {
        const imp = scanJsImports(importer.code).find(i => resolveLocalImport(action.file, i.spec, fileSet) === targetFile)
        if (!imp) return { ok: false, reason: `Import dari ${targetFile} sudah tidak ada — temuan kadaluarsa.` }
        const res = removeLine(importer.code, imp.line)
        if (!res) return { ok: false, reason: 'Baris import tidak bisa dihapus.' }
        return {
          ok: true,
          files: files.map(f => (f.name === importer.name ? { ...f, code: res.code } : f)),
          addedFiles: [],
          description: `Sisi siklus ${importer.name} → ${targetFile} diputus (baris import dihapus).`,
          before: res.before.trim(),
        }
      }
      if (lang === 'python') {
        const imp = scanPyImports(importer.code).find(i => `${i.module.split('.')[0]}.py` === targetFile)
        if (!imp) return { ok: false, reason: `Import dari ${targetFile} sudah tidak ada — temuan kadaluarsa.` }
        const res = removeLine(importer.code, imp.line)
        if (!res) return { ok: false, reason: 'Baris import tidak bisa dihapus.' }
        return {
          ok: true,
          files: files.map(f => (f.name === importer.name ? { ...f, code: res.code } : f)),
          addedFiles: [],
          description: `Sisi siklus ${importer.name} → ${targetFile} diputus (baris import dihapus).`,
          before: res.before.trim(),
        }
      }
      return { ok: false, reason: 'Bahasa berkas tidak didukung untuk pemutusan siklus.' }
    }

    /* ---------- dead export → unexport ---------- */
    case 'ws-dead-export:unexport': {
      if (!action.symbol) return { ok: false, reason: 'Simbol tidak ada.' }
      const declLine = findExportDeclLine(importer.code, action.symbol)
      if (declLine === null) return { ok: false, reason: `Deklarasi export "${action.symbol}" tidak ditemukan — temuan kadaluarsa.` }
      // pastikan tetap tidak diimpor siapa pun
      const stillUsed = files.some(f => {
        if (f.name === importer.name) return false
        return scanJsImports(f.code).some(i => resolveLocalImport(f.name, i.spec, new Set(files.map(x => x.name))) === importer.name && i.names.some(n => n.imported === action.symbol))
      })
      if (stillUsed) return { ok: false, reason: `"${action.symbol}" kini diimpor file lain — temuan kadaluarsa.` }
      const res = replaceLine(importer.code, declLine, t => t.replace(new RegExp(`^((?:\\s*)(?:export\\s+(?:default\\s+)?(?:async\\s+)?)?)export\\s+`), '$1'))
      if (!res || res.after === res.before) return { ok: false, reason: 'Kata export tidak bisa dilepas (bentuk tidak dikenali).' }
      return {
        ok: true,
        files: files.map(f => (f.name === importer.name ? { ...f, code: res.code } : f)),
        addedFiles: [],
        description: `"export" dilepas dari deklarasi ${action.symbol} di ${importer.name}:${declLine} — kode tetap ada.`,
        before: res.before.trim(),
        after: res.after.trim(),
      }
    }

    /* ---------- arity ---------- */
    case 'ws-arity:trim-call-args': {
      if (!action.symbol || !action.paramCount) return { ok: false, reason: 'Data arity tidak lengkap.' }
      const trimmed = trimCallOnLine(importer.code, action.line, action.symbol, action.paramCount)
      if (!trimmed) return { ok: false, reason: `Pemanggilan ${action.symbol}() tidak ditemukan/dipangkas di ${importer.name}:${action.line} — temuan kadaluarsa.` }
      return {
        ok: true,
        files: files.map(f => (f.name === importer.name ? { ...f, code: trimmed } : f)),
        addedFiles: [],
        description: `Pemanggilan ${action.symbol}() dipangkas menyisakan ${action.paramCount} argumen pertama.`,
      }
    }

    case 'ws-arity:expand-params': {
      const target = findFile(files, action.targetFile)
      if (!target || !action.symbol || !action.paramCount || !action.callCount) return { ok: false, reason: 'Data arity tidak lengkap.' }
      const expanded = expandParamsOnCode(target.code, action.symbol, action.paramCount, action.callCount - action.paramCount)
      if (!expanded) return { ok: false, reason: `Deklarasi ${action.symbol}() tidak ditemukan di ${target.name} (atau parameternya multi-baris).` }
      return {
        ok: true,
        files: files.map(f => (f.name === target.name ? { ...f, code: expanded.code } : f)),
        addedFiles: [],
        description: `Signature ${action.symbol} di ${target.name}:${expanded.line} diperluas menjadi ${action.callCount} parameter (arg${action.paramCount + 1}+ — beri nama yang bermakna).`,
      }
    }

    /* ---------- arity Python & Go ---------- */
    case 'ws-py-arity:trim-call-args':
    case 'ws-go-arity:trim-call-args': {
      if (!action.symbol || !action.paramCount) return { ok: false, reason: 'Data arity tidak lengkap.' }
      const useQualified = action.ruleId === 'ws-go-arity' && action.pkg
      const trimmed = useQualified
        ? trimQualifiedCallOnLine(importer.code, action.line, action.pkg!, action.symbol, action.paramCount)
        : trimCallOnLine(importer.code, action.line, action.symbol, action.paramCount)
      if (!trimmed) return { ok: false, reason: `Pemanggilan ${action.symbol}() tidak ditemukan/dipangkas di ${importer.name}:${action.line} — temuan kadaluarsa.` }
      return {
        ok: true,
        files: files.map(f => (f.name === importer.name ? { ...f, code: trimmed } : f)),
        addedFiles: [],
        description: `Pemanggilan ${action.symbol}() dipangkas menyisakan ${action.paramCount} argumen pertama.`,
      }
    }

    case 'ws-py-arity:expand-params-py':
    case 'ws-go-arity:expand-params-go': {
      const target = findFile(files, action.targetFile)
      if (!target || !action.symbol || !action.paramCount || !action.callCount) return { ok: false, reason: 'Data arity tidak lengkap.' }
      const expanded = expandParamsDefLike(target.code, action.symbol, action.paramCount, action.callCount - action.paramCount, action.ruleId === 'ws-go-arity')
      if (!expanded) return { ok: false, reason: `Deklarasi ${action.symbol}() tidak ditemukan di ${target.name} (atau parameternya multi-baris).` }
      return {
        ok: true,
        files: files.map(f => (f.name === target.name ? { ...f, code: expanded.code } : f)),
        addedFiles: [],
        description: `Signature ${action.symbol} di ${target.name}:${expanded.line} diperluas menjadi ${action.callCount} parameter — beri nama yang bermakna.`,
      }
    }

    /* ---------- Go: import tak terpakai ---------- */
    case 'ws-go-unused-import:remove-import-line': {
      if (!action.spec) return { ok: false, reason: 'Path import tidak ada.' }
      const lines = importer.code.split('\n')
      const impRe = new RegExp(`^\\s*(?:[A-Za-z_]\\w*\\s+)?"${action.spec.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}"\\s*$`)
      const singleRe = new RegExp(`^\\s*import\\s+(?:[A-Za-z_]\\w*\\s+)?"${action.spec.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}"`)
      let lineNo = -1
      for (let i = 0; i < lines.length; i++) {
        if (impRe.test(lines[i]) || singleRe.test(lines[i])) {
          lineNo = i + 1
          break
        }
      }
      if (lineNo === -1) return { ok: false, reason: `Import "${action.spec}" sudah tidak ada di ${importer.name} — temuan kadaluarsa.` }
      // validasi: tetap tidak terpakai
      const masked = maskCode(importer.code)
      const ident = action.spec.split('/').filter(Boolean).pop() ?? ''
      if (ident && new RegExp(`(?<![\\w.'"\`])${esc(ident)}\\s*\\.`).test(masked)) {
        return { ok: false, reason: `Paket "${ident}" kini dipakai di kode — temuan kadaluarsa.` }
      }
      const res = removeLine(importer.code, lineNo)
      if (!res) return { ok: false, reason: 'Baris import tidak bisa dihapus.' }
      return {
        ok: true,
        files: files.map(f => (f.name === importer.name ? { ...f, code: res.code } : f)),
        addedFiles: [],
        description: `Import "${action.spec}" dihapus dari ${importer.name}:${lineNo} — build tidak lagi gagal karena import tak terpakai.`,
        before: res.before.trim(),
      }
    }

    /* ---------- PHP: berkas yang di-require tidak ada ---------- */
    case 'ws-php-require-missing:create-stub-file': {
      if (!action.spec) return { ok: false, reason: 'Jalur require tidak ada.' }
      const base = importer.name.includes('/') ? importer.name.slice(0, importer.name.lastIndexOf('/')) : ''
      const candidates = [action.spec, base ? `${base}/${action.spec}` : action.spec]
      if (candidates.some(c => files.some(f => f.name === c))) {
        return { ok: false, reason: `"${action.spec}" kini sudah ada di workspace — temuan kadaluarsa.` }
      }
      const raw = candidates.find(c => sanitizeFileName(c) === c) ?? action.spec
      const clean = sanitizeFileName(raw)
      if (!clean) return { ok: false, reason: `Jalur stub tidak valid: "${raw}".` }
      if (files.length >= 50) return { ok: false, reason: 'Workspace penuh (maks 50 file).' }
      const content = '<?php\n\n// TODO (bughunter): berkas stub dibuat otomatis — lengkapi implementasinya.\n'
      return {
        ok: true,
        files: [...files, { name: clean, code: content }],
        addedFiles: [clean],
        description: `Berkas baru ${clean} dibuat berisi stub bertanda TODO.`,
      }
    }

    /* ---------- Java: import yang hilang ---------- */
    case 'ws-java-missing-import:add-import': {
      if (!action.symbol || !action.pkg || !action.targetFile) return { ok: false, reason: 'Data import tidak lengkap.' }
      const importRe = new RegExp(`^\\s*import\\s+${esc(action.pkg)}\\.${esc(action.symbol)}\\s*;`, 'm')
      if (importRe.test(importer.code)) {
        return { ok: false, reason: `Import ${action.pkg}.${action.symbol} kini sudah ada — temuan kadaluarsa.` }
      }
      const lines = importer.code.split('\n')
      let insertAfter = -1
      for (let i = 0; i < lines.length; i++) {
        if (/^\s*import\s/.test(lines[i])) insertAfter = i
      }
      if (insertAfter === -1) {
        for (let i = 0; i < lines.length; i++) {
          if (/^\s*package\s/.test(lines[i])) {
            insertAfter = i
            break
          }
        }
      }
      const newLine = `import ${action.pkg}.${action.symbol};`
      if (insertAfter >= 0) lines.splice(insertAfter + 1, 0, newLine)
      else lines.unshift(newLine)
      return {
        ok: true,
        files: files.map(f => (f.name === importer.name ? { ...f, code: lines.join('\n') } : f)),
        addedFiles: [],
        description: `"${newLine}" disisipkan di ${importer.name}${insertAfter >= 0 ? ` (baris ${insertAfter + 2})` : ' (bagian atas)'}.`,
      }
    }

    /* ---------- dependensi CVE ---------- */
    case 'ws-dep-cve:bump-dep-version': {
      if (!action.symbol || !action.fixedIn) return { ok: false, reason: 'Data dependensi tidak lengkap.' }
      const isPkg = /package\.json$/i.test(importer.name)
      const isReq = /requirements(\.[\w-]+)?\.txt$/i.test(importer.name)
      if (!isPkg && !isReq) return { ok: false, reason: 'Berkas bukan manifest dependensi.' }
      const pkg = action.symbol
      const res = replaceLine(importer.code, action.line, t => {
        if (isPkg) {
          const re = new RegExp(`("${esc(pkg)}"\\s*:\\s*["'])([^"']+)(["'])`, 'i')
          if (!re.test(t)) return null
          return t.replace(re, (_all: string, p1: string, ver: string, p2: string) => {
            const prefix = /^[~^>=]*/.exec(ver)?.[0] ?? ''
            return `${p1}${prefix}${action.fixedIn}${p2}`
          })
        }
        const re = new RegExp(`^\\s*${esc(pkg)}\\s*(==|>=|~=|!=|===)?\\s*[\\w.+-]+`, 'i')
        if (!re.test(t)) return null
        return t.replace(re, (m0: string) => {
          const opMatch = /(==|>=|~=|!=|===)/.exec(m0)
          const op = opMatch ? opMatch[1] : '=='
          return `${m0.slice(0, m0.toLowerCase().indexOf(pkg.toLowerCase()) + pkg.length)}${op}${action.fixedIn}`
        })
      })
      if (!res || res.after === res.before) return { ok: false, reason: `Entri ${pkg} tidak ditemukan di baris ${action.line} — temuan kadaluarsa.` }
      return {
        ok: true,
        files: files.map(f => (f.name === importer.name ? { ...f, code: res.code } : f)),
        addedFiles: [],
        description: `${pkg} dinaikkan ke ${isPkg ? `^${action.fixedIn}` : `== ${action.fixedIn}`} di ${importer.name}. Jalankan ${isPkg ? 'npm install' : 'pip install -r requirements.txt'} agar terpasang.`,
        before: res.before.trim(),
        after: res.after.trim(),
      }
    }

    default:
      return { ok: false, reason: `Kombinasi aturan/solusi tidak dikenal: ${action.ruleId}/${action.option}.` }
  }
}

/** Terapkan BANYAK aksi berurutan pada satu salinan kerja. */
export function applyGuidedFixes(
  files: WorkspaceFileInput[],
  actions: GuidedFixAction[],
): { files: WorkspaceFileInput[]; addedFiles: string[]; results: Array<{ ok: boolean; option: string; file: string; targetFile?: string; line?: number; description?: string; before?: string; after?: string; reason?: string }>; appliedCount: number } {
  let working = files.map(f => ({ ...f }))
  const addedFiles: string[] = []
  const results: Array<{ ok: boolean; option: string; file: string; targetFile?: string; line?: number; description?: string; before?: string; after?: string; reason?: string }> = []
  let appliedCount = 0

  for (const action of actions) {
    const outcome = applyGuidedFix(working, action)
    if (outcome.ok) {
      working = outcome.files
      for (const a of outcome.addedFiles) if (!addedFiles.includes(a)) addedFiles.push(a)
      appliedCount++
      results.push({
        ok: true,
        option: action.option,
        file: action.file,
        targetFile: action.targetFile,
        line: action.line,
        description: outcome.description,
        before: outcome.before,
        after: outcome.after,
      })
    } else {
      results.push({
        ok: false,
        option: action.option,
        file: action.file,
        targetFile: action.targetFile,
        line: action.line,
        reason: outcome.reason,
      })
    }
  }
  return { files: working, addedFiles, results, appliedCount }
}
