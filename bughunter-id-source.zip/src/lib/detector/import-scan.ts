import type { SourceLang } from '@/lib/types'

/**
 * ============================================================
 *  PEMINDAI IMPORT/EKSPOR MURNI — dipakai bersama oleh
 *  workspace.ts (deteksi) dan guided-fix.ts (perbaikan berpandu).
 *  Semua fungsi murni: tidak menyimpan state, tidak ber-I/O.
 * ============================================================
 */

/* ---------- pemetaan ekstensi ---------- */

const EXT_LANGUAGE: Record<string, SourceLang> = {
  js: 'javascript',
  mjs: 'javascript',
  cjs: 'javascript',
  jsx: 'javascript',
  ts: 'javascript',
  tsx: 'javascript',
  py: 'python',
  java: 'java',
  php: 'php',
  go: 'go',
}

export function languageForFile(name: string): SourceLang | null {
  const m = /\.([a-z0-9]+)$/i.exec(name)
  return m ? (EXT_LANGUAGE[m[1].toLowerCase()] ?? null) : null
}

/** Bersihkan nama berkas dari traversal/karakter berbahaya. Return null jika tidak valid. */
export function sanitizeFileName(raw: string): string | null {
  if (!raw || raw.length > 200) return null
  // Normalisasi backslash, buang kontrol char, pecah per segmen.
  const normalized = raw.replace(/\\/g, '/')
  if (/[\u0000-\u001f\u007f]/.test(normalized)) return null
  const segments = normalized
    .split('/')
    .filter(seg => seg.length > 0 && seg !== '.' && seg !== '..')
  if (segments.length === 0) return null
  const clean = segments.join('/')
  return clean.length <= 200 ? clean : null
}

/* ---------- resolusi jalur import relatif ---------- */

/** Normalisasi spesifikasi import relatif menjadi kandidat jalur file workspace. */
export function resolveLocalImport(fromFile: string, spec: string, fileSet: Set<string>): string | null {
  const base = fromFile.includes('/') ? fromFile.slice(0, fromFile.lastIndexOf('/')) : ''
  const parts = (base ? base.split('/') : [])
  for (const seg of spec.split('/')) {
    if (seg === '.' || seg === '') continue
    if (seg === '..') parts.pop()
    else parts.push(seg)
  }
  const bare = parts.join('/')
  const candidates = [
    bare,
    `${bare}.js`, `${bare}.ts`, `${bare}.jsx`, `${bare}.tsx`, `${bare}.mjs`, `${bare}.cjs`,
    `${bare}/index.js`, `${bare}/index.ts`, `${bare}/index.jsx`, `${bare}/index.tsx`,
  ]
  for (const c of candidates) if (fileSet.has(c)) return c
  return null
}

/**
 * Jalur berkas BARU yang paling masuk akal untuk spesifikasi import yang
 * tidak ter-resolve — dipakai fitur "buat file stub". Meniru preferensi
 * resolveLocalImport (ekstensi sesuai pengimpor, bawaan .js).
 */
export function stubPathForImport(fromFile: string, spec: string): string {
  const base = fromFile.includes('/') ? fromFile.slice(0, fromFile.lastIndexOf('/')) : ''
  const parts = (base ? base.split('/') : [])
  for (const seg of spec.split('/')) {
    if (seg === '.' || seg === '') continue
    if (seg === '..') parts.pop()
    else parts.push(seg)
  }
  const bare = parts.join('/')
  const extMatch = /\.([a-z0-9]+)$/i.exec(bare)
  if (extMatch && /^(js|mjs|cjs|jsx|ts|tsx)$/i.test(extMatch[1])) return bare
  // tanpa ekstensi: ikuti ekstensi pengimpor (ts→ts), selain itu .js
  const importerExt = /\.([a-z0-9]+)$/i.exec(fromFile)?.[1]?.toLowerCase()
  const ext = importerExt && /^(ts|tsx)$/.test(importerExt) ? importerExt : 'js'
  return `${bare}.${ext}`
}

/* ---------- ekspor JS/TS ---------- */

export interface JsExports {
  named: Set<string>
  hasDefault: boolean
  hasStarReexport: boolean
  isModule: boolean
}

export function scanJsExports(code: string): JsExports {
  const named = new Set<string>()
  let hasDefault = false
  let hasStarReexport = false

  const push = (s: string) => {
    const t = s.trim()
    if (t) named.add(t)
  }

  // export function/const/let/var/class/type/interface/enum NAMA
  const declRe = /export\s+(?:default\s+)?(?:async\s+)?(?:function\*?|class|const|let|var|type|interface|enum)\s+([A-Za-z_$][\w$]*)/g
  let m: RegExpExecArray | null
  while ((m = declRe.exec(code))) {
    if (m[0].includes('default')) hasDefault = true
    push(m[1])
  }
  // export { a, b as c }
  const braceRe = /export\s*\{([^}]*)\}/g
  while ((m = braceRe.exec(code))) {
    for (const part of m[1].split(',')) {
      const name = part.split(/\s+as\s+/).pop()
      if (name) push(name)
    }
  }
  // export * from '...'
  if (/export\s*\*\s*(?:from|,\s*\{)/.test(code)) hasStarReexport = true
  // export default <expr>/function tanpa nama
  if (/\bexport\s+default\b/.test(code)) hasDefault = true
  // CommonJS: module.exports = { a, b } atau exports.a = ...
  const cjsObjRe = /module\.exports\s*=\s*\{([^}]*)\}/g
  while ((m = cjsObjRe.exec(code))) {
    for (const part of m[1].split(',')) {
      const key = part.split(':')[0]?.trim()
      if (key && /^[A-Za-z_$][\w$]*$/.test(key)) push(key)
    }
  }
  const cjsAssignRe = /(?:^|\n)\s*exports\.([A-Za-z_$][\w$]*)\s*=/g
  while ((m = cjsAssignRe.exec(code))) push(m[1])
  if (/module\.exports\s*=/.test(code)) hasDefault = true

  const isModule =
    /^\s*(?:import|export)\s/m.test(code) || /\brequire\s*\(/.test(code) || /\bexports\b/.test(code)
  return { named, hasDefault, hasStarReexport, isModule }
}

/* ---------- parser import JS/TS ---------- */

export interface JsImport {
  line: number
  spec: string
  names: Array<{ imported: string; local: string }>
  hasDefault: boolean
  hasNamespace: boolean
}

export function scanJsImports(code: string): JsImport[] {
  const imports: JsImport[] = []
  const lines = code.split('\n')

  lines.forEach((line, idx) => {
    // import x from './p' | import { a, b } from './p' | import x, { a } from './p'
    // | import * as ns from './p' | export { a } from './p' | import './p' (efek samping)
    const fromRe = /(?:import|export)\s+(?:([A-Za-z_$][\w$]*)\s*(?:,\s*)?)?(?:\{([^}]*)\}|\*\s+as\s+([A-Za-z_$][\w$]*))?\s*(?:from\s*)?['"](\.[^'"]+)['"]/
    const from = fromRe.exec(line)
    if (from) {
      const names: JsImport['names'] = []
      if (from[2]) {
        for (const part of from[2].split(',')) {
          const seg = part.trim()
          if (!seg) continue
          const [imported, local] = seg.split(/\s+as\s+/).map(s => s.trim())
          if (imported) names.push({ imported, local: local || imported })
        }
      }
      imports.push({
        line: idx + 1,
        spec: from[4],
        names,
        hasDefault: Boolean(from[1]),
        hasNamespace: Boolean(from[3]),
      })
      return
    }
    // const x = require('./p') | const { a } = require('./p')
    const reqRe = /(?:const|let|var)\s+(?:\{([^}]*)\}|([A-Za-z_$][\w$]*))\s*=\s*require\s*\(\s*['"](\.[^'"]+)['"]\s*\)/
    const req = reqRe.exec(line)
    if (req) {
      const names: JsImport['names'] = []
      if (req[1]) {
        for (const part of req[1].split(',')) {
          const seg = part.trim()
          if (seg) names.push({ imported: seg, local: seg })
        }
      }
      imports.push({ line: idx + 1, spec: req[3], names, hasDefault: Boolean(req[2]), hasNamespace: false })
    }
  })

  return imports
}

/* ---------- import Python ---------- */

export interface PyImport {
  line: number
  module: string
  symbols: string[] // kosong = import modul biasa
}

export function scanPyImports(code: string): PyImport[] {
  const out: PyImport[] = []
  code.split('\n').forEach((line, idx) => {
    const fromRe = /^\s*from\s+([A-Za-z_][\w.]*)\s+import\s+(.+)$/
    const impRe = /^\s*import\s+([A-Za-z_][\w.]*)/
    const from = fromRe.exec(line)
    if (from) {
      out.push({
        line: idx + 1,
        module: from[1],
        symbols: from[2].split(',').map(s => s.trim().split(/\s+as\s+/)[0]).filter(Boolean),
      })
      return
    }
    const imp = impRe.exec(line)
    if (imp) out.push({ line: idx + 1, module: imp[1], symbols: [] })
  })
  return out
}

/* ---------- kredensial bersama ---------- */

/**
 * Kata kunci kredensial sebagai SEGMEN nama variabel — bukan nama persis.
 * Nama dipecah pada `_-` DAN batas camelCase, sehingga DB_PASSWORD, dbPass,
 * MY_API_KEY, passwordHash, dan authToken semuanya dikenali, sementara
 * `passed`, `tokenize`, `passwordless`, dan `bypass` TIDAK ikut tertangkap.
 * (Filter dilakukan di kode, bukan murni regex — flag `i` membuat [A-Z]
 * ikut cocok huruf kecil sehingga murni-regex menghasilkan false positive.)
 */
const SECRET_ASSIGN_RE = /\b([A-Za-z_$][\w$-]*)\s*(?:=>|[:=])\s*["'`]([^"'`\s]{8,})["'`]/g
const SECRET_DEFINE_RE = /\bdefine\s*\(\s*['"]([\w-]{2,60})['"]\s*,\s*['"]([^'"\s]{8,})['"]/g

const SECRET_SEGMENTS = new Set(['password', 'passwd', 'pwd', 'pass', 'secret', 'token', 'apikey'])

function isSecretKeyName(name: string): boolean {
  const segs = name
    .replace(/([a-z0-9])([A-Z])/g, '$1_$2')
    .split(/[_\-$]/)
    .filter(Boolean)
    .map(s => s.toLowerCase())
  if (segs.some(s => SECRET_SEGMENTS.has(s))) return true
  if (segs.includes('api') && segs.includes('key')) return true
  if (segs.includes('auth') && (segs.includes('token') || segs.includes('key'))) return true
  return false
}

export function scanSecretValues(code: string): Array<{ value: string; line: number; keyName: string }> {
  const found: Array<{ value: string; line: number; keyName: string }> = []
  code.split('\n').forEach((line, idx) => {
    SECRET_ASSIGN_RE.lastIndex = 0
    let m: RegExpExecArray | null
    while ((m = SECRET_ASSIGN_RE.exec(line))) {
      if (!isSecretKeyName(m[1])) continue
      found.push({ value: m[2], line: idx + 1, keyName: m[1] })
    }
    SECRET_DEFINE_RE.lastIndex = 0
    while ((m = SECRET_DEFINE_RE.exec(line))) {
      if (!isSecretKeyName(m[1])) continue
      found.push({ value: m[2], line: idx + 1, keyName: m[1] })
    }
  })
  return found
}
