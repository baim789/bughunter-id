import type { WorkspaceFileInput } from '@/lib/types'
import { maskCode, countCallArgs } from './smart'
import { languageForFile } from './import-scan'

/**
 * ============================================================
 *  LAPISAN LINTAS FILE UNTUK PYTHON / GO / PHP / JAVA
 * ============================================================
 * Temuan yang HANYA terlihat bila banyak file dianalisis bersama,
 * diperluas ke bahasa selain JS/TS. Semua cek deterministik dan
 * dirancang tanpa false positive:
 *
 *  Python  : arity panggilan lintas modul, pemanggilan fungsi yang
 *            tidak terdefinisi di mana pun (typo terjebak).
 *  Go      : import tak terpakai (gagal build), paket lokal yang
 *            tidak ada di workspace (berdasar go.mod), arity panggilan
 *            dalam paket & lintas paket lokal.
 *  PHP     : require/include ke berkas yang tidak ada, deklarasi
 *            class duplikat (fatal redeclare).
 *  Java    : pemakaian class paket lain tanpa import, deklarasi
 *            class duplikat dalam satu paket.
 *
 * Prinsip: tidak ada edit otomatis kecuali lewat solusi berpandu.
 * ============================================================
 */

export interface CrossLangCtx {
  addCrossBug: (
    file: string,
    draft: {
      title: string
      description: string
      severity: 'critical' | 'high' | 'medium' | 'low'
      line: number
      category: string
      suggestion: string
    },
    ruleId: string,
    ctx?: { targetFile?: string; symbol?: string; spec?: string; pkg?: string; paramCount?: number; callCount?: number },
  ) => void
  byName: Map<string, WorkspaceFileInput>
  fileSet: Set<string>
}

/* ---------- util umum ---------- */

/** Buang komentar baris (# dan //) dari teks yang SUDAH dimasking. */
function stripLineComments(masked: string): string {
  return masked
    .split('\n')
    .map(l => {
      const h = l.indexOf('#')
      const s = l.indexOf('//')
      let cut = -1
      if (h >= 0 && s >= 0) cut = Math.min(h, s)
      else if (h >= 0) cut = h
      else if (s >= 0) cut = s
      return cut >= 0 ? l.slice(0, cut) : l
    })
    .join('\n')
}

function lineOf(text: string, absIdx: number): number {
  return text.slice(0, absIdx).split('\n').length
}

/** Buang komentar di akhir baris MENTAH (tanpa menyentuh string). Untuk parsing import/require. */
function stripTrailingComment(line: string): string {
  let inStr: string | null = null
  for (let i = 0; i < line.length; i++) {
    const c = line[i]
    if (inStr) {
      if (c === '\\') i++
      else if (c === inStr) inStr = null
      continue
    }
    if (c === '"' || c === "'" || c === '`') {
      inStr = c
      continue
    }
    if ((c === '/' && line[i + 1] === '/') || c === '#') return line.slice(0, i)
  }
  return line
}

/** Hitung argumen pemanggilan; deteksi spread `*x` / `**x` (Python/Go `...`). */
function countArgsSpreadAware(masked: string, openParenIdx: number): { count: number; spread: boolean } | null {
  let depth = 0
  let i = openParenIdx
  let args = 0
  let curNonEmpty = false
  let spread = false
  while (i < masked.length) {
    const ch = masked[i]
    if (ch === '(') depth++
    else if (ch === ')') {
      depth--
      if (depth === 0) break
    } else if (ch === ',' && depth === 1) {
      args++
      curNonEmpty = false
      i++
      continue
    }
    if (depth >= 1 && !/\s/.test(ch)) {
      if (depth === 1 && ch === '*' && (i === openParenIdx + 1 || masked[i - 1] === '(' || masked[i - 1] === ',' || masked[i - 1] === ' ')) spread = true
      if (ch === '.' && masked[i + 1] === '.' && masked[i + 2] === '.') spread = true
      curNonEmpty = true
    }
    i++
  }
  if (i >= masked.length) return null
  if (curNonEmpty) args += 1
  return { count: args, spread }
}

/** Jumlah parameter pada teks dalam kurung; return null bila ada *args/rest/multi-baris tak tertutup. */
function parseParams(paramsRaw: string): number | null {
  const raw = paramsRaw.trim()
  if (!raw) return 0
  if (raw.includes('*')) return null // *args / **kwargs / rest / pointer receiver tanpa nama
  let depth = 0
  let count = 1
  for (const ch of raw) {
    if (ch === '(' || ch === '[' || ch === '{') depth++
    else if (ch === ')' || ch === ']' || ch === '}') depth--
    else if (ch === ',' && depth === 0) count++
  }
  return count
}

/**
 * Jumlah parameter WAJIB (minimum) — parameter ber-default dianggap opsional.
 * null bila signature memuat *args/**kwargs (jumlah minimum tak bisa dipastikan).
 */
function parseMinParams(paramsRaw: string): number | null {
  const raw = paramsRaw.trim()
  if (!raw) return 0
  if (raw.includes('*')) return null
  let depth = 0
  let min = 0
  let seg = ''
  const flush = () => {
    const t = seg.trim()
    if (t && !t.includes('=')) min++
    seg = ''
  }
  for (const ch of raw) {
    if (ch === '(' || ch === '[' || ch === '{') {
      depth++
      seg += ch
    } else if (ch === ')' || ch === ']' || ch === '}') {
      depth--
      seg += ch
    } else if (ch === ',' && depth === 0) {
      flush()
    } else {
      seg += ch
    }
  }
  flush()
  return min
}

/** Kumpulkan pemanggilan `name(` di teks masked+stripped, lewati .metode(), @dekorator, dan baris def/class/import. */
function collectCalls(
  text: string,
  opts: { skipLineRe?: RegExp; allowQualified?: boolean },
): Array<{ name: string; line: number; idx: number; openAbs: number; qualified?: string }> {
  const out: Array<{ name: string; line: number; idx: number; openAbs: number; qualified?: string }> = []
  const lines = text.split('\n')
  let offset = 0
  for (let li = 0; li < lines.length; li++) {
    const raw = lines[li]
    const trimmed = raw.trim()
    if (opts.skipLineRe && opts.skipLineRe.test(trimmed)) {
      offset += raw.length + 1
      continue
    }
    const re = opts.allowQualified
      ? /(?<![\w.'"`])(?:([A-Za-z_][\w.]*)\.)?([A-Za-z_][\w]*)\s*\(/g
      : /(?<![\w.'"`@])([A-Za-z_][\w]*)\s*\(/g
    re.lastIndex = 0
    let m: RegExpExecArray | null
    while ((m = re.exec(raw))) {
      const name = opts.allowQualified ? m[2] : m[1]
      // char sebelum match: pastikan bukan kelanjutan identifier (sudah dicegah lookbehind)
      const openRel = m.index + m[0].length - 1
      out.push({ name, line: li + 1, idx: offset + m.index, openAbs: offset + openRel, qualified: m[1] })
    }
    offset += raw.length + 1
  }
  return out
}

function isPythonBuiltin(name: string): boolean {
  return PY_BUILTINS.has(name)
}

const PY_BUILTINS = new Set([
  'abs', 'aiter', 'all', 'any', 'anext', 'ascii', 'bin', 'bool', 'breakpoint', 'bytearray', 'bytes',
  'callable', 'chr', 'classmethod', 'compile', 'complex', 'delattr', 'dict', 'dir', 'divmod',
  'enumerate', 'eval', 'exec', 'filter', 'float', 'format', 'frozenset', 'getattr', 'globals',
  'hasattr', 'hash', 'help', 'hex', 'id', 'input', 'int', 'isinstance', 'issubclass', 'iter', 'len',
  'list', 'locals', 'map', 'max', 'memoryview', 'min', 'next', 'object', 'oct', 'open', 'ord', 'pow',
  'print', 'property', 'range', 'repr', 'reversed', 'round', 'set', 'setattr', 'slice', 'sorted',
  'staticmethod', 'str', 'sum', 'super', 'tuple', 'type', 'vars', 'zip', '__import__',
  // pengecualian & konstanta umum
  'Exception', 'BaseException', 'ValueError', 'TypeError', 'KeyError', 'IndexError',
  'AttributeError', 'RuntimeError', 'NotImplementedError', 'StopIteration', 'StopAsyncIteration',
  'ZeroDivisionError', 'OSError', 'IOError', 'FileNotFoundError', 'FileExistsError',
  'PermissionError', 'IsADirectoryError', 'NotADirectoryError', 'InterruptedError', 'TimeoutError',
  'OverflowError', 'ArithmeticError', 'FloatingPointError', 'LookupError', 'NameError',
  'UnboundLocalError', 'AssertionError', 'ImportError', 'ModuleNotFoundError', 'SyntaxError',
  'IndentationError', 'TabError', 'UnicodeError', 'UnicodeDecodeError', 'UnicodeEncodeError',
  'SystemError', 'SystemExit', 'KeyboardInterrupt', 'EOFError', 'EnvironmentError', 'MemoryError',
  'RecursionError', 'ReferenceError', 'BufferError', 'Warning', 'UserWarning', 'DeprecationWarning',
  'PendingDeprecationWarning', 'FutureWarning', 'RuntimeWarning', 'SyntaxWarning', 'ImportWarning',
  'UnicodeWarning', 'BytesWarning', 'ResourceWarning', 'ConnectionError', 'BrokenPipeError',
  'ConnectionAbortedError', 'ConnectionRefusedError', 'ConnectionResetError', 'GeneratorExit',
  'NotImplemented', 'Ellipsis', 'True', 'False', 'None', 'self', 'cls',
])

/* ============================================================
 *  PYTHON
 * ============================================================ */

interface PyDef {
  file: string
  name: string
  paramCount: number | null
  minParams: number | null
  line: number
}

function collectPyDefs(files: WorkspaceFileInput[]): PyDef[] {
  const defs: PyDef[] = []
  for (const f of files) {
    if (languageForFile(f.name) !== 'python') continue
    const masked = stripLineComments(maskCode(f.code))
    const lines = masked.split('\n')
    lines.forEach((line, idx) => {
      const m = /^(?:async\s+)?def\s+([A-Za-z_]\w*)\s*\((.*)$/.exec(line)
      if (!m) return
      // params bisa multi-baris: cari kurung tutup pada masked penuh
      let params = m[2]
      if (!params.includes(')')) {
        // gabung baris berikut sampai ')' (maks 12 baris)
        for (let k = idx + 1; k < Math.min(lines.length, idx + 12); k++) {
          params += ' ' + lines[k].trim()
          if (params.includes(')')) break
        }
      }
      const inner = params.slice(0, params.lastIndexOf(')') >= 0 ? params.lastIndexOf(')') : params.length)
      defs.push({
        file: f.name,
        name: m[1],
        paramCount: parseParams(inner),
        minParams: parseMinParams(inner),
        line: idx + 1,
      })
    })
  }
  return defs
}

function analyzePython(files: WorkspaceFileInput[], ctx: CrossLangCtx) {
  const pyFiles = files.filter(f => languageForFile(f.name) === 'python')
  if (pyFiles.length === 0) return
  const defs = collectPyDefs(files)
  const defsByName = new Map<string, PyDef[]>()
  for (const d of defs) {
    const list = defsByName.get(d.name) ?? []
    list.push(d)
    defsByName.set(d.name, list)
  }
  // nama yang di-assign / jadi parameter di file mana pun → kandidat callable lokal
  const assignedNames = new Set<string>()
  const paramNames = new Set<string>()
  for (const f of pyFiles) {
    const masked = stripLineComments(maskCode(f.code))
    let m: RegExpExecArray | null
    const assignRe = /([A-Za-z_]\w*)\s*(?::[^=]+)?=(?!=)/g
    while ((m = assignRe.exec(masked))) assignedNames.add(m[1])
    const paramRe = /def\s+[A-Za-z_]\w*\s*\(([^)]*)\)/g
    while ((m = paramRe.exec(masked))) {
      for (const p of m[1].split(',')) {
        const nm = p.trim().split(/[:=*]/)[0].trim()
        if (nm) paramNames.add(nm)
      }
    }
  }

  for (const f of pyFiles) {
    const masked = stripLineComments(maskCode(f.code))
    // simbol yang diimpor file ini
    const imported = new Set<string>()
    let im: RegExpExecArray | null
    const impRe = /^(?:from\s+[.\w]+\s+import\s+(.+)|import\s+([.\w]+(?:\s*,\s*[.\w]+)*))/gm
    while ((im = impRe.exec(masked))) {
      if (im[1]) for (const s of im[1].split(',')) imported.add(s.trim().split(/\s+as\s+/)[0].trim())
      if (im[2]) for (const s of im[2].split(',')) imported.add(s.trim().split(/\s+as\s+/)[0].split('.')[0].trim())
    }
    const localAssigned = new Set<string>()
    let am: RegExpExecArray | null
    const localAssignRe = /([A-Za-z_]\w*)\s*(?::[^=]+)?=(?!=)/g
    while ((am = localAssignRe.exec(masked))) localAssigned.add(am[1])

    const calls = collectCalls(masked, { skipLineRe: /^(?:async\s+def|def|class|import|from|@)/ })
    for (const c of calls) {
      const inThisFile = defsByName.get(c.name)?.some(d => d.file === f.name)
      /* --- arity lintas modul --- */
      if (inThisFile) continue // lokal menang — bukan urusan lintas file
      const foreign = defsByName.get(c.name)
      if (foreign && foreign.length === 1 && foreign[0].paramCount !== null) {
        const counted = countArgsSpreadAware(masked, c.openAbs)
        if (counted && !counted.spread && counted.count > foreign[0].paramCount) {
          ctx.addCrossBug(
            f.name,
            {
              title: `${c.name}() dipanggil dengan ${counted.count} argumen — didefinisikan di ${foreign[0].file} dengan ${foreign[0].paramCount} parameter`,
              description: `Fungsi ${c.name} di ${foreign[0].file} (baris ${foreign[0].line}) menerima ${foreign[0].paramCount} parameter, tetapi baris ini mengirim ${counted.count} argumen. Python melempar TypeError saat runtime — pemanggilan gagal total, bukan sekadar diabaikan.`,
              severity: 'high',
              line: c.line,
              category: 'Lintas File',
              suggestion: `Samakan pemanggilan dengan signature di ${foreign[0].file} (${foreign[0].paramCount} parameter), atau perluas parameternya bila argumen tambahan memang diperlukan.`,
            },
            'ws-py-arity',
            { targetFile: foreign[0].file, symbol: c.name, paramCount: foreign[0].paramCount, callCount: counted.count },
          )
        } else if (counted && !counted.spread && counted.count < (foreign[0].minParams ?? foreign[0].paramCount)) {
          // argumen kekurangan: parameter wajib (tanpa default) tidak terisi → TypeError saat runtime
          ctx.addCrossBug(
            f.name,
            {
              title: `${c.name}() dipanggil dengan ${counted.count} argumen — didefinisikan di ${foreign[0].file} dengan ${foreign[0].minParams} parameter wajib`,
              description: `Fungsi ${c.name} di ${foreign[0].file} (baris ${foreign[0].line}) memerlukan ${foreign[0].minParams} parameter wajib, tetapi baris ini hanya mengirim ${counted.count}. Python melempar TypeError ("missing required positional argument") saat runtime.`,
              severity: 'high',
              line: c.line,
              category: 'Lintas File',
              suggestion: `Lengkapi argumen sesuai signature di ${foreign[0].file} (${foreign[0].minParams} parameter wajib), atau beri nilai default pada parameter yang belum terisi bila memang opsional.`,
            },
            'ws-py-arity-few',
            { targetFile: foreign[0].file, symbol: c.name, paramCount: foreign[0].minParams ?? foreign[0].paramCount, callCount: counted.count },
          )
        }
        continue
      }
      /* --- pemanggilan tak terdefinisi --- */
      if (foreign) continue // didefinisikan di >1 file — ambigu, jangan berani
      if (isPythonBuiltin(c.name)) continue
      if (imported.has(c.name)) continue
      if (localAssigned.has(c.name) || assignedNames.has(c.name) || paramNames.has(c.name)) continue
      ctx.addCrossBug(
        f.name,
        {
          title: `Pemanggilan ${c.name}() tidak terdefinisi di workspace`,
          description: `Nama ${c.name} tidak didefinisikan di file ini, tidak diimpor, tidak didefinisikan di file Python mana pun, dan bukan fungsi bawaan Python. Saat dijalankan, baris ini melempar NameError — biasanya typo atau fungsi yang lupa dibuat/diimpor.`,
          severity: 'high',
          line: c.line,
          category: 'Lintas File',
          suggestion: `Periksa ejaan "${c.name}", impor dari modul yang benar, atau buat fungsi tersebut. Jika ini callback yang dijadwalkan ditambahkan, tandai dengan TODO.`,
        },
        'ws-py-undefined-call',
        { symbol: c.name },
      )
    }
  }
}

/* ============================================================
 *  GO
 * ============================================================ */

interface GoImport {
  line: number
  path: string
  alias: string | null // null = tanpa alias; '_' blank import; '.' dot import
}

interface GoFunc {
  file: string
  pkg: string
  name: string
  paramCount: number | null
  line: number
  exported: boolean
}

function collectGoInfo(files: WorkspaceFileInput[]): {
  moduleName: string | null
  importsByFile: Map<string, GoImport[]>
  funcs: GoFunc[]
  pkgByFile: Map<string, string>
} {
  let moduleName: string | null = null
  const importsByFile = new Map<string, GoImport[]>()
  const funcs: GoFunc[] = []
  const pkgByFile = new Map<string, string>()
  for (const f of files) {
    const isGoMod = /(^|\/)go\.mod$/.test(f.name)
    if (!isGoMod && languageForFile(f.name) !== 'go') continue
    // parsing import/package/module dari baris MENTAH (quote dipertahankan), komentar dibuang
    const rawLines = f.code.split('\n').map(stripTrailingComment)
    // module dari go.mod
    if (isGoMod) {
      const mm = /^module\s+(\S+)/m.exec(rawLines.join('\n'))
      if (mm) moduleName = mm[1]
    }
    // package clause
    const pm = /^package\s+([A-Za-z_]\w*)/m.exec(rawLines.join('\n'))
    if (pm) pkgByFile.set(f.name, pm[1])
    // imports
    const imports: GoImport[] = []
    let inBlock = false
    rawLines.forEach((line, idx) => {
      const trimmed = line.trim()
      if (/^import\s*\(/.test(trimmed)) {
        inBlock = true
        return
      }
      if (inBlock) {
        if (trimmed.startsWith(')')) {
          inBlock = false
          return
        }
        const im = /^(?:([A-Za-z_]\w*)\s+)?"([^"]+)"/.exec(trimmed)
        if (im) imports.push({ line: idx + 1, path: im[2], alias: im[1] ?? null })
        return
      }
      const single = /^import\s+(?:([A-Za-z_]\w*)\s+)?"([^"]+)"/.exec(trimmed)
      if (single) imports.push({ line: idx + 1, path: single[2], alias: single[1] ?? null })
    })
    importsByFile.set(f.name, imports)
    // funcs: `func Name(` — skip method (func (recv) Name) — dari masked (string tak mengganggu signature)
    const masked = stripLineComments(maskCode(f.code))
    const lines = masked.split('\n')
    lines.forEach((line, idx) => {
      const fm = /^func\s+([A-Za-z_]\w*)\s*\((.*)$/.exec(line)
      if (!fm) return
      let params = fm[2]
      if (!params.includes(')')) {
        for (let k = idx + 1; k < Math.min(lines.length, idx + 12); k++) {
          params += ' ' + lines[k].trim()
          if (params.includes(')')) break
        }
      }
      const close = params.lastIndexOf(')')
      const inner = close >= 0 ? params.slice(0, close) : params
      // fungsi variadic (…T) menerima jumlah argumen bebas — jumlah tak bisa dipastikan
      funcs.push({
        file: f.name,
        pkg: pkgByFile.get(f.name) ?? '',
        name: fm[1],
        paramCount: /\.\.\./.test(inner) ? null : parseParams(inner),
        line: idx + 1,
        exported: /^[A-Z]/.test(fm[1]),
      })
    })
  }
  return { moduleName, importsByFile, funcs, pkgByFile }
}

function analyzeGo(files: WorkspaceFileInput[], ctx: CrossLangCtx) {
  const goFiles = files.filter(f => languageForFile(f.name) === 'go')
  if (goFiles.length === 0) return
  const { moduleName, importsByFile, funcs, pkgByFile } = collectGoInfo(files)
  const funcsByPkg = new Map<string, GoFunc[]>()
  for (const fn of funcs) {
    const list = funcsByPkg.get(fn.pkg) ?? []
    list.push(fn)
    funcsByPkg.set(fn.pkg, list)
  }

  for (const f of goFiles) {
    const masked = stripLineComments(maskCode(f.code))
    const imports = importsByFile.get(f.name) ?? []
    const myPkg = pkgByFile.get(f.name) ?? ''

    /* --- import tak terpakai (gagal build di Go) --- */
    for (const imp of imports) {
      if (imp.alias === '_' || imp.alias === '.') continue
      const ident = imp.alias ?? imp.path.split('/').filter(Boolean).pop() ?? ''
      if (!ident) continue
      if (!new RegExp(`(?<![\\w.'"\`])${ident}\\s*\\.`).test(masked)) {
        ctx.addCrossBug(
          f.name,
          {
            title: `Import "${imp.path}" tidak pernah dipakai`,
            description: `Paket "${ident}" diimpor di baris ini tetapi tidak ada satu pun pemakaian ${ident}. di seluruh berkas. Go menolak mem-build program dengan import tak terpakai (error "imported and not used") — build gagal total.`,
            severity: 'high',
            line: imp.line,
            category: 'Lintas File',
            suggestion: `Hapus baris import "${imp.path}", atau pakai paketnya (mungkin pemanggilannya lupa ditulis).`,
          },
          'ws-go-unused-import',
          { symbol: ident, spec: imp.path },
        )
      }
    }

    /* --- paket lokal yang tidak ada (berdasarkan go.mod) --- */
    if (moduleName) {
      for (const imp of imports) {
        if (!imp.path.startsWith(`${moduleName}/`)) continue
        const sub = imp.path.slice(moduleName.length + 1)
        const exists = ctx.fileSet.has(`${sub}.go`) || [...ctx.fileSet].some(n => n.startsWith(`${sub}/`) && n.endsWith('.go'))
        if (!exists) {
          ctx.addCrossBug(
            f.name,
            {
              title: `Paket lokal "${sub}" tidak ditemukan di workspace`,
              description: `Import "${imp.path}" menunjuk paket internal modul ${moduleName}, tetapi tidak ada berkas .go di folder "${sub}/" pada workspace. Build akan gagal dengan "package ... is not in std" atau cannot find package.`,
              severity: 'high',
              line: imp.line,
              category: 'Lintas File',
              suggestion: `Unggah folder ${sub}/ ke workspace, perbaiki jalur import, atau hapus pemakaiannya.`,
            },
            'ws-go-missing-local-package',
            { spec: imp.path, symbol: sub },
          )
        }
      }
    }

    /* --- arity: panggilan dalam paket (bare) & lintas paket lokal (pkg.Fn) --- */
    const calls = collectCalls(masked, { skipLineRe: /^(?:import|package|func)\b/, allowQualified: true })
    const localFuncNames = new Set(funcs.filter(fn => fn.file === f.name).map(fn => fn.name))
    for (const c of calls) {
      if (c.qualified) {
        // panggilan berkualifikasi: pkg harus cocok dengan package clause file lain di workspace
        if (c.qualified === myPkg) continue
        const foreign = funcsByPkg.get(c.qualified)?.find(fn => fn.name === c.name)
        if (!foreign || foreign.paramCount === null) continue
        const counted = countArgsSpreadAware(masked, c.openAbs)
        if (counted && !counted.spread && counted.count > foreign.paramCount) {
          ctx.addCrossBug(
            f.name,
            {
              title: `${c.qualified}.${c.name}() dipanggil dengan ${counted.count} argumen — paket ${c.qualified} mendeklarasikan ${foreign.paramCount} parameter`,
              description: `Fungsi ${c.name} di ${foreign.file} (baris ${foreign.line}) menerima ${foreign.paramCount} parameter, tetapi baris ini mengirim ${counted.count}. Go menolak build dengan jumlah argumen yang tidak cocok (too many arguments).`,
              severity: 'high',
              line: c.line,
              category: 'Lintas File',
              suggestion: `Samakan pemanggilan dengan signature di ${foreign.file} (${foreign.paramCount} parameter), atau perluas parameternya.`,
            },
            'ws-go-arity',
            { targetFile: foreign.file, symbol: c.name, pkg: c.qualified, paramCount: foreign.paramCount, callCount: counted.count },
          )
        } else if (counted && !counted.spread && counted.count < foreign.paramCount) {
          // argumen kekurangan: build Go juga gagal (not enough arguments)
          ctx.addCrossBug(
            f.name,
            {
              title: `${c.qualified}.${c.name}() dipanggil dengan ${counted.count} argumen — paket ${c.qualified} mendeklarasikan ${foreign.paramCount} parameter`,
              description: `Fungsi ${c.name} di ${foreign.file} (baris ${foreign.line}) menerima ${foreign.paramCount} parameter, tetapi baris ini hanya mengirim ${counted.count}. Go menolak build (not enough arguments in call).`,
              severity: 'high',
              line: c.line,
              category: 'Lintas File',
              suggestion: `Lengkapi argumen sesuai signature di ${foreign.file} (${foreign.paramCount} parameter), atau sederhanakan parameternya bila sebagian tidak diperlukan.`,
            },
            'ws-go-arity-few',
            { targetFile: foreign.file, symbol: c.name, pkg: c.qualified, paramCount: foreign.paramCount, callCount: counted.count },
          )
        }
        continue
      }
      // panggilan bare dalam paket yang sama (file lain)
      if (localFuncNames.has(c.name)) continue
      const same = funcs.find(fn => fn.pkg === myPkg && fn.name === c.name && fn.file !== f.name)
      if (!same || same.paramCount === null) continue
      const counted = countArgsSpreadAware(masked, c.openAbs)
      if (counted && !counted.spread && counted.count > same.paramCount) {
        ctx.addCrossBug(
          f.name,
          {
            title: `${c.name}() dipanggil dengan ${counted.count} argumen — dideklarasikan di ${same.file} dengan ${same.paramCount} parameter`,
            description: `Fungsi ${c.name} di ${same.file} (baris ${same.line}, paket ${myPkg}) menerima ${same.paramCount} parameter, tetapi baris ini mengirim ${counted.count} — build Go gagal (too many arguments in call).`,
            severity: 'high',
            line: c.line,
            category: 'Lintas File',
            suggestion: `Samakan pemanggilan dengan signature di ${same.file} (${same.paramCount} parameter), atau perluas parameternya.`,
          },
          'ws-go-arity',
          { targetFile: same.file, symbol: c.name, paramCount: same.paramCount, callCount: counted.count },
        )
      } else if (counted && !counted.spread && counted.count < same.paramCount) {
        // argumen kekurangan: build Go juga gagal (not enough arguments)
        ctx.addCrossBug(
          f.name,
          {
            title: `${c.name}() dipanggil dengan ${counted.count} argumen — dideklarasikan di ${same.file} dengan ${same.paramCount} parameter`,
            description: `Fungsi ${c.name} di ${same.file} (baris ${same.line}, paket ${myPkg}) menerima ${same.paramCount} parameter, tetapi baris ini hanya mengirim ${counted.count} — build Go gagal (not enough arguments in call).`,
            severity: 'high',
            line: c.line,
            category: 'Lintas File',
            suggestion: `Lengkapi argumen sesuai signature di ${same.file} (${same.paramCount} parameter), atau sederhanakan parameternya bila sebagian tidak diperlukan.`,
          },
          'ws-go-arity-few',
          { targetFile: same.file, symbol: c.name, paramCount: same.paramCount, callCount: counted.count },
        )
      }
    }
  }
}

/* ============================================================
 *  PHP
 * ============================================================ */

function analyzePhp(files: WorkspaceFileInput[], ctx: CrossLangCtx) {
  const phpFiles = files.filter(f => languageForFile(f.name) === 'php')
  if (phpFiles.length === 0) return

  /* --- require/include ke berkas yang tidak ada --- */
  // bentuk didukung: require 'x.php' | require('x.php') | require __DIR__ . '/x.php'
  //                 | require dirname(__FILE__) . "/x.php" (prefix __DIR__ membuat
  //                   jalur berawalan '/' tetap RELATIF, bukan absolut)
  const requireRe =
    /^\s*(require|include)(?:_once)?\s*\(?\s*(?:(__DIR__|dirname\s*\(\s*__FILE__\s*\))\s*\.\s*)?['"]([^'"]+\.php)['"]/i
  for (const f of phpFiles) {
    // parsing dari baris MENTAH (quote dipertahankan), komentar dibuang
    const rawLines = f.code.split('\n').map(stripTrailingComment)
    rawLines.forEach((line, idx) => {
      const m = requireRe.exec(line)
      if (!m) return
      const target = m[3]
      const viaDir = Boolean(m[2]) // __DIR__ / dirname(__FILE__) → selalu relatif ke berkas ini
      if (viaDir) {
        // __DIR__ . '/pasien.php' → 'pasien.php'; __DIR__ . './a/b.php' → './a/b.php'
        if (target.includes('$') || target.includes('://')) return
      } else {
        if (target.startsWith('/') || target.includes('$') || target.includes('://')) return
      }
      const base = f.name.includes('/') ? f.name.slice(0, f.name.lastIndexOf('/')) : ''
      const rel = viaDir && target.startsWith('/') ? target.slice(1) : target
      const candidates = [
        rel,
        base ? `${base}/${rel}` : rel,
        rel.endsWith('.php') ? rel : `${rel}.php`,
        base && !rel.endsWith('.php') ? `${base}/${rel}.php` : rel,
      ]
      const found = candidates.some(c => ctx.fileSet.has(c))
      if (!found) {
        ctx.addCrossBug(
          f.name,
          {
            title: `Berkas "${target}" yang di-${m[1].toLowerCase()} tidak ada di workspace`,
            description: `Baris ini memuat berkas "${target}"${viaDir ? ' (relatif terhadap __DIR__)' : ''}, tetapi tidak ada di antara berkas yang diunggah (dicari di samping berkas ini maupun di akar proyek). Jika berkasnya memang ada tapi tidak diunggah, pemindaian tidak bisa memverifikasi simbol dari sana; jika jalurnya salah, aplikasi melempar fatal error saat berjalan.`,
            severity: 'high',
            line: idx + 1,
            category: 'Lintas File',
            suggestion: `Pastikan berkas "${target}" ikut diunggah, perbaiki jalurnya, atau ganti require menjadi require_once untuk mencegah muat ganda.`,
          },
          'ws-php-require-missing',
          { spec: target },
        )
      }
    })
  }

  /* --- deklarasi class duplikat (fatal saat keduanya dimuat) --- */
  const classDecls = new Map<string, Array<{ file: string; line: number }>>()
  for (const f of phpFiles) {
    const masked = stripLineComments(maskCode(f.code))
    masked.split('\n').forEach((line, idx) => {
      const m = /^\s*(?:abstract\s+|final\s+)?class\s+([A-Za-z_]\w*)/.exec(line)
      if (m) {
        const list = classDecls.get(m[1]) ?? []
        list.push({ file: f.name, line: idx + 1 })
        classDecls.set(m[1], list)
      }
    })
  }
  for (const [name, locs] of classDecls) {
    if (locs.length < 2) continue
    for (const loc of locs) {
      const others = locs.filter(l => l.file !== loc.file).map(l => l.file)
      if (others.length === 0) continue
      ctx.addCrossBug(
        loc.file,
        {
          title: `Class "${name}" dideklarasikan di lebih dari satu berkas`,
          description: `Class ${name} juga dideklarasikan di: ${others.join(', ')}. Begitu kedua berkas dimuat dalam satu proses, PHP melempar fatal error "Cannot declare class ${name}, because the name is already in use".`,
          severity: 'high',
          line: loc.line,
          category: 'Lintas File',
          suggestion: `Ganti nama salah satu class, atau pastikan hanya satu berkas yang dimuat (autoload dengan namespace adalah solusi baku).`,
        },
        'ws-php-duplicate-class',
        { symbol: name },
      )
    }
  }
}

/* ============================================================
 *  JAVA
 * ============================================================ */

function analyzeJava(files: WorkspaceFileInput[], ctx: CrossLangCtx) {
  const javaFiles = files.filter(f => languageForFile(f.name) === 'java')
  if (javaFiles.length === 0) return

  interface JavaClass {
    file: string
    name: string
    pkg: string
    line: number
  }
  const classes: JavaClass[] = []
  const pkgByFile = new Map<string, string>()
  const importsByFile = new Map<string, Set<string>>()
  for (const f of javaFiles) {
    const masked = stripLineComments(maskCode(f.code))
    const pm = /^\s*package\s+([\w.]+)\s*;/m.exec(masked)
    const pkg = pm ? pm[1] : ''
    pkgByFile.set(f.name, pkg)
    const imports = new Set<string>()
    masked.split('\n').forEach((line, idx) => {
      const im = /^\s*import\s+(?:static\s+)?([\w.]+|\*)\s*;/.exec(line)
      if (im) imports.add(im[1])
      const cm = /^\s*(?:public\s+|protected\s+|abstract\s+|final\s+|sealed\s+|non-sealed\s+)*(?:class|interface|enum|record)\s+([A-Za-z_]\w*)/.exec(line)
      if (cm) classes.push({ file: f.name, name: cm[1], pkg, line: idx + 1 })
    })
    importsByFile.set(f.name, imports)
  }

  /* --- class paket lain dipakai tanpa import --- */
  const classesByName = new Map<string, JavaClass[]>()
  for (const c of classes) {
    const list = classesByName.get(c.name) ?? []
    list.push(c)
    classesByName.set(c.name, list)
  }

  /* --- statement import yang menunjuk class/paket yang tidak ada di workspace --- */
  {
    const declaredPackages = new Set<string>()
    for (const pkg of pkgByFile.values()) if (pkg) declaredPackages.add(pkg)
    const classesByBase = new Map<string, string[]>()
    for (const c of classes) {
      const base = c.file.includes('/') ? c.file.slice(c.file.lastIndexOf('/') + 1) : c.file
      const list = classesByBase.get(base) ?? []
      list.push(c.name)
      classesByBase.set(base, list)
    }
    for (const f of javaFiles) {
      const masked = stripLineComments(maskCode(f.code))
      masked.split('\n').forEach((line, idx) => {
        const im = /^\s*import\s+(?!static\b)([\w.]+)\s*;/.exec(line)
        if (!im) return
        const full = im[1]
        const parts = full.split('.')
        if (parts.length < 2) return // import NamaKelas; memang tidak sah — bukan urusan lintas file
        // pustaka standar / JDK / eksternal yang jelas — bukan urusan workspace
        if (/^(?:java|javax|jakarta|javafx|jdk|sun|com\.sun|org\.omg|org\.w3c|org\.xml)\./.test(full)) return
        const cls = parts[parts.length - 1]
        const importPkg = parts.slice(0, -1).join('.')
        const defs = classesByName.get(cls) ?? []
        if (defs.some(d => d.pkg === importPkg)) return // import valid
        let title: string
        let description: string
        if (declaredPackages.has(importPkg)) {
          title = `Import "${full}" — paket ${importPkg} milik proyek ini tidak memiliki class ${cls}`
          description = `Paket ${importPkg} dideklarasikan sendiri di workspace ini, tetapi tidak ada class bernama ${cls} di paket tersebut${defs.length ? ` (class ${cls} justru ada di paket lain)` : ''}. Kompilasi gagal: "cannot find symbol".`
        } else if (!defs.length && classesByBase.has(`${cls}.java`)) {
          const dekl = (classesByBase.get(`${cls}.java`) ?? []).join(', ')
          title = `Import "${full}" tidak menemukan class ${cls} — berkas ${cls}.java ada tetapi tidak mendeklarasikannya`
          description = `Berkas ${cls}.java ada di workspace, tetapi isinya mendeklarasikan: ${dekl || '(tidak ada class)'} — tidak ada class ${cls} di seluruh workspace. Kompilasi gagal: "cannot find symbol".`
        } else if (defs.length && defs.every(d => d.pkg === '')) {
          title = `Class ${cls} ada di paket default — import "${full}" pasti salah`
          description = `Class ${cls} didefinisikan di ${defs.map(d => d.file).join(', ')} tanpa pernyataan package (paket default). Class di paket default tidak dapat diimpor dengan nama paket eksplisit seperti "${full}" — kompilasi gagal: "cannot find symbol".`
        } else {
          return // kemungkinan dependensi pihak ketiga — jangan berani
        }
        ctx.addCrossBug(
          f.name,
          {
            title,
            description,
            severity: 'high',
            line: idx + 1,
            category: 'Lintas File',
            suggestion: `Sesuaikan statement import dengan lokasi class yang sebenarnya, atau pindahkan/definisikan class ${cls} ke paket yang diimpor.`,
          },
          'ws-java-import-missing',
          { spec: full },
        )
      })
    }
  }
  for (const f of javaFiles) {
    const masked = stripLineComments(maskCode(f.code))
    const myPkg = pkgByFile.get(f.name) ?? ''
    const imports = importsByFile.get(f.name) ?? new Set<string>()
    const definedHere = new Set(classes.filter(c => c.file === f.name).map(c => c.name))
    const newRe = /(?<![\w.'"`])new\s+([A-Za-z_][\w.]*)\s*\(/g
    let m: RegExpExecArray | null
    while ((m = newRe.exec(masked))) {
      const full = m[1]
      const parts = full.split('.')
      const cls = parts[parts.length - 1]
      if (definedHere.has(cls)) continue
      const defs = classesByName.get(cls)
      if (!defs || defs.length === 0) continue
      // pakai nama berkualifikasi penuh → OK (mis. new java.util.Date())
      if (parts.length > 1) {
        const usedPkg = parts.slice(0, -1).join('.')
        if (defs.some(d => d.pkg === usedPkg)) continue
      }
      const target = defs.find(d => d.pkg !== myPkg)
      if (!target) continue // paket sama / ambigu antar paket — jangan berani
      const hasImport =
        imports.has(`${target.pkg}.${target.name}`) ||
        imports.has(`${target.pkg}.*`) ||
        [...imports].some(i => i.startsWith(`${target.pkg}.`) === false && i === '*')
      if (hasImport) continue
      // class dengan nama sama di paket sendiri → tidak butuh import
      if (defs.some(d => d.pkg === myPkg)) continue
      ctx.addCrossBug(
        f.name,
        {
          title: `Class "${target.name}" dari paket ${target.pkg} dipakai tanpa import`,
          description: `new ${target.name}(...) di baris ini menunjuk class yang didefinisikan di ${target.file} (paket ${target.pkg || 'default'}), sedangkan berkas ini berada di paket ${myPkg || 'default'} dan tidak mengimpornya. Kompilasi gagal: "cannot find symbol".`,
          severity: 'high',
          line: lineOf(masked, m.index),
          category: 'Lintas File',
          suggestion: `Tambahkan "import ${target.pkg}.${target.name};" di bagian atas ${f.name}, atau gunakan nama berkualifikasi ${target.pkg}.${target.name} di pemanggilan.`,
        },
        'ws-java-missing-import',
        { targetFile: target.file, symbol: target.name, pkg: target.pkg },
      )
    }

    /* --- class duplikat dalam satu paket --- */
    for (const c of classes) {
      if (c.file !== f.name) continue
      const twins = classesByName.get(c.name)?.filter(t => t.pkg === c.pkg && t.file !== c.file) ?? []
      if (twins.length === 0) continue
      ctx.addCrossBug(
        c.file,
        {
          title: `Class "${c.name}" dideklarasikan di beberapa berkas dalam paket yang sama`,
          description: `Tipe ${c.name} juga dideklarasikan di: ${twins.map(t => t.file).join(', ')}. Dalam satu paket, deklarasi ganda membuat kompilasi gagal dengan "duplicate class".`,
          severity: 'high',
          line: c.line,
          category: 'Lintas File',
          suggestion: `Hapus/gabungkan salah satu deklarasi, atau pindahkan ke paket berbeda bila memang dua tipe yang berbeda.`,
        },
        'ws-java-duplicate-class',
        { symbol: c.name },
      )
    }
  }
}

/* ---------- pintu masuk ---------- */

export function analyzeCrossLanguage(files: WorkspaceFileInput[], ctx: CrossLangCtx): void {
  analyzePython(files, ctx)
  analyzeGo(files, ctx)
  analyzePhp(files, ctx)
  analyzeJava(files, ctx)
}
