import { Worker } from 'node:worker_threads'
import os from 'node:os'
import path from 'node:path'
import fs from 'node:fs'
import type { WorkspaceFileInput, WorkspaceFileResult } from '@/lib/types'
import type { ScanAnalyzeOptions } from './scan-shared'

/**
 * ============================================================
 *  PEMINDAIAN PARALEL FASE-1 (v0.11) — worker thread multi-core
 * ============================================================
 * Hanya fase 1 (analisis per file, fungsi murni analyzeFilePhase1)
 * yang diparalelkan. Lapisan lintas file butuh seluruh workspace
 * dan tetap serial di thread utama — bagiannya kecil (terukur
 * < 15% dari total di benchmark 80–200 file).
 *
 * Keputusan desain:
 * - Worker dipakai dari BUNDLE JS murni (scan-worker.bundle.mjs, hasil
 *   scripts/build-scan-worker.sh) sehingga berjalan di runtime apapun
 *   (server dev ini Node; Bun juga bisa). Bila bundle basi/tak ada:
 *   coba worker .ts langsung (hanya Bun), selain itu serial.
 * - Hasil deteksi jalur paralel = jalur serial karena keduanya memanggil
 *   analyzeFilePhase1 yang sama (lihat scan-shared.ts).
 * - Worker satu-pakai per pemindaian (spawn ±8–40 ms, jauh di bawah
 *   durasi scan yang memenuhi ambang) — sederhana & bebas state.
 * - Ambang aktivasi (PARALLEL_MIN_*) mencegah overhead spawn pada
 *   proyek kecil yang sudah selesai dalam puluhan ms.
 * - Env BUGHUNTER_WORKERS=0 memaksa serial (diagnosis/pembanding).
 * ============================================================
 */

const IS_BUN = typeof process !== 'undefined' && !!process.versions?.bun
const WORKER_TS = path.join(process.cwd(), 'src', 'lib', 'detector', 'scan-worker.ts')
/**
 * Bundle worker (JS murni, hasil scripts/build-scan-worker.sh) — dipilih
 * lebih dulu karena jalan di runtime APAPUN (server dev ini Node; bun hanya
 * wrapper). Bila bundle basi (sumber detector lebih baru) atau tak ada,
 * pakai worker .ts langsung (hanya Bun), selain itu serial.
 */
const WORKER_BUNDLE = path.join(process.cwd(), 'src', 'lib', 'detector', 'scan-worker.bundle.mjs')
/** Cache status kedaluwarsa (TTL singkat agar rebuild terdeteksi tanpa restart). */
let bundleState: { state: 'fresh' | 'stale'; at: number } | null = null
const BUNDLE_TTL_MS = 10_000

function bundleFresh(): boolean {
  if (bundleState && Date.now() - bundleState.at < BUNDLE_TTL_MS) return bundleState.state === 'fresh'
  try {
    const bundleMtime = fs.statSync(WORKER_BUNDLE).mtimeMs
    let newest = bundleMtime
    const walk = (dir: string) => {
      for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
        const p = path.join(dir, e.name)
        if (e.isDirectory()) walk(p)
        else if (/\.tsx?$/.test(e.name)) {
          const m = fs.statSync(p).mtimeMs
          if (m > newest) newest = m
        }
      }
    }
    walk(path.join(process.cwd(), 'src', 'lib'))
    bundleState = { state: newest > bundleMtime + 2_000 ? 'stale' : 'fresh', at: Date.now() }
  } catch {
    bundleState = { state: 'stale', at: Date.now() }
  }
  if (bundleState.state === 'stale') console.warn('[scan-parallel] bundle worker basi/tidak ada — jalankan scripts/build-scan-worker.sh, sementara pakai jalur serial/TS.')
  return bundleState.state === 'fresh'
}

function pickWorkerFile(): string | null {
  if (bundleFresh()) return WORKER_BUNDLE
  if (IS_BUN && fs.existsSync(WORKER_TS)) return WORKER_TS
  return null
}
/**
 * Jumlah CPU yang benar-benar tersedia untuk worker.
 * - Env BUGHUNTER_CPUS menimpa (alat uji: simulasikan mesin 4+ core).
 * - Cgroup v2 (cpu.max) & v1 (cfs_quota_us/cfs_period_us) dibaca dulu:
 *   di Docker/K8s dengan quota, os.cpus() sering melaporkan core HOST
 *   (mis. 16) padahal kuota hanya 2 — ambang & pool jadi salah. Nilai
 *   pecahan dibulatkan ke bawah (kuota 1,5 core → diperlakukan 1).
 * - Fallback: os.cpus().
 */
export function effectiveCpus(): number {
  const ov = Number(process.env.BUGHUNTER_CPUS)
  if (Number.isFinite(ov) && ov >= 1) return Math.floor(ov)
  try {
    const v2 = fs.readFileSync('/sys/fs/cgroup/cpu.max', 'utf8').trim().split(/\s+/)
    if (v2[0] !== 'max') {
      const q = Number(v2[0])
      const p = Number(v2[1])
      if (p > 0 && q > 0) return Math.max(1, Math.floor(q / p))
    }
    const q1 = Number(fs.readFileSync('/sys/fs/cgroup/cpu/cpu.cfs_quota_us', 'utf8').trim())
    const p1 = Number(fs.readFileSync('/sys/fs/cgroup/cpu/cpu.cfs_period_us', 'utf8').trim())
    if (q1 > 0 && p1 > 0) return Math.max(1, Math.floor(q1 / p1))
  } catch {
    /* bukan cgroup / izin dibatasi → fallback */
  }
  return Math.max(1, os.cpus()?.length ?? 1)
}

/**
 * Ambang aktivasi sadar-CPU: paralel hanya bila cukup besar untuk menutup
 * biaya spawn+clone payload (diukur v0.11: di 2 vCPU, JSON/clone thread utama
 * memakan hampir semua untung — di sana hanya pekerjaan ≥ 96 file & ≥ 1,2 jt
 * char yang masih untung; di mesin ≥ 4 core ambang bisa jauh lebih rendah).
 */
export function parallelEligible(fileCount: number, totalChars: number): boolean {
  const cpus = effectiveCpus()
  if (cpus <= 2) return fileCount >= 96 && totalChars >= 1_200_000
  return fileCount >= 32 && totalChars >= 500_000
}

/** Batas aman satu worker (scan normal ≈ < 2 detik di ambang terendah). */
const WORKER_TIMEOUT_MS = 120_000

export function workerPoolSize(fileCount: number): number {
  const cpus = effectiveCpus()
  return Math.min(4, Math.max(2, cpus), Math.ceil(fileCount / 12))
}

export type ParallelOutcome = {
  results: WorkspaceFileResult[]
  /** Durasi analisis per file (ms), diukur di dalam worker, urutan asli. */
  elapsed: number[]
}

/**
 * Analisis fase-1 seluruh file memakai pool worker (ukuran workerPoolSize).
 * Mengembalikan null bila jalur paralel tidak tersedia/gagal — pemanggil
 * WAJIB fallback ke jalur serial (hasil akhir tetap identik).
 */
export async function analyzeFilesInWorkers(
  files: WorkspaceFileInput[],
  analyzeOptions: ScanAnalyzeOptions,
): Promise<ParallelOutcome | null> {
  if (!IS_BUN && !bundleFresh()) return null
  if (process.env.BUGHUNTER_WORKERS === '0') return null
  if (process.env.BUGHUNTER_FORCE_SERIAL === '1') return null

  const pool = workerPoolSize(files.length)
  // Round-robin: ukuran file bervariasi → distribusi merata tanpa sort.
  const chunks: { idx: number; f: WorkspaceFileInput }[][] = Array.from({ length: pool }, () => [])
  files.forEach((f, i) => chunks[i % pool]!.push({ idx: i, f }))

  try {
    const workerFile = pickWorkerFile()
    if (!workerFile) return null
    const tP = Date.now()
    const outs = await Promise.all(chunks.map(chunk => runOneWorker(workerFile, chunk, analyzeOptions)))
    console.log(`[scan-parallel] AKTIF pool=${pool} file=${files.length} worker=${path.basename(workerFile)} total=${Date.now() - tP}ms perWorker=[${outs.map(o => o.workerMs).join(',')}]`)
    const results: WorkspaceFileResult[] = new Array(files.length)
    const elapsed: number[] = new Array(files.length).fill(0)
    for (const out of outs) {
      out.chunk.forEach(({ idx }, k) => {
        results[idx] = out.results[k]!
        elapsed[idx] = out.elapsed[k] ?? 0
      })
    }
    return { results, elapsed }
  } catch {
    return null // worker gagal/timeout → jalur serial
  }
}

function runOneWorker(
  workerFile: string,
  chunk: { idx: number; f: WorkspaceFileInput }[],
  analyzeOptions: ScanAnalyzeOptions,
): Promise<{ chunk: { idx: number; f: WorkspaceFileInput }[]; workerMs: number; results: WorkspaceFileResult[]; elapsed: number[] }> {
  return new Promise((resolve, reject) => {
    let settled = false
    let w: Worker
    const tW = Date.now()
    try {
      w = new Worker(workerFile)
    } catch (e) {
      reject(e instanceof Error ? e : new Error(String(e)))
      return
    }
    const finish = (fn: () => void) => {
      if (settled) return
      settled = true
      clearTimeout(timer)
      void w.terminate()
      fn()
    }
    const timer = setTimeout(() => finish(() => reject(new Error('worker timeout'))), WORKER_TIMEOUT_MS)
    w.on('message', (m: { ok?: boolean; results?: WorkspaceFileResult[]; elapsed?: number[]; error?: string }) => {
      if (m?.ok && Array.isArray(m.results)) {
        finish(() => resolve({ chunk, workerMs: Date.now() - tW, results: m.results!, elapsed: m.elapsed ?? [] }))
      } else {
        finish(() => reject(new Error(m?.error ?? 'worker gagal')))
      }
    })
    w.on('error', e => finish(() => reject(e)))
    w.on('exit', code => {
      if (!settled && code !== 0) finish(() => reject(new Error(`worker exit ${code}`)))
    })
    w.postMessage({ files: chunk.map(c => c.f), analyzeOptions })
  })
}
