import type { DraftBug } from './rules'

/**
 * ============================================================
 *  TAINT ANALYSIS (LITE) — BugHunter ID
 * ============================================================
 * Analisis aliran data satu-file dua-lintas (two-pass):
 *   Pass 1 — kumpulkan VARIABEL TERCEMARKAI (tainted): variabel
 *            yang diisi dari sumber input tidak terpercaya
 *            (request body/query/params, argv, input(), dll).
 *   Pass 2 — cari SINK berbahaya (query SQL, eksekusi perintah,
 *            eval, innerHTML) yang memakai variabel tersebut.
 *
 * Ini membedakan `eval(a)` yang benar-benar berbahaya dari
 * `eval("2+2")` yang hanya berisiko — kecerdasan yang tidak
 * dimiliki deteksi pola baris-tunggal.
 * ============================================================
 */

/* ---------- sumber input tak terpercaya ---------- */

// JS/TS: req.body / req.query / req.params / req.cookies / req.headers,
// process.argv, URLSearchParams, location.search (browser)
const JS_SOURCE_LINE =
  /(?:\breq(?:uest)?\s*\.\s*(?:body|query|params|cookies|headers)\b|\bprocess\s*\.\s*argv\b|\bnew\s+URLSearchParams\b|\blocation\s*\.\s*search\b|\bwindow\s*\.\s*location\s*\.\s*search\b)/

const JS_TAINT_DECL =
  /\b(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*[^;\n]*?(?:\breq(?:uest)?\s*\.\s*(?:body|query|params|cookies|headers)\b|\bprocess\s*\.\s*argv\b|\bnew\s+URLSearchParams\b|\blocation\s*\.\s*search\b)/
const JS_TAINT_ASSIGN = /^\s*([A-Za-z_$][\w$]*)\s*=\s*[^;\n]*?\breq(?:uest)?\s*\.\s*(?:body|query|params|cookies|headers)\b/

// Python: request.GET/POST/args/form/values/json/data/cookies/headers, input(), sys.argv
const PY_TAINT_DECL =
  /^\s*([A-Za-z_]\w*)\s*=\s*[^#\n]*?(?:\brequest\s*\.\s*(?:GET|POST|args|form|values|json|data|cookies|headers)\b|\binput\s*\(|\bsys\s*\.\s*argv\b|\bflask\s*\.\s*request\b)/

/* ---------- ekstraksi variabel tercemarkai ---------- */

function collectJsTainted(lines: string[]): Map<string, number> {
  const tainted = new Map<string, number>()
  lines.forEach((line, idx) => {
    let m = JS_TAINT_DECL.exec(line)
    if (m) {
      tainted.set(m[1], idx + 1)
      return
    }
    m = JS_TAINT_ASSIGN.exec(line)
    if (m) tainted.set(m[1], idx + 1)
  })
  return tainted
}

function collectPyTainted(lines: string[]): Map<string, number> {
  const tainted = new Map<string, number>()
  lines.forEach((line, idx) => {
    const m = PY_TAINT_DECL.exec(line)
    if (m) tainted.set(m[1], idx + 1)
  })
  return tainted
}

/* ---------- pola sink ---------- */

const SQL_KEYWORD = /\b(select|insert\s+into|update\s+\w+\s+set|delete\s+from)\b/i

/** Apakah baris memakai placeholder terparameter (?) atau $1/$2 — parameterized query aman. */
function isParameterized(line: string): boolean {
  return /(\?\s*["'`]|\$\d|\bprepare\s*\(|\bwith\b\s*\(|%s["']?\s*,|\bexecute\s*\(\s*["'][^"']*\?)/.test(line)
}

function taintUsedInLine(line: string, names: Iterable<string>): string | null {
  for (const name of names) {
    const re = new RegExp(`\\b${name}\\b`)
    if (re.test(line)) return name
  }
  return null
}

/* ---------- detector JS/TS ---------- */

export function detectTaintJs(lines: string[], code: string): DraftBug[] {
  const bugs: DraftBug[] = []
  const tainted = collectJsTainted(lines)
  if (tainted.size === 0) return bugs
  const names = tainted.keys()
  const seenSink = new Set<string>()

  lines.forEach((line, idx) => {
    const bare = line.trim()
    if (!bare || bare.startsWith('//')) return
    const no = idx + 1

    // SINK 1 — query SQL dibangun dengan konkatenasi/interpolasi variabel tercemarkai
    if (SQL_KEYWORD.test(line) && !isParameterized(line)) {
      const t = taintUsedInLine(line, names)
      if (t) {
        // bentuk penggabungan: `${t}` di template literal, + t, t +, atau f-string style
        const concat =
          new RegExp(`\\$\\{\\s*${t}\\b|\\+\\s*${t}\\b|\\b${t}\\s*\\+|\\$\\{[^}]*\\b${t}\\b`).test(line) ||
          /\.\s*concat\s*\(/.test(line)
        if (concat && !seenSink.has(`sql:${no}`)) {
          seenSink.add(`sql:${no}`)
          bugs.push({
            title: `SQL Injection: query dibangun dari input pengguna ("${t}")`,
            description:
              'Variabel "' + t + '" berasal dari input tidak terpercaya (request/argv) dan digabung langsung ke teks query. Penyerang bisa mengubah makna query — membaca, mengubah, atau menghapus data arbitrer.',
            severity: 'critical',
            line: no,
            category: 'Keamanan',
            suggestion:
              'Gunakan parameterized query / prepared statement (mis. db.query("... WHERE id = ?", [t])) atau ORM query builder — jangan pernah menggabungkan string SQL dengan input pengguna.',
            ruleId: 'js-taint-sql',
          })
        }
      }
    }

    // SINK 2 — eksekusi kode/perintah dengan variabel tercemarkai
    if (/\b(?:eval|exec\s*Sync|child_process\s*\.\s*exec|require\s*\(\s*['"]child_process['"]\s*\)\s*\.\s*exec)\s*\(/.test(line)) {
      const t = taintUsedInLine(line, names)
      if (t && !seenSink.has(`cmd:${no}`)) {
        seenSink.add(`cmd:${no}`)
        bugs.push({
          title: `Command/code injection: input pengguna ("${t}") masuk eval/exec`,
          description:
            'Variabel "' + t + '" dari sumber tidak terpercaya dieksekusi sebagai kode/perintah shell. Penyerang dapat menjalankan perintah arbitrer di server (Remote Code Execution).',
          severity: 'critical',
          line: no,
          category: 'Keamanan',
          suggestion:
            'Hindari eval/exec pada input pengguna. Untuk perintah sistem, gunakan spawn dengan array argumen tanpa shell, atau whitelist nilai yang diizinkan.',
          ruleId: 'js-taint-cmd',
        })
      }
    }

    // SINK 3 — XSS via innerHTML / document.write
    if (/\binnerHTML\s*=|\bdocument\s*\.\s*write\s*\(/.test(line)) {
      const t = taintUsedInLine(line, names)
      if (t && !seenSink.has(`xss:${no}`)) {
        seenSink.add(`xss:${no}`)
        bugs.push({
          title: `XSS: input pengguna ("${t}") ditulis tanpa sanitasi ke DOM`,
          description:
            'Variabel "' + t + '" dari sumber tidak terpercaya dimasukkan ke innerHTML/document.write. Skrip dari penyerang akan tereksekusi di browser pengguna lain (Stored/Reflected XSS).',
          severity: 'high',
          line: no,
          category: 'Keamanan',
          suggestion:
            'Gunakan textContent untuk teks biasa, atau sanitasi dengan DOMPurify sebelum merender HTML dari input tidak terpercaya.',
          ruleId: 'js-taint-xss',
        })
      }
    }
  })

  return bugs
}

/* ---------- detector Python ---------- */

export function detectTaintPy(lines: string[], code: string): DraftBug[] {
  const bugs: DraftBug[] = []
  const tainted = collectPyTainted(lines)
  if (tainted.size === 0) return bugs
  const names = tainted.keys()
  const seenSink = new Set<string>()

  lines.forEach((line, idx) => {
    const bare = line.trim()
    if (!bare || bare.startsWith('#')) return
    const no = idx + 1

    // SINK 1 — SQL dengan f-string / % / format / konkatenasi
    if (SQL_KEYWORD.test(line) && !isParameterized(line)) {
      const t = taintUsedInLine(line, names)
      if (t) {
        const concat =
          new RegExp(`f["'][^"']*\\{\\s*${t}\\b|\\{[^}]*\\b${t}\\b[^}]*\\}["']|%\\s*\\(?\\s*${t}\\b|\\.format\\([^)]*\\b${t}\\b|\\+\\s*${t}\\b|\\b${t}\\s*\\+`).test(line)
        if (concat && !seenSink.has(`sql:${no}`)) {
          seenSink.add(`sql:${no}`)
          bugs.push({
            title: `SQL Injection: query dibangun dari input pengguna ("${t}")`,
            description:
              'Variabel "' + t + '" berasal dari request/input() dan digabung ke teks query (f-string/format/%). Penyerang dapat memanipulasi query untuk membaca atau merusak data.',
            severity: 'critical',
            line: no,
            category: 'Keamanan',
            suggestion:
              'Gunakan parameterized query: cursor.execute("... WHERE id = %s", (nilai,)) — jangan pernah format string SQL dengan input pengguna.',
            ruleId: 'py-taint-sql',
          })
        }
      }
    }

    // SINK 2 — eksekusi perintah/kode
    if (/\bos\s*\.\s*(?:system|popen)\s*\(|\bsubprocess\s*\.\s*(?:call|run|Popen)\s*\([^)]*shell\s*=\s*True|\beval\s*\(|\bexec\s*\(/.test(line)) {
      const t = taintUsedInLine(line, names)
      if (t && !seenSink.has(`cmd:${no}`)) {
        seenSink.add(`cmd:${no}`)
        bugs.push({
          title: `Command/code injection: input pengguna ("${t}") masuk os.system/subprocess/eval`,
          description:
            'Variabel "' + t + '" dari sumber tidak terpercaya dieksekusi sebagai perintah shell/kode Python. Penyerang dapat menjalankan perintah arbitrer di server.',
          severity: 'critical',
          line: no,
          category: 'Keamanan',
          suggestion:
            'Gunakan subprocess dengan daftar argumen (shell=False), validasi/whitelist input, dan hindari eval/exec untuk data eksternal.',
          ruleId: 'py-taint-cmd',
        })
      }
    }
  })

  return bugs
}
