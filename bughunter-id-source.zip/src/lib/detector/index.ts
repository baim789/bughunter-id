import { v4 as uuidv4 } from 'uuid'
import type { Bug, Severity, SourceLang } from '@/lib/types'
import { RULES, MULTI_LINE_DETECTORS, type Rule, type DraftBug } from './rules'
import { SEVERITY_ORDER } from '@/lib/severity'

export type { Rule, DraftBug } from './rules'

/**
 * Inline suppression: tulis komentar `bughunter-ignore` di baris yang
 * ditemuan ingin diabaikan, atau `bughunter-ignore-next-line` di baris
 * sebelumnya. Berlaku untuk SEMUA aturan pada baris tersebut.
 */
const SUPPRESS_SAME_LINE = /bughunter-ignore(?!-next)/i
const SUPPRESS_NEXT_LINE = /bughunter-ignore-next-line/i

const SEVERITY_WEIGHT: Record<Severity, number> = {
  critical: 25,
  high: 12,
  medium: 5,
  low: 2,
}

interface LanguageSignature {
  lang: SourceLang
  strong: RegExp
  weak: RegExp[]
  weight: number
}

const SIGNATURES: LanguageSignature[] = [
  {
    lang: 'php',
    strong: /<\?php/,
    weak: [/\$\w+\s*=/, /->\w+\(/, /\becho\b/, /\$_(GET|POST|REQUEST)\[/],
    weight: 2,
  },
  {
    lang: 'go',
    strong: /^package\s+\w+/m,
    weak: [/:=/, /fmt\./, /\bfunc\s+\w+\s*\(/, /^import\s+\(/m, /defer\s/],
    weight: 2,
  },
  {
    lang: 'python',
    strong: /__name__\s*==\s*['"]__main__['"]|^\s*def\s+\w+\s*\(.*\)\s*:\s*$/m,
    weak: [/^\s*import\s+\w+$/m, /\belif\b/, /\bself\./, /^\s*@\w+/m, /\bprint\s*\(/, /\bNone\b/, /:\s*$/m],
    weight: 1,
  },
  {
    lang: 'java',
    strong: /public\s+(static\s+)?(void|class)\s+\w+|System\.out\.print/,
    weak: [/^import\s+java[x.]?/m, /@Override/, /private\s+\w+\s+\w+;/, /new\s+\w+\s*\(/, /\bString\b/],
    weight: 2,
  },
  {
    lang: 'javascript',
    strong: /=>|console\.log\s*\(|\brequire\s*\(|\bimport\b.*\bfrom\b/,
    weak: [/\bconst\s+\w+\s*=/, /\blet\s+\w+\s*=/, /\bfunction\s+\w*\s*\(/, /document\./, /\basync\b/, /===/],
    weight: 1,
  },
]

export function detectLanguage(code: string): SourceLang | null {
  const scores: Partial<Record<SourceLang, number>> = {}
  for (const sig of SIGNATURES) {
    let score = 0
    if (sig.strong.test(code)) score += 5
    for (const w of sig.weak) {
      const matches = code.match(new RegExp(w.source, w.flags.includes('m') ? w.flags : w.flags + 'g'))
      if (matches) score += Math.min(matches.length, 5) * 0.5 * sig.weight
    }
    scores[sig.lang] = score
  }
  const sorted = Object.entries(scores).sort((a, b) => b[1] - a[1])
  if (sorted.length === 0 || (sorted[0][1] ?? 0) < 2) return null
  return sorted[0][0] as SourceLang
}

function draftToBug(draft: DraftBug, source: 'rule' | 'ai'): Bug {
  return { id: uuidv4(), source, ...draft }
}

function runRuleOnLine(rule: Rule, line: string, fullCode: string): Severity | null {
  if (rule.contextPattern && !rule.contextPattern.test(fullCode)) return null
  if (rule.exclude && rule.exclude.test(line)) return null
  if (!rule.pattern.test(line)) return null

  let severity: Severity = rule.severity
  if (rule.escalate && rule.escalate.pattern.test(line)) {
    severity = rule.escalate.severity
  }
  return severity
}

export interface AnalyzeOptions {
  /** ID aturan yang dinonaktifkan pengguna (dari Pengaturan Aturan). */
  disabledRules?: Iterable<string>
}

export function analyzeCode(code: string, language: string, options?: AnalyzeOptions): Bug[] {
  const disabled = new Set(options?.disabledRules ?? [])
  const rules = (RULES[language] ?? []).filter(r => !disabled.has(r.id))
  const lines = code.split('\n')
  const seen = new Set<string>()
  const bugs: Bug[] = []

  // 1) line-based rules
  for (const rule of rules) {
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i]
      if (!line.trim()) continue
      // inline suppression: komentar bughunter-ignore di baris ini / sebelumnya
      if (SUPPRESS_SAME_LINE.test(line)) continue
      if (i > 0 && SUPPRESS_NEXT_LINE.test(lines[i - 1])) continue
      const severity = runRuleOnLine(rule, line, code)
      if (!severity) continue
      const key = `${i + 1}:${rule.id}`
      if (seen.has(key)) continue
      seen.add(key)
      bugs.push(
        draftToBug(
          {
            title: rule.title,
            description: rule.description,
            severity,
            line: i + 1,
            suggestion: rule.suggestion,
            category: rule.category,
            ruleId: rule.id,
          },
          'rule',
        ),
      )
    }
  }

  // 2) multi-line detectors (termasuk taint & cek cerdas)
  const detectors = MULTI_LINE_DETECTORS[language] ?? []
  for (const detector of detectors) {
    for (const draft of detector(lines, code)) {
      if (draft.ruleId && disabled.has(draft.ruleId)) continue
      const key = `ml:${draft.line}:${draft.title}`
      if (seen.has(key)) continue
      // hormati juga suppression inline untuk temuan multi-baris
      const lineText = lines[draft.line - 1] ?? ''
      const prevText = lines[draft.line - 2] ?? ''
      if (SUPPRESS_SAME_LINE.test(lineText) || SUPPRESS_NEXT_LINE.test(prevText)) continue
      seen.add(key)
      bugs.push(draftToBug(draft, 'rule'))
    }
  }

  return sortBugs(bugs)
}

export function sortBugs(bugs: Bug[]): Bug[] {
  return [...bugs].sort((a, b) => {
    const sevDiff = SEVERITY_ORDER[a.severity] - SEVERITY_ORDER[b.severity]
    if (sevDiff !== 0) return sevDiff
    return a.line - b.line
  })
}

/** Merge rule bugs and AI bugs, deduplicating obvious overlaps (same line + same category). */
export function mergeBugs(ruleBugs: Bug[], aiBugs: Bug[]): Bug[] {
  const merged: Bug[] = [...ruleBugs]
  const ruleKeys = new Set(ruleBugs.map(b => `${b.line}:${b.category}`))
  for (const ai of aiBugs) {
    if (ruleKeys.has(`${ai.line}:${ai.category}`)) continue
    merged.push(ai)
  }
  return sortBugs(merged)
}

export function computeHealthScore(bugs: Bug[]): number {
  const penalty = bugs.reduce((sum, b) => sum + SEVERITY_WEIGHT[b.severity], 0)
  return Math.max(0, 100 - penalty)
}

export function countBySeverity(bugs: Bug[]): Record<Severity, number> {
  const counts: Record<Severity, number> = { critical: 0, high: 0, medium: 0, low: 0 }
  for (const b of bugs) counts[b.severity] += 1
  return counts
}
