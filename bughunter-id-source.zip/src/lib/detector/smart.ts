import type { DraftBug } from './rules'

/**
 * ============================================================
 *  CEK CERDAS IN-FILE (JavaScript/TypeScript)
 * ============================================================
 * Lapisan di atas aturan berbasis baris: memahami struktur dasar
 * kode (deklarasi, pemakaian, pemanggilan) dengan teknik masking
 * string/komentar agar tidak terjadi false positive dari teks
 * yang kebetulan mirip kode.
 *
 *  1. Variabel yang dideklarasikan tapi tidak pernah dipakai.
 *  2. Penugasan ulang ke variabel `const` (TypeError saat runtime).
 *  3. Pemanggilan fungsi dengan jumlah argumen lebih banyak dari
 *     parameter deklarasinya (argumen ekstra diam-diam diabaikan
 *     pada deklarasi tanpa rest → sumber bug logika).
 * ============================================================
 */

/** Ganti isi string, template literal, dan komentar dengan placeholder privat (panjang & baris dipertahankan).
 *  Placeholder '\uE000' (private use area) dipakai alih-alih spasi agar argumen berupa string
 *  tetap terhitung sebagai argumen non-kosong saat menghitung jumlah argumen panggilan,
 *  tetapi tidak pernah cocok dengan \bidentifier\b mana pun. */
const MASK_CHAR = '\uE000'

export function maskCode(code: string): string {
  let out = ''
  let i = 0
  const n = code.length
  const push = (ch: string) => {
    out += ch === '\n' ? '\n' : MASK_CHAR
  }
  while (i < n) {
    const c = code[i]
    // komentar satu baris
    if (c === '/' && code[i + 1] === '/') {
      while (i < n && code[i] !== '\n') {
        push(code[i])
        i++
      }
      continue
    }
    // komentar blok
    if (c === '/' && code[i + 1] === '*') {
      push(code[i])
      push(code[i + 1])
      i += 2
      while (i < n && !(code[i] === '*' && code[i + 1] === '/')) {
        push(code[i])
        i++
      }
      if (i < n) {
        push(code[i])
        push(code[i + 1])
        i += 2
      }
      continue
    }
    // string / template literal
    if (c === '"' || c === "'" || c === '`') {
      const q = c
      push(c)
      i++
      while (i < n && code[i] !== q) {
        if (code[i] === '\\' && i + 1 < n) {
          push(code[i])
          push(code[i + 1])
          i += 2
          continue
        }
        push(code[i])
        i++
      }
      if (i < n) {
        push(c)
        i++
      }
      continue
    }
    out += c
    i++
  }
  return out
}

/* ---------- indeks identifier satu-pass (performa berkas besar) ---------- */

/**
 * Indeks SEMUA kemunculan identifier dalam kode ter-mask, dibangun SEKALI per
 * berkas. Menggantikan pemindaian ulang seluruh berkas untuk setiap simbol
 * (O(simbol × ukuran) → O(ukuran)) sehingga berkas sangat besar tetap linier.
 * Semantik `\bnama\b` dipertahankan persis — termasuk identifier berbatas '$'
 * (mis. "$x" tetap terhitung sebagai kemunculan "x" karena '$' bukan karakter
 * kata bagi \b), dan substring di dalam token lebih panjang TIDAK dihitung.
 */
const IDENT_RE = /[A-Za-z_$][\w$]*/g

interface IdentIndex {
  /** nama → jumlah kemunculan (setara match /\bnama\b/g) */
  count: Map<string, number>
  /** nama → posisi awal tiap kemunculan (urut naik) */
  positions: Map<string, number[]>
  /** posisi karakter → nomor baris 1-based (pencarian biner) */
  lineOf: (pos: number) => number
}

function buildIdentIndex(masked: string): IdentIndex {
  const positions = new Map<string, number[]>()
  const add = (name: string, pos: number) => {
    const list = positions.get(name)
    if (list) list.push(pos)
    else positions.set(name, [pos])
  }
  IDENT_RE.lastIndex = 0
  let m: RegExpExecArray | null
  while ((m = IDENT_RE.exec(masked))) {
    const start = m.index
    const tok = m[0]
    if (start > 0 && /[\w$]/.test(masked[start - 1]!)) continue // bagian token lebih panjang
    // Pecah token pada '$': setiap gabungan segmen berurutan adalah kecocokan
    // \b...\b yang sah (batas sebelum segmen = awal token atau '$').
    const segStarts = [0]
    for (let i = 0; i < tok.length; i++) if (tok[i] === '$') segStarts.push(i + 1)
    for (let i = 0; i < segStarts.length; i++) {
      for (let j = i; j < segStarts.length; j++) {
        const from = segStarts[i]!
        const to = j + 1 < segStarts.length ? segStarts[j + 1]! - 1 : tok.length
        if (to > from) add(tok.slice(from, to), start + from)
      }
    }
  }
  const lineStarts: number[] = [0]
  for (let i = 0; i < masked.length; i++) {
    if (masked[i] === '\n') lineStarts.push(i + 1)
  }
  const count = new Map<string, number>()
  for (const [nama, daftar] of positions) count.set(nama, daftar.length)
  const lineOf = (pos: number): number => {
    let lo = 0
    let hi = lineStarts.length - 1
    while (lo < hi) {
      const mid = (lo + hi + 1) >> 1
      if (lineStarts[mid]! <= pos) lo = mid
      else hi = mid - 1
    }
    return lo + 1
  }
  return { count, positions, lineOf }
}

/** Cari '(' setelah akhir token, melewati whitespace apa pun (termasuk newline). */
function openParenAfter(masked: string, endPos: number): number {
  let i = endPos
  while (i < masked.length && /\s/.test(masked[i]!)) i++
  return masked[i] === '(' ? i : -1
}

/* ---------- 1) variabel tak terpakai ---------- */

const DECL_RE = /\b(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=/g
/** Tanpa syarat "=" — semantik lama pencarian baris deklarasi (mis. for-of). */
const DECL_ANY_RE = /\b(?:const|let|var)\s+([A-Za-z_$][\w$]*)/g

export function detectUnusedVars(lines: string[], code: string): DraftBug[] {
  const bugs: DraftBug[] = []
  const masked = maskCode(code)
  const index = buildIdentIndex(masked)

  let m: RegExpExecArray | null
  // baris deklarasi pertama per nama TANPA syarat "=" (untuk cek export)
  const declLinePos = new Map<string, number>()
  DECL_ANY_RE.lastIndex = 0
  while ((m = DECL_ANY_RE.exec(masked))) {
    if (!declLinePos.has(m[1])) declLinePos.set(m[1], m.index)
  }
  // deklarasi pertama per nama DENGAN inisialisasi (yang diperiksa) — urutan sama dengan semula
  const firstDecl = new Map<string, number>()
  DECL_RE.lastIndex = 0
  while ((m = DECL_RE.exec(masked))) {
    const name = m[1]
    if (!firstDecl.has(name)) firstDecl.set(name, m.index)
  }
  for (const [name, declPos] of firstDecl) {
    if (name.startsWith('_')) continue // konvensi variabel sengaja tak dipakai
    // baris deklarasi memiliki "export" → simbol dipakai file lain
    const anyPos = declLinePos.get(name) ?? declPos
    const declLine = lines[index.lineOf(anyPos) - 1] ?? ''
    if (/\bexport\b/.test(declLine)) continue
    // hitung kemunculan nama di seluruh kode (hasil masking → hanya kode nyata)
    const occurrences = index.count.get(name) ?? 0
    if (occurrences <= 1) {
      const lineNo = index.lineOf(declPos)
      bugs.push({
        title: `Variabel "${name}" dideklarasikan tapi tidak pernah dipakai`,
        description:
          'Deklarasi ini tidak pernah direferensikan di bagian mana pun dari kode. Selain memboroskan membaca, variabel mati sering menjadi tanda logika yang lupa diselesaikan atau sisa refaktor.',
        severity: 'low',
        line: lineNo,
        category: 'Kualitas Kode',
        suggestion: `Hapus deklarasi "${name}" bila memang tidak diperlukan, atau selesaikan logika yang seharusnya memakainya.`,
        ruleId: 'js-unused-var',
      })
    }
  }
  return bugs
}

/* ---------- 2) penugasan ulang const ---------- */

const CONST_DECL_RE = /\bconst\s+([A-Za-z_$][\w$]*)\s*=/g
const ASSIGN_OP_RE = new RegExp('^\\s*(?:=(?![=>])|\\+=|-=|\\*=|/=|%=|\\*\\*=|&&=|\\|\\|=|\\?\\?=)')

export function detectConstReassign(lines: string[], code: string): DraftBug[] {
  const bugs: DraftBug[] = []
  const masked = maskCode(code)
  const index = buildIdentIndex(masked)

  CONST_DECL_RE.lastIndex = 0
  let m: RegExpExecArray | null
  while ((m = CONST_DECL_RE.exec(masked))) {
    const name = m[1]
    if (name.startsWith('_')) continue
    const declLineNo = index.lineOf(m.index)
    const occ = index.positions.get(name)
    if (!occ) continue
    // cari penugasan ulang pada baris SETELAH deklarasi (deklarasi sebaris tidak dihitung)
    for (const p of occ) {
      if (index.lineOf(p) <= declLineNo) continue
      if (!ASSIGN_OP_RE.test(masked.slice(p + name.length, p + name.length + 80))) continue
      bugs.push({
        title: `Penugasan ulang ke konstanta "${name}" (TypeError: Assignment to constant variable)`,
        description:
          '"const" tidak bisa ditugaskan ulang. Kode ini akan melempar TypeError saat dieksekusi dan menghentikan alur program.',
        severity: 'high',
        line: index.lineOf(p),
        category: 'Bug Logika',
        suggestion: `Ubah deklarasi "${name}" menjadi "let" bila memang nilainya perlu berubah, atau perbaiki logika yang menugaskannya.`,
        ruleId: 'js-const-reassign',
      })
      break
    }
  }
  return bugs
}

/* ---------- 3) jumlah argumen pemanggilan vs deklarasi ---------- */

interface FnDecl {
  name: string
  paramCount: number
  line: number
  hasRest: boolean
}

function parseParamCount(params: string): { count: number; hasRest: boolean } {
  const raw = params.trim()
  if (!raw) return { count: 0, hasRest: false }
  let depth = 0
  const parts: string[] = []
  let cur = ''
  for (const ch of raw) {
    if (ch === '(' || ch === '[' || ch === '{') depth++
    if (ch === ')' || ch === ']' || ch === '}') depth--
    if (ch === ',' && depth === 0) {
      parts.push(cur)
      cur = ''
      continue
    }
    cur += ch
  }
  parts.push(cur)
  let hasRest = false
  const count = parts.filter(p => {
    const t = p.trim()
    if (!t) return false
    if (t.startsWith('...')) {
      hasRest = true
      return false
    }
    return true
  }).length
  return { count, hasRest }
}

/** Hitung jumlah argumen pada sumber teks panggilan (level teratas, string sudah dimasking). */
export function countCallArgs(masked: string, openParenIdx: number): { count: number; hasSpread: boolean } | null {
  let depth = 0
  let i = openParenIdx
  let args = 0
  let curNonEmpty = false
  let hasSpread = false
  while (i < masked.length) {
    const ch = masked[i]
    if (ch === '(') depth++
    else if (ch === ')') {
      depth--
      if (depth === 0) break
    } else if (ch === ',' && depth === 1) {
      args++
      curNonEmpty = false
      i++
      continue
    }
    if (depth >= 1 && !/\s/.test(ch)) {
      curNonEmpty = true
      if (ch === '.' && masked[i + 1] === '.' && masked[i + 2] === '.') hasSpread = true
    }
    i++
  }
  if (i >= masked.length) return null // tidak ketemu penutup
  if (curNonEmpty) args += 1
  return { count: args, hasSpread }
}

export function detectCallArity(lines: string[], code: string): DraftBug[] {
  const bugs: DraftBug[] = []
  const masked = maskCode(code)
  const index = buildIdentIndex(masked)

  // kumpulkan deklarasi fungsi bernama (function declaration + const arrow)
  const decls: FnDecl[] = []
  const declRe = /\bfunction\s+([A-Za-z_$][\w$]*)\s*\(([^)]*)\)/g
  const arrowRe = /\b(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*\(([^)]*)\)\s*=>/g
  let m: RegExpExecArray | null
  while ((m = declRe.exec(masked))) {
    const { count, hasRest } = parseParamCount(m[2])
    decls.push({
      name: m[1],
      paramCount: count,
      hasRest,
      line: index.lineOf(m.index),
    })
  }
  while ((m = arrowRe.exec(masked))) {
    const { count, hasRest } = parseParamCount(m[2])
    decls.push({
      name: m[1],
      paramCount: count,
      hasRest,
      line: index.lineOf(m.index),
    })
  }
  if (decls.length === 0) return bugs

  const declIndexByLine = new Map<number, string>()
  for (const d of decls) declIndexByLine.set(d.line, d.name)

  for (const decl of decls) {
    if (decl.name.length < 3) continue // nama pendek (go, db) terlalu rawan salah sasaran
    if (decl.hasRest) continue // rest menerima argumen ekstra
    for (const p of index.positions.get(decl.name) ?? []) {
      // setara lookbehind (?<![.\w$'"`]): [\w$] sudah ditangani indeks
      const prev = p > 0 ? masked[p - 1]! : ''
      if (prev === '.' || prev === "'" || prev === '"' || prev === '`') continue
      const parenPos = openParenAfter(masked, p + decl.name.length)
      if (parenPos < 0) continue
      const callLine = index.lineOf(p)
      // lewati posisi deklarasi fungsinya sendiri
      if (declIndexByLine.get(callLine) === decl.name) continue
      // lewati jika diawali keyword function/async (posisi deklarasi di baris sama)
      const before = masked.slice(Math.max(0, p - 60), p)
      if (/\bfunction\s*$|\basync\s+function\s*$/.test(before)) continue
      const counted = countCallArgs(masked, parenPos)
      if (!counted) continue
      if (counted.hasSpread) continue
      if (counted.count > decl.paramCount) {
        bugs.push({
          title: `Pemanggilan ${decl.name}() dengan ${counted.count} argumen — deklarasinya hanya menerima ${decl.paramCount}`,
          description:
            'Argumen ekstra tidak punya parameter penampung sehingga diabaikan diam-diam. Ini hampir selalu tanda salah kirim data (urutan/posisi argumen tertukar atau parameter lupa dihapus).',
          severity: 'medium',
          line: callLine,
          category: 'Bug Logika',
          suggestion: `Sesuaikan pemanggilan dengan signature ${decl.name}() — atau tambahkan parameter/rest di deklarasinya bila argumen ekstra memang disengaja.`,
          ruleId: 'js-arg-mismatch',
        })
      }
    }
  }
  return bugs
}
