import type {
  Bug,
  SourceLang,
  WorkspaceFileInput,
  WorkspaceFileResult,
  WorkspaceFixChange,
  WorkspaceFixFileResult,
  WorkspaceFixSkip,
} from '@/lib/types'
import { computeHealthScore, countBySeverity } from './index'
import { applyAutoFixes } from './fixers'
import { analyzeFilePhase1, type ScanAnalyzeOptions } from './scan-shared'
import { analyzeFilesInWorkers, parallelEligible } from './scan-parallel'
import { countCallArgs, maskCode } from './smart'
import { scanPackageJson, scanRequirementsTxt, type DepFinding } from '../deps-advisory'
import { buildGuidedFixes } from './guided-fix'
import {
  languageForFile,
  sanitizeFileName,
  resolveLocalImport,
  scanJsExports,
  scanJsImports,
  scanPyImports,
  scanSecretValues,
} from './import-scan'
import { analyzeCrossLanguage } from './cross-lang'

// re-export: pemakai lama mengimpor dari sini
export { languageForFile, sanitizeFileName } from './import-scan'

/**
 * ============================================================
 *  MESIN ANALISIS LINTAS-FILE (Workspace BugHunter ID)
 * ============================================================
 * Analisis per file tetap memakai mesin 60+ aturan yang sama.
 * Lapisan ini menambahkan temuan yang HANYA terlihat bila banyak
 * file dianalisis bersama (deterministik, tanpa false positive
 * semaksimal mungkin):
 *
 *  1. Import lokal JS/TS yang menunjuk simbol yang tidak ada di
 *     file tujuan (mis. `import { fmt } from './utils'` padahal
 *     utils tidak mengekspor fmt) — severity tinggi.
 *  2. Import lokal JS/TS yang menunjuk file yang tidak ada di
 *     workspace — sedang (bisa juga file sengaja tidak diunggah).
 *  3. `from X import simbol` Python yang tidak tersedia di X.py.
 *  4. Deklarasi global duplikat antar file skrip JS (bukan modul)
 *     yang saling menimpa saat dimuat bersama.
 *  5. Kredensial (hardcoded secret) yang NILAINYA SAMA muncul di
 *     beberapa file — satu sumber bocor, banyak titik eksploit.
 *
 * Prinsip "tanpa kerusakan": temuan lintas file TIDAK pernah
 * diperbaiki otomatis (menambah export/mengubah path adalah
 * keputusan desain) — selalu disertai saran konkret.
 * ============================================================
 */

/* ---------- helper umum ---------- */

function makeBug(draft: Omit<Bug, 'id' | 'source'>): Bug {
  return { id: `ws-${Math.random().toString(36).slice(2)}${Date.now().toString(36)}`, source: 'rule', ...draft }
}

function firstLineOf(code: string, re: RegExp): number {
  const lines = code.split('\n')
  for (let i = 0; i < lines.length; i++) {
    re.lastIndex = 0
    if (re.test(lines[i])) return i + 1
  }
  return 1
}

/* ============================================================
 *  ANALISIS WORKSPACE
 * ============================================================ */

export async function analyzeWorkspaceFiles(
  files: WorkspaceFileInput[],
  options?: {
    disabledRules?: Iterable<string>
    /** Dipanggil setelah analisis awal tiap file (untuk progres real-time). */
    onFileResult?: (r: WorkspaceFileResult, elapsedMs: number, index: number) => void
  },
): Promise<WorkspaceFileResult[]> {
  const analyzeOptions: ScanAnalyzeOptions = {
    disabledRules: options?.disabledRules ? Array.from(options.disabledRules) : undefined,
  }
  const disabled = new Set(options?.disabledRules ?? [])
  const fileSet = new Set(files.map(f => f.name))
  const byName = new Map(files.map(f => [f.name, f]))

  /* --- analisis per file (mesin 60+ aturan) ---
   * Fase 1 ini murni per file: dijalankan PARALEL via worker thread
   * bila volume pekerjaan melewati ambang (proyek besar), selain itu
   * serial di thread utama. Kedua jalur memanggil analyzeFilePhase1
   * yang sama → hasil deteksi identik (lihat scan-parallel.ts).
   */
  const totalChars = files.reduce((s, f) => s + f.code.length, 0)
  const wantParallel = parallelEligible(files.length, totalChars)
  const parallel = wantParallel ? await analyzeFilesInWorkers(files, analyzeOptions) : null
  console.log(`[workspace] fase1 file=${files.length} char=${totalChars} jalur=${parallel ? 'PARALEL' : 'serial'}`)

  const results: WorkspaceFileResult[] = []
  if (parallel) {
    for (let index = 0; index < parallel.results.length; index++) {
      const r = parallel.results[index]!
      results.push(r)
      options?.onFileResult?.(r, parallel.elapsed[index] ?? 0, index)
    }
  } else {
    for (let index = 0; index < files.length; index++) {
      const f = files[index]!
      const t0 = Date.now()
      const r = analyzeFilePhase1(f, analyzeOptions)
      results.push(r)
      options?.onFileResult?.(r, Date.now() - t0, index)
    }
  }
  const bugsByFile = new Map(results.map(r => [r.name, r.bugs]))

  const addBug = (file: string, bug: Bug) => {
    const list = bugsByFile.get(file)
    if (!list) return
    if (list.some(b => b.line === bug.line && b.title === bug.title)) return // dedupe
    list.push(bug)
  }

  /**
   * Tambah temuan lintas file dengan ruleId + opsi perbaikan berpandu.
   * Hormati disabledRules (Pengaturan Aturan) juga di lapisan ini.
   */
  const addCrossBug = (
    file: string,
    draft: Omit<Bug, 'id' | 'source'>,
    ruleId: string,
    ctx: { targetFile?: string; symbol?: string; spec?: string; paramCount?: number; callCount?: number; fixedIn?: string } = {},
  ) => {
    if (disabled.has(ruleId)) return
    const targetCode = ctx.targetFile ? byName.get(ctx.targetFile)?.code : undefined
    const importerCode = byName.get(file)?.code
    const guided = buildGuidedFixes(ruleId, {
      file,
      line: draft.line,
      targetCode,
      importerCode,
      ...ctx,
    })
    const bug = makeBug({ ...draft, ruleId })
    if (guided && guided.length > 0) bug.guidedFixes = guided
    addBug(file, bug)
  }

  // Cache scanJsExports per berkas — dipakai lintas lapisan (1, 2, 7, 8) agar
  // berkas tujuan tidak di-scan ulang untuk setiap import (proyek besar).
  const expCache = new Map<string, ReturnType<typeof scanJsExports>>()
  const expOf = (name: string, code: string) => {
    let e = expCache.get(name)
    if (!e) {
      e = scanJsExports(code)
      expCache.set(name, e)
    }
    return e
  }

  /* --- 1) & 2): import lokal JS/TS --- */
  for (const f of files) {
    const lang = languageForFile(f.name)
    if (lang !== 'javascript') continue
    for (const imp of scanJsImports(f.code)) {
      const target = resolveLocalImport(f.name, imp.spec, fileSet)
      if (!target) {
        addCrossBug(
          f.name,
          {
            title: `Import relatif "${imp.spec}" tidak ditemukan di workspace`,
            description: `Berkas tujuan tidak ada di antara file yang diunggah. Jika file ini memang bagian proyek, pemindaian tidak bisa memverifikasi simbol yang diimpor dari sana.`,
            severity: 'medium',
            line: imp.line,
            category: 'Lintas File',
            suggestion: `Pastikan berkas untuk "${imp.spec}" ikut diunggah ke workspace, atau perbaiki jalur import (periksa ejaan dan ekstensi).`,
          },
          'ws-js-import-missing-file',
          { spec: imp.spec },
        )
        continue
      }
      const targetCode = byName.get(target)!.code
      const exp = expOf(target, targetCode)
      if (exp.hasStarReexport) continue // tidak bisa dipastikan tanpa resolusi berantai — hindari false positive
      for (const n of imp.names) {
        if (!exp.named.has(n.imported)) {
          addCrossBug(
            f.name,
            {
              title: `"${n.imported}" tidak diekspor oleh ${target}`,
              description: `File ini mengimpor ${n.imported} dari ${target}, tetapi di berkas tersebut tidak ada deklarasi export untuk nama itu. Saat dijalankan, nilainya undefined dan menyebabkan TypeError.`,
              severity: 'high',
              line: imp.line,
              category: 'Lintas File',
              suggestion: `Tambahkan export di ${target} (mis. export function ${n.imported}...), atau perbaiki ejaan import, atau ekspor ulang dari modul lain.`,
            },
            'ws-js-import-symbol',
            { targetFile: target, symbol: n.imported },
          )
        }
      }
      if (imp.hasDefault && !exp.hasDefault) {
        addCrossBug(
          f.name,
          {
            title: `Import default dari ${target} yang tidak punya export default`,
            description: `Berkas ${target} tidak memiliki export default, sehingga nilai import default bernilai undefined.`,
            severity: 'high',
            line: imp.line,
            category: 'Lintas File',
            suggestion: `Tambahkan "export default" di ${target} atau ubah menjadi import bernama.`,
          },
          'ws-js-import-default',
          { targetFile: target },
        )
      }
    }
  }

  /* --- 3): import Python --- */
  for (const f of files) {
    if (languageForFile(f.name) !== 'python') continue
    for (const imp of scanPyImports(f.code)) {
      const rootModule = imp.module.split('.')[0]
      const target = `${rootModule}.py`
      if (!fileSet.has(target)) continue // modul eksternal / stdlib — bukan urusan lintas file
      const targetCode = byName.get(target)!.code
      for (const sym of imp.symbols) {
        // simbol "tersedia" hanya bila target benar-benar mendefinisikan NAMA itu
        // (def/class/penugasan variabel dengan nama sama) — bukan assignment apa pun
        const symEsc = sym.replace(/\$/g, '\\$')
        const definedRe = new RegExp(`^(?:def\\s+${symEsc}\\b|class\\s+${symEsc}\\b|${symEsc}\\s*=)`, 'm')
        if (!definedRe.test(targetCode)) {
          addCrossBug(
            f.name,
            {
              title: `"${sym}" tidak tersedia di ${target}`,
              description: `Baris from ${imp.module} import ... meminta ${sym}, tetapi ${target} tidak mendefinisikan fungsi/kelas/variabel bernama itu. Import akan gagal saat runtime (ImportError).`,
              severity: 'high',
              line: imp.line,
              category: 'Lintas File',
              suggestion: `Definisikan ${sym} di ${target}, perbaiki ejaan, atau impor dari modul yang benar.`,
            },
            'ws-py-import-symbol',
            { targetFile: target, symbol: sym },
          )
        }
      }
    }
  }

  /* --- 4): deklarasi global duplikat antar file skrip JS --- */
  const declRe = /^(?:function|class|const|let|var)\s+([A-Za-z_$][\w$]*)/
  const globalDecls = new Map<string, Array<{ file: string; line: number }>>()
  for (const f of files) {
    if (languageForFile(f.name) !== 'javascript') continue
    if (scanJsExports(f.code).isModule) continue // modul punya scope sendiri — tidak bertabrakan
    f.code.split('\n').forEach((line, idx) => {
      const m = declRe.exec(line.trim())
      if (m) {
        const list = globalDecls.get(m[1]) ?? []
        list.push({ file: f.name, line: idx + 1 })
        globalDecls.set(m[1], list)
      }
    })
  }
  for (const [name, locs] of globalDecls) {
    if (locs.length < 2) continue
    for (let i = 1; i < locs.length; i++) {
      const loc = locs[i]
      const others = locs.filter(l => l !== loc).map(l => l.file).join(', ')
      addCrossBug(
        loc.file,
        {
          title: `Deklarasi global "${name}" tumpang tindih antar file`,
          description: `"${name}" juga dideklarasikan di ${others}. Karena kedua file berupa skrip (bukan modul), deklarasi belakangan menimpa yang pertama saat dimuat bersama — sumber bug perilaku yang sulit dilacak.`,
          severity: 'medium',
          line: loc.line,
          category: 'Lintas File',
          suggestion: `Ganti salah satu file menjadi modul (tambahkan import/export), beri nama berbeda, atau bungkus dalam blok/scope masing-masing.`,
        },
        'ws-duplicate-global',
        { symbol: name },
      )
    }
  }

  /* --- 5): kredensial bernilai sama di beberapa file --- */
  const secretMap = new Map<string, Array<{ file: string; line: number }>>()
  for (const f of files) {
    for (const s of scanSecretValues(f.code)) {
      const list = secretMap.get(s.value) ?? []
      list.push({ file: f.name, line: s.line })
      secretMap.set(s.value, list)
    }
  }
  for (const [, locs] of secretMap) {
    if (locs.length < 2) continue
    const uniqueFiles = [...new Set(locs.map(l => l.file))]
    if (uniqueFiles.length < 2) continue
    for (const loc of locs) {
      const others = uniqueFiles.filter(fn => fn !== loc.file).join(', ')
      addCrossBug(
        loc.file,
        {
          title: 'Kredensial yang sama digunakan di beberapa file',
          description: `Nilai kredensial di baris ini identik dengan yang ada di: ${others}. Satu kebocoran di mana pun akan membuka semuanya, dan rotasi menjadi sulit dilacak.`,
          severity: 'high',
          line: loc.line,
          category: 'Lintas File',
          suggestion: `Pindahkan ke environment variable (.env yang di-gitignore), muat sekali di satu modul konfigurasi, lalu ROTASI nilainya — dianggap sudah terekspos.`,
        },
        'ws-shared-secret',
      )
    }
  }

  /* --- 6): import melingkar (circular imports) --- */
  {
    // Bangun graf: file → file yang diimpornya (lokal workspace).
    const graph = new Map<string, string[]>()
    const firstEdgeLine = new Map<string, number>() // "a->b" → baris import pertama di a
    for (const f of files) {
      const lang = languageForFile(f.name)
      if (lang === 'javascript') {
        const edges: string[] = []
        for (const imp of scanJsImports(f.code)) {
          const target = resolveLocalImport(f.name, imp.spec, fileSet)
          if (target && target !== f.name) {
            edges.push(target)
            const key = `${f.name}->${target}`
            if (!firstEdgeLine.has(key)) firstEdgeLine.set(key, imp.line)
          }
        }
        graph.set(f.name, edges)
      } else if (lang === 'python') {
        const edges: string[] = []
        for (const imp of scanPyImports(f.code)) {
          const target = `${imp.module.split('.')[0]}.py`
          if (target !== f.name && fileSet.has(target)) {
            edges.push(target)
            const key = `${f.name}->${target}`
            if (!firstEdgeLine.has(key)) firstEdgeLine.set(key, imp.line)
          }
        }
        graph.set(f.name, edges)
      }
    }

    // DFS cari siklus (kembalian ke node abu-abu = siklus).
    const color = new Map<string, 0 | 1 | 2>() // 0 putih, 1 abu, 2 hitam
    const stack: string[] = []
    const cycles: string[][] = []
    const cycleSeen = new Set<string>()
    const dfs = (node: string) => {
      color.set(node, 1)
      stack.push(node)
      for (const next of graph.get(node) ?? []) {
        const c = color.get(next) ?? 0
        if (c === 1) {
          // siklus: potong stack dari kemunculan next
          const idx = stack.indexOf(next)
          const cycle = stack.slice(idx)
          const key = [...cycle].sort().join('|')
          if (!cycleSeen.has(key)) {
            cycleSeen.add(key)
            cycles.push([...cycle])
          }
        } else if (c === 0) {
          dfs(next)
        }
      }
      stack.pop()
      color.set(node, 2)
    }
    for (const node of graph.keys()) {
      if ((color.get(node) ?? 0) === 0) dfs(node)
    }

    for (const cycle of cycles) {
      // tiap anggota siklus: bug di baris import yang mengarah ke anggota siklus lain
      for (let i = 0; i < cycle.length; i++) {
        const from = cycle[i]
        const to = cycle[(i + 1) % cycle.length]
        const line = firstEdgeLine.get(`${from}->${to}`) ?? 1
        const path = [...cycle, cycle[0]].join(' → ')
        addCrossBug(
          from,
          {
            title: 'Import melingkar antar file (circular import)',
            description: `Rantai impor membentuk lingkaran: ${path}. Saat modul dimulai, sebagian variabel/fungsi bisa bernilai undefined karena modul lain belum selesai dimuat — bug yang sulit direproduksi.`,
            severity: 'medium',
            line,
            category: 'Lintas File',
            suggestion:
              'Pecah modul bersama menjadi modul utilitas independen yang tidak saling mengimpor, atau impor simbol di dalam fungsi (lazy import) alih-alih di level atas.',
          },
          'ws-circular-import',
          { targetFile: to },
        )
      }
    }
  }

  /* --- 7): export tak terpakai antar file (dead code) --- */
  {
    const jsFiles = files.filter(f => languageForFile(f.name) === 'javascript')
    if (jsFiles.length >= 3) {
      // kumpulkan semua simbol yang diimpor per file tujuan
      const usedNames = new Map<string, Set<string>>() // target → nama yang diimpor orang lain
      const importersOf = new Map<string, Set<string>>() // target → siapa saja yang mengimpornya
      for (const f of jsFiles) {
        for (const imp of scanJsImports(f.code)) {
          const target = resolveLocalImport(f.name, imp.spec, fileSet)
          if (!target || target === f.name) continue
          if (!usedNames.has(target)) usedNames.set(target, new Set())
          if (!importersOf.has(target)) importersOf.set(target, new Set())
          importersOf.get(target)!.add(f.name)
          if (imp.hasNamespace || imp.hasDefault) {
            // namespace/default → semua named export dianggap berpotensi terpakai
            usedNames.get(target)!.add('*')
          }
          for (const n of imp.names) usedNames.get(target)!.add(n.imported)
        }
      }
      const ENTRY_BASE = /^(index|main|app|server|mod|__init__)$/
      for (const f of jsFiles) {
        const exp = expOf(f.name, f.code)
        if (!exp.isModule || exp.hasStarReexport) continue
        if (exp.hasDefault && /module\.exports/.test(f.code)) continue // CJS dinamis — konservatif
        const base = f.name.split('/').pop()!.replace(/\.[^.]+$/, '')
        if (ENTRY_BASE.test(base)) continue // entry point memang tidak diimpor
        const used = usedNames.get(f.name)
        if (used?.has('*')) continue
        const rawLines = f.code.split('\n') // sekali per berkas (bukan per simbol)
        for (const name of exp.named) {
          if (used?.has(name)) continue
          const declRe = new RegExp(`\\bexport\\b[^\\n]*\\b${name.replace(/\$/g, '\\$')}\\b`)
          let line = 1
          for (let li = 0; li < rawLines.length; li++) {
            if (declRe.test(rawLines[li]!)) {
              line = li + 1
              break
            }
          }
          addCrossBug(
            f.name,
            {
              title: `"${name}" diekspor tapi tidak pernah diimpor file lain`,
              description:
                'Tidak ada file di workspace ini yang memakai simbol ini. Jika memang sengaja disiapkan untuk pemakai luar, abaikan; jika tidak, ini kode mati yang ikut membebani pemeliharaan.',
              severity: 'low',
              line,
              category: 'Lintas File',
              suggestion: `Hapus export "${name}" beserta kodenya bila tidak diperlukan, atau pakai simbol ini di file pemakainya.`,
            },
            'ws-dead-export',
            { symbol: name, targetFile: f.name }, // target = file sendiri (untuk cek bentuk deklarasi)
          )
        }
      }
    }
  }

  /* --- 8): pemanggilan fungsi lintas file dengan jumlah argumen salah --- */
  {
    // signature fungsi yang diekspor: "target:name" → {paramCount, hasRest}
    interface ExportedFn {
      target: string
      paramCount: number
      hasRest: boolean
      hasDefaults: boolean
      declLine: number
    }
    const exportedFns = new Map<string, ExportedFn>()
    for (const f of files) {
      if (languageForFile(f.name) !== 'javascript') continue
      const exp = expOf(f.name, f.code)
      if (!exp.isModule) continue
      const lines = f.code.split('\n')
      lines.forEach((line, idx) => {
        const fnRe = /\bexport\s+(?:default\s+)?(?:async\s+)?function\s+([A-Za-z_$][\w$]*)\s*\(([^)]*)\)/
        const arrowRe = /\bexport\s+const\s+([A-Za-z_$][\w$]*)\s*=\s*\(([^)]*)\)\s*=>/
        const m = fnRe.exec(line) ?? arrowRe.exec(line)
        if (!m) return
        const name = m[1]
        const params = m[2].trim()
        if (params.includes('...')) return // rest → menerima argumen ekstra
        let paramCount = 0
        if (params) {
          let depth = 0
          paramCount = 1
          for (const ch of params) {
            if (ch === '(' || ch === '[' || ch === '{') depth++
            else if (ch === ')' || ch === ']' || ch === '}') depth--
            else if (ch === ',' && depth === 0) paramCount++
          }
        }
        exportedFns.set(`${f.name}:${name}`, {
          target: f.name,
          paramCount,
          hasRest: false,
          hasDefaults: params.includes('='),
          declLine: idx + 1,
        })
      })
    }
    if (exportedFns.size > 0) {
      for (const f of files) {
        if (languageForFile(f.name) !== 'javascript') continue
        let maskedCall: string | null = null // mask sekali per berkas (bukan per simbol)
        for (const imp of scanJsImports(f.code)) {
          const target = resolveLocalImport(f.name, imp.spec, fileSet)
          if (!target) continue
          for (const n of imp.names) {
            const fn = exportedFns.get(`${target}:${n.imported}`)
            if (!fn) continue
            // hanya fungsi (bukan const non-fungsi): cek target benar mendeklarasikan function
            const targetCode = byName.get(target)!.code
            const isFn =
              new RegExp(`\\bfunction\\s+${n.imported.replace(/\$/g, '\\$')}\\b`).test(targetCode) ||
              new RegExp(`\\bconst\\s+${n.imported.replace(/\$/g, '\\$')}\\s*=\\s*\\([^)]*\\)\\s*=>`).test(targetCode)
            if (!isFn) continue
            // cari pemanggilan di file pengimpor (pakai nama lokal alias)
            maskedCall ??= maskCode(f.code)
            const callRe = new RegExp(`(?<![.\\w$'"\`])${n.local.replace(/\$/g, '\\$')}\\s*\\(`, 'g')
            let cm: RegExpExecArray | null
            while ((cm = callRe.exec(maskedCall))) {
              const callLine = maskedCall.slice(0, cm.index).split('\n').length
              // lewati jika ini posisi deklarasi function di file pengimpor sendiri
              const before = maskedCall.slice(Math.max(0, cm.index - 60), cm.index)
              if (/\bfunction\s*$|\basync\s+function\s*$/.test(before)) continue
              const counted = countCallArgs(maskedCall, cm.index + cm[0].lastIndexOf('('))
              if (!counted || counted.hasSpread) continue
              if (counted.count > fn.paramCount) {
                addCrossBug(
                  f.name,
                  {
                    title: `${n.local}() dipanggil dengan ${counted.count} argumen — ${target} hanya mendeklarasikan ${fn.paramCount} parameter`,
                    description:
                      'Signature fungsi di ' + target + ' menerima ' + fn.paramCount + ' parameter, tetapi baris ini mengirim ' + counted.count + ' argumen. Argumen ekstra diabaikan diam-diam — hampir selalu tanda data yang salah kirim antar file.',
                    severity: 'medium',
                    line: callLine,
                    category: 'Lintas File',
                    suggestion: `Samakan pemanggilan dengan signature di ${target} (${fn.paramCount} parameter), atau perluas parameternya bila argumen tambahan memang diperlukan.`,
                  },
                  'ws-arity',
                  { targetFile: target, symbol: n.local, paramCount: fn.paramCount, callCount: counted.count },
                )
              } else if (counted.count < fn.paramCount && !fn.hasDefaults) {
                // argumen kekurangan (tanpa default): parameter hilang bernilai undefined secara diam-diam
                addCrossBug(
                  f.name,
                  {
                    title: `${n.local}() dipanggil dengan ${counted.count} argumen — ${target} mendeklarasikan ${fn.paramCount} parameter`,
                    description:
                      'Signature fungsi di ' + target + ' memerlukan ' + fn.paramCount + ' parameter, tetapi baris ini hanya mengirim ' + counted.count + '. JavaScript mengisi parameter yang hilang dengan undefined secara diam-diam — hampir selalu tanda argumen yang tertinggal atau salah urutan.',
                    severity: 'medium',
                    line: callLine,
                    category: 'Lintas File',
                    suggestion: `Lengkapi argumen sesuai signature di ${target} (${fn.paramCount} parameter), atau beri nilai default pada parameter yang belum terisi bila memang opsional.`,
                  },
                  'ws-arity-few',
                  { targetFile: target, symbol: n.local, paramCount: fn.paramCount, callCount: counted.count },
                )
              }
            }
          }
        }
      }
    }
  }

  /* --- 9): pemindaian dependensi (package.json / requirements.txt) --- */
  for (const f of files) {
    const isPkg = /(^|\/)package\.json$/i.test(f.name)
    const isReq = /(^|\/)requirements(\.[\w-]+)?\.txt$/i.test(f.name)
    if (!isPkg && !isReq) continue
    const findings: DepFinding[] = isPkg ? scanPackageJson(f.code) : scanRequirementsTxt(f.code)
    for (const d of findings) {
      addCrossBug(
        f.name,
        {
          title: `Dependensi rentan: ${d.pkg}@${d.version} — ${d.cve}`,
          description: `${d.title}. Versi terpasang ${d.version} lebih rendah dari versi perbaikan ${d.fixedIn}. Kerentanan yang diketahui di dependensi adalah pintu masuk paling umum di proyek nyata.`,
          severity: d.severity,
          line: d.line,
          category: 'Dependensi',
          suggestion: `Naikkan ke versi >= ${d.fixedIn} (${isPkg ? `npm install ${d.pkg}@^${d.fixedIn}` : `pip install --upgrade ${d.pkg}`}). Jalankan ${isPkg ? 'npm audit' : 'pip-audit'} untuk daftar CVE terbaru.`,
        },
        'ws-dep-cve',
        { symbol: d.pkg, fixedIn: d.fixedIn },
      )
    }
  }

  /* --- 10..17): lintas file untuk Python / Go / PHP / Java --- */
  analyzeCrossLanguage(files, {
    addCrossBug: (file, draft, ruleId, extra) => addCrossBug(file, draft, ruleId, extra ?? {}),
    byName,
    fileSet,
  })

  /* --- finalisasi: hitung ulang agregat per file --- */
  for (const r of results) {
    r.bugs = sortWorkspaceBugs(r.bugs)
    const counts = countBySeverity(r.bugs)
    r.bugCount = r.bugs.length
    r.criticalCount = counts.critical
    r.highCount = counts.high
    r.mediumCount = counts.medium
    r.lowCount = counts.low
    r.healthScore = r.supported ? computeHealthScore(r.bugs) : 100
  }
  return results
}

function sortWorkspaceBugs(bugs: Bug[]): Bug[] {
  const order: Record<string, number> = { critical: 0, high: 1, medium: 2, low: 3 }
  return [...bugs].sort((a, b) => (order[a.severity] ?? 9) - (order[b.severity] ?? 9) || a.line - b.line)
}

/** Jumlah temuan yang berasal dari lapisan lintas file. */
export function countCrossFileBugs(results: WorkspaceFileResult[]): number {
  return results.reduce(
    (sum, r) => sum + r.bugs.filter(b => b.category === 'Lintas File').length,
    0,
  )
}

/* ============================================================
 *  PERBAIKAN OTOMATIS BERSAMA (SEMUA FILE)
 * ============================================================ */

/**
 * Terapkan semua auto-fix aman pada SETIAP file yang didukung.
 * Temuan lintas file tidak pernah diubah otomatis — hanya diberi saran.
 */
export function applyWorkspaceFixes(
  files: WorkspaceFileInput[],
  options?: {
    /** Dipanggil setelah tiap file diproses (untuk progres real-time). */
    onFileResult?: (r: WorkspaceFixFileResult, elapsedMs: number, index: number) => void
  },
): {
  files: WorkspaceFixFileResult[]
  fixedCount: number
  skippedCount: number
} {
  const results: WorkspaceFixFileResult[] = []
  let fixedCount = 0
  let skippedCount = 0

  for (let i = 0; i < files.length; i++) {
    const f = files[i]!
    const t0 = Date.now()
    const lang = languageForFile(f.name)
    let result: WorkspaceFixFileResult
    if (!lang) {
      result = { name: f.name, supported: false, fixedCode: f.code, changes: [], skipped: [] }
    } else {
      const res = applyAutoFixes(f.code, lang)
      const changes: WorkspaceFixChange[] = res.changes.map(c => ({ ...c, file: f.name }))
      const skipped: WorkspaceFixSkip[] = res.skipped.map(s => ({ ...s, file: f.name }))
      fixedCount += changes.length
      skippedCount += skipped.length
      result = { name: f.name, supported: true, fixedCode: res.fixedCode, changes, skipped }
    }
    options?.onFileResult?.(result, Date.now() - t0, i)
    results.push(result)
  }
  return { files: results, fixedCount, skippedCount }
}
