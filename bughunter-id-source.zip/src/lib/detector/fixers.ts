import type { AutoFixChange, AutoFixSkip, SourceLang } from '@/lib/types'

/**
 * ============================================================
 *  MESIN AUTO-FIX AMAN (BugHunter ID)
 * ============================================================
 * Prinsip desain — "perbaiki tanpa kerusakan":
 *  1. HANYA aturan yang deterministik & terbukti aman yang punya fixer.
 *     Bug berisiko (eval, exec, innerHTML, SQL concat, dll.) tidak
 *     pernah diperbaiki otomatis — hanya diberi saran.
 *  2. Perbaikan selalu berada pada SATU baris dan TIDAK PERNAH
 *     menambah/menghapus baris → nomor baris temuan lain tetap valid.
 *  3. Setiap fixer punya guard pengaman (mis. jangan sentuh baris
 *     yang mengandung string literal, jangan ubah kode yang bisa
 *     mengubah perilaku program).
 *  4. UI selalu menyimpan kode asli + tombol "Kembalikan Kode Asli"
 *     (undo), dan hasil fix otomatis dipindai ulang untuk verifikasi.
 * ============================================================
 */

export interface FixerContext {
  fullCode: string
  language: SourceLang
}

export interface Fixer {
  id: string
  ruleIds: string[]
  languages: SourceLang[]
  description: string
  /** Kembalikan baris yang sudah diperbaiki, atau null jika tidak aman/tidak bisa. */
  fix: (line: string, ctx: FixerContext) => string | null
}

/* ---------------- helper keamanan ---------------- */

/** Hapus isi string literal ('...', "...", `...`) agar penghitungan hanya pada kode. */
function stripStrings(line: string): string {
  return line.replace(/(["'`])(?:\\.|(?!\1).)*\1/g, '""')
}

/** True jika semua kutip pada baris berpasangan (tidak sedang membuka string multi-baris). */
function quotesBalanced(line: string): boolean {
  for (const q of ["'", '"', '`'] as const) {
    const count = (line.match(new RegExp(`\\${q}`, 'g')) ?? []).length
    if (count % 2 !== 0) return false
  }
  return true
}

function isCommentLine(line: string): boolean {
  return /^\s*(\/\/|\*|\/\*|#)/.test(line)
}

/* ---------------- fixer per bahasa ---------------- */

// JS: == menjadi === (persis pola rule js-loose-equality)
const fixJsStrictEquality: Fixer = {
  id: 'fix-js-strict-equality',
  ruleIds: ['js-loose-equality'],
  languages: ['javascript'],
  description: 'Mengganti operator "==" dengan "===" (perbandingan ketat anti bug konversi tipe).',
  fix(line) {
    const eqRe = /(?<![=!<>])==(?!=)/g
    if (isCommentLine(line) || !quotesBalanced(line)) return null
    const rawCount = (line.match(eqRe) ?? []).length
    if (rawCount === 0) return null
    // Guard: jika "==" juga muncul di dalam string literal, jangan sentuh (raw != outside).
    const outsideCount = (stripStrings(line).match(eqRe) ?? []).length
    if (rawCount !== outsideCount) return null
    const out = line.replace(eqRe, '===')
    return out === line ? null : out
  },
}

// JS: var → let (guard: tidak ada deklarasi ulang yang akan error dengan let)
const fixJsVarToLet: Fixer = {
  id: 'fix-js-var-to-let',
  ruleIds: ['js-var-usage'],
  languages: ['javascript'],
  description:
    'Mengganti "var" dengan "let" (diperiksa dulu: aman dari deklarasi ulang dan tidak bentrok let/const lain).',
  fix(line, { fullCode }) {
    const m = line.match(/\bvar\s+([A-Za-z_$][\w$]*)\s*=/)
    if (!m) return null
    const name = m[1]
    // Guard 1: identifier dideklarasikan dengan var lebih dari sekali → let akan error.
    const varDecls = (fullCode.match(new RegExp(`\\bvar\\s+${name}\\b`, 'g')) ?? []).length
    if (varDecls > 1) return null
    // Guard 2: identifier juga dideklarasikan let/const di tempat lain → lewati.
    if (new RegExp(`\\b(?:let|const)\\s+${name}\\b`).test(fullCode)) return null
    const out = line.replace(/\bvar(?=\s+[A-Za-z_$][\w$]*\s*=)/, 'let')
    return out === line ? null : out
  },
}

// JS: hapus pernyataan debugger (hanya jika menjadi satu-satunya pernyataan di baris itu)
// Catatan: teks komentar TIDAK boleh mengandung kata "debugger" agar tidak terdeteksi ulang saat re-scan.
const fixJsDebugger: Fixer = {
  id: 'fix-js-debugger',
  ruleIds: ['js-debugger'],
  languages: ['javascript'],
  description:
    'Menghapus pernyataan debugger dan menggantinya komentar (baris disimpan agar nomor baris tidak bergeser).',
  fix(line) {
    const trimmed = line.trim()
    if (!/^debugger\s*;?$/.test(trimmed)) return null
    const out = line.replace(/\bdebugger\b\s*;?/, '// [BugHunter] pernyataan debug dihapus')
    return out === line ? null : out
  },
}

// SENGAJA TIDAK ADA fixer untuk js-console-log:
// argumen console.log bisa memiliki efek samping (mis. console.log(getData())) —
// menghapus/komentari baris tersebut berpotensi MENGUBAH PERILAKU program.
// Temuan ini hanya diberi saran perbaikan manual (sama seperti kebijakan eslint no-console).

// JS: isi blok catch kosong satu-baris dengan console.error
const fixJsEmptyCatch: Fixer = {
  id: 'fix-js-empty-catch',
  ruleIds: ['js-empty-catch'],
  languages: ['javascript'],
  description: 'Menambahkan console.error(...) di dalam blok catch kosong agar kegagalan tidak senyap.',
  fix(line) {
    const m = line.match(/catch\s*\(\s*([^)]*?)\s*\)\s*\{\s*\}/)
    if (!m) return null
    let stmt: string
    if (m[1]) {
      if (!/^[A-Za-z_$][\w$]*$/.test(m[1])) return null // bukan identifier sederhana → jangan sentuh
      stmt = `console.error(${m[1]})`
    } else {
      stmt = "console.error('Caught error')" // optional catch binding (catch { })
    }
    const out = line.replace(/\{\s*\}/, `{ ${stmt}; }`)
    return out === line ? null : out
  },
}

// Python: bare except → except Exception:
const fixPyBareExcept: Fixer = {
  id: 'fix-py-bare-except',
  ruleIds: ['py-bare-except'],
  languages: ['python'],
  description:
    'Mengubah "except:" menjadi "except Exception:" agar KeyboardInterrupt/SystemExit tidak ikut tertelan.',
  fix(line) {
    if (!/^\s*except\s*:/.test(line)) return null
    const out = line.replace(/except\s*:/, 'except Exception:')
    return out === line ? null : out
  },
}

// Python: == None → is None, != None → is not None (PEP 8)
const fixPyEqNone: Fixer = {
  id: 'fix-py-eq-none',
  ruleIds: ['py-eq-none'],
  languages: ['python'],
  description: 'Mengganti "== None" menjadi "is None" dan "!= None" menjadi "is not None" (PEP 8).',
  fix(line) {
    const cmpRe = /==\s*None\b|!=\s*None\b/g
    if (isCommentLine(line) || !quotesBalanced(line)) return null
    const rawCount = (line.match(cmpRe) ?? []).length
    if (rawCount === 0) return null
    const outsideCount = (stripStrings(line).match(cmpRe) ?? []).length
    if (rawCount !== outsideCount) return null
    const out = line
      .replace(/==\s*None\b/g, 'is None')
      .replace(/!=\s*None\b/g, 'is not None')
    return out === line ? null : out
  },
}

// SENGAJA TIDAK ADA fixer untuk java-empty-catch:
// menambahkan komentar hanya menutupi deteksi (detector multi-baris tetap menganggap
// blok kosong), sedangkan perbaikan nyata (logger/rethrow/fallback) mengubah perilaku
// dan butuh keputusan manusia. Temuan ini hanya diberi saran perbaikan manual.

export const FIXERS: Fixer[] = [
  fixJsStrictEquality,
  fixJsVarToLet,
  fixJsDebugger,
  fixJsEmptyCatch,
  fixPyBareExcept,
  fixPyEqNone,
]

/** ID aturan yang mendukung perbaikan otomatis (dipakai UI untuk menampilkan tombol). */
export const FIXABLE_RULE_IDS: ReadonlySet<string> = new Set(
  FIXERS.flatMap(f => f.ruleIds),
)

export interface AutoFixTargets {
  line: number
  ruleId: string
}

export interface ApplyResult {
  fixedCode: string
  changes: AutoFixChange[]
  skipped: AutoFixSkip[]
}

/**
 * Terapkan semua auto-fix yang aman pada kode.
 * @param targets jika diisi, hanya (line, ruleId) pada daftar ini yang diperbaiki.
 *                Jika kosong/undefined, semua fixer yang cocok diterapkan.
 */
export function applyAutoFixes(
  code: string,
  language: SourceLang,
  targets?: AutoFixTargets[],
): ApplyResult {
  const lines = code.split('\n')
  const originalLineCount = lines.length
  const changes: AutoFixChange[] = []
  const skipped: AutoFixSkip[] = []

  const targetKeys = new Set<string>()
  const hasTargets = Array.isArray(targets) && targets.length > 0
  if (hasTargets) {
    for (const t of targets!) {
      if (typeof t?.line === 'number' && typeof t?.ruleId === 'string') {
        targetKeys.add(`${t.line}:${t.ruleId}`)
      }
    }
  }

  const applicable = FIXERS.filter(f => f.languages.includes(language))

  for (let i = 0; i < lines.length; i++) {
    const lineNo = i + 1
    const original = lines[i]
    if (!original.trim()) continue

    const lineTargets = hasTargets
      ? applicable.filter(f => f.ruleIds.some(r => targetKeys.has(`${lineNo}:${r}`)))
      : applicable

    // Baris ditargetkan secara eksplisit tapi tidak ada fixer yang cocok → catat sebagai skip.
    if (hasTargets && lineTargets.length === 0) {
      const targetedRule = targets!.find(t => t.line === lineNo)
      if (targetedRule) {
        skipped.push({
          line: lineNo,
          ruleId: targetedRule.ruleId,
          reason: 'Aturan ini belum didukung perbaikan otomatis yang aman — ikuti saran perbaikan manual.',
        })
      }
      continue
    }

    let current = original
    const used: Fixer[] = []
    for (const fixer of lineTargets) {
      let next: string | null = null
      try {
        next = fixer.fix(current, { fullCode: code, language })
      } catch {
        next = null
      }
      // Validasi hasil: tetap satu baris, tidak mengandung newline, dan benar-benar berubah.
      if (
        typeof next === 'string' &&
        next !== current &&
        !next.includes('\n')
      ) {
        current = next
        used.push(fixer)
      }
    }

    if (used.length > 0 && current !== original) {
      changes.push({
        line: lineNo,
        ruleId: used[0].ruleIds[0],
        fixerId: used.map(f => f.id).join('+'),
        before: original,
        after: current,
        description: used.map(f => f.description).join(' '),
        language,
      })
      lines[i] = current
    }
  }

  // Jaring pengaman terakhir: jumlah baris TIDAK BOLEH berubah.
  if (lines.length !== originalLineCount) {
    return { fixedCode: code, changes: [], skipped }
  }

  return { fixedCode: lines.join('\n'), changes, skipped }
}
