import type { Severity } from '@/lib/types'
import { detectTaintJs, detectTaintPy } from './taint'
import { detectUnusedVars, detectConstReassign, detectCallArity } from './smart'

export interface Rule {
  id: string
  pattern: RegExp
  exclude?: RegExp
  title: string
  description: string
  severity: Severity
  category: string
  suggestion: string
  /** Escalate severity if this extra pattern also matches the same line */
  escalate?: { pattern: RegExp; severity: Severity }
  /** Rule only fires when the whole code matches this pattern */
  contextPattern?: RegExp
}

export const RULES: Record<string, Rule[]> = {
  javascript: [
    {
      id: 'js-hardcoded-secret',
      pattern: /\b(?:[\w$-]*[_-])?(?:api[_-]?key|apikey|secret|password|passwd|pwd|pass|token|auth[_-]?(?:token|key))(?:[_-][\w$-]*)?\b\s*[:=]\s*["'`][^"'`]{6,}["'`]/i,
      title: 'Kredensial ditulis langsung di kode (hardcoded secret)',
      description:
        'Kunci API, password, atau token yang ditulis langsung dalam kode dapat terekspos lewat repository publik, bundle produksi, atau log error. Ini adalah salah satu penyebab kebocoran data paling umum.',
      severity: 'critical',
      category: 'Keamanan',
      suggestion:
        'Pindahkan kredensial ke environment variable (process.env.API_KEY) dan tambahkan file .env ke .gitignore. Rotasi kunci yang sudah pernah ter-commit.',
    },
    {
      id: 'js-eval',
      pattern: /\beval\s*\(/,
      title: 'Penggunaan eval() yang berbahaya',
      description:
        'eval() mengeksekusi string sebagai kode JavaScript. Jika ada input tidak terpercaya yang masuk ke string tersebut, penyerang dapat menjalankan kode arbitrer (code injection).',
      severity: 'critical',
      category: 'Keamanan',
      suggestion:
        'Hapus eval(). Gunakan JSON.parse() untuk data terstruktur, bracket notation objek untuk akses properti dinamis, atau refactor logika agar tidak butuh eksekusi string.',
    },
    {
      id: 'js-innerhtml',
      pattern: /\.innerHTML\s*=/,
      title: 'Penugasan innerHTML berisiko XSS',
      description:
        'Menetapkan innerHTML dengan data yang tidak disanitasi memungkinkan serangan Cross-Site Scripting (XSS) — skrip jahat dapat dijalankan di browser pengguna.',
      severity: 'high',
      category: 'Keamanan',
      suggestion:
        'Gunakan textContent untuk teks biasa. Jika HTML memang diperlukan, sanitasi terlebih dahulu dengan pustaka seperti DOMPurify.',
    },
    {
      id: 'js-debugger',
      pattern: /\bdebugger\b/,
      title: 'Pernyataan debugger tertinggal di kode',
      description:
        'Pernyataan debugger akan menghentikan eksekusi program saat DevTools terbuka dan menandakan kode debug yang lupa dibersihkan sebelum rilis.',
      severity: 'high',
      category: 'Debugging',
      suggestion: 'Hapus pernyataan debugger sebelum melakukan deploy ke produksi.',
    },
    {
      id: 'js-document-write',
      pattern: /document\.write\s*\(/,
      title: 'Penggunaan document.write()',
      description:
        'document.write() dapat dieksploitasi untuk XSS, memblokir parsing halaman, dan berperilaku tidak menentu pada dokumen yang sudah dimuat.',
      severity: 'high',
      category: 'Keamanan',
      suggestion:
        'Gunakan createElement() dan appendChild(), atau perbarui konten elemen melalui textContent/innerHTML yang sudah disanitasi.',
    },
    {
      id: 'js-assign-in-condition',
      pattern: /\bif\s*\([^()]*?(?<![=!<>])=(?!=)/,
      title: 'Penugasan (=) di dalam kondisi if',
      description:
        'Kemungkinan salah ketik: operator penugasan (=) digunakan alih-alih perbandingan (===). Kondisi ini selalu bernilai nilai yang di-assign sehingga logika branch menjadi salah.',
      severity: 'high',
      category: 'Bug Logika',
      suggestion:
        'Ganti "=" dengan "===" (atau "!==" untuk negasi). Contoh: if (userId === null) bukan if (userId = null).',
    },
    {
      id: 'js-timeout-string',
      pattern: /\b(setTimeout|setInterval)\s*\(\s*["'`]/,
      title: 'setTimeout/setInterval dengan argumen string',
      description:
        'String argumen dievaluasi sebagai kode (seperti eval) sehingga berisiko code injection dan lambat karena kompilasi runtime.',
      severity: 'medium',
      category: 'Keamanan',
      suggestion: 'Kirimkan fungsi sebagai argumen: setTimeout(refreshData, 3000) bukan setTimeout("refreshData()", 3000).',
    },
    {
      id: 'js-empty-catch',
      pattern: /catch\s*\([^)]*\)\s*\{\s*\}/,
      title: 'Blok catch kosong (error ditelan diam-diam)',
      description:
        'Error yang ditangkap tetapi diabaikan membuat kegagalan sulit didiagnosis — aplikasi bisa gagal senyap tanpa jejak log.',
      severity: 'medium',
      category: 'Penanganan Error',
      suggestion:
        'Catat error dengan console.error(e) atau logger, lalu tentukan: apakah perlu di-retry, di-rethrow, atau ditangani dengan nilai fallback.',
    },
    {
      id: 'js-loose-equality',
      pattern: /(?<![=!<>])==(?!=)/,
      exclude: /^\s*(\/\/|\*|\/\*)/,
      title: 'Perbandingan longgar dengan ==',
      description:
        'Operator == melakukan konversi tipe otomatis yang membingungkan (mis. "" == 0 bernilai true) dan sering menyebabkan bug logika halus.',
      severity: 'medium',
      category: 'Bug Logika',
      suggestion: 'Gunakan === dan !== untuk perbandingan yang aman terhadap perbedaan tipe.',
    },
    {
      id: 'js-for-in-array',
      pattern: /\bfor\s*\(\s*(?:const|let|var)?\s*\w+\s+in\s+\w+/,
      title: 'Iterasi array menggunakan for...in',
      description:
        'for...in mengiterasi nama properti (string), bukan indeks array — termasuk properti tambahan yang menempel pada array, dan urutannya tidak dijamin.',
      severity: 'medium',
      category: 'Bug Logika',
      suggestion: 'Gunakan for...of, forEach(), atau loop berbasis indeks klasik untuk array.',
    },
    {
      id: 'js-var-usage',
      pattern: /\bvar\s+\w+\s*=/,
      title: 'Deklarasi variabel dengan var',
      description:
        'var memiliki hoisting dan function scope yang memicu bug sulit dilacak (mis. di dalam loop dan closure). Gunakan let/const yang block-scoped.',
      severity: 'low',
      category: 'Kualitas Kode',
      suggestion: 'Ganti var dengan const (default) atau let jika nilainya memang perlu diubah.',
    },
    {
      id: 'js-console-log',
      pattern: /\bconsole\.(log|debug|info)\s*\(/,
      title: 'Pernyataan console.log tertinggal',
      description:
        'Log konsol yang ditinggal di produksi mengurangi performa dan berpotensi membocorkan data internal ke pengguna akhir.',
      severity: 'low',
        category: 'Debugging',
      suggestion:
        'Hapus console.log, atau gunakan pustaka logging dengan level yang bisa dimatikan di produksi (mis. winston/pino).',
    },
    {
      id: 'js-parseint-no-radix',
      pattern: /\bparseInt\s*\(\s*[^,()]+\s*\)/,
      title: 'parseInt tanpa parameter radix',
      description:
        'Tanpa radix, parseInt menebak basis angka — string "08" atau "0x1F" bisa terparse berbeda antar lingkungan dan memicu hasil yang salah.',
      severity: 'low',
      category: 'Bug Logika',
      suggestion: 'Selalu sertakan radix: parseInt(nilai, 10).',
    },
  ],

  python: [
    {
      id: 'py-hardcoded-secret',
      pattern: /\b(?:[\w-]*[_-])?(?:password|passwd|pwd|pass|secret|api[_-]?key|apikey|token|auth[_-]?(?:token|key))(?:[_-][\w-]*)?\b\s*=\s*["'][^"']{4,}["']/i,
      title: 'Kredensial ditulis langsung di kode (hardcoded secret)',
      description:
        'Password atau kunci API yang di-hardcode dapat terekspos lewat repository, log, atau bytecode yang didistribusikan.',
      severity: 'critical',
      category: 'Keamanan',
      suggestion:
        'Gunakan environment variable dengan os.environ / python-dotenv, atau vault terpusat. Rotasi kredensial yang sudah terekspos.',
    },
    {
      id: 'py-eval-exec',
      pattern: /\b(eval|exec)\s*\(/,
      title: 'Penggunaan eval()/exec() yang berbahaya',
      description:
        'eval()/exec() mengeksekusi string sebagai kode Python. Dengan input tidak terpercaya, penyerang dapat menjalankan kode arbitrer di server.',
      severity: 'critical',
        category: 'Keamanan',
      suggestion:
        'Ganti dengan ast.literal_eval() untuk data literal, json.loads() untuk JSON, atau petakan input ke fungsi tertentu lewat dict whitelist.',
    },
    {
      id: 'py-mutable-default-arg',
      pattern: /\bdef\s+\w+\s*\([^)]*=\s*(\[\]|\{\}|set\(\)|list\(\)|dict\(\))/,
      title: 'Argumen default mutable pada fungsi',
      description:
        'Default argument ([] atau {}) dievaluasi sekali saat definisi fungsi dan dibagikan di antara semua pemanggilan — perubahan pada pemanggilan pertama akan membocor ke pemanggilan berikutnya.',
      severity: 'critical',
      category: 'Bug Logika',
      suggestion:
        'Gunakan None sebagai default lalu inisialisasi di dalam fungsi: def f(x=None): x = x if x is not None else []',
    },
    {
      id: 'py-os-system',
      pattern: /os\.system\s*\(|subprocess\.\w+\([^)]*shell\s*=\s*True/,
      title: 'Eksekusi shell rentan command injection',
      description:
        'os.system() atau subprocess dengan shell=True menjalankan string melalui shell. Input tidak terpercaya (mis. "file.txt; rm -rf /") dapat dieksekusi sebagai perintah.',
      severity: 'critical',
      category: 'Keamanan',
      suggestion:
        'Gunakan subprocess.run([...]) tanpa shell=True dan kirim argumen sebagai list agar tidak diinterpretasi shell. Validasi/whitelist input.',
    },
    {
      id: 'py-sql-concat',
      pattern: /["'][^"']*\b(SELECT|INSERT\s+INTO|UPDATE|DELETE\s+FROM)\b[^"']*["']\s*(%|\+|\.format\(|\bformat\()/i,
      title: 'Query SQL dibangun dengan format/konkatenasi string',
      description:
        'Query SQL yang dirakit dari string memungkinkan SQL injection — penyerang dapat membaca, mengubah, atau menghapus seluruh isi database.',
      severity: 'critical',
      category: 'Keamanan',
      suggestion:
        'Gunakan parameterized query: cursor.execute("SELECT * FROM users WHERE name = %s", (nama,)) atau ORM seperti SQLAlchemy.',
    },
    {
      id: 'py-sql-fstring',
      pattern: /f["'][^"']*\b(SELECT|INSERT\s+INTO|UPDATE|DELETE\s+FROM)\b[^"']*["']/i,
      title: 'Query SQL memakai f-string',
      description:
        'Menyisipkan variabel langsung ke query SQL lewat f-string membuka celah SQL injection, sekecil apa pun kemungkinan input berasal dari pengguna.',
      severity: 'critical',
      category: 'Keamanan',
      suggestion: 'Gunakan parameterized query atau ORM. F-string hanya untuk teks yang ditampilkan, bukan query.',
    },
    {
      id: 'py-bare-except',
      pattern: /^\s*except\s*:/,
      title: 'Bare except tanpa tipe exception',
      description:
        'except: menangkap SEMUA exception termasuk SystemExit dan KeyboardInterrupt, menyembunyikan bug nyata dan membuat program sulit dihentikan.',
      severity: 'high',
      category: 'Penanganan Error',
      suggestion:
        'Tangkap exception spesifik (except ValueError:) atau minimal except Exception:. Hindari menelan error tanpa logging.',
    },
    {
      id: 'py-pickle',
      pattern: /\bpickle\.(load|loads)\s*\(/,
      title: 'Deserialisasi pickle pada data tidak terpercaya',
      description:
        'pickle.loads dapat mengeksekusi kode arbitrer saat memuat data yang dimanipulasi penyerang. Ini vektor serangan klasik pada aplikasi Python.',
      severity: 'high',
      category: 'Keamanan',
      suggestion: 'Gunakan format aman seperti JSON untuk data eksternal. Pickle hanya untuk data terpercaya (cache internal).',
    },
    {
      id: 'py-weak-hash',
      pattern: /hashlib\.(md5|sha1)\s*\(/i,
      title: 'Fungsi hash lemah (MD5/SHA-1)',
      description:
        'MD5 dan SHA-1 sudah patah secara kriptografis dan tidak boleh dipakai untuk password maupun integritas data yang menyangkut keamanan.',
      severity: 'high',
      category: 'Keamanan',
      suggestion:
        'Untuk password gunakan bcrypt/argon2/passlib. Untuk hash umum gunakan hashlib.sha256 atau SHA-3.',
    },
    {
      id: 'py-open-no-context',
      pattern: /^\s*\w+\s*=\s*open\s*\(/,
      exclude: /^\s*(with|as)\b/,
      title: 'open() tanpa context manager (with)',
      description:
        'File yang dibuka tanpa with tidak dijamin tertutup saat terjadi exception — menyebabkan kebocoran file descriptor dan data yang belum di-flush.',
      severity: 'medium',
      category: 'Kualitas Kode',
      suggestion: 'Bungkus dengan with open(path) as f: agar file tertutup otomatis.',
    },
    {
      id: 'py-builtin-shadow',
      pattern: /^\s*(list|dict|str|set|tuple|int|float|id|type|input|sum|min|max|len|format|filter|map)\s*=\s*/,
      title: 'Variabel menimpa nama built-in Python',
      description:
        'Menimpa nama built-in (mis. list = [...] atau str = x) membuat pemanggilan built-in tersebut setelah baris ini gagal dengan TypeError.',
      severity: 'medium',
      category: 'Bug Logika',
      suggestion: 'Gunakan nama variabel deskriptif lain, mis. items, text, total.',
    },
    {
      id: 'py-random-security',
      pattern: /\brandom\.(random|randint|choice|randrange)\s*\(/,
      escalate: { pattern: /(token|password|secret|otp|api[_-]?key|session)/i, severity: 'high' },
      title: 'Modul random bukan generator kriptografis',
      description:
        'Modul random bukan generator kriptografis. Jika dipakai untuk token, password, atau session id, nilainya dapat ditebak penyerang.',
      severity: 'low',
      category: 'Keamanan',
      suggestion: 'Untuk kebutuhan keamanan gunakan modul secrets: secrets.token_hex(32).',
    },
    {
      id: 'py-eq-none',
      pattern: /==\s*None\b|!=\s*None\b/,
      title: 'Perbandingan dengan None menggunakan ==',
      description:
        'Perbandingan identity None sebaiknya memakai is/is not karena __eq__ bisa dioverride sehingga hasil == None menyesatkan.',
      severity: 'low',
      category: 'Kualitas Kode',
      suggestion: 'Gunakan if result is None: atau if result is not None:.',
    },
    {
      id: 'py-global-stmt',
      pattern: /^\s*global\s+\w+/,
      title: 'Pernyataan global mengubah state luar fungsi',
      description:
        'Mengubah variabel global dari dalam fungsi membuat aliran data sulit dilacak, tidak thread-safe, dan menyulitkan pengujian.',
      severity: 'low',
      category: 'Kualitas Kode',
      suggestion: 'Kirimkan nilai sebagai parameter dan kembalikan hasil lewat return.',
    },
  ],

  java: [
    {
      id: 'java-hardcoded-secret',
      pattern: /\b(?:[\w-]*[_-])?(?:password|passwd|pwd|pass|secret|apiKey|api[_-]?key|token|auth[_-]?(?:token|key))(?:[_-][\w-]*)?\b\s*=\s*"[^"]{4,}"/i,
      title: 'Kredensial ditulis langsung di kode (hardcoded secret)',
      description:
        'String kredensial dalam source code mudah terekstrak dari file .class, repository, atau dekompilasi, dan tidak bisa diubah tanpa build ulang.',
      severity: 'critical',
      category: 'Keamanan',
      suggestion:
        'Simpan di environment variable, sistem konfigurasi eksternal (Spring Cloud Config / vault), atau Java KeyStore.',
    },
    {
      id: 'java-sql-concat',
      pattern: /"[^"]*\b(SELECT|INSERT\s+INTO|UPDATE|DELETE\s+FROM)\b[^"]*"\s*\+/i,
      title: 'Query SQL dirakit dengan konkatenasi string',
      description:
        'Pola ini adalah bentuk klasik SQL injection. PreparedStatement dengan parameter binding wajib digunakan untuk semua query berinput pengguna.',
      severity: 'critical',
      category: 'Keamanan',
      suggestion:
        'Gunakan PreparedStatement: conn.prepareStatement("SELECT * FROM users WHERE id = ?") lalu setString(1, userId).',
    },
    {
      id: 'java-string-comparison',
      pattern: /\b\w+\s*==\s*"[^"]*"|"[^"]*"\s*==\s*\w+/,
      title: 'Perbandingan String dengan operator ==',
      description:
        'Pada Java, == membandingkan referensi objek, bukan isi string. Dua string dengan isi sama bisa bernilai false jika berasal dari objek berbeda.',
      severity: 'high',
      category: 'Bug Logika',
      suggestion: 'Gunakan equals(): PASSWORD.equals(input) — letakkan konstanta di kiri agar aman dari null.',
    },
    {
      id: 'java-runtime-exec',
      pattern: /Runtime\.getRuntime\(\)\.exec\s*\(|new\s+ProcessBuilder\s*\(/,
      escalate: { pattern: /\b(userInput|input|param|request|arg)\b/i, severity: 'critical' },
      title: 'Eksekusi perintah sistem dari aplikasi',
      description:
        'Menjalankan perintah OS dari aplikasi berisiko command injection jika ada input pengguna yang masuk ke argumen perintah.',
      severity: 'high',
      category: 'Keamanan',
      suggestion:
        'Hindari eksekusi shell. Jika terpaksa, gunakan ProcessBuilder dengan argumen terpisah (tanpa shell), whitelist input, dan jalankan dengan privilege minimal.',
    },
    {
      id: 'java-catch-throwable',
      pattern: /catch\s*\(\s*(Exception|Throwable)\s+\w+\s*\)/,
      title: 'Menangkap Exception/Throwable terlalu umum',
      description:
        'Menangkap semua exception menyembunyikan bug pemrograman (mis. NullPointerException) dan membuat penanganan error menjadi tidak tepat sasaran.',
      severity: 'medium',
      category: 'Penanganan Error',
      suggestion: 'Tangkap exception spesifik (mis. catch (IOException e)) dan biarkan unexpected exception menyebar ke handler global.',
    },
    {
      id: 'java-empty-catch',
      pattern: /catch\s*\([^)]*\)\s*\{\s*\}/,
      title: 'Blok catch kosong (error ditelan diam-diam)',
      description:
        'Exception yang ditangkap lalu diabaikan membuat kegagalan tidak terlihat di log dan aplikasi berlanjut dalam kondisi tidak terdefinisi.',
      severity: 'medium',
      category: 'Penanganan Error',
      suggestion: 'Minimal catat dengan logger.error("konteks", e) atau rethrow sebagai exception aplikasi.',
    },
    {
      id: 'java-printstacktrace',
      pattern: /\.printStackTrace\s*\(\s*\)/,
      title: 'printStackTrace() alih-alih logger',
      description:
        'printStackTrace menulis ke stderr yang tidak terintegrasi dengan sistem logging produksi — jejak error hilang di infrastruktur monitoring.',
      severity: 'medium',
      category: 'Penanganan Error',
      suggestion: 'Gunakan SLF4J/Logback: log.error("Gagal memproses", e).',
    },
    {
      id: 'java-sysout',
      pattern: /System\.out\.print(ln)?\s*\(/,
      title: 'System.out.println untuk output/log',
      description:
        'System.out tidak memiliki level, timestamp, maupun rotasi file; di produksi ini menghambat observability dan performa.',
      severity: 'low',
      category: 'Kualitas Kode',
      suggestion: 'Ganti dengan logger (SLF4J) atau gunakan return value untuk aliran data program.',
    },
    {
      id: 'java-new-string',
      pattern: /new\s+String\s*\(\s*"/,
      title: 'Instansiasi String dengan new',
      description:
        'new String("...") membuat objek duplikat di heap alih-alih memakai string pool — boros memori tanpa manfaat.',
      severity: 'low',
      category: 'Kualitas Kode',
      suggestion: 'Gunakan literal: String s = "teks";',
    },
    {
      id: 'java-public-static-mutable',
      pattern: /public\s+static\s+(?!final)\w+.*\b(List|Map|Set|ArrayList|HashMap|HashSet|int\[\]|String\[\])\b/,
      title: 'Field public static yang mutable',
      description:
        'Koleksi statis publik dapat dimodifikasi dari mana saja tanpa kontrol — sumber race condition dan state korup yang sulit dilacak.',
      severity: 'medium',
      category: 'Kualitas Kode',
      suggestion: 'Jadikan private, sediakan akses via metode, dan pertimbangkan Collections.unmodifiableList/List.of(...).',
    },
    {
      id: 'java-weak-hash',
      pattern: /MessageDigest\.getInstance\(\s*"(MD5|SHA-?1)"\s*\)/i,
      title: 'Algoritma hash lemah (MD5/SHA-1)',
      description:
        'MD5/SHA-1 rentan terhadap collision dan tidak layak untuk verifikasi integritas maupun penyimpanan password.',
      severity: 'high',
      category: 'Keamanan',
      suggestion: 'Gunakan SHA-256 untuk hash umum, dan bcrypt/PBKDF2/Argon2 untuk password.',
    },
  ],

  php: [
    {
      id: 'php-hardcoded-secret',
      pattern:
        /(?:\$(?:[\w]*[_-])?(?:password|passwd|pwd|pass|secret|api[_-]?key|apikey|token|auth[_-]?(?:token|key))(?:[_-][\w]*)?\b\s*=\s*["'][^"']{4,}["'])|(?:define\s*\(\s*['"](?:[\w-]*[_-])?(?:password|passwd|pwd|pass|secret|api[_-]?key|apikey|token|auth[_-]?(?:token|key))(?:[_-][\w-]*)?['"]\s*,\s*["'][^"']{4,}["'])/i,
      title: 'Kredensial ditulis langsung di kode (hardcoded secret)',
      description:
        'Kredensial dalam source PHP terekspos pada repository, backup, dan deployment; rotasinya juga menyulitkan karena tersebar di banyak file.',
      severity: 'critical',
      category: 'Keamanan',
      suggestion: 'Gunakan environment variable (getenv / $_ENV) atau file konfigurasi di luar webroot yang di-require saat runtime.',
    },
    {
      id: 'php-mysql-ext',
      pattern: /\bmysql_(query|connect|pconnect|select_db|fetch_array|fetch_assoc|fetch_row|real_escape_string|num_rows|error)\s*\(/,
      title: 'Ekstensi mysql_* yang sudah dihapus',
      description:
        'Ekstensi mysql_* dihapus sejak PHP 7.0 — kode ini fatal error di PHP modern, dan tanpa parameter binding sangat rentan SQL injection.',
      severity: 'critical',
      category: 'Keamanan',
      suggestion: 'Migrasi ke MySQLi atau PDO dengan prepared statements: $stmt = $pdo->prepare("... WHERE id = ?").',
    },
    {
      id: 'php-eval',
      pattern: /\beval\s*\(\s*\$/,
      title: 'eval() pada variabel — code injection',
      description:
        'Mengeksekusi isi variabel sebagai kode PHP. Input yang dapat mempengaruhi variabel ini berarti penyerang dapat menjalankan kode arbitrer di server.',
      severity: 'critical',
      category: 'Keamanan',
      suggestion: 'Hilangkan eval. Refactor dengan mapping array ke fungsi/callback atau strategi dispatch lain.',
    },
    {
      id: 'php-sql-concat-userinput',
      pattern: /\$_(GET|POST|REQUEST|COOKIE)\s*\[[^\]]*\]\s*\.\s*["']|["']\s*\.\s*\$_(GET|POST|REQUEST|COOKIE)\s*\[/,
      title: 'Input pengguna dikonkatenasi ke query/SQL',
      description:
        'Menggabungkan $_GET/$_POST langsung ke string query membuka SQL injection — serangan termudah untuk membocorkan seluruh database.',
      severity: 'critical',
      category: 'Keamanan',
      suggestion:
        'Gunakan prepared statements (PDO): $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?"); $stmt->execute([$id]);',
    },
    {
      id: 'php-echo-userinput',
      pattern: /echo\s+\$_(GET|POST|REQUEST|COOKIE)|print\s*\(\s*\$_(GET|POST|REQUEST|COOKIE)/,
      title: 'Echo input pengguna tanpa escaping — XSS',
      description:
        'Menampilkan $_GET/$_POST langsung ke HTML memungkinkan Cross-Site Scripting: skrip penyerang berjalan di browser korban.',
      severity: 'critical',
      category: 'Keamanan',
      suggestion: 'Selalu escape output: echo htmlspecialchars($val, ENT_QUOTES, "UTF-8").',
    },
    {
      id: 'php-extract',
      pattern: /extract\s*\(\s*\$_(GET|POST|REQUEST|COOKIE)/,
      title: 'extract() pada input pengguna — variable overwrite',
      description:
        'extract() mengubah seluruh parameter request menjadi variabel, memungkinkan penyerang menimpa variabel internal apa pun (termasuk flag otorisasi).',
      severity: 'critical',
      category: 'Keamanan',
      suggestion: 'Akses input secara eksplisit: $id = $_GET["id"] ?? null; lalu validasi.',
    },
    {
      id: 'php-include-var',
      pattern: /\b(include|require)(?:_once)?\s*\(?\s*\$/,
      title: 'include/require dengan path variabel',
      description:
        'Path file yang ditentukan variabel dapat dimanipulasi untuk Local/Remote File Inclusion (LFI/RFI) — penyerang memuat file arbitrer atau kode jarak jauh.',
      severity: 'high',
      category: 'Keamanan',
      suggestion: 'Gunakan whitelist: $pages = ["home" => "home.php"]; include $pages[$page] ?? "404.php";',
    },
    {
      id: 'php-weak-hash',
      pattern: /\b(md5|sha1)\s*\(/i,
      title: 'Fungsi hash lemah (md5/sha1)',
      description:
        'md5/sha1 tidak layak untuk password (dapat di-brute force sangat cepat) maupun untuk kebutuhan keamanan lain.',
      severity: 'high',
      category: 'Keamanan',
      suggestion: 'Gunakan password_hash($pw, PASSWORD_DEFAULT) untuk password dan hash("sha256", ...) untuk hash umum.',
    },
    {
      id: 'php-suppress-errors',
      pattern: /@(?=\s*\w+\s*\(|\s*\$)/,
      title: 'Operator supresi error @',
      description:
        'Menyembunyikan error dengan @ membuat kegagalan (mis. koneksi DB, file hilang) tidak terlihat dan sulit di-debug di produksi.',
      severity: 'medium',
      category: 'Penanganan Error',
      suggestion: 'Tangani error secara eksplisit dengan try/catch atau pemeriksaan return value; aktifkan error logging.',
    },
    {
      id: 'php-loose-comparison',
      pattern: /(?<![=!<>])==(?!=)/,
      title: 'Perbandingan longgar == (type juggling)',
      description:
        'Pada PHP, "0" == false bernilai true. Perbandingan longgar memicu bug dan kerentanan type juggling, terutama saat membandingkan hash/token.',
      severity: 'medium',
      category: 'Bug Logika',
      suggestion: 'Gunakan === dan !== untuk perbandingan ketat, termasuk verifikasi hash.',
    },
    {
      id: 'php-deprecated-ereg',
      pattern: /\b(ereg|eregi|ereg_replace|eregi_replace|split)\s*\(/,
      title: 'Fungsi POSIX regex yang deprecated',
      description:
        'ereg()/split() deprecated sejak PHP 5.3 dan dihapus di PHP 7 — kode ini fatal error di PHP modern.',
      severity: 'medium',
      category: 'Kualitas Kode',
      suggestion: 'Migrasi ke fungsi PCRE: preg_match(), preg_replace(), preg_split().',
    },
    {
      id: 'php-rand-security',
      pattern: /\b(rand|mt_rand)\s*\(/,
      escalate: { pattern: /(token|password|secret|otp|session)/i, severity: 'high' },
      title: 'rand()/mt_rand() — hasil tidak kriptografis',
      description:
        'Generator acak rand/mt_rand dapat diprediksi; tidak boleh dipakai untuk token, OTP, maupun reset password.',
      severity: 'medium',
      category: 'Keamanan',
      suggestion: 'Gunakan random_int(100000, 999999) atau random_bytes(32) untuk kebutuhan keamanan.',
    },
    {
      id: 'php-die-exit',
      pattern: /\b(die|exit)\s*\(/,
      title: 'die()/exit() di tengah alur aplikasi',
      description:
        'Menghentikan proses secara paksa menghambat penanganan error terpusat, unit testing, dan shutdown yang bersih.',
      severity: 'low',
      category: 'Kualitas Kode',
      suggestion: 'Lempar exception dan biarkan handler global memutuskan respons yang sesuai.',
    },
  ],

  go: [
    {
      id: 'go-hardcoded-secret',
      pattern: /\b(password|passwd|secret|apiKey|api[_-]?key|token)\b\s*:?=\s*"[^"]{4,}"/i,
      title: 'Kredensial ditulis langsung di kode (hardcoded secret)',
      description:
        'Konstanta kredensial tertanam di binary hasil compile dan terekspos di repository — sangat sulit dirotasi tanpa build ulang.',
      severity: 'critical',
      category: 'Keamanan',
      suggestion: 'Muat dari environment variable (os.Getenv) atau sistem konfigurasi/vault saat startup.',
    },
    {
      id: 'go-sql-concat',
      pattern: /"[^"]*\b(SELECT|INSERT\s+INTO|UPDATE|DELETE\s+FROM)\b[^"]*"\s*\+/i,
      title: 'Query SQL dibangun dengan konkatenasi string',
      description:
        'SQL injection masuk lewat konkatenasi input ke query. Paket database/sql mendukung placeholder $1/? — gunakan itu.',
      severity: 'critical',
      category: 'Keamanan',
      suggestion:
        'Gunakan parameterized query: db.Query("SELECT * FROM users WHERE name = ?", name) — driver akan melakukan escaping dengan aman.',
    },
    {
      id: 'go-exec-userinput',
      pattern: /exec\.Command(Context)?\s*\(/,
      escalate: { pattern: /\b(userInput|input|arg|req|param)\b/i, severity: 'critical' },
      title: 'Eksekusi perintah eksternal (os/exec)',
      description:
        'Menjalankan perintah dengan data yang dipengaruhi pengguna berisiko command injection, terutama saat memakai shell wrapper (sh -c).',
      severity: 'medium',
      category: 'Keamanan',
      suggestion:
        'Panggil binary dengan argumen terpisah tanpa shell (exec.Command("git", "status")), validasi/whitelist semua input, dan hindari "sh", "-c".',
    },
    {
      id: 'go-ignored-error',
      pattern: /,\s*_\s*:=|,\s*_\s*=/,
      exclude: /range\s|,\s*ok\s*:=|for\s/,
      title: 'Error dibuang dengan blank identifier (_)',
      description:
        'Mengabaikan error dengan _ menyembunyikan kegagalan operasi I/O, network, atau parsing — bug hanya muncul sebagai data rusak di kemudian hari.',
      severity: 'medium',
      category: 'Penanganan Error',
      suggestion: 'Tangani error secara eksplisit: out, err := cmd.Output(); if err != nil { return fmt.Errorf("run: %w", err) }',
    },
    {
      id: 'go-mathrand',
      pattern: /\brand\.(Int|Intn|Int63|Float64|Uint32)\s*\(/,
      escalate: { pattern: /(token|password|secret|otp|key|session)/i, severity: 'high' },
      title: 'math/rand bukan generator kriptografis',
      description:
        'Deret math/rand dapat diprediksi dari beberapa output. Untuk keamanan (token, session id, OTP) ini fatal.',
      severity: 'medium',
      category: 'Keamanan',
      suggestion: 'Gunakan crypto/rand: rand.Read(buf) atau crypto/rand.Int(rand.Reader, max).',
    },
    {
      id: 'go-panic',
      pattern: /\bpanic\s*\(/,
      escalate: { pattern: /(userInput|request|input|handler)/i, severity: 'high' },
      title: 'panic() di jalur aplikasi',
      description:
        'panic menghentikan seluruh proses kecuali di-recover. Pada server, panic dari input eksternal mematikan semua request yang sedang berjalan.',
      severity: 'medium',
      category: 'Penanganan Error',
      suggestion: 'Kembalikan error: return fmt.Errorf("parse %q: %w", in, err). Panic hanya untuk bug programmer yang memang unrecoverable.',
    },
    {
      id: 'go-time-sleep-sync',
      pattern: /time\.Sleep\s*\(/,
      title: 'time.Sleep untuk sinkronisasi',
      description:
        'Menunggu dengan delay tetap adalah race condition yang terselubung — bisa terlalu cepat (gagal) atau terlalu lambat (boros resource).',
      severity: 'medium',
      category: 'Bug Logika',
      suggestion: 'Gunakan channel, sync.WaitGroup, context.WithTimeout, atau polling kondisi dengan ticker.',
    },
    {
      id: 'go-unlock-not-deferred',
      pattern: /\.Unlock\s*\(\s*\)/,
      exclude: /^\s*defer\b/,
      title: 'Mutex.Unlock tidak dipanggil via defer',
      description:
        'Unlock manual mudah terlewat saat ada return/panic di tengah fungsi — mengakibatkan deadlock yang sulit direproduksi.',
      severity: 'medium',
      category: 'Bug Logika',
      suggestion: 'Panggil defer mu.Unlock() tepat setelah mu.Lock() agar dilepas di semua jalur keluar.',
    },
    {
      id: 'go-empty-interface',
      pattern: /interface\{\}/,
      title: 'Penggunaan interface{} (any) yang lepas tipe',
      description:
        'interface{} menghilangkan type safety dan memindahkan bug ke runtime. Kode menjadi sulit dipahami dan direfaktor.',
      severity: 'low',
      category: 'Kualitas Kode',
      suggestion:
        'Definisikan interface spesifik atau gunakan generics (Go 1.18+): func Map[T, U any](s []T, f func(T) U) []U.',
    },
    {
      id: 'go-fmt-print-debug',
      pattern: /fmt\.Print(ln|f)?\s*\(/,
      title: 'fmt.Print* untuk logging',
      description:
        'Print ke stdout tanpa level, timestamp, dan struktur menyulitkan monitoring di produksi.',
      severity: 'low',
      category: 'Debugging',
      suggestion: 'Gunakan log/slog (Go 1.21+) atau zap/zerolog dengan level dan format terstruktur.',
    },
  ],
}

/** Extra multi-line detectors per language */
export interface DraftBug {
  title: string
  description: string
  severity: Severity
  line: number
  suggestion: string
  category: string
  /** ID aturan asal bug (opsional, diisi detector line-based untuk dukungan auto-fix). */
  ruleId?: string
}

export type MultiLineDetector = (lines: string[], code: string) => DraftBug[]

export const MULTI_LINE_DETECTORS: Record<string, MultiLineDetector[]> = {
  javascript: [
    detectSwitchFallthrough,
    detectMultilineEmptyCatch,
    detectTaintJs,
    detectUnusedVars,
    detectConstReassign,
    detectCallArity,
  ],
  java: [detectMultilineEmptyCatch],
  python: [detectPythonExceptPass, detectTaintPy],
  go: [detectGoDeferInLoop],
  php: [],
}

/* ---------------- multi-line implementations ---------------- */

function detectSwitchFallthrough(lines: string[]): DraftBug[] {
  const bugs: DraftBug[] = []
  const depth = computeBraceDepths(lines)

  let switchIdx = -1
  let switchDepth = -1
  let caseStart = -1
  let caseLine = 0

  const flush = (endIdx: number) => {
    if (caseStart === -1) return
    const body = lines.slice(caseStart, endIdx)
    const hasTerminator = body.some(l => /\b(break|return|throw|continue)\b/.test(l))
    const bodyCode = body.join('\n')
    const statements = bodyCode
      .replace(/case\s+.*:/g, '')
      .replace(/default\s*:/g, '')
      .trim()
    if (!hasTerminator && statements.length > 0) {
      bugs.push({
        title: 'Switch case tanpa break — fallthrough ke case berikutnya',
        description:
          'Blok case ini tidak memiliki break/return/throw/continue sehingga eksekusi menerus (fall through) ke case di bawahnya. Fallthrough tidak disengaja adalah sumber bug logika klasik.',
        severity: 'high',
        line: caseLine,
        category: 'Bug Logika',
        suggestion:
          'Tambahkan break di akhir blok case, atau beri komentar // fallthrough eksplisit jika memang disengaja.',
      })
    }
    caseStart = -1
  }

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i]
    if (switchIdx === -1) {
      if (/\bswitch\s*\(/.test(line)) {
        switchIdx = i
        switchDepth = depth[i]
      }
      continue
    }
    if (i === switchIdx) continue

    if (depth[i] <= switchDepth && /\}/.test(line)) {
      flush(i)
      switchIdx = -1
      continue
    }
    if (depth[i] === switchDepth + 1 && /^\s*(case\s+.*:|default\s*:)/.test(line)) {
      flush(i)
      caseStart = i + 1
      caseLine = i + 1
    }
  }
  flush(lines.length)
  return bugs
}

function detectMultilineEmptyCatch(lines: string[]): DraftBug[] {
  const bugs: DraftBug[] = []
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i]
    if (!/catch\s*\(/.test(line)) continue
    if (/\{\s*\}/.test(line)) continue // inline empty already handled by rule
    if (!/\{/.test(line)) continue
    let j = i + 1
    while (j < lines.length && lines[j].trim() === '') j++
    if (j < lines.length && lines[j].trim().startsWith('}')) {
      bugs.push({
        title: 'Blok catch kosong (error ditelan diam-diam)',
        description:
          'Exception ditangkap tetapi tidak ada penanganan apa pun. Kegagalan tidak tercatat di log dan aplikasi berlanjut dalam kondisi tidak terdefinisi.',
        severity: 'medium',
        line: i + 1,
        category: 'Penanganan Error',
        suggestion:
          'Catat error minimal dengan console.error(e) / logger.error("ctx", e), lalu putuskan strategi: retry, fallback, atau rethrow.',
      })
    }
  }
  return bugs
}

function detectPythonExceptPass(lines: string[]): DraftBug[] {
  const bugs: DraftBug[] = []
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i]
    const m = line.match(/^(\s*)except\b[^:]*:\s*$/)
    if (!m) continue
    const indent = m[1].length
    let j = i + 1
    while (j < lines.length && lines[j].trim() === '') j++
    if (j >= lines.length) continue
    const nextIndent = lines[j].length - lines[j].trimStart().length
    if (nextIndent > indent && lines[j].trim() === 'pass') {
      bugs.push({
        title: 'Exception ditangkap lalu di-pass tanpa penanganan',
        description:
          'Blok except yang hanya berisi pass menelan semua error tanpa jejak. Bug logika dan kegagalan I/O akan hilang tanpa berek dan sangat sulit didiagnosis.',
        severity: 'medium',
        line: j + 1,
        category: 'Penanganan Error',
        suggestion:
          'Catat error dengan logging.exception("konteks") dan tangkap tipe exception yang spesifik, bukan semua.',
      })
    }
  }
  return bugs
}

function detectGoDeferInLoop(lines: string[]): DraftBug[] {
  const bugs: DraftBug[] = []
  const stack: { keyword: string; line: number }[] = []

  for (let i = 0; i < lines.length; i++) {
    const stripped = stripGoStringsAndComments(lines[i])

    const closes = (stripped.match(/\}/g) || []).length
    for (let c = 0; c < closes; c++) stack.pop()

    if (/^\s*defer\b/.test(stripped)) {
      for (let s = stack.length - 1; s >= 0; s--) {
        if (stack[s].keyword === 'func') break
        if (stack[s].keyword === 'for') {
          bugs.push({
            title: 'defer di dalam loop — resource menumpuk sampai fungsi selesai',
            description:
              'Defer dieksekusi saat fungsi keluar, bukan saat iterasi selesai. Dalam loop panjang, file handle/koneksi/lock menumpuk dan dapat menyebabkan kehabisan resource.',
            severity: 'high',
            line: i + 1,
            category: 'Bug Logika',
            suggestion:
              'Bungkus iterasi dalam fungsi tersendiri agar defer dieksekusi tiap iterasi: for ... { func() { f, err := os.Open(...); defer f.Close(); ... }() }',
          })
          break
        }
      }
    }

    const opens = (stripped.match(/\{/g) || []).length
    for (let o = 0; o < opens; o++) {
      let keyword = 'block'
      if (/\bfor\b/.test(stripped)) keyword = 'for'
      else if (/\bfunc\b/.test(stripped)) keyword = 'func'
      stack.push({ keyword, line: i + 1 })
    }
  }
  return bugs
}

/* ---------------- shared helpers ---------------- */

function computeBraceDepths(lines: string[]): number[] {
  const depths: number[] = []
  let depth = 0
  for (const line of lines) {
    depths.push(depth)
    const stripped = stripGoStringsAndComments(line)
    depth += (stripped.match(/\{/g) || []).length - (stripped.match(/\}/g) || []).length
  }
  return depths
}

function stripGoStringsAndComments(line: string): string {
  return line
    .replace(/\/\/.*$/, '')
    .replace(/"(?:[^"\\]|\\.)*"/g, '""')
    .replace(/`[^`]*`/g, '``')
    .replace(/'(?:[^'\\]|\\.)'/g, "''")
}
