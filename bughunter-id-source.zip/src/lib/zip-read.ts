import { inflateRawSync } from 'node:zlib'
import type { WorkspaceFileInput } from './types'
import { MAX_FILES, MAX_FILE_CHARS, MAX_TOTAL_CHARS } from './workspace-validate'

/**
 * ============================================================
 *  PEMBACA ZIP MINIMAL (tanpa dependensi eksternal)
 * ============================================================
 * Mem-parse arsip ZIP standar dari buffer: membaca End of Central
 * Directory → Central Directory → mengekstrak tiap entri.
 * Mendukung metode kompresi 0 (store) dan 8 (deflate) — dua metode
 * yang dipakai hampir semua alat pengarsip (Windows Explorer, unzip,
 * macOS Archive Utility, `zip` CLI).
 *
 * Hanya melayani berkas TEKS untuk workspace: biner, folder, dan
 * sampah sistem di-skip dengan alasan tercatat.
 * ============================================================
 */

export interface ZipReadResult {
  files: WorkspaceFileInput[]
  info: {
    totalEntries: number
    accepted: number
    skippedBinary: number
    skippedTooBig: number
    skippedJunk: number
    skippedOverLimit: number
    rootStripped: string | null
  }
}

const MAX_ZIP_BYTES = 6 * 1_000_000 // ZIP maksimal 6 MB (terkompresi)
const MAX_ENTRIES = 500

/** Folder & berkas sampah yang tidak perlu dianalisis. */
function isJunkPath(name: string): boolean {
  const lower = name.toLowerCase()
  return (
    lower.startsWith('__macosx/') ||
    lower.includes('/__macosx/') ||
    lower.includes('/.git/') ||
    lower.startsWith('.git/') ||
    lower.includes('/node_modules/') ||
    lower.startsWith('node_modules/') ||
    lower.endsWith('/.ds_store') ||
    lower === '.ds_store' ||
    lower.endsWith('/thumbs.db') ||
    lower === 'thumbs.db' ||
    lower.includes('/.idea/') ||
    lower.startsWith('.idea/') ||
    lower.includes('/.vscode/') ||
    lower.startsWith('.vscode/')
  )
}

interface RawEntry {
  name: string
  method: number
  compressedSize: number
  size: number
  localOffset: number
}

function findEocd(buf: Buffer): number {
  // EOCD minimal 22 byte; komentar arsip bisa hingga 65535 byte.
  const start = Math.max(0, buf.length - 22 - 65535)
  for (let i = buf.length - 22; i >= start; i--) {
    if (buf.readUInt32LE(i) === 0x06054b50) return i
  }
  return -1
}

function listEntries(buf: Buffer, eocd: number): RawEntry[] {
  const count = buf.readUInt16LE(eocd + 10)
  const cdOffset = buf.readUInt32LE(eocd + 16)
  const entries: RawEntry[] = []
  let p = cdOffset
  for (let i = 0; i < count && p + 46 <= buf.length; i++) {
    if (buf.readUInt32LE(p) !== 0x02014b50) break // struktur rusak — berhenti aman
    const method = buf.readUInt16LE(p + 10)
    const compressedSize = buf.readUInt32LE(p + 20)
    const size = buf.readUInt32LE(p + 24)
    const nameLen = buf.readUInt16LE(p + 28)
    const extraLen = buf.readUInt16LE(p + 30)
    const commentLen = buf.readUInt16LE(p + 32)
    const localOffset = buf.readUInt32LE(p + 42)
    const name = buf.slice(p + 46, p + 46 + nameLen).toString('utf8')
    entries.push({ name, method, compressedSize, size, localOffset })
    p += 46 + nameLen + extraLen + commentLen
  }
  return entries
}

function extractEntry(buf: Buffer, e: RawEntry): Buffer | null {
  if (e.localOffset + 30 > buf.length) return null
  if (buf.readUInt32LE(e.localOffset) !== 0x04034b50) return null
  const nameLen = buf.readUInt16LE(e.localOffset + 26)
  const extraLen = buf.readUInt16LE(e.localOffset + 28)
  const dataStart = e.localOffset + 30 + nameLen + extraLen
  const dataEnd = dataStart + e.compressedSize
  if (dataEnd > buf.length) return null
  const data = buf.slice(dataStart, dataEnd)
  try {
    if (e.method === 0) return data
    if (e.method === 8) return inflateRawSync(data)
    return null
  } catch {
    return null
  }
}

/** Dekode sebagai teks UTF-8 ketat; return null bila biner. */
function decodeText(data: Buffer): string | null {
  if (data.length === 0) return ''
  if (data.includes(0)) return null
  try {
    return new TextDecoder('utf-8', { fatal: true }).decode(data)
  } catch {
    return null
  }
}

/** Buang satu folder akar umum (mis. semua entri di dalam "proyekku/"). */
function stripCommonRoot(names: string[]): string | null {
  if (names.length === 0) return null
  const first = names[0].split('/')[0]
  if (!first || names.length < 2) return null
  for (const n of names) {
    const seg = n.split('/')[0]
    if (seg !== first) return null
  }
  return first
}

/**
 * Baca ZIP dan ambil seluruh berkas teks yang layak dianalisis.
 * Batas: MAX_ENTRIES entri, MAX_FILES berkas, MAX_FILE_CHARS/berkas,
 * MAX_TOTAL_CHARS total — sama dengan batas workspace.
 */
export function readZipWorkspace(buf: Buffer): ZipReadResult {
  const info: ZipReadResult['info'] = {
    totalEntries: 0,
    accepted: 0,
    skippedBinary: 0,
    skippedTooBig: 0,
    skippedJunk: 0,
    skippedOverLimit: 0,
    rootStripped: null,
  }
  const files: WorkspaceFileInput[] = []
  let totalChars = 0

  if (buf.length > MAX_ZIP_BYTES) {
    throw new Error(`Ukuran ZIP melebihi ${(MAX_ZIP_BYTES / 1_000_000).toFixed(0)} MB.`)
  }

  const eocd = findEocd(buf)
  if (eocd === -1) {
    throw new Error('Berkas bukan arsip ZIP yang valid (signature tidak ditemukan).')
  }

  const entries = listEntries(buf, eocd)
  info.totalEntries = entries.length
  if (entries.length > MAX_ENTRIES) {
    throw new Error(`ZIP berisi terlalu banyak entri (maksimal ${MAX_ENTRIES}).`)
  }

  // Tentukan folder akar umum untuk dibuang (agar jalur relatif bersih)
  const realNames = entries.filter(e => !e.name.endsWith('/') && !isJunkPath(e.name)).map(e => e.name)
  const root = stripCommonRoot(realNames)
  info.rootStripped = root

  let usedNames = new Set<string>()
  for (const e of entries) {
    if (e.name.endsWith('/')) continue // folder
    if (isJunkPath(e.name)) {
      info.skippedJunk++
      continue
    }
    let name = e.name.replace(/\\/g, '/')
    if (root && name.startsWith(`${root}/`)) name = name.slice(root.length + 1)
    if (!name) continue

    if (files.length >= MAX_FILES) {
      info.skippedOverLimit++
      continue
    }
    if (e.size > MAX_FILE_CHARS) {
      info.skippedTooBig++
      continue
    }

    const data = extractEntry(buf, e)
    if (!data) {
      info.skippedBinary++
      continue
    }
    const text = decodeText(data)
    if (text === null) {
      info.skippedBinary++
      continue
    }

    // dedupe nama (zip bisa berisi entri ganda)
    let finalName = name
    let n = 2
    while (usedNames.has(finalName)) {
      const dot = finalName.lastIndexOf('.')
      finalName = dot > 0 ? `${finalName.slice(0, dot)}-${n}${finalName.slice(dot)}` : `${finalName}-${n}`
      n++
    }
    usedNames.add(finalName)

    if (totalChars + text.length > MAX_TOTAL_CHARS) {
      info.skippedOverLimit++
      continue
    }
    files.push({ name: finalName, code: text })
    totalChars += text.length
    info.accepted++
  }

  usedNames = new Set()
  return { files, info }
}

/** Versi ringan: cek apakah buffer adalah ZIP (magic PK). Dipakai untuk validasi cepat. */
export function isZipBuffer(buf: Buffer): boolean {
  return buf.length > 3 && buf[0] === 0x50 && buf[1] === 0x4b
}
