'use client'
/* Koneksi socket.io-browser ke layanan log real-time (via gateway XTransformPort).
 * Satu koneksi per halaman; room per browser (tersimpan di localStorage).
 * Kegagalan koneksi = kembali ke simulasi terminal di sisi klien. */

import { io, type Socket } from 'socket.io-client'

export interface AgentSocketEvent {
  kind: 'open' | 'line' | 'status'
  term: string
  title?: string
  subtitle?: string
  text?: string
  tone?: 'cmd' | 'ok' | 'warn' | 'err' | 'info' | 'dim'
  status?: 'running' | 'done' | 'error'
}

let socket: Socket | null = null
let statusListener: ((live: boolean) => void) | null = null
let eventListener: ((e: AgentSocketEvent) => void) | null = null

/** Room per browser — semua tab berbagi room yang sama. */
export function agentRoom(): string {
  if (typeof window === 'undefined') return 'room-server-only'
  const KEY = 'bughunter-agent-room'
  let r = window.localStorage.getItem(KEY)
  if (!r || !/^[A-Za-z0-9_-]{4,64}$/.test(r)) {
    r = `room-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`
    window.localStorage.setItem(KEY, r)
  }
  return r
}

export function isSocketLive(): boolean {
  return Boolean(socket?.connected)
}

/**
 * Sambungkan (sekali) lalu pasang listener. Return socket aktif atau null.
 * Memanggil lagi hanya mengganti listener.
 */
export function connectAgentSocket(
  onEvent: (e: AgentSocketEvent) => void,
  onStatus?: (live: boolean) => void,
): Socket | null {
  eventListener = onEvent
  if (onStatus) statusListener = onStatus
  if (socket) return socket
  if (typeof window === 'undefined') return null
  try {
    socket = io('/?XTransformPort=3003', {
      path: '/',
      transports: ['websocket', 'polling'],
      reconnectionAttempts: 8,
      reconnectionDelay: 1500,
      timeout: 6000,
    })
    socket.on('connect', () => {
      socket?.emit('join', agentRoom())
      statusListener?.(true)
    })
    socket.on('disconnect', () => statusListener?.(false))
    socket.on('connect_error', () => statusListener?.(false))
    socket.on('agent-event', (raw: unknown) => {
      const e = sanitize(raw)
      if (e && eventListener) eventListener(e)
    })
  } catch {
    socket = null
    return null
  }
  return socket
}

function sanitize(raw: unknown): AgentSocketEvent | null {
  if (!raw || typeof raw !== 'object') return null
  const e = raw as Record<string, unknown>
  const kind = e.kind
  const term = typeof e.term === 'string' ? e.term : ''
  if ((kind !== 'open' && kind !== 'line' && kind !== 'status') || !term) return null
  const out: AgentSocketEvent = { kind, term }
  if (typeof e.title === 'string') out.title = e.title
  if (typeof e.subtitle === 'string') out.subtitle = e.subtitle
  if (typeof e.text === 'string') out.text = e.text
  if (typeof e.tone === 'string') out.tone = e.tone as AgentSocketEvent['tone']
  if (e.status === 'running' || e.status === 'done' || e.status === 'error') out.status = e.status
  return out
}
