'use client'
/* BugHunter ID — UI agen 3 kolom: Chat | Workspace | Terminal.
 * Kolom 1: chat (unggah file, notifikasi proses, opsi persetujuan, AI GLM).
 * Kolom 2: workspace (berkas masukan + unduh hasil kerja).
 * Kolom 3: terminal (jumlah menyesuaikan kompleksitas bug; lintas file = paralel).
 * Lebar kolom bisa diperlebar/diperkecil lewat pegangan di antar kolom.
 * Sesi kerja tersimpan otomatis ke database dan ditawarkan untuk dilanjutkan. */

import { useEffect } from 'react'
import { Bug as BugIcon } from 'lucide-react'
import { Workbench } from '@/components/agent/workbench'
import { RulesSettings } from '@/components/bug-detector/rules-settings'
import { TrendDialog } from '@/components/agent/trend-dialog'
import { AccountButton } from '@/components/agent/account-button'
import { useAgentStore, PHASE_LABEL } from '@/lib/agent-store'
import { cn } from '@/lib/utils'

export default function BugHunterPage() {
  const phase = useAgentStore(s => s.phase)
  const busy = useAgentStore(s => s.busy)
  const files = useAgentStore(s => s.files)
  const scan = useAgentStore(s => s.scan)
  const terminals = useAgentStore(s => s.terminals)
  const initRestore = useAgentStore(s => s.initRestore)
  const initLive = useAgentStore(s => s.initLive)
  const socketLive = useAgentStore(s => s.socketLive)
  const running = terminals.filter(t => t.status === 'running').length

  useEffect(() => {
    // sekali per halaman dibuka: tawarkan lanjutkan sesi terakhir lewat opsi chat
    void initRestore()
  }, [initRestore])

  useEffect(() => {
    // sambungkan log terminal real-time dari server (fallback = simulasi lokal)
    initLive()
  }, [initLive])

  return (
    <div className="flex h-screen flex-col overflow-hidden bg-[#0d1117] text-[#e6edf3]">
      {/* header */}
      <header className="flex h-12 shrink-0 items-center gap-2.5 border-b border-[#30363d] bg-[#161b22] px-3 sm:px-4">
        <div className="flex h-7 w-7 items-center justify-center rounded-md border border-[#3fb9505c] bg-[#3fb9501a]">
          <BugIcon className="h-4 w-4 text-[#3fb950]" />
        </div>
        <h1 className="text-sm font-bold tracking-tight">
          BugHunter <span className="text-[#3fb950]">ID</span>
        </h1>
        <span className="hidden text-[11px] text-[#8b949e] lg:inline">
          Agen deteksi &amp; perbaikan bug lintas file
        </span>
        <div className="ml-auto flex items-center gap-2">
          <span
            className={cn(
              'hidden items-center gap-1.5 rounded-full border px-2 py-0.5 text-[10.5px] sm:inline-flex',
              socketLive
                ? 'border-[#3fb9505c] bg-[#3fb9501a] text-[#3fb950]'
                : 'border-[#30363d] bg-[#161b22] text-[#8b949e]',
            )}
            title={socketLive ? 'Log terminal real-time dari server aktif' : 'Log real-time tidak tersambung — memakai simulasi lokal'}
          >
            <span className={cn('h-1.5 w-1.5 rounded-full', socketLive ? 'animate-pulse bg-[#3fb950]' : 'bg-[#484f58]')} />
            {socketLive ? 'LIVE' : 'lokal'}
          </span>
          <span
            className={cn(
              'inline-flex items-center gap-1.5 rounded-full border px-2 py-0.5 text-[10.5px]',
              busy
                ? 'border-[#e3b34166] bg-[#e3b3411a] text-[#e3b341]'
                : 'border-[#2ea04366] bg-[#23863626] text-[#3fb950]',
            )}
          >
            <span className={cn('h-1.5 w-1.5 rounded-full', busy ? 'animate-pulse bg-[#e3b341]' : 'bg-[#3fb950]')} />
            {PHASE_LABEL[phase]}
          </span>
          <RulesSettings />
          <TrendDialog />
          <AccountButton />
        </div>
      </header>

      {/* 3 kolom utama */}
      <main className="min-h-0 flex-1">
        <Workbench />
      </main>

      {/* bilah status */}
      <footer className="flex h-7 shrink-0 items-center justify-between gap-3 border-t border-[#30363d] bg-[#161b22] px-3 text-[10.5px] text-[#8b949e] sm:px-4">
        <span className="truncate">
          {files.length} berkas · {scan ? `${scan.bugCount} temuan · skor ${scan.healthScore}/100` : 'belum dipindai'}
        </span>
        <span className="hidden shrink-0 sm:inline">
          Terminal: {terminals.length} sesi{running > 0 ? ` · ${running} aktif` : ''} · v0.12.3
        </span>
        <a
          href="/bughunter-id-source.zip"
          download="bughunter-id-source.zip"
          className="shrink-0 transition-colors hover:text-[#3fb950]"
        >
          ⬇ Source (.zip)
        </a>
      </footer>
    </div>
  )
}
