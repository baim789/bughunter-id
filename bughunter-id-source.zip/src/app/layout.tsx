import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import { AppSessionProvider } from "@/components/auth/session-provider";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "BugHunter ID — Pendeteksi Bug Kode Multi-Bahasa",
  description:
    "Aplikasi pendeteksi bug source code untuk JavaScript/TypeScript, Python, Java, PHP, dan Go. Mesin deteksi rule-based 60+ aturan ditambah analisis mendalam GLM AI, lengkap dengan saran perbaikan dan riwayat pemindaian.",
  keywords: [
    "bug detector",
    "code analysis",
    "pendeteksi bug",
    "static analysis",
    "code review",
    "security scanner",
  ],
  authors: [{ name: "BugHunter ID" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <AppSessionProvider>{children}</AppSessionProvider>
        <Toaster />
      </body>
    </html>
  );
}
