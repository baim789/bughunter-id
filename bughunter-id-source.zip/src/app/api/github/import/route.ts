import { NextRequest, NextResponse } from 'next/server'
import { rateLimit, getClientIp } from '@/lib/rate-limit'
import { readTarGzWorkspace } from '@/lib/tar-read'
import { sanitizeFileName } from '@/lib/detector/import-scan'

const RATE_LIMIT = Number(process.env.RATE_LIMIT_GITHUB_PER_MIN) || 5
const MAX_TARBALL_BYTES = 12 * 1_000_000
const FETCH_TIMEOUT_MS = 30_000

/**
 * POST /api/github/import
 * Body: { url: "https://github.com/owner/repo[/tree/branch]" }
 * Mengunduh tarball repositori publik dari codeload.github.com,
 * mengekstrak berkas teks (batas & penyaringan sama dengan ZIP),
 * lalu mengembalikannya sebagai daftar file workspace.
 */
export async function POST(request: NextRequest) {
  try {
    const rl = rateLimit(`gh-import:${getClientIp(request)}`, RATE_LIMIT)
    if (!rl.ok) {
      return NextResponse.json(
        { error: `Terlalu banyak impor. Coba lagi dalam ${rl.retryAfter} detik.` },
        { status: 429, headers: { 'retry-after': String(rl.retryAfter) } },
      )
    }

    const body = await request.json().catch(() => ({}))
    const rawUrl = typeof body.url === 'string' ? body.url.trim() : ''
    if (!rawUrl) {
      return NextResponse.json(
        { error: 'Sertakan url repositori GitHub, mis. https://github.com/owner/repo.' },
        { status: 400 },
      )
    }

    const parsed = parseGithubUrl(rawUrl)
    if (!parsed) {
      return NextResponse.json(
        { error: 'Alamat GitHub tidak dikenali. Gunakan format https://github.com/pemilik/repo (boleh /tree/branch).' },
        { status: 400 },
      )
    }
    const { owner, repo, branch } = parsed

    const tarballUrl =
      branch === 'HEAD'
        ? `https://codeload.github.com/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/tar.gz/HEAD`
        : `https://codeload.github.com/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/tar.gz/refs/heads/${encodeURIComponent(branch)}`
    let res: Response
    try {
      res = await fetch(tarballUrl, {
        signal: AbortSignal.timeout(FETCH_TIMEOUT_MS),
        headers: { 'user-agent': 'BugHunter-ID/0.7 (+code-analysis)' },
        redirect: 'follow',
      })
    } catch {
      return NextResponse.json(
        { error: 'Gagal terhubung ke GitHub (jaringan/timeout). Coba lagi.' },
        { status: 502 },
      )
    }

    if (res.status === 404) {
      return NextResponse.json(
        { error: `Repositori "${owner}/${repo}" (branch "${branch}") tidak ditemukan. Repositori privat tidak bisa diimpor — periksa alamat & visibilitasnya.` },
        { status: 404 },
      )
    }
    if (!res.ok) {
      return NextResponse.json(
        { error: `GitHub menjawab ${res.status} saat mengambil arsip. Coba lagi nanti.` },
        { status: 502 },
      )
    }

    const declaredLen = Number(res.headers.get('content-length') ?? '0')
    if (Number.isFinite(declaredLen) && declaredLen > MAX_TARBALL_BYTES) {
      return NextResponse.json(
        { error: `Repositori terlalu besar untuk diimpor (arsip > ${MAX_TARBALL_BYTES / 1_000_000} MB). Unggah bagian berkasnya lewat ZIP.` },
        { status: 413 },
      )
    }
    const gz = Buffer.from(await res.arrayBuffer())
    if (gz.length > MAX_TARBALL_BYTES) {
      return NextResponse.json(
        { error: `Repositori terlalu besar untuk diimpor (arsip > ${MAX_TARBALL_BYTES / 1_000_000} MB). Unggah bagian berkasnya lewat ZIP.` },
        { status: 413 },
      )
    }

    let result
    try {
      result = readTarGzWorkspace(gz)
    } catch (err) {
      return NextResponse.json(
        { error: err instanceof Error ? err.message : 'Arsip repositori tidak dapat dibaca.' },
        { status: 400 },
      )
    }

    // sanitasi nama berlapis (tar sudah dibersihkan, lapisan kedua untuk keamanan)
    const files = result.files
      .map(f => ({ name: sanitizeFileName(f.name), code: f.code }))
      .filter((f): f is { name: string; code: string } => f.name !== null)

    if (files.length === 0) {
      return NextResponse.json(
        {
          error: 'Tidak ada berkas teks yang bisa dimuat dari repositori (mungkin semua biner atau melebihi batas ukuran).',
          info: result.info,
        },
        { status: 400 },
      )
    }

    return NextResponse.json({
      ok: true,
      files,
      info: {
        repo: `${owner}/${repo}`,
        branch,
        ...result.info,
        truncated: result.info.skippedOverLimit > 0,
      },
    })
  } catch (error) {
    console.error('[github/import] error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan internal saat mengimpor repositori. Coba lagi.' },
      { status: 500 },
    )
  }
}

/** Parse bentuk URL github: owner/repo, github.com/owner/repo, .../tree/branch, boleh .git. */
function parseGithubUrl(raw: string): { owner: string; repo: string; branch: string } | null {
  let t = raw.trim().replace(/\.git$/i, '')
  t = t.replace(/^https?:\/\//i, '').replace(/^www\./i, '')
  // buang fragmen/query
  t = t.split(/[?#]/)[0]
  // tanpa awalan github.com → owner TIDAK boleh mengandung titik (cegah example.com/foo lolos)
  const bare = /^github\.com\//.test(t)
  const m = /^(?:github\.com\/)?([\w-]+)\/([\w.-]+)(?:\/tree\/(.+))?$/.exec(t)
  if (!m) return null
  const owner = m[1]
  const repo = m[2]
  if (!/^\w[\w-]*$/.test(owner) || !/^[\w.-]+$/.test(repo)) return null
  if (!bare && owner.includes('.')) return null
  if (owner.toLowerCase() === 'orgs' || owner.toLowerCase() === 'topics') return null
  // branch bisa mengandung "/" — ambil seluruh sisa
  const branch = (m[3] ?? 'HEAD').split('/').filter(Boolean).join('/')
  return { owner, repo, branch: branch || 'HEAD' }
}
