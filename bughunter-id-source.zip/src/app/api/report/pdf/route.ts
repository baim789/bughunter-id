import { NextRequest, NextResponse } from 'next/server'
import { rateLimit, getClientIp } from '@/lib/rate-limit'
import { buildPdfReport, type PdfReportPayload, type PdfFileReport } from '@/lib/pdf-report'
import type { Severity } from '@/lib/types'

const RATE_LIMIT = Number(process.env.RATE_LIMIT_REPORT_PER_MIN) || 30
const SEVERITIES: Severity[] = ['critical', 'high', 'medium', 'low']

/**
 * POST /api/report/pdf
 * Body: payload laporan (ringkasan + daftar berkas + temuan).
 * Return: application/pdf sebagai unduhan. Tidak menyimpan apa pun.
 */
export async function POST(request: NextRequest) {
  try {
    const contentType = (request.headers.get('content-type') ?? '').toLowerCase()
    if (!contentType.includes('application/json')) {
      return NextResponse.json({ error: 'Content-Type harus application/json.' }, { status: 415 })
    }

    const rl = rateLimit(`report:${getClientIp(request)}`, RATE_LIMIT)
    if (!rl.ok) {
      return NextResponse.json(
        { error: `Terlalu banyak permintaan. Coba lagi dalam ${rl.retryAfter} detik.` },
        { status: 429, headers: { 'retry-after': String(rl.retryAfter) } },
      )
    }

    const body = (await request.json().catch(() => null)) as PdfReportPayload | null
    if (!body || !body.summary || !Array.isArray(body.files)) {
      return NextResponse.json(
        { error: 'Payload laporan tidak valid: butuh summary + files.' },
        { status: 400 },
      )
    }
    if (body.files.length > 60) {
      return NextResponse.json({ error: 'Maksimal 60 berkas per laporan.' }, { status: 400 })
    }

    const s = body.summary
    const num = (v: unknown, d = 0) => (typeof v === 'number' && Number.isFinite(v) ? Math.max(0, Math.round(v)) : d)
    const clampStr = (v: unknown, max: number) =>
      typeof v === 'string' ? v.slice(0, max) : ''

    const files: PdfFileReport[] = body.files.slice(0, 60).map(f => ({
      name: clampStr(f?.name, 160) || '(tanpa nama)',
      language: clampStr(f?.language, 40) || 'tidak-dikenal',
      healthScore: Math.min(100, num(f?.healthScore, 100)),
      bugCount: num(f?.bugCount, Array.isArray(f?.bugs) ? f.bugs.length : 0),
      bugs: (Array.isArray(f?.bugs) ? f.bugs : []).slice(0, 300).map(b => ({
        severity: SEVERITIES.includes(b?.severity as Severity) ? (b.severity as Severity) : 'low',
        line: Math.max(1, num(b?.line, 1)),
        category: clampStr(b?.category, 60) || 'Umum',
        title: clampStr(b?.title, 200) || 'Temuan',
        description: clampStr(b?.description, 500),
        suggestion: clampStr(b?.suggestion, 500),
        crossFile: Boolean(b?.crossFile),
      })),
    }))

    const payload: PdfReportPayload = {
      kind: body.kind === 'workspace' ? 'workspace' : 'single',
      title: clampStr(body.title, 160),
      summary: {
        healthScore: Math.min(100, num(s.healthScore, 100)),
        bugCount: num(s.bugCount),
        criticalCount: num(s.criticalCount),
        highCount: num(s.highCount),
        mediumCount: num(s.mediumCount),
        lowCount: num(s.lowCount),
        crossFileCount: num(s.crossFileCount),
        depCount: num(s.depCount),
        fileCount: num(s.fileCount, files.length),
        totalLines: num(s.totalLines),
      },
      files,
    }

    const pdf = buildPdfReport(payload)
    const now = new Date()
    const stamp = `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}-${String(now.getHours()).padStart(2, '0')}${String(now.getMinutes()).padStart(2, '0')}`
    const filename = `bughunter-laporan-${payload.kind}-${stamp}.pdf`

    return new NextResponse(new Uint8Array(pdf), {
      status: 200,
      headers: {
        'content-type': 'application/pdf',
        'content-disposition': `attachment; filename="${filename}"`,
        'cache-control': 'no-store',
      },
    })
  } catch (error) {
    console.error('[report/pdf] error:', error)
    return NextResponse.json(
      { error: 'Gagal membuat laporan PDF. Coba lagi.' },
      { status: 500 },
    )
  }
}
