import { NextResponse } from "next/server";

// Health endpoint sederhana untuk pemantauan / uji jarak-jauh.
export async function GET() {
  return NextResponse.json({
    ok: true,
    service: "bughunter-id",
    time: new Date().toISOString(),
  });
}
