import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'

/** Daftar ringkas sesi agen (terbaru dulu) — tanpa payload besar.
 *  Saat masuk: hanya sesi milik akun. Anonim: hanya sesi tanpa pemilik. */
export async function GET(request: NextRequest) {
  try {
    const limitRaw = request.nextUrl.searchParams.get('limit') ?? '20'
    const limit = Math.min(Math.max(Number.parseInt(limitRaw, 10) || 20, 1), 50)

    const authSession = await getServerSession(authOptions)
    const userId = (authSession?.user as { id?: string } | undefined)?.id ?? null

    const rows = await db.agentSession.findMany({
      where: { userId: userId ?? null },
      orderBy: { updatedAt: 'desc' },
      take: limit,
      select: {
        id: true,
        title: true,
        messageCount: true,
        fileCount: true,
        bugCount: true,
        healthScore: true,
        createdAt: true,
        updatedAt: true,
      },
    })

    return NextResponse.json({
      ok: true,
      sessions: rows.map(r => ({
        id: r.id,
        title: r.title,
        messageCount: r.messageCount,
        fileCount: r.fileCount,
        bugCount: r.bugCount,
        healthScore: r.healthScore,
        createdAt: r.createdAt,
        updatedAt: r.updatedAt,
      })),
    })
  } catch (error) {
    console.error('[agent-sessions] list error:', error)
    return NextResponse.json({ error: 'Gagal memuat daftar sesi.' }, { status: 500 })
  }
}
