import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'
import { rateLimit, getClientIp } from '@/lib/rate-limit'
import { isJsonRequest, validateWorkspaceFiles } from '@/lib/workspace-validate'
import type { WorkspaceScanResult } from '@/lib/types'

export const maxDuration = 120

const AI_TIMEOUT_MS = 90_000
const AI_INIT_TIMEOUT_MS = 30_000
const MAX_MESSAGE_CHARS = 4_000
/** Kode yang dikutip per file ke prompt AI (hemat token, tetap memadai untuk konteks). */
const MAX_CODE_PER_FILE = 6_000
/** Maksimal temuan yang dikutip ke prompt. */
const MAX_FINDINGS_IN_PROMPT = 40
const RATE_LIMIT_AGENT_CHAT = Number(process.env.RATE_LIMIT_AGENT_CHAT_PER_MIN) || 10

interface FindingBrief {
  file: string
  line: number
  severity: string
  category: string
  title: string
  suggestion: string
}

function collectFindings(scan: WorkspaceScanResult | null): FindingBrief[] {
  if (!scan) return []
  const out: FindingBrief[] = []
  for (const f of scan.files) {
    for (const b of f.bugs) {
      out.push({
        file: f.name,
        line: b.line,
        severity: b.severity,
        category: b.category,
        title: b.title,
        suggestion: b.suggestion,
      })
    }
  }
  // urutkan: terberat dulu (critical -> low) lalu nama file
  const rank: Record<string, number> = { critical: 0, high: 1, medium: 2, low: 3 }
  out.sort((a, b) => (rank[a.severity] ?? 9) - (rank[b.severity] ?? 9) || a.file.localeCompare(b.file))
  return out.slice(0, MAX_FINDINGS_IN_PROMPT)
}

function buildSystemPrompt(): string {
  return [
    'Kamu adalah asisten BugHunter ID — agen pendeteksi & perbaikan bug di aplikasi web.',
    'Kamu berada di kolom chat aplikasi; pengguna berbahasa Indonesia.',
    'Kamu menerima: pertanyaan pengguna, daftar file workspace, hasil pemindaian terakhir (skor + temuan), dan kutipan kode bila relevan.',
    '',
    'Aturan jawaban (WAJIB):',
    '- Balas dalam Bahasa Indonesia yang jelas dan padat (maksimal ~250 kata kecuali diminta detail).',
    '- Gunakan teks biasa + poin-poin; JANGAN pakai tabel atau heading markdown berat.',
    '- Saat menjelaskan temuan, sebut nama file dan nomor baris persis seperti di konteks.',
    '- JANGAN mengarang temuan yang tidak ada di konteks; jika konteks kosong, katakan belum ada data dan sarankan perintah "pindai".',
    '- Kamu TIDAK bisa mengeksekusi apa pun sendiri. Untuk tindakan, sarankan perintah chat: "pindai", "perbaiki", "unduh zip", "laporan pdf", atau tombol solusi yang muncul di chat.',
    '- Jawab pertanyaan umum pemrograman tetap terkait konteks pengguna bila ada.',
  ].join('\n')
}

function buildContextPrompt(
  message: string,
  files: { name: string; code: string }[],
  scan: WorkspaceScanResult | null,
): string {
  const parts: string[] = []

  parts.push('== KONTEKS WORKSPACE ==')
  if (files.length === 0) {
    parts.push('(workspace kosong — belum ada file diunggah)')
  } else {
    parts.push(`File (${files.length}): ${files.map(f => f.name).join(', ')}`)
  }
  parts.push('')

  parts.push('== HASIL PEMINDAIAN TERAKHIR ==')
  if (!scan) {
    parts.push('(belum ada pemindaian — sarankan perintah "pindai" bila relevan)')
  } else {
    parts.push(
      `Skor kesehatan ${scan.healthScore}/100 · ${scan.bugCount} temuan (${scan.crossFileCount} lintas file) di ${scan.fileCount} file.`,
    )
    const findings = collectFindings(scan)
    if (findings.length > 0) {
      parts.push('Temuan teratas (severity tertinggi dulu):')
      for (const f of findings) {
        parts.push(`- [${f.severity.toUpperCase()}] ${f.file}:${f.line} (${f.category}) ${f.title} — saran: ${f.suggestion}`)
      }
    } else {
      parts.push('Tidak ada temuan — workspace bersih.')
    }
  }
  parts.push('')

  // Kutipan kode: hanya file yang DISINGGUNG namanya di pesan (maks 2 file),
  // agar jawaban AI spesifik tanpa meledakkan ukuran prompt.
  const mentioned = files.filter(f => {
    const base = f.name.split('/').pop()?.toLowerCase() ?? ''
    return base.length > 0 && message.toLowerCase().includes(base)
  })
  if (mentioned.length > 0) {
    parts.push('== KUTIPAN KODE (file yang kamu sebut) ==')
    for (const f of mentioned.slice(0, 2)) {
      parts.push(`--- ${f.name} ---`)
      parts.push(f.code.length > MAX_CODE_PER_FILE ? `${f.code.slice(0, MAX_CODE_PER_FILE)}\n…(dipotong)` : f.code)
    }
    parts.push('')
  }

  parts.push('== PERTANYAAN PENGGUNA ==')
  parts.push(message)
  return parts.join('\n')
}

async function askGlm(
  message: string,
  files: { name: string; code: string }[],
  scan: WorkspaceScanResult | null,
): Promise<string> {
  const zai = await Promise.race([
    ZAI.create(),
    new Promise<never>((_, reject) =>
      setTimeout(() => reject(new Error('Inisialisasi AI melewati batas waktu')), AI_INIT_TIMEOUT_MS),
    ),
  ])
  const completion = (await Promise.race([
    zai.chat.completions.create({
      messages: [
        { role: 'system', content: buildSystemPrompt() },
        { role: 'user', content: buildContextPrompt(message, files, scan) },
      ],
      temperature: 0.4,
    }),
    new Promise<never>((_, reject) =>
      setTimeout(() => reject(new Error('AI chat timeout')), AI_TIMEOUT_MS),
    ),
  ])) as { choices?: Array<{ message?: { content?: string } }> }

  const reply = completion.choices?.[0]?.message?.content?.trim() ?? ''
  if (!reply) throw new Error('AI memberi jawaban kosong')
  return reply.slice(0, 6_000)
}

export async function POST(request: NextRequest) {
  try {
    if (!isJsonRequest(request.headers.get('content-type'))) {
      return NextResponse.json({ error: 'Content-Type harus application/json.' }, { status: 415 })
    }

    const rl = rateLimit(`agent-chat:${getClientIp(request)}`, RATE_LIMIT_AGENT_CHAT)
    if (!rl.ok) {
      return NextResponse.json(
        { error: `Terlalu banyak pertanyaan AI. Coba lagi dalam ${rl.retryAfter} detik.` },
        { status: 429, headers: { 'retry-after': String(rl.retryAfter) } },
      )
    }

    const body = await request.json().catch(() => ({}))
    const message = typeof body.message === 'string' ? body.message.trim() : ''
    if (!message) {
      return NextResponse.json({ error: 'Pertanyaan tidak boleh kosong.' }, { status: 400 })
    }
    if (message.length > MAX_MESSAGE_CHARS) {
      return NextResponse.json(
        { error: `Pertanyaan terlalu panjang (maksimal ${MAX_MESSAGE_CHARS} karakter).` },
        { status: 400 },
      )
    }

    // File opsional (boleh kosong → tanya jawab umum). Validasi sama dengan workspace.
    let files: { name: string; code: string }[] = []
    if (Array.isArray(body.files) && body.files.length > 0) {
      const v = validateWorkspaceFiles(body)
      if (!v.ok) return NextResponse.json({ error: v.error }, { status: v.status })
      files = v.files
    }

    const scan: WorkspaceScanResult | null =
      body.scan && typeof body.scan === 'object' && Array.isArray((body.scan as WorkspaceScanResult).files)
        ? (body.scan as WorkspaceScanResult)
        : null

    const reply = await askGlm(message, files, scan)
    return NextResponse.json({ ok: true, reply })
  } catch (error) {
    // Detail error (kredensial/jaringan/SDK) hanya ke log server — tidak bocor ke klien.
    console.error('[agent-chat] AI error:', error)
    return NextResponse.json(
      { error: 'Layanan AI sedang tidak tersedia. Coba lagi sebentar, atau gunakan perintah "pindai" / "perbaiki" yang berjalan lokal.' },
      { status: 502 },
    )
  }
}
