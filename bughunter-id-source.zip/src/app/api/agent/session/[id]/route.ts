import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import type { WorkspaceFileInput, WorkspaceScanResult } from '@/lib/types'

const ID_RE = /^[A-Za-z0-9_-]{1,64}$/

/** Pastikan pemakai berhak membaca sesi: anonim hanya sesi tanpa pemilik. */
async function guardAccess(id: string) {
  const row = await db.agentSession.findUnique({ where: { id }, select: { userId: true } })
  if (!row) return { status: 404 as const }
  const authSession = await getServerSession(authOptions)
  const userId = (authSession?.user as { id?: string } | undefined)?.id ?? null
  if (row.userId && row.userId !== userId) return { status: 404 as const }
  return { status: null as null | 404 }
}

interface StoredMessage {
  id: string
  role: 'user' | 'agent'
  kind: string
  ts: number
  text?: string
  tone?: string
  options?: unknown[]
  scan?: unknown
  fix?: unknown
  via?: string
}

/** Ambil satu sesi agen lengkap (pesan + file + scan) untuk dimuat ulang. */
export async function GET(_request: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await ctx.params
    if (!ID_RE.test(id)) {
      return NextResponse.json({ error: 'Format id sesi tidak valid.' }, { status: 400 })
    }
    const guard = await guardAccess(id)
    if (guard.status) {
      return NextResponse.json({ error: 'Sesi tidak ditemukan.' }, { status: guard.status })
    }

    const row = await db.agentSession.findUnique({ where: { id } })
    if (!row) {
      return NextResponse.json({ error: 'Sesi tidak ditemukan.' }, { status: 404 })
    }

    let messages: StoredMessage[] = []
    try {
      const parsed = JSON.parse(row.messagesJson)
      if (Array.isArray(parsed)) messages = parsed as StoredMessage[]
    } catch {
      messages = []
    }

    let files: WorkspaceFileInput[] = []
    try {
      const parsed = JSON.parse(row.filesJson)
      if (Array.isArray(parsed)) files = parsed as WorkspaceFileInput[]
    } catch {
      files = []
    }

    let scan: WorkspaceScanResult | null = null
    if (row.scanJson) {
      try {
        const parsed = JSON.parse(row.scanJson)
        if (parsed && typeof parsed === 'object' && Array.isArray(parsed.files)) scan = parsed
      } catch {
        scan = null
      }
    }

    return NextResponse.json({
      ok: true,
      session: {
        id: row.id,
        title: row.title,
        messages,
        files,
        scan,
        createdAt: row.createdAt,
        updatedAt: row.updatedAt,
      },
    })
  } catch (error) {
    console.error('[agent-session] get error:', error)
    return NextResponse.json({ error: 'Gagal memuat sesi.' }, { status: 500 })
  }
}

/** Hapus satu sesi agen. */
export async function DELETE(_request: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await ctx.params
    if (!ID_RE.test(id)) {
      return NextResponse.json({ error: 'Format id sesi tidak valid.' }, { status: 400 })
    }
    const guard = await guardAccess(id)
    if (guard.status) {
      return NextResponse.json({ error: 'Sesi tidak ditemukan.' }, { status: guard.status })
    }
    await db.agentSession.delete({ where: { id } })
    return NextResponse.json({ ok: true })
  } catch (error) {
    if (
      error &&
      typeof error === 'object' &&
      'code' in error &&
      (error as { code?: string }).code === 'P2025'
    ) {
      return NextResponse.json({ error: 'Sesi tidak ditemukan.' }, { status: 404 })
    }
    console.error('[agent-session] delete error:', error)
    return NextResponse.json({ error: 'Gagal menghapus sesi.' }, { status: 500 })
  }
}
