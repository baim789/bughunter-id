import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { rateLimit, getClientIp } from '@/lib/rate-limit'
import { isJsonRequest, validateWorkspaceFiles } from '@/lib/workspace-validate'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import type { WorkspaceScanResult } from '@/lib/types'

/**
 * Simpan (upsert) sesi agen: pesan chat + file workspace + hasil scan terakhir.
 * Dipanggil otomatis (debounce) dari UI setelah tiap aksi penting, jadi:
 * - id opsional (null = sesi baru)
 * - ukuran divalidasi ketat agar DB tetap ringan
 */
const MAX_MESSAGES_JSON = 600_000
const MAX_SCAN_JSON = 600_000
const RATE_LIMIT_SESSION_SAVE = Number(process.env.RATE_LIMIT_SESSION_PER_MIN) || 60
const ID_RE = /^[A-Za-z0-9_-]{1,64}$/

export async function POST(request: NextRequest) {
  try {
    if (!isJsonRequest(request.headers.get('content-type'))) {
      return NextResponse.json({ error: 'Content-Type harus application/json.' }, { status: 415 })
    }

    const rl = rateLimit(`agent-session:${getClientIp(request)}`, RATE_LIMIT_SESSION_SAVE)
    if (!rl.ok) {
      return NextResponse.json(
        { error: `Terlalu banyak simpanan sesi. Coba lagi dalam ${rl.retryAfter} detik.` },
        { status: 429, headers: { 'retry-after': String(rl.retryAfter) } },
      )
    }

    const body = await request.json().catch(() => ({}))
    const id = typeof body.id === 'string' && ID_RE.test(body.id) ? body.id : null

    // Sesi menempel ke akun bila sedang masuk; anonim = sesi tanpa pemilik
    const authSession = await getServerSession(authOptions)
    const userId = (authSession?.user as { id?: string } | undefined)?.id ?? null

    // Validasi file workspace (batas sama: 200 file, 200 KB/file, 5 juta karakter).
    // Workspace kosong sah (sesi baru saja dibuka).
    let files: { name: string; code: string }[] = []
    if (Array.isArray(body.files) && body.files.length > 0) {
      const v = validateWorkspaceFiles(body)
      if (!v.ok) return NextResponse.json({ error: v.error }, { status: v.status })
      files = v.files
    }

    const messagesRaw = Array.isArray(body.messages) ? body.messages : []
    const messagesJson = JSON.stringify(messagesRaw)
    if (messagesJson.length > MAX_MESSAGES_JSON) {
      return NextResponse.json({ error: 'Riwayat pesan terlalu besar untuk disimpan.' }, { status: 400 })
    }

    let scanJson: string | null = null
    const scan = body.scan as WorkspaceScanResult | null
    if (scan && typeof scan === 'object' && Array.isArray(scan.files)) {
      scanJson = JSON.stringify({
        fileCount: scan.fileCount,
        supportedCount: scan.supportedCount,
        totalLines: scan.totalLines,
        bugCount: scan.bugCount,
        criticalCount: scan.criticalCount,
        highCount: scan.highCount,
        mediumCount: scan.mediumCount,
        lowCount: scan.lowCount,
        healthScore: scan.healthScore,
        crossFileCount: scan.crossFileCount,
        files: scan.files,
        createdAt: scan.createdAt ?? new Date().toISOString(),
      })
      if (scanJson.length > MAX_SCAN_JSON) {
        return NextResponse.json({ error: 'Hasil pemindaian terlalu besar untuk disimpan.' }, { status: 400 })
      }
    }

    const title =
      typeof body.title === 'string' && body.title.trim()
        ? body.title.trim().slice(0, 80)
        : 'Sesi agen'

    const firstUser = messagesRaw.find(
      (m: { role?: unknown }) => m?.role === 'user',
    ) as { text?: unknown } | undefined
    const derivedTitle =
      title !== 'Sesi agen' || typeof firstUser?.text !== 'string'
        ? title
        : firstUser.text.replace(/\s+/g, ' ').trim().slice(0, 60) || 'Sesi agen'

    const data = {
      title: derivedTitle,
      messageCount: messagesRaw.length,
      fileCount: files.length,
      bugCount: scan?.bugCount ?? 0,
      healthScore: scan?.healthScore ?? 100,
      messagesJson,
      filesJson: JSON.stringify(files),
      scanJson,
    }

    if (id) {
      const existing = await db.agentSession.findUnique({
        where: { id },
        select: { userId: true },
      })
      if (existing && existing.userId && existing.userId !== userId) {
        // Sesi milik akun lain — jangan ditimpa; simpan sebagai sesi baru milik kita
        const fresh = await db.agentSession.create({ data: { ...data, userId } })
        return NextResponse.json({ ok: true, id: fresh.id, title: fresh.title, savedAt: fresh.updatedAt })
      }
      // Adopsi: sesi anonim yang disimpan saat sedang masuk menjadi milik akun
      const adoptOwner = existing && !existing.userId && userId ? { userId } : {}
      const saved = await db.agentSession.upsert({
        where: { id },
        update: { ...data, ...adoptOwner },
        create: { id, ...data, userId },
      })
      return NextResponse.json({
        ok: true,
        id: saved.id,
        title: saved.title,
        savedAt: saved.updatedAt,
      })
    }
    const saved = await db.agentSession.create({ data: { ...data, userId } })

    return NextResponse.json({
      ok: true,
      id: saved.id,
      title: saved.title,
      savedAt: saved.updatedAt,
    })
  } catch (error) {
    console.error('[agent-session] save error:', error)
    return NextResponse.json({ error: 'Gagal menyimpan sesi.' }, { status: 500 })
  }
}
