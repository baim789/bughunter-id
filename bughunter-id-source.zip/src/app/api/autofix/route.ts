import { NextRequest, NextResponse } from 'next/server'
import { analyzeCode, detectLanguage } from '@/lib/detector'
import { applyAutoFixes, FIXABLE_RULE_IDS, type AutoFixTargets } from '@/lib/detector/fixers'
import { SUPPORTED_LANGUAGES } from '@/lib/types'
import { rateLimit, getClientIp } from '@/lib/rate-limit'

const RATE_LIMIT_AUTOFIX = Number(process.env.RATE_LIMIT_AUTOFIX_PER_MIN) || 60

/**
 * POST /api/autofix
 * Body: { code: string, language?: string, targets?: { line: number, ruleId: string }[] }
 *
 * Memperbaiki bug secara OTOMATIS hanya untuk aturan yang fixer-nya terbukti aman.
 * - Tanpa targets  : perbaiki semua temuan yang mendukung auto-fix.
 * - Dengan targets : hanya (baris, aturan) yang diminta.
 *
 * Jaminan keamanan (lihat src/lib/detector/fixers.ts):
 * - Tidak pernah menambah/menghapus baris → nomor baris tetap valid.
 * - Setiap fixer punya guard (string literal, deklarasi ulang, dsb.).
 * - Tidak pernah menyentuh bug berisiko (eval, SQL concat, innerHTML, ...).
 * - Tidak menyimpan apa pun ke database — kode asli tetap di sisi pengguna.
 */
export async function POST(request: NextRequest) {
  try {
    // Anti-CSRF: hanya terima JSON eksplisit (lihat /api/analyze).
    const contentType = (request.headers.get('content-type') ?? '').toLowerCase()
    if (!contentType.includes('application/json')) {
      return NextResponse.json(
        { error: 'Content-Type harus application/json.' },
        { status: 415 },
      )
    }

    // Rate limit per IP — operasi regex pada kode besar tetap perlu dilindungi.
    const rl = rateLimit(`autofix:${getClientIp(request)}`, RATE_LIMIT_AUTOFIX)
    if (!rl.ok) {
      return NextResponse.json(
        { error: `Terlalu banyak permintaan. Coba lagi dalam ${rl.retryAfter} detik.` },
        { status: 429, headers: { 'retry-after': String(rl.retryAfter) } },
      )
    }

    const body = await request.json().catch(() => ({}))
    const code = typeof body.code === 'string' ? body.code : ''
    const requestedLang = typeof body.language === 'string' ? body.language : 'auto'

    if (!code.trim()) {
      return NextResponse.json(
        { error: 'Kode tidak boleh kosong. Tempel kode terlebih dahulu lalu pindai.' },
        { status: 400 },
      )
    }

    if (code.length > 100_000) {
      return NextResponse.json(
        { error: 'Kode terlalu panjang (maksimal 100.000 karakter).' },
        { status: 400 },
      )
    }

    let language = requestedLang
    if (language === 'auto') {
      const detected = detectLanguage(code)
      if (!detected) {
        return NextResponse.json(
          { error: 'Bahasa tidak dapat dideteksi otomatis. Pilih bahasa secara manual.' },
          { status: 400 },
        )
      }
      language = detected
    }

    if (!SUPPORTED_LANGUAGES.includes(language as never)) {
      return NextResponse.json(
        { error: `Bahasa "${language}" tidak didukung.` },
        { status: 400 },
      )
    }

    // Validasi bentuk targets (perbaikan per-bug dari UI).
    let targets: AutoFixTargets[] | undefined
    if (Array.isArray(body.targets)) {
      targets = (body.targets as unknown[])
        .filter(
          (t): t is AutoFixTargets =>
            typeof t === 'object' &&
            t !== null &&
            typeof (t as AutoFixTargets).line === 'number' &&
            typeof (t as AutoFixTargets).ruleId === 'string',
        )
        .map(t => ({ line: Math.round(t.line), ruleId: t.ruleId }))
    }

    // Hitung total temuan yang bisa di-fix (untuk info UI).
    const bugs = analyzeCode(code, language)
    const totalFixable = bugs.filter(b => b.ruleId && FIXABLE_RULE_IDS.has(b.ruleId)).length

    const result = applyAutoFixes(code, language as never, targets)

    return NextResponse.json({
      ok: true,
      language,
      fixedCode: result.fixedCode,
      changes: result.changes,
      skipped: result.skipped,
      fixedCount: result.changes.length,
      totalFixable,
    })
  } catch (error) {
    console.error('[autofix] unexpected error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan internal saat menerapkan perbaikan otomatis. Coba lagi.' },
      { status: 500 },
    )
  }
}
