import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import type { HistoryItem } from '@/lib/types'

/** Format id yang valid (cuid/uuid/angka) — cegah string pathologi masuk ke DB. */
const ID_PATTERN = /^[A-Za-z0-9_-]{1,64}$/

export async function GET(request: NextRequest) {
  try {
    const limitParam = request.nextUrl.searchParams.get('limit')
    const parsed = Number.parseInt(limitParam ?? '', 10)
    const limit = Math.min(Math.max(Number.isFinite(parsed) ? parsed : 30, 1), 100)

    const [scans, workspaceScans] = await Promise.all([
      db.scan.findMany({
        orderBy: { createdAt: 'desc' },
        take: limit,
        select: {
          id: true,
          language: true,
          codeSnippet: true,
          bugCount: true,
          criticalCount: true,
          highCount: true,
          mediumCount: true,
          lowCount: true,
          healthScore: true,
          source: true,
          aiEnabled: true,
          createdAt: true,
        },
      }),
      db.workspaceScan.findMany({
        orderBy: { createdAt: 'desc' },
        take: limit,
        select: {
          id: true,
          fileCount: true,
          filesJson: true,
          bugCount: true,
          criticalCount: true,
          highCount: true,
          mediumCount: true,
          lowCount: true,
          healthScore: true,
          createdAt: true,
        },
      }),
    ])

    type MergedItem = HistoryItem & { _ts: number }
    const merged: MergedItem[] = [
      ...scans.map(s => ({
        id: s.id,
        kind: 'single' as const,
        language: s.language,
        preview: s.codeSnippet.replace(/\s+/g, ' ').trim().slice(0, 120),
        bugCount: s.bugCount,
        criticalCount: s.criticalCount,
        highCount: s.highCount,
        mediumCount: s.mediumCount,
        lowCount: s.lowCount,
        healthScore: s.healthScore,
        source: s.source,
        aiEnabled: s.aiEnabled,
        createdAt: s.createdAt.toISOString(),
        _ts: s.createdAt.getTime(),
      })),
      ...workspaceScans.map(w => {
        // apakah file workspace tersimpan lengkap (bisa dimuat ulang ke editor)?
        let restoreable = false
        try {
          const parsed = JSON.parse(w.filesJson)
          restoreable = Array.isArray(parsed) && parsed.length > 0 && parsed.every((f: { code?: unknown }) => typeof f.code === 'string')
        } catch {
          restoreable = false
        }
        return {
          id: w.id,
          kind: 'workspace' as const,
          language: 'workspace',
          preview: `${w.fileCount} file dianalisis bersama`,
          bugCount: w.bugCount,
          criticalCount: w.criticalCount,
          highCount: w.highCount,
          mediumCount: w.mediumCount,
          lowCount: w.lowCount,
          healthScore: w.healthScore,
          source: 'rule',
          aiEnabled: false,
          createdAt: w.createdAt.toISOString(),
          fileCount: w.fileCount,
          restoreable,
          _ts: w.createdAt.getTime(),
        }
      }),
    ].sort((a, b) => b._ts - a._ts)

    return NextResponse.json({
      history: merged.slice(0, limit).map(({ _ts: _drop, ...item }) => item),
    })
  } catch (error) {
    console.error('[history] error:', error)
    return NextResponse.json(
      { error: 'Gagal memuat riwayat pemindaian.' },
      { status: 500 },
    )
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const id = request.nextUrl.searchParams.get('id')
    if (!id) {
      return NextResponse.json({ error: 'Parameter id wajib diisi.' }, { status: 400 })
    }
    if (!ID_PATTERN.test(id)) {
      return NextResponse.json({ error: 'Format id tidak valid.' }, { status: 400 })
    }
    await db.scan.delete({ where: { id } })
    return NextResponse.json({ ok: true })
  } catch (error) {
    // Bedakan "memang tidak ada" (404) dari kegagalan DB sungguhan (500)
    // agar pesan tidak menyesatkan saat troubleshooting.
    if ((error as { code?: string })?.code === 'P2025') {
      return NextResponse.json(
        { error: 'Riwayat tidak ditemukan atau sudah dihapus.' },
        { status: 404 },
      )
    }
    console.error('[history] delete error:', error)
    return NextResponse.json({ error: 'Gagal menghapus riwayat.' }, { status: 500 })
  }
}
