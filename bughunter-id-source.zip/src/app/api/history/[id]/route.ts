import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import type { Bug } from '@/lib/types'

/** Format id yang valid (cuid/uuid/angka) — cegah string pathologi masuk ke DB. */
const ID_PATTERN = /^[A-Za-z0-9_-]{1,64}$/

export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await params
    if (!ID_PATTERN.test(id)) {
      return NextResponse.json({ error: 'Format id tidak valid.' }, { status: 400 })
    }
    const scan = await db.scan.findUnique({ where: { id } })
    if (!scan) {
      return NextResponse.json({ error: 'Riwayat tidak ditemukan.' }, { status: 404 })
    }

    let bugs: Bug[] = []
    try {
      const parsed = JSON.parse(scan.bugsJson)
      if (Array.isArray(parsed)) bugs = parsed as Bug[]
    } catch {
      bugs = []
    }

    return NextResponse.json({
      scan: {
        id: scan.id,
        language: scan.language,
        lineCount: scan.lineCount,
        bugCount: scan.bugCount,
        criticalCount: scan.criticalCount,
        highCount: scan.highCount,
        mediumCount: scan.mediumCount,
        lowCount: scan.lowCount,
        healthScore: scan.healthScore,
        source: scan.source,
        aiEnabled: scan.aiEnabled,
        codeSnippet: scan.codeSnippet,
        bugs,
        createdAt: scan.createdAt,
      },
    })
  } catch (error) {
    console.error('[history/detail] error:', error)
    return NextResponse.json(
      { error: 'Gagal memuat detail riwayat.' },
      { status: 500 },
    )
  }
}
