import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import type { Severity, Stats } from '@/lib/types'

export async function GET() {
  try {
    const scans = await db.scan.findMany({
      orderBy: { createdAt: 'desc' },
      take: 500,
      select: {
        language: true,
        bugCount: true,
        criticalCount: true,
        highCount: true,
        mediumCount: true,
        lowCount: true,
        healthScore: true,
      },
    })

    const byLanguage: Record<string, number> = {}
    const bySeverity: Record<Severity, number> = { critical: 0, high: 0, medium: 0, low: 0 }
    let totalBugs = 0
    let healthSum = 0

    for (const s of scans) {
      totalBugs += s.bugCount
      healthSum += s.healthScore
      byLanguage[s.language] = (byLanguage[s.language] ?? 0) + 1
      bySeverity.critical += s.criticalCount
      bySeverity.high += s.highCount
      bySeverity.medium += s.mediumCount
      bySeverity.low += s.lowCount
    }

    const stats: Stats = {
      totalScans: scans.length,
      totalBugs,
      avgHealth: scans.length > 0 ? Math.round(healthSum / scans.length) : 100,
      byLanguage,
      bySeverity,
    }

    return NextResponse.json({ stats })
  } catch (error) {
    console.error('[stats] error:', error)
    return NextResponse.json({ error: 'Gagal memuat statistik.' }, { status: 500 })
  }
}
