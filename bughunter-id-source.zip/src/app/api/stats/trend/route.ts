import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { db } from '@/lib/db'
import { authOptions } from '@/lib/auth'
import { rateLimit, getClientIp } from '@/lib/rate-limit'

const RATE_LIMIT = Number(process.env.RATE_LIMIT_STATS_PER_MIN) || 60

/**
 * GET /api/stats/trend
 * Tren kesehatan kode dari riwayat pemindaian workspace.
 * - Masuk akun  : hanya pemindaian milik user tersebut (scope "saya").
 * - Anonim      : hanya pemindaian tanpa akun (scope "anonim").
 * Mengembalikan maksimal 40 titik terakhir (naik berdasarkan waktu) + ringkasan.
 */
export async function GET(request: Request) {
  try {
    const rl = rateLimit(`trend:${getClientIp(request)}`, RATE_LIMIT)
    if (!rl.ok) {
      return NextResponse.json(
        { error: `Terlalu banyak permintaan. Coba lagi dalam ${rl.retryAfter} detik.` },
        { status: 429, headers: { 'retry-after': String(rl.retryAfter) } },
      )
    }

    const session = await getServerSession(authOptions)
    const userId = typeof session?.user?.id === 'string' ? session.user.id : null
    const scope = userId ? 'saya' : 'anonim'

    const [rows, total] = await Promise.all([
      db.workspaceScan.findMany({
        where: { userId },
        orderBy: { createdAt: 'desc' },
        take: 40,
        select: {
          id: true,
          createdAt: true,
          healthScore: true,
          bugCount: true,
          criticalCount: true,
          highCount: true,
          mediumCount: true,
          lowCount: true,
          crossFileCount: true,
          fileCount: true,
        },
      }),
      db.workspaceScan.count({ where: { userId } }),
    ])

    const points = rows
      .slice()
      .reverse()
      .map(r => ({
        id: r.id,
        at: r.createdAt.toISOString(),
        healthScore: r.healthScore,
        bugCount: r.bugCount,
        criticalCount: r.criticalCount,
        highCount: r.highCount,
        mediumCount: r.mediumCount,
        lowCount: r.lowCount,
        crossFileCount: r.crossFileCount,
        fileCount: r.fileCount,
      }))

    const last = points[points.length - 1] ?? null
    const prev = points.length >= 2 ? points[points.length - 2] : null
    const avgHealth =
      points.length > 0
        ? Math.round(points.reduce((s, p) => s + p.healthScore, 0) / points.length)
        : null

    return NextResponse.json({
      scope,
      summary: {
        total,
        shown: points.length,
        avgHealth,
        lastScore: last?.healthScore ?? null,
        deltaScore: last && prev ? last.healthScore - prev.healthScore : null,
        lastBugs: last?.bugCount ?? null,
        lastCritical: last?.criticalCount ?? null,
        lastCrossFile: last?.crossFileCount ?? null,
      },
      points,
    })
  } catch (error) {
    console.error('[stats/trend] error:', error)
    return NextResponse.json({ error: 'Gagal memuat tren kesehatan kode.' }, { status: 500 })
  }
}
