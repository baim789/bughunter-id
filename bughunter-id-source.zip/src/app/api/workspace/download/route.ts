import { NextRequest, NextResponse } from 'next/server'
import { createZip, type ZipEntry } from '@/lib/zip'
import { isJsonRequest, validateWorkspaceFiles } from '@/lib/workspace-validate'
import { rateLimit, getClientIp } from '@/lib/rate-limit'

const RATE_LIMIT = Number(process.env.RATE_LIMIT_WORKSPACE_DOWNLOAD_PER_MIN) || 10

/**
 * POST /api/workspace/download
 * Body: { files: [{name, code}], mode?: 'fixed' | 'original' }
 * Mengemas seluruh file workspace (hasil perbaikan atau versi asli)
 * menjadi arsip .zip yang diunduh browser.
 */
export async function POST(request: NextRequest) {
  try {
    if (!isJsonRequest(request.headers.get('content-type'))) {
      return NextResponse.json({ error: 'Content-Type harus application/json.' }, { status: 415 })
    }
    const rl = rateLimit(`ws-download:${getClientIp(request)}`, RATE_LIMIT)
    if (!rl.ok) {
      return NextResponse.json(
        { error: `Terlalu banyak permintaan. Coba lagi dalam ${rl.retryAfter} detik.` },
        { status: 429, headers: { 'retry-after': String(rl.retryAfter) } },
      )
    }

    const body = await request.json().catch(() => ({}))
    const validation = validateWorkspaceFiles(body)
    if (!validation.ok) {
      return NextResponse.json({ error: validation.error }, { status: validation.status })
    }

    const mode = body?.mode === 'original' ? 'original' : 'fixed'

    const entries: ZipEntry[] = validation.files.map(f => ({ name: f.name, content: f.code }))
    // Ringkasan kecil di dalam arsip supaya hasilnya memakai diri sendiri.
    entries.push({
      name: mode === 'fixed' ? 'LAPORAN-PERBAIKAN.txt' : 'LAPORAN-WORKSPACE.txt',
      content: [
        'BugHunter ID — Arsip Workspace',
        `Tanggal : ${new Date().toISOString()}`,
        `Mode    : ${mode === 'fixed' ? 'Kode hasil perbaikan otomatis (aman)' : 'Kode asli sebelum perbaikan'}`,
        `Jumlah  : ${validation.files.length} file`,
        '',
        'File:',
        ...validation.files.map(f => ` - ${f.name} (${f.code.split('\n').length} baris, ${f.code.length} karakter)`),
        '',
        'Catatan: perbaikan otomatis hanya menyentuh kelas bug yang terbukti aman.',
        'Temuan berisiko (eval, SQL concat, kredensial, dsb.) sengaja tidak diubah —',
        'ikuti saran perbaikan manual pada hasil pemindaian.',
      ].join('\n'),
    })

    let zip: Uint8Array
    try {
      zip = createZip(entries)
    } catch (err) {
      return NextResponse.json(
        { error: err instanceof Error ? err.message : 'Gagal membuat arsip.' },
        { status: 400 },
      )
    }

    const filename = `bughunter-workspace-${mode}.zip`
    return new Response(new Uint8Array(zip), {
      status: 200,
      headers: {
        'content-type': 'application/zip',
        'content-disposition': `attachment; filename="${filename}"`,
        'content-length': String(zip.length),
        'cache-control': 'no-store',
      },
    })
  } catch (error) {
    console.error('[workspace/download] error:', error)
    return NextResponse.json({ error: 'Gagal membuat arsip ZIP.' }, { status: 500 })
  }
}
