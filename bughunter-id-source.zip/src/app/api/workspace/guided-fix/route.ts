import { NextRequest, NextResponse } from 'next/server'
import { applyGuidedFixes } from '@/lib/detector/guided-fix'
import { isJsonRequest, validateWorkspaceFiles } from '@/lib/workspace-validate'
import { rateLimit, getClientIp } from '@/lib/rate-limit'
import { diffLines, diffStats } from '@/lib/diff'
import type { GuidedFixAction } from '@/lib/types'

const RATE_LIMIT = Number(process.env.RATE_LIMIT_WORKSPACE_PER_MIN) || 20
const MAX_ACTIONS = 10

/**
 * Validasi bentuk aksi perbaikan berpandu dari body.
 * Hanya field terkontrol yang diterima; sisanya dibuang.
 */
function parseActions(raw: unknown): GuidedFixAction[] | null {
  if (!Array.isArray(raw) || raw.length === 0) return null
  if (raw.length > MAX_ACTIONS) return null
  const out: GuidedFixAction[] = []
  for (const a of raw) {
    const item = a as Record<string, unknown>
    if (typeof item.ruleId !== 'string' || item.ruleId.length > 64) return null
    if (typeof item.option !== 'string' || item.option.length > 32) return null
    if (typeof item.file !== 'string' || item.file.length > 200) return null
    const line = Number(item.line)
    if (!Number.isInteger(line) || line < 1 || line > 1_000_000) return null
    const str = (v: unknown, max: number) => (typeof v === 'string' && v.length > 0 && v.length <= max ? v : undefined)
    const num = (v: unknown) => {
      const n = Number(v)
      return Number.isInteger(n) && n >= 0 && n <= 10_000 ? n : undefined
    }
    out.push({
      ruleId: item.ruleId,
      option: item.option,
      file: item.file,
      line,
      targetFile: str(item.targetFile, 200),
      symbol: str(item.symbol, 128),
      spec: str(item.spec, 300),
      pkg: str(item.pkg, 200),
      paramCount: num(item.paramCount),
      callCount: num(item.callCount),
      fixedIn: str(item.fixedIn, 32),
    })
  }
  return out
}

/**
 * POST /api/workspace/guided-fix
 * Body: { files: [{name, code}], actions: [{ruleId, option, file, line, ...}] }
 * Mengeksekusi solusi perbaikan berpandu yang dipilih pengguna pada temuan
 * lintas file. Setiap aksi divalidasi ulang terhadap isi file terkini
 * (anti-kadaluarsa); aksi yang tidak cocok ditolak dengan alasan jelas.
 * Tidak menyimpan apa pun ke database.
 */
export async function POST(request: NextRequest) {
  try {
    if (!isJsonRequest(request.headers.get('content-type'))) {
      return NextResponse.json({ error: 'Content-Type harus application/json.' }, { status: 415 })
    }
    const rl = rateLimit(`ws-guided:${getClientIp(request)}`, RATE_LIMIT)
    if (!rl.ok) {
      return NextResponse.json(
        { error: `Terlalu banyak permintaan. Coba lagi dalam ${rl.retryAfter} detik.` },
        { status: 429, headers: { 'retry-after': String(rl.retryAfter) } },
      )
    }

    const body = await request.json().catch(() => ({}))
    const validation = validateWorkspaceFiles(body)
    if (!validation.ok) {
      return NextResponse.json({ error: validation.error }, { status: validation.status })
    }
    const actions = parseActions((body as { actions?: unknown }).actions)
    if (!actions) {
      return NextResponse.json(
        { error: `Sertakan actions (1..${MAX_ACTIONS}) berisi {ruleId, option, file, line}.` },
        { status: 400 },
      )
    }
    const dryRun = (body as { dryRun?: unknown }).dryRun === true

    const result = applyGuidedFixes(validation.files, actions)

    /* Mode pratinjau: kembalikan DIFF, bukan file siap pakai — klien baru
     * mengeksekusi sungguhan setelah pengguna menyetujui lewat chat. */
    if (dryRun) {
      const beforeByName = new Map(validation.files.map(f => [f.name, f.code]))
      const diffs = []
      for (const f of result.files) {
        const before = beforeByName.get(f.name)
        if (before === undefined) {
          diffs.push({ file: f.name, added: f.code.split('\n').length, removed: 0, lines: diffLines('', f.code), isNew: true })
          continue
        }
        if (before === f.code) continue
        const lines = diffLines(before, f.code)
        const { added, removed } = diffStats(lines)
        diffs.push({ file: f.name, added, removed, lines, isNew: false })
      }
      return NextResponse.json({
        ok: true,
        dryRun: true,
        appliedCount: result.appliedCount,
        addedFiles: result.addedFiles,
        results: result.results,
        preview: { diffs, filesChanged: diffs.length },
      })
    }

    return NextResponse.json({
      ok: true,
      files: result.files,
      addedFiles: result.addedFiles,
      appliedCount: result.appliedCount,
      results: result.results,
    })
  } catch (error) {
    console.error('[workspace/guided-fix] error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan internal saat menerapkan perbaikan berpandu. Coba lagi.' },
      { status: 500 },
    )
  }
}
