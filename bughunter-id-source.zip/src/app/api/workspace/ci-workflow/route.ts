import { NextResponse } from 'next/server'
import { rateLimit, getClientIp } from '@/lib/rate-limit'

const RATE_LIMIT = Number(process.env.RATE_LIMIT_CI_PER_MIN) || 10

/**
 * Workflow GitHub Actions siap pakai yang memakai API BugHunter ID:
 * kumpulkan berkas dari repositori → POST /api/workspace/analyze → POST /api/workspace/export
 * (SARIF 2.1.0) → unggah artefak + Code Scanning.
 *
 * Konfigurasi yang dibutuhkan user:
 * - Secret repo  : BUGHUNTER_URL  (URL aplikasi BugHunter ID)
 * - Opsional var : BUGHUNTER_MAX_BUGS (gagal-kan job bila temuan melewati batas)
 */
const WORKFLOW_YAML = `# ============================================================
#  BugHunter ID v0.12.3 — Workflow pemindaian bug (GitHub Actions)
#
#  Cara pakai:
#  1. Simpan file ini sebagai .github/workflows/bughunter.yml di repositori Anda.
#  2. Tambahkan secret repositori BUGHUNTER_URL berisi URL aplikasi BugHunter ID
#     (Settings - Secrets and variables - Actions - New repository secret).
#  3. Opsional: tambahkan variable BUGHUNTER_MAX_BUGS agar job gagal bila jumlah
#     temuan melewati batas (contoh: 10). Kosong/0 berarti tidak pernah gagal.
#  4. Setiap push/PR: hasil pemindaian diunggah sebagai artefak bughunter-results
#     dan (bila tersedia) ke GitHub Code Scanning.
# ============================================================
name: BugHunter ID Scan

on:
  push:
    branches: [main]
  pull_request:
  workflow_dispatch:

permissions:
  contents: read
  security-events: write

concurrency:
  group: bughunter-\${{ github.ref }}
  cancel-in-progress: true

jobs:
  scan:
    name: Pindai dengan BugHunter ID
    runs-on: ubuntu-latest
    steps:
      - name: Ambil kode
        uses: actions/checkout@v4

      - name: Siapkan Node.js
        uses: actions/setup-node@v4
        with:
          node-version: 20

      - name: Kumpulkan berkas & kirim ke BugHunter ID
        env:
          BUGHUNTER_URL: \${{ secrets.BUGHUNTER_URL }}
          BUGHUNTER_MAX_BUGS: \${{ vars.BUGHUNTER_MAX_BUGS || '0' }}
        run: |
          node - <<'NODE'
          const fs = require('node:fs');
          const path = require('node:path');
          const EXT = new Set(['.js', '.jsx', '.mjs', '.cjs', '.ts', '.tsx', '.py', '.java', '.php', '.go']);
          const SKIP = new Set(['node_modules', '.git', '.next', 'dist', 'build', 'out', 'vendor', 'coverage', '__pycache__', '.venv', 'venv']);
          const MAX_FILES = 200, MAX_TOTAL_CHARS = 5000000, MAX_FILE_CHARS = 200000;
          const cand = [];
          (function walk(dir) {
            if (cand.length >= MAX_FILES) return;
            let entries = [];
            try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch (e) { return; }
            for (const e of entries) {
              if (cand.length >= MAX_FILES) break;
              const p = path.join(dir, e.name);
              if (e.isDirectory()) { if (!SKIP.has(e.name)) walk(p); continue; }
              if (!e.isFile() || e.name.startsWith('.')) continue;
              if (!EXT.has(path.extname(e.name).toLowerCase())) continue;
              try {
                const code = fs.readFileSync(p, 'utf8');
                if (code.length > MAX_FILE_CHARS) continue;
                cand.push({ name: path.relative(process.cwd(), p).split(path.sep).join('/'), code: code });
              } catch (e) { /* lewati berkas tak terbaca */ }
            }
          })(process.cwd());
          const files = [];
          let total = 0;
          for (const f of cand) {
            if (files.length >= MAX_FILES || total + f.code.length > MAX_TOTAL_CHARS) break;
            files.push(f); total += f.code.length;
          }
          if (!files.length) { console.log('BugHunter: tidak ada berkas yang didukung - pemindaian dilewati.'); process.exit(0); }
          (async () => {
            const base = (process.env.BUGHUNTER_URL || '').replace(/\\/+$/, '');
            if (!base) { console.error('BugHunter: secret BUGHUNTER_URL belum diatur (Settings - Secrets and variables - Actions).'); process.exit(1); }
            const an = await fetch(base + '/api/workspace/analyze', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ files: files }) });
            if (!an.ok) throw new Error('analyze HTTP ' + an.status + ': ' + (await an.text()).slice(0, 300));
            const data = await an.json();
            const scan = data.scan;
            console.log('BugHunter: skor kesehatan ' + scan.healthScore + '/100 - ' + scan.bugCount + ' temuan (' + scan.crossFileCount + ' lintas file) di ' + scan.fileCount + ' berkas.');
            const ex = await fetch(base + '/api/workspace/export', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ scan: scan, format: 'sarif' }) });
            if (!ex.ok) throw new Error('export HTTP ' + ex.status);
            fs.writeFileSync('bughunter-results.sarif', await ex.text());
            console.log('BugHunter: hasil disimpan ke bughunter-results.sarif');
            const max = Number(process.env.BUGHUNTER_MAX_BUGS || '0');
            if (max > 0 && scan.bugCount > max) {
              console.error('BugHunter: jumlah temuan (' + scan.bugCount + ') melewati batas BUGHUNTER_MAX_BUGS (' + max + ').');
              process.exit(1);
            }
          })().catch(err => { console.error('BugHunter gagal: ' + ((err && err.message) || err)); process.exit(1); });
          NODE

      - name: Unggah hasil SARIF sebagai artefak
        uses: actions/upload-artifact@v4
        if: success() || failure()
        with:
          name: bughunter-results
          path: bughunter-results.sarif
          if-no-files-found: ignore

      - name: Unggah ke GitHub Code Scanning (opsional)
        uses: github/codeql-action/upload-sarif@v3
        continue-on-error: true
        with:
          sarif_file: bughunter-results.sarif
`

/**
 * GET /api/workspace/ci-workflow
 * Mengembalikan file YAML workflow GitHub Actions siap pakai (text/yaml).
 */
export async function GET(request: Request) {
  try {
    const rl = rateLimit(`ci-yaml:${getClientIp(request)}`, RATE_LIMIT)
    if (!rl.ok) {
      return NextResponse.json(
        { error: `Terlalu banyak permintaan. Coba lagi dalam ${rl.retryAfter} detik.` },
        { status: 429, headers: { 'retry-after': String(rl.retryAfter) } },
      )
    }
    return new NextResponse(WORKFLOW_YAML, {
      status: 200,
      headers: {
        'Content-Type': 'text/yaml; charset=utf-8',
        'Cache-Control': 'no-store',
      },
    })
  } catch (error) {
    console.error('[workspace/ci-workflow] error:', error)
    return NextResponse.json({ error: 'Gagal membuat workflow CI/CD.' }, { status: 500 })
  }
}
