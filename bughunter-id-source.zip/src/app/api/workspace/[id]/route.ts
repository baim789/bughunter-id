import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import type { WorkspaceFileInput } from '@/lib/types'

/** Format id yang valid (cuid/uuid) — cegah string pathologi masuk ke DB. */
const ID_PATTERN = /^[A-Za-z0-9_-]{1,64}$/

interface StoredFile {
  name: string
  code?: string
}

/** GET /api/workspace/[id] — detail hasil pemindaian workspace. */
export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await params
    if (!ID_PATTERN.test(id)) {
      return NextResponse.json({ error: 'Format id tidak valid.' }, { status: 400 })
    }
    const scan = await db.workspaceScan.findUnique({ where: { id } })
    if (!scan) {
      return NextResponse.json({ error: 'Riwayat workspace tidak ditemukan.' }, { status: 404 })
    }

    let files: StoredFile[] = []
    try {
      const parsed = JSON.parse(scan.filesJson)
      if (Array.isArray(parsed)) files = parsed as StoredFile[]
    } catch {
      files = []
    }
    const restoreable = files.length > 0 && files.every(f => typeof f.code === 'string')

    return NextResponse.json({
      scan: {
        id: scan.id,
        fileCount: scan.fileCount,
        supportedCount: scan.supportedCount,
        totalLines: scan.totalLines,
        bugCount: scan.bugCount,
        criticalCount: scan.criticalCount,
        highCount: scan.highCount,
        mediumCount: scan.mediumCount,
        lowCount: scan.lowCount,
        healthScore: scan.healthScore,
        crossFileCount: scan.crossFileCount,
        restoreable,
        files: restoreable ? (files as WorkspaceFileInput[]) : files.map(f => ({ name: f.name })),
        createdAt: scan.createdAt,
      },
    })
  } catch (error) {
    console.error('[workspace/detail] error:', error)
    return NextResponse.json({ error: 'Gagal memuat detail workspace.' }, { status: 500 })
  }
}

/** DELETE /api/workspace/[id] — hapus riwayat workspace. */
export async function DELETE(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await params
    if (!ID_PATTERN.test(id)) {
      return NextResponse.json({ error: 'Format id tidak valid.' }, { status: 400 })
    }
    await db.workspaceScan.delete({ where: { id } })
    return NextResponse.json({ ok: true })
  } catch (error) {
    if ((error as { code?: string })?.code === 'P2025') {
      return NextResponse.json({ error: 'Riwayat workspace tidak ditemukan.' }, { status: 404 })
    }
    console.error('[workspace/delete] error:', error)
    return NextResponse.json({ error: 'Gagal menghapus riwayat workspace.' }, { status: 500 })
  }
}
