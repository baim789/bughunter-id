import { NextRequest, NextResponse } from 'next/server'
import { rateLimit, getClientIp } from '@/lib/rate-limit'
import { readZipWorkspace } from '@/lib/zip-read'

const RATE_LIMIT = Number(process.env.RATE_LIMIT_WORKSPACE_PER_MIN) || 20
const MAX_ZIP_BYTES = 6 * 1_000_000

/**
 * POST /api/workspace/upload-zip
 * Body: multipart/form-data dengan field "file" (arsip .zip)
 * - Ekstrak seluruh berkas teks (store & deflate), buang biner/folder/
 *   sampah sistem (__MACOSX, .git, node_modules, .DS_Store, ...).
 * - Folder akar umum dibuang agar jalur relatif bersih.
 * - Batas sama dengan workspace: 50 file, 200 KB/file, 1,2 MB total.
 */
export async function POST(request: NextRequest) {
  try {
    const rl = rateLimit(`ws-zip:${getClientIp(request)}`, RATE_LIMIT)
    if (!rl.ok) {
      return NextResponse.json(
        { error: `Terlalu banyak permintaan. Coba lagi dalam ${rl.retryAfter} detik.` },
        { status: 429, headers: { 'retry-after': String(rl.retryAfter) } },
      )
    }

    const contentLength = Number(request.headers.get('content-length') ?? '0')
    if (Number.isFinite(contentLength) && contentLength > MAX_ZIP_BYTES + 100_000) {
      return NextResponse.json({ error: 'Ukuran ZIP terlalu besar (maksimal 6 MB).' }, { status: 413 })
    }

    let form: FormData
    try {
      form = await request.formData()
    } catch {
      return NextResponse.json(
        { error: 'Kirim berkas sebagai multipart/form-data dengan field "file".' },
        { status: 400 },
      )
    }

    const file = form.get('file')
    if (!file || typeof file === 'string') {
      return NextResponse.json({ error: 'Field "file" (arsip .zip) wajib diisi.' }, { status: 400 })
    }
    if (file.size > MAX_ZIP_BYTES) {
      return NextResponse.json({ error: 'Ukuran ZIP terlalu besar (maksimal 6 MB).' }, { status: 413 })
    }

    const buf = Buffer.from(await file.arrayBuffer())
    let result
    try {
      result = readZipWorkspace(buf)
    } catch (err) {
      return NextResponse.json(
        { error: err instanceof Error ? err.message : 'ZIP tidak dapat dibaca.' },
        { status: 400 },
      )
    }

    if (result.files.length === 0) {
      return NextResponse.json(
        {
          error:
            'Tidak ada berkas teks yang bisa dimuat dari ZIP (mungkin semua biner, kosong, atau melebihi batas ukuran).',
          info: result.info,
        },
        { status: 400 },
      )
    }

    return NextResponse.json({ ok: true, files: result.files, info: result.info })
  } catch (error) {
    console.error('[workspace/upload-zip] error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan internal saat membuka ZIP. Coba lagi.' },
      { status: 500 },
    )
  }
}
