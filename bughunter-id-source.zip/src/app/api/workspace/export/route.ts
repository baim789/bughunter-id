import { NextRequest, NextResponse } from 'next/server'
import { rateLimit, getClientIp } from '@/lib/rate-limit'
import { isJsonRequest } from '@/lib/workspace-validate'
import type { WorkspaceScanResult } from '@/lib/types'

const RATE_LIMIT = Number(process.env.RATE_LIMIT_WORKSPACE_PER_MIN) || 20

const SEVERITY_TO_SARIF: Record<string, 'error' | 'warning' | 'note'> = {
  critical: 'error',
  high: 'error',
  medium: 'warning',
  low: 'note',
}

interface RawScan {
  healthScore?: number
  bugCount?: number
  criticalCount?: number
  highCount?: number
  mediumCount?: number
  lowCount?: number
  crossFileCount?: number
  fileCount?: number
  totalLines?: number
  files?: Array<{
    name?: string
    language?: string
    healthScore?: number
    bugCount?: number
    bugs?: Array<{
      title?: string
      description?: string
      severity?: string
      line?: number
      category?: string
      suggestion?: string
      ruleId?: string
    }>
  }>
}

/** Validasi ringan bentuk scan dari body — kembalikan null bila tidak sah. */
function parseScan(raw: unknown): RawScan | null {
  if (!raw || typeof raw !== 'object') return null
  const s = raw as RawScan
  if (!Array.isArray(s.files) || s.files.length === 0) return null
  if (s.files.length > 200) return null
  return s
}

/**
 * POST /api/workspace/export
 * Body: { scan, format: "sarif" | "json" }
 * - sarif : SARIF 2.1.0 untuk integrasi CI/CD (GitHub Code Scanning, SARIF viewer).
 * - json  : dump terstruktur penuh hasil pemindaian workspace.
 */
export async function POST(request: NextRequest) {
  try {
    if (!isJsonRequest(request.headers.get('content-type'))) {
      return NextResponse.json({ error: 'Content-Type harus application/json.' }, { status: 415 })
    }
    const rl = rateLimit(`ws-export:${getClientIp(request)}`, RATE_LIMIT)
    if (!rl.ok) {
      return NextResponse.json(
        { error: `Terlalu banyak permintaan. Coba lagi dalam ${rl.retryAfter} detik.` },
        { status: 429, headers: { 'retry-after': String(rl.retryAfter) } },
      )
    }

    const body = await request.json().catch(() => ({}))
    const scan = parseScan((body as { scan?: unknown }).scan)
    if (!scan) {
      return NextResponse.json({ error: 'Sertakan scan hasil /api/workspace/analyze (minimal berisi files[]._).' }, { status: 400 })
    }
    const format = (body as { format?: unknown }).format === 'sarif' ? 'sarif' : 'json'

    if (format === 'sarif') {
      // kumpulkan aturan unik untuk run.tool.driver.rules
      const rulesById = new Map<string, { id: string; short: string; help: string }>()
      const results: unknown[] = []
      for (const f of scan.files ?? []) {
        const fileName = typeof f.name === 'string' ? f.name : 'unknown'
        for (const b of f.bugs ?? []) {
          const ruleId = typeof b.ruleId === 'string' && b.ruleId ? b.ruleId : `bughunter-${b.category ?? 'umum'}`
          if (!rulesById.has(ruleId)) {
            rulesById.set(ruleId, {
              id: ruleId,
              short: String(b.category ?? 'Umum'),
              help: String(b.suggestion ?? ''),
            })
          }
          const line = Number(b.line)
          results.push({
            ruleId,
            level: SEVERITY_TO_SARIF[String(b.severity)] ?? 'note',
            message: { text: `${String(b.title ?? 'Temuan')} — ${String(b.description ?? '')}` },
            locations: [
              {
                physicalLocation: {
                  artifactLocation: { uri: fileName.replace(/\\/g, '/') },
                  region: { startLine: Number.isFinite(line) && line >= 1 ? line : 1 },
                },
              },
            ],
          })
        }
      }
      const sarif = {
        $schema: 'https://json.schemastore.org/sarif-2.1.0.json',
        version: '2.1.0',
        runs: [
          {
            tool: {
              driver: {
                name: 'BugHunter ID',
                informationUri: 'https://github.com/',
                version: '0.12.3',
                rules: [...rulesById.values()].map(r => ({
                  id: r.id,
                  shortDescription: { text: r.short },
                  help: { text: r.help },
                })),
              },
            },
            properties: {
              healthScore: scan.healthScore ?? null,
              bugCount: scan.bugCount ?? null,
              crossFileCount: scan.crossFileCount ?? null,
            },
            results,
          },
        ],
      }
      return NextResponse.json(sarif)
    }

    // format json — dump terstruktur
    return NextResponse.json({
      generator: 'BugHunter ID v0.12.3',
      generatedAt: new Date().toISOString(),
      summary: {
        fileCount: scan.fileCount ?? (scan.files ?? []).length,
        totalLines: scan.totalLines ?? null,
        healthScore: scan.healthScore ?? null,
        bugCount: scan.bugCount ?? null,
        criticalCount: scan.criticalCount ?? 0,
        highCount: scan.highCount ?? 0,
        mediumCount: scan.mediumCount ?? 0,
        lowCount: scan.lowCount ?? 0,
        crossFileCount: scan.crossFileCount ?? 0,
      },
      files: (scan.files ?? []).map(f => ({
        name: f.name,
        language: f.language ?? null,
        healthScore: f.healthScore ?? null,
        bugCount: f.bugCount ?? (f.bugs ?? []).length,
        bugs: (f.bugs ?? []).map(b => ({
          severity: b.severity ?? null,
          line: b.line ?? null,
          category: b.category ?? null,
          ruleId: b.ruleId ?? null,
          title: b.title ?? null,
          description: b.description ?? null,
          suggestion: b.suggestion ?? null,
        })),
      })),
    })
  } catch (error) {
    console.error('[workspace/export] error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan internal saat mengekspor hasil. Coba lagi.' },
      { status: 500 },
    )
  }
}
