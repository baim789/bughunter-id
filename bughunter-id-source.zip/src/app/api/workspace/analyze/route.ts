import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { db } from '@/lib/db'
import { authOptions } from '@/lib/auth'
import { analyzeWorkspaceFiles, countCrossFileBugs } from '@/lib/detector/workspace'
import { isJsonRequest, validateWorkspaceFiles, MAX_STORABLE_CHARS } from '@/lib/workspace-validate'
import { rateLimit, getClientIp } from '@/lib/rate-limit'
import { emitAgentLog, parseLogRoom } from '@/lib/agent-log'
import type { WorkspaceScanResult } from '@/lib/types'

const RATE_LIMIT = Number(process.env.RATE_LIMIT_WORKSPACE_PER_MIN) || 20

/** Normalisasi daftar aturan yang dinonaktifkan dari body (maks 300 id, tiap id ≤ 64 char). */
function parseDisabledRules(raw: unknown): string[] {
  if (!Array.isArray(raw)) return []
  return raw
    .filter((r): r is string => typeof r === 'string' && r.length > 0 && r.length <= 64)
    .slice(0, 300)
}

/**
 * POST /api/workspace/analyze
 * Body: { files: [{ name, code }, ...] }
 * Memindai SEMUA file sekaligus + lapisan temuan lintas file
 * (import yang tidak cocok, duplikat global, kredensial bersama).
 */
export async function POST(request: NextRequest) {
  try {
    if (!isJsonRequest(request.headers.get('content-type'))) {
      return NextResponse.json({ error: 'Content-Type harus application/json.' }, { status: 415 })
    }
    const rl = rateLimit(`ws-analyze:${getClientIp(request)}`, RATE_LIMIT)
    if (!rl.ok) {
      return NextResponse.json(
        { error: `Terlalu banyak permintaan. Coba lagi dalam ${rl.retryAfter} detik.` },
        { status: 429, headers: { 'retry-after': String(rl.retryAfter) } },
      )
    }

    // Tautkan riwayat pemindaian ke akun (bila sudah masuk) untuk fitur tren kesehatan kode.
    const authSession = await getServerSession(authOptions)
    const userId = typeof authSession?.user?.id === 'string' ? authSession.user.id : null

    const body = await request.json().catch(() => ({}))
    const validation = validateWorkspaceFiles(body)
    if (!validation.ok) {
      return NextResponse.json({ error: validation.error }, { status: validation.status })
    }
    const disabledRules = parseDisabledRules(body.disabledRules)
    const room = parseLogRoom((body as { room?: unknown }).room)

    // Progres real-time per file → kolom Terminal browser (jika layanan socket aktif)
    let opened = false
    const onFileResult = (
      r: { name: string; bugCount: number },
      ms: number,
      index: number,
    ) => {
      if (!room) return
      const events = []
      if (!opened) {
        opened = true
        events.push({ kind: 'open' as const, term: 'scan-server', title: 'pemindai', subtitle: `server · ${validation.files.length} file` })
      }
      events.push({
        kind: 'line' as const,
        term: 'scan-server',
        text: `> [${index + 1}/${validation.files.length}] ${r.name} — ${r.bugCount} temuan (${ms} ms)`,
        tone: (r.bugCount > 0 ? 'warn' : 'info') as 'warn' | 'info',
      })
      emitAgentLog(room, events)
    }

    const results = await analyzeWorkspaceFiles(validation.files, { disabledRules, onFileResult })
    const crossFileCount = countCrossFileBugs(results)

    const totalLines = results.reduce((s, r) => s + r.lineCount, 0)
    const supported = results.filter(r => r.supported)
    const counts = results.reduce(
      (acc, r) => ({
        bugCount: acc.bugCount + r.bugCount,
        critical: acc.critical + r.criticalCount,
        high: acc.high + r.highCount,
        medium: acc.medium + r.mediumCount,
        low: acc.low + r.lowCount,
      }),
      { bugCount: 0, critical: 0, high: 0, medium: 0, low: 0 },
    )
    const healthScore =
      supported.length > 0
        ? Math.round(supported.reduce((s, r) => s + r.healthScore, 0) / supported.length)
        : 100

    // Simpan riwayat; kode ikut disimpan hanya bila totalnya ringan (agar bisa dimuat ulang).
    const storable = validation.totalChars <= MAX_STORABLE_CHARS
    const filesJson = JSON.stringify(
      storable
        ? validation.files.map(f => ({ name: f.name, code: f.code }))
        : results.map(r => ({ name: r.name })),
    )

    const scan = await db.workspaceScan.create({
      data: {
        fileCount: results.length,
        supportedCount: supported.length,
        totalLines,
        bugCount: counts.bugCount,
        criticalCount: counts.critical,
        highCount: counts.high,
        mediumCount: counts.medium,
        lowCount: counts.low,
        healthScore,
        crossFileCount,
        filesJson,
        userId,
      },
    })

    // Ringkasan akhir ke terminal real-time
    if (room && opened) {
      emitAgentLog(room, [
        {
          kind: 'line',
          term: 'scan-server',
          text: `> Lapisan lintas file: ${crossFileCount} temuan lintas file`,
          tone: crossFileCount > 0 ? 'warn' : 'dim',
        },
        {
          kind: 'line',
          term: 'scan-server',
          text: `✓ Selesai — skor kesehatan ${healthScore}/100, ${counts.bugCount} temuan`,
          tone: 'ok',
        },
        { kind: 'status', term: 'scan-server', status: 'done' },
      ])
    }

    const response: WorkspaceScanResult = {
      id: scan.id,
      fileCount: results.length,
      supportedCount: supported.length,
      totalLines,
      bugCount: counts.bugCount,
      criticalCount: counts.critical,
      highCount: counts.high,
      mediumCount: counts.medium,
      lowCount: counts.low,
      healthScore,
      crossFileCount,
      files: results,
      createdAt: scan.createdAt.toISOString(),
    }
    return NextResponse.json({ scan: response })
  } catch (error) {
    console.error('[workspace/analyze] error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan internal saat memindai workspace. Coba lagi.' },
      { status: 500 },
    )
  }
}
