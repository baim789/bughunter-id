import { NextRequest, NextResponse } from 'next/server'
import { applyWorkspaceFixes } from '@/lib/detector/workspace'
import { isJsonRequest, validateWorkspaceFiles } from '@/lib/workspace-validate'
import { rateLimit, getClientIp } from '@/lib/rate-limit'
import { emitAgentLog, parseLogRoom } from '@/lib/agent-log'
import type { WorkspaceFixResponse } from '@/lib/types'

const RATE_LIMIT = Number(process.env.RATE_LIMIT_WORKSPACE_PER_MIN) || 20

/**
 * POST /api/workspace/fix
 * Body: { files: [{ name, code }, ...] }
 * Menerapkan SEMUA perbaikan otomatis yang terbukti aman pada SETIAP
 * file dalam satu operasi (perbaikan komprehensif lintas file).
 * - Tidak pernah menambah/menghapus baris → nomor baris tetap valid.
 * - Temuan lintas file (import, duplikat, kredensial) TIDAK diubah
 *   otomatis karena butuh keputusan desain — diserahkan ke saran.
 * - Tidak menyimpan apa pun ke database.
 */
export async function POST(request: NextRequest) {
  try {
    if (!isJsonRequest(request.headers.get('content-type'))) {
      return NextResponse.json({ error: 'Content-Type harus application/json.' }, { status: 415 })
    }
    const rl = rateLimit(`ws-fix:${getClientIp(request)}`, RATE_LIMIT)
    if (!rl.ok) {
      return NextResponse.json(
        { error: `Terlalu banyak permintaan. Coba lagi dalam ${rl.retryAfter} detik.` },
        { status: 429, headers: { 'retry-after': String(rl.retryAfter) } },
      )
    }

    const body = await request.json().catch(() => ({}))
    const validation = validateWorkspaceFiles(body)
    if (!validation.ok) {
      return NextResponse.json({ error: validation.error }, { status: validation.status })
    }
    const room = parseLogRoom((body as { room?: unknown }).room)

    // Progres real-time per file → kolom Terminal browser
    let opened = false
    const result = applyWorkspaceFixes(validation.files, {
      onFileResult: (r, ms, index) => {
        if (!room) return
        const events = []
        if (!opened) {
          opened = true
          events.push({ kind: 'open' as const, term: 'fix-server', title: 'auto-fix', subtitle: `server · ${validation.files.length} file` })
        }
        events.push({
          kind: 'line' as const,
          term: 'fix-server',
          text: `> [${index + 1}/${validation.files.length}] ${r.name} — ${r.changes.length} perbaikan (${ms} ms)`,
          tone: (r.changes.length > 0 ? 'info' : 'dim') as 'info' | 'dim',
        })
        emitAgentLog(room, events)
      },
    })

    if (room && opened) {
      emitAgentLog(room, [
        {
          kind: 'line',
          term: 'fix-server',
          text: `✓ ${result.fixedCount} perbaikan diterapkan, ${result.skippedCount} dilewati`,
          tone: 'ok',
        },
        { kind: 'status', term: 'fix-server', status: 'done' },
      ])
    }

    const response: WorkspaceFixResponse = {
      ok: true,
      files: result.files,
      fixedCount: result.fixedCount,
      skippedCount: result.skippedCount,
    }
    return NextResponse.json(response)
  } catch (error) {
    console.error('[workspace/fix] error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan internal saat memperbaiki workspace. Coba lagi.' },
      { status: 500 },
    )
  }
}
