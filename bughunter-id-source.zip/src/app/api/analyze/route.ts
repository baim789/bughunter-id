import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import ZAI from 'z-ai-web-dev-sdk'
import { rateLimit, getClientIp } from '@/lib/rate-limit'
import {
  analyzeCode,
  detectLanguage,
  mergeBugs,
  computeHealthScore,
  countBySeverity,
} from '@/lib/detector'
import { SUPPORTED_LANGUAGES, type Bug, type Severity } from '@/lib/types'

export const maxDuration = 120

const AI_TIMEOUT_MS = 90_000
const AI_INIT_TIMEOUT_MS = 30_000
const MAX_CODE_FOR_AI = 6_000
const RATE_LIMIT_ANALYZE = Number(process.env.RATE_LIMIT_ANALYZE_PER_MIN) || 30

/** Normalisasi daftar aturan yang dinonaktifkan dari body (maks 300 id, tiap id ≤ 64 char). */
function parseDisabledRules(raw: unknown): string[] {
  if (!Array.isArray(raw)) return []
  return raw
    .filter((r): r is string => typeof r === 'string' && r.length > 0 && r.length <= 64)
    .slice(0, 300)
}

const SEVERITIES: Severity[] = ['critical', 'high', 'medium', 'low']

interface AiRawBug {
  title?: unknown
  description?: unknown
  severity?: unknown
  line?: unknown
  suggestion?: unknown
  category?: unknown
}

function buildAiPrompt(language: string, code: string): string {
  return [
    `Analisis kode ${language} berikut sebagai senior code reviewer yang sangat teliti.`,
    'Temukan bug logika, celah keamanan, masalah penanganan error, dan pelanggaran best practice yang TIDAK sepele.',
    'Fokus pada masalah nyata yang bisa menyebabkan kegagalan runtime, kerentanan, atau perilaku tidak terduga.',
    '',
    'Aturan jawaban (WAJIB):',
    '- Balas HANYA dengan JSON array, tanpa teks pembuka/penutup, tanpa markdown.',
    '- Setiap elemen adalah objek dengan properti: "title" (string singkat), "description" (penjelasan 1-3 kalimat dalam Bahasa Indonesia), "severity" ("critical"|"high"|"medium"|"low"), "line" (nomor baris integer >= 1), "suggestion" (saran perbaikan konkret dalam Bahasa Indonesia), "category" (satu dari: "Keamanan", "Bug Logika", "Penanganan Error", "Kualitas Kode", "Performa", "Debugging").',
    '- Jika tidak menemukan masalah, balas: []',
    '',
    `Kode (${language}):`,
    '```',
    code,
    '```',
  ].join('\n')
}

function extractJsonArray(text: string): AiRawBug[] {
  const fenced = text.match(/```(?:json)?\s*([\s\S]*?)```/)
  const raw = fenced ? fenced[1] : text
  const start = raw.indexOf('[')
  const end = raw.lastIndexOf(']')
  if (start === -1 || end === -1 || end <= start) {
    throw new Error('AI response does not contain a JSON array')
  }
  const parsed = JSON.parse(raw.slice(start, end + 1))
  if (!Array.isArray(parsed)) throw new Error('AI response is not an array')
  return parsed as AiRawBug[]
}

function normalizeAiBugs(raw: AiRawBug[], maxLine: number): Bug[] {
  const bugs: Bug[] = []
  for (const item of raw) {
    if (typeof item.title !== 'string' || !item.title.trim()) continue
    const severity = SEVERITIES.includes(item.severity as Severity)
      ? (item.severity as Severity)
      : 'medium'
    let line = 1
    if (typeof item.line === 'number' && Number.isFinite(item.line)) {
      line = Math.min(Math.max(Math.round(item.line), 1), maxLine)
    }
    bugs.push({
      id: crypto.randomUUID(),
      source: 'ai',
      title: item.title.trim().slice(0, 200),
      description:
        typeof item.description === 'string' && item.description.trim()
          ? item.description.trim().slice(0, 800)
          : 'AI menemukan potensi masalah pada baris ini.',
      severity,
      line,
      suggestion:
        typeof item.suggestion === 'string' && item.suggestion.trim()
          ? item.suggestion.trim().slice(0, 800)
          : 'Periksa dan perbaiki logika pada baris ini.',
      category:
        typeof item.category === 'string' && item.category.trim()
          ? item.category.trim().slice(0, 60)
          : 'Bug Logika',
    })
  }
  return bugs
}

async function analyzeWithAI(language: string, code: string): Promise<Bug[]> {
  // Inisialisasi SDK juga diberi batas waktu agar request tidak menggantung
  // bila kredensial/jaringan bermasalah.
  const zai = await Promise.race([
    ZAI.create(),
    new Promise<never>((_, reject) =>
      setTimeout(() => reject(new Error('Inisialisasi AI melewati batas waktu')), AI_INIT_TIMEOUT_MS),
    ),
  ])
  const completion = (await Promise.race([
    zai.chat.completions.create({
      messages: [
        {
          role: 'system',
          content:
            'Kamu adalah senior code reviewer. Kamu hanya membalas dengan JSON array yang valid sesuai instruksi. Kamu tidak pernah menambahkan teks lain.',
        },
        { role: 'user', content: buildAiPrompt(language, code.slice(0, MAX_CODE_FOR_AI)) },
      ],
      temperature: 0.2,
    }),
    new Promise<never>((_, reject) =>
      setTimeout(() => reject(new Error('AI analysis timeout')), AI_TIMEOUT_MS),
    ),
  ])) as { choices?: Array<{ message?: { content?: string } }> }

  const content = completion.choices?.[0]?.message?.content ?? ''
  const raw = extractJsonArray(content)
  const maxLine = code.split('\n').length
  return normalizeAiBugs(raw, maxLine)
}

export async function POST(request: NextRequest) {
  try {
    // Anti-CSRF: hanya terima JSON eksplisit. Form/fetch lintas situs dengan
    // content-type text/plain memicu preflight (atau ditolak di sini).
    const contentType = (request.headers.get('content-type') ?? '').toLowerCase()
    if (!contentType.includes('application/json')) {
      return NextResponse.json(
        { error: 'Content-Type harus application/json.' },
        { status: 415 },
      )
    }

    // Rate limit per IP: analisis (terutama mode AI) mahal secara CPU/jaringan.
    const rl = rateLimit(`analyze:${getClientIp(request)}`, RATE_LIMIT_ANALYZE)
    if (!rl.ok) {
      return NextResponse.json(
        { error: `Terlalu banyak permintaan. Coba lagi dalam ${rl.retryAfter} detik.` },
        { status: 429, headers: { 'retry-after': String(rl.retryAfter) } },
      )
    }

    const body = await request.json().catch(() => ({}))
    const code = typeof body.code === 'string' ? body.code : ''
    const requestedLang = typeof body.language === 'string' ? body.language : 'auto'
    const useAI = Boolean(body.useAI)
    const disabledRules = parseDisabledRules(body.disabledRules)

    if (!code.trim()) {
      return NextResponse.json(
        { error: 'Kode tidak boleh kosong. Tempel atau tulis kode terlebih dahulu.' },
        { status: 400 },
      )
    }

    if (code.length > 100_000) {
      return NextResponse.json(
        { error: 'Kode terlalu panjang (maksimal 100.000 karakter).' },
        { status: 400 },
      )
    }

    let language = requestedLang
    if (language === 'auto') {
      const detected = detectLanguage(code)
      if (!detected) {
        return NextResponse.json(
          {
            error:
              'Bahasa tidak dapat dideteksi otomatis. Silakan pilih bahasa secara manual pada dropdown.',
          },
          { status: 400 },
        )
      }
      language = detected
    }

    if (!SUPPORTED_LANGUAGES.includes(language as never)) {
      return NextResponse.json(
        { error: `Bahasa "${language}" tidak didukung.` },
        { status: 400 },
      )
    }

    // 1) rule-based detection (always runs, instant)
    const ruleBugs = analyzeCode(code, language, { disabledRules })

    // 2) AI deep analysis (optional)
    let aiBugs: Bug[] = []
    let aiError: string | null = null
    if (useAI) {
      try {
        aiBugs = await analyzeWithAI(language, code)
      } catch (err) {
        // Detail error hanya ke log server — jangan bocorkan pesan internal
        // (jalur berkas, pesan SDK, kredensial) ke klien.
        console.error('[analyze] AI error:', err)
        aiError =
          'Analisis AI gagal. Hasil di bawah tetap lengkap dari mesin rule-based.'
      }
    }

    const bugs = mergeBugs(ruleBugs, aiBugs)
    const counts = countBySeverity(bugs)
    const healthScore = computeHealthScore(bugs)
    const source = useAI && aiBugs.length > 0 ? 'hybrid' : 'rule'

    const scan = await db.scan.create({
      data: {
        language,
        codeSnippet: code.slice(0, 20_000),
        lineCount: code.split('\n').length,
        bugCount: bugs.length,
        criticalCount: counts.critical,
        highCount: counts.high,
        mediumCount: counts.medium,
        lowCount: counts.low,
        healthScore,
        source,
        aiEnabled: useAI,
        bugsJson: JSON.stringify(bugs),
      },
    })

    return NextResponse.json({
      scan: {
        id: scan.id,
        language,
        lineCount: scan.lineCount,
        bugCount: bugs.length,
        criticalCount: counts.critical,
        highCount: counts.high,
        mediumCount: counts.medium,
        lowCount: counts.low,
        healthScore,
        source,
        aiEnabled: useAI,
        bugs,
        createdAt: scan.createdAt,
      },
      ruleBugCount: ruleBugs.length,
      aiBugCount: aiBugs.length,
      aiError,
    })
  } catch (error) {
    console.error('[analyze] unexpected error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan internal saat menganalisis kode. Coba lagi.' },
      { status: 500 },
    )
  }
}
