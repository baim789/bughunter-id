import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { hashPassword } from '@/lib/auth'
import { rateLimit, getClientIp } from '@/lib/rate-limit'

const RATE_LIMIT = 10

/** POST /api/auth/register — daftar akun { email, password, name? }. */
export async function POST(request: NextRequest) {
  try {
    const rl = rateLimit(`register:${getClientIp(request)}`, RATE_LIMIT)
    if (!rl.ok) {
      return NextResponse.json(
        { error: `Terlalu banyak percobaan. Coba lagi dalam ${rl.retryAfter} detik.` },
        { status: 429 },
      )
    }

    const body = await request.json().catch(() => ({}))
    const email = typeof body.email === 'string' ? body.email.trim().toLowerCase() : ''
    const password = typeof body.password === 'string' ? body.password : ''
    const name = typeof body.name === 'string' ? body.name.trim().slice(0, 60) : ''

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 120) {
      return NextResponse.json({ error: 'Format email tidak valid.' }, { status: 400 })
    }
    if (password.length < 8 || password.length > 128) {
      return NextResponse.json({ error: 'Sandi minimal 8 karakter (maksimal 128).' }, { status: 400 })
    }

    const existing = await db.user.findUnique({ where: { email } })
    if (existing) {
      return NextResponse.json({ error: 'Email sudah terdaftar — silakan masuk.' }, { status: 409 })
    }

    const user = await db.user.create({
      data: { email, name, passwordHash: hashPassword(password) },
      select: { id: true, email: true, name: true },
    })
    return NextResponse.json({ ok: true, user })
  } catch (error) {
    console.error('[auth/register] error:', error)
    return NextResponse.json({ error: 'Gagal mendaftarkan akun. Coba lagi.' }, { status: 500 })
  }
}
