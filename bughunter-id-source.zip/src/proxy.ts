import { NextRequest, NextResponse } from 'next/server'

/**
 * Gerbang keamanan level edge (Next.js 16 "proxy", dulu "middleware").
 * Berlaku untuk semua rute /api/*:
 * - Menolak body berukuran ekstrem (413) SEBELUM server mem-parse JSON,
 *   mencegah pemborosan memori/CPU oleh payload raksasa.
 * - Batas 1,5 MB sudah sangat longgar untuk kode sumber tunggal (batas analisis
 *   200 KB/file + overhead JSON), tetap jauh di bawah bahaya.
 *
 * Catatan: request tanpa header content-length (chunked) lolos gerbang ini dan
 * tetap divalidasi oleh handler (batas 200 KB kode per file).
 */
const MAX_BODY_BYTES = 1_500_000
// Workspace mengirim banyak file sekaligus → batas lebih longgar
// (server tetap memvalidasi ≤200 file, 200 KB/file, 5 juta char total kode;
// 5 jt char × eskapi JSON terburuk 2× + overhead ≈ 11 MB → 24 MB aman).
const MAX_BODY_BYTES_WORKSPACE = 24_000_000
// Laporan PDF membawa daftar temuan (tanpa kode) → batas menengah.
const MAX_BODY_BYTES_REPORT = 4_000_000
// Agen: chat AI mengirim file + scan; simpan sesi mengirim seluruh workspace
// (batas workspace yang sama) → disamakan dengan workspace.
const MAX_BODY_BYTES_AGENT = 24_000_000

export default function proxy(request: NextRequest) {
  if (request.method === 'POST' || request.method === 'PUT' || request.method === 'PATCH') {
    const path = request.nextUrl.pathname
    const isWorkspace = path.startsWith('/api/workspace')
    const isReport = path.startsWith('/api/report')
    const isAgent = path.startsWith('/api/agent')
    const maxBytes = isWorkspace
      ? MAX_BODY_BYTES_WORKSPACE
      : isReport
        ? MAX_BODY_BYTES_REPORT
        : isAgent
          ? MAX_BODY_BYTES_AGENT
          : MAX_BODY_BYTES
    const contentLength = Number(request.headers.get('content-length') ?? '0')
    if (Number.isFinite(contentLength) && contentLength > maxBytes) {
      return NextResponse.json(
        {
          error: `Payload terlalu besar. Maksimal ${(maxBytes / 1_000_000).toFixed(1).replace('.', ',')} MB per permintaan.`,
        },
        { status: 413 },
      )
    }
  }
  return NextResponse.next()
}

export const config = {
  matcher: '/api/:path*',
}
