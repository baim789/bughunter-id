'use client'
/* Pembungkus SessionProvider (next-auth v4 tidak punya "use client" sendiri,
 * sehingga tidak boleh diimpor langsung dari Server Component layout). */

import { SessionProvider as NextAuthProvider } from 'next-auth/react'
import type { ReactNode } from 'react'

export function AppSessionProvider({ children }: { children: ReactNode }) {
  return <NextAuthProvider>{children}</NextAuthProvider>
}
