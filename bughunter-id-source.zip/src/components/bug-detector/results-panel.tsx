'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { toast } from '@/hooks/use-toast'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Separator } from '@/components/ui/separator'
import {
  ShieldCheck,
  Wrench,
  Bot,
  Ruler,
  AlertTriangle,
  Loader2,
  Crosshair,
  Undo2,
  History,
  FileText,
} from 'lucide-react'
import type { AutoFixChange, AutoFixSkip, Bug, ScanResult, Severity } from '@/lib/types'
import { SEVERITY_META, healthVerdict } from '@/lib/severity'
import { FIXABLE_RULE_IDS } from '@/lib/detector/fixers'
import { downloadPdfReport } from '@/lib/report-client'

interface ResultsPanelProps {
  result: ScanResult | null
  analyzing: boolean
  aiError: string | null
  aiNote: string | null
  onSelectLine: (line: number) => void
  fixing: boolean
  canUndo: boolean
  lastFixes: AutoFixChange[]
  lastSkipped: AutoFixSkip[]
  onAutoFixBug: (bug: Bug) => void
  onAutoFixAll: () => void
  onUndoFix: () => void
}

export function isFixableBug(bug: Bug): boolean {
  return Boolean(bug.ruleId && FIXABLE_RULE_IDS.has(bug.ruleId))
}

function ScoreRing({ score }: { score: number }) {
  const verdict = healthVerdict(score)
  const radius = 52
  const circumference = 2 * Math.PI * radius
  const offset = circumference * (1 - score / 100)

  return (
    <div className="relative h-[128px] w-[128px] shrink-0">
      <svg className="h-full w-full -rotate-90" viewBox="0 0 128 128" role="img" aria-label={`Skor kesehatan ${score} dari 100`}>
        <circle cx="64" cy="64" r={radius} fill="none" stroke="#21262d" strokeWidth="10" />
        <circle
          cx="64"
          cy="64"
          r={radius}
          fill="none"
          stroke={verdict.color}
          strokeWidth="10"
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          style={{ transition: 'stroke-dashoffset 0.8s ease, stroke 0.8s ease' }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-3xl font-bold text-[#e6edf3]" style={{ color: verdict.color }}>
          {score}
        </span>
        <span className="text-[10px] uppercase tracking-wider text-[#8b949e]">dari 100</span>
      </div>
    </div>
  )
}

function SeverityChip({ severity, count }: { severity: keyof typeof SEVERITY_META; count: number }) {
  const meta = SEVERITY_META[severity]
  return (
    <div
      className="flex flex-col items-center rounded-lg border px-3 py-2"
      style={{ borderColor: meta.border, backgroundColor: meta.bg }}
    >
      <span className="text-xl font-bold" style={{ color: meta.color }}>
        {count}
      </span>
      <span className="text-[11px] text-[#8b949e]">{meta.label}</span>
    </div>
  )
}

function BugCard({
  bug,
  onSelectLine,
  onAutoFixBug,
  fixing,
  index,
}: {
  bug: Bug
  onSelectLine: (line: number) => void
  onAutoFixBug: (bug: Bug) => void
  fixing: boolean
  index: number
}) {
  const meta = SEVERITY_META[bug.severity]
  const fixable = isFixableBug(bug)
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.25, delay: Math.min(index * 0.04, 0.4) }}
      className="rounded-lg border border-[#30363d] bg-[#0d1117]"
      style={{ borderLeft: `3px solid ${meta.color}` }}
    >
      <div className="flex flex-wrap items-center gap-2 px-3 pt-3">
        <span
          className="rounded px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wide"
          style={{ backgroundColor: meta.bg, color: meta.color, border: `1px solid ${meta.border}` }}
        >
          {meta.label}
        </span>
        <span className="text-sm font-semibold text-[#e6edf3]">{bug.title}</span>
      </div>
      <div className="flex flex-wrap items-center gap-1.5 px-3 pt-2">
        <button
          onClick={() => onSelectLine(bug.line)}
          className="inline-flex items-center gap-1 rounded border border-[#30363d] bg-[#161b22] px-1.5 py-0.5 font-mono text-[11px] text-[#3fb950] transition-colors hover:bg-[#21262d]"
          title="Tampilkan baris ini di editor"
        >
          <Crosshair className="h-3 w-3" />
          Baris {bug.line}
        </button>
        <Badge variant="outline" className="border-[#30363d] bg-transparent text-[10px] text-[#8b949e]">
          {bug.category}
        </Badge>
        {bug.source === 'ai' && (
          <Badge className="border border-[#e3b34133] bg-[#e3b3411a] text-[10px] text-[#e3b341]">
            <Bot className="mr-1 h-3 w-3" />
            AI
          </Badge>
        )}
        {fixable && (
          <Badge className="border border-[#3fb95033] bg-[#3fb9501a] text-[10px] text-[#3fb950]">
            <Wrench className="mr-1 h-3 w-3" />
            Auto-fix aman
          </Badge>
        )}
      </div>
      <p className="px-3 pt-2 text-[13px] leading-relaxed text-[#a8b3bf]">{bug.description}</p>
      <Separator className="mt-3 bg-[#21262d]" />
      <div className="flex flex-wrap gap-2 px-3 py-2.5">
        <Wrench className="mt-0.5 h-3.5 w-3.5 shrink-0 text-[#3fb950]" />
        <div className="min-w-[180px] flex-1">
          <p className="text-[11px] font-semibold uppercase tracking-wide text-[#3fb950]">Saran Perbaikan</p>
          <p className="mt-0.5 text-[13px] leading-relaxed text-[#c9d1d9]">{bug.suggestion}</p>
        </div>
        {fixable && (
          <button
            onClick={() => onAutoFixBug(bug)}
            disabled={fixing}
            className="ml-auto inline-flex h-7 items-center gap-1.5 self-start rounded-md border border-[#2ea04366] bg-[#23863633] px-2.5 text-[11px] font-semibold text-[#3fb950] transition-colors hover:bg-[#23863655] disabled:cursor-not-allowed disabled:opacity-50"
            title="Terapkan perbaikan otomatis yang aman pada baris ini"
          >
            <Wrench className="h-3 w-3" />
            Perbaiki
          </button>
        )}
      </div>
    </motion.div>
  )
}

function FixHistorySection({ changes, skipped }: { changes: AutoFixChange[]; skipped: AutoFixSkip[] }) {
  const truncate = (s: string) => (s.length > 120 ? s.slice(0, 117) + '...' : s)
  return (
    <div className="border-b border-[#30363d] bg-[#0d1117] px-4 py-3">
      <p className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wide text-[#3fb950]">
        <History className="h-3.5 w-3.5" />
        Perbaikan otomatis diterapkan ({changes.length})
      </p>
      <div className="mt-2 space-y-2">
        {changes.map((c, i) => (
          <div key={`${c.line}-${c.ruleId}-${i}`} className="rounded-lg border border-[#30363d] bg-[#161b22] p-2.5">
            <div className="flex flex-wrap items-center gap-1.5">
              <span className="rounded border border-[#30363d] bg-[#0d1117] px-1.5 py-0.5 font-mono text-[11px] text-[#3fb950]">
                Baris {c.line}
              </span>
              <span className="text-[11px] text-[#8b949e]">{c.description}</span>
            </div>
            <div className="mt-1.5 space-y-1 font-mono text-[11px] leading-relaxed">
              <p className="rounded bg-[#f8514914] px-2 py-1 text-[#f85149] line-through decoration-[#f8514966] break-all">
                - {truncate(c.before.trim())}
              </p>
              <p className="rounded bg-[#3fb95014] px-2 py-1 text-[#3fb950] break-all">+ {truncate(c.after.trim())}</p>
            </div>
          </div>
        ))}
        {skipped.map((s, i) => (
          <div key={`skip-${s.line}-${s.ruleId}-${i}`} className="rounded-lg border border-[#f0883e33] bg-[#f0883e0d] p-2.5">
            <p className="text-[11px] leading-relaxed text-[#f0883e]">
              Baris {s.line} dilewati — {s.reason}
            </p>
          </div>
        ))}
      </div>
    </div>
  )
}

export function ResultsPanel({
  result,
  analyzing,
  aiError,
  aiNote,
  onSelectLine,
  fixing,
  canUndo,
  lastFixes,
  lastSkipped,
  onAutoFixBug,
  onAutoFixAll,
  onUndoFix,
}: ResultsPanelProps) {
  const fixableCount = result ? result.bugs.filter(isFixableBug).length : 0
  const [downloadingPdf, setDownloadingPdf] = useState(false)

  const handleDownloadPdf = async () => {
    if (!result || downloadingPdf) return
    setDownloadingPdf(true)
    try {
      await downloadPdfReport(
        {
          kind: 'single',
          title: `Pemindaian ${result.language.toUpperCase()} — ${result.bugCount} temuan`,
          summary: {
            healthScore: result.healthScore,
            bugCount: result.bugCount,
            criticalCount: result.criticalCount,
            highCount: result.highCount,
            mediumCount: result.mediumCount,
            lowCount: result.lowCount,
            totalLines: result.lineCount,
          },
          files: [
            {
              name: `editor.${result.language === 'python' ? 'py' : result.language === 'java' ? 'java' : result.language === 'php' ? 'php' : result.language === 'go' ? 'go' : 'js'}`,
              language: result.language,
              healthScore: result.healthScore,
              bugCount: result.bugCount,
              bugs: (result.bugs as Bug[]).map(b => ({
                severity: b.severity as Severity,
                line: b.line,
                category: b.category,
                title: b.title,
                description: b.description,
                suggestion: b.suggestion,
              })),
            },
          ],
        },
        'bughunter-laporan-editor.pdf',
      )
      toast({ title: 'Laporan PDF diunduh', description: 'Siap dilampirkan ke laporan tim atau dokumentasi.' })
    } catch (err) {
      toast({
        title: 'Gagal membuat laporan PDF',
        description: err instanceof Error ? err.message : undefined,
        variant: 'destructive',
      })
    } finally {
      setDownloadingPdf(false)
    }
  }

  return (
    <Card className="flex h-full flex-col overflow-hidden rounded-xl border-[#30363d] bg-[#161b22]">
      <CardHeader className="border-b border-[#30363d] px-4 py-3">
        <div className="flex items-center justify-between gap-2">
          <CardTitle className="flex items-center gap-2 text-sm font-semibold text-[#e6edf3]">
            <Ruler className="h-4 w-4 text-[#3fb950]" />
            Hasil Analisis
          </CardTitle>
          {result && (
            <button
              onClick={handleDownloadPdf}
              disabled={downloadingPdf}
              className="inline-flex items-center gap-1.5 rounded-md border border-[#58a6ff5c] bg-[#58a6ff1a] px-2.5 py-1 text-[11px] font-semibold text-[#58a6ff] transition-colors hover:bg-[#58a6ff33] disabled:cursor-not-allowed disabled:opacity-60"
              title="Unduh laporan lengkap sebagai PDF"
            >
              {downloadingPdf ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <FileText className="h-3.5 w-3.5" />}
              PDF
            </button>
          )}
        </div>
      </CardHeader>
      <CardContent className="flex-1 p-0">
        {analyzing ? (
          <div className="flex h-full min-h-[320px] flex-col items-center justify-center gap-3 text-[#8b949e]">
            <Loader2 className="h-8 w-8 animate-spin text-[#3fb950]" />
            <p className="text-sm">Memindai kode...</p>
            <p className="text-xs text-[#484f58]">
              {aiNote ?? 'Mesin rule-based sedang memeriksa setiap baris'}
            </p>
          </div>
        ) : !result ? (
          <div className="flex h-full min-h-[320px] flex-col items-center justify-center gap-3 px-8 text-center">
            <ShieldCheck className="h-10 w-10 text-[#30363d]" />
            <p className="text-sm font-medium text-[#8b949e]">Belum ada hasil pemindaian</p>
            <p className="max-w-[280px] text-xs leading-relaxed text-[#484f58]">
              Tempel kode di editor sebelah kiri, pilih bahasa (atau biarkan otomatis), lalu klik
              tombol Pindai Bug. Aktifkan analisis AI untuk pemeriksaan yang lebih mendalam.
            </p>
          </div>
        ) : (
          <div className="flex h-full flex-col">
            {/* summary */}
            <div className="flex flex-wrap items-center gap-4 border-b border-[#30363d] px-4 py-4">
              <ScoreRing score={result.healthScore} />
              <div className="min-w-[180px] flex-1">
                <p className="text-sm font-semibold text-[#e6edf3]">
                  Skor Kesehatan:{' '}
                  <span style={{ color: healthVerdict(result.healthScore).color }}>
                    {healthVerdict(result.healthScore).label}
                  </span>
                </p>
                <p className="mt-0.5 text-xs text-[#8b949e]">
                  {result.bugCount} temuan pada {result.lineCount} baris kode{' '}
                  {result.language.toUpperCase()}
                </p>
                <div className="mt-3 grid grid-cols-4 gap-2">
                  <SeverityChip severity="critical" count={result.criticalCount} />
                  <SeverityChip severity="high" count={result.highCount} />
                  <SeverityChip severity="medium" count={result.mediumCount} />
                  <SeverityChip severity="low" count={result.lowCount} />
                </div>
                {(fixableCount > 0 || canUndo) && (
                  <div className="mt-3 flex flex-wrap items-center gap-2">
                    {fixableCount > 0 && (
                      <button
                        onClick={onAutoFixAll}
                        disabled={fixing || analyzing}
                        className="inline-flex items-center gap-1.5 rounded-md border border-[#2ea04366] bg-[#238636] px-3 py-1.5 text-[11px] font-semibold text-white transition-colors hover:bg-[#2ea043] disabled:cursor-not-allowed disabled:opacity-60"
                        title="Terapkan semua perbaikan otomatis yang aman"
                      >
                        {fixing ? (
                          <Loader2 className="h-3.5 w-3.5 animate-spin" />
                        ) : (
                          <Wrench className="h-3.5 w-3.5" />
                        )}
                        {fixing ? 'Memperbaiki...' : `Perbaiki Otomatis (${fixableCount}) — Aman`}
                      </button>
                    )}
                    {canUndo && (
                      <button
                        onClick={onUndoFix}
                        disabled={fixing || analyzing}
                        className="inline-flex items-center gap-1.5 rounded-md border border-[#30363d] bg-[#21262d] px-3 py-1.5 text-[11px] font-semibold text-[#c9d1d9] transition-colors hover:bg-[#30363d] disabled:cursor-not-allowed disabled:opacity-60"
                        title="Kembalikan kode ke kondisi sebelum auto-fix"
                      >
                        <Undo2 className="h-3.5 w-3.5" />
                        Kembalikan Kode Asli
                      </button>
                    )}
                    <span className="text-[10px] leading-tight text-[#484f58]">
                      Hanya aturan terbukti aman yang diperbaiki · kode asli bisa dikembalikan
                    </span>
                  </div>
                )}
              </div>
            </div>

            {aiError && (
              <div className="flex items-start gap-2 border-b border-[#30363d] bg-[#f0883e1a] px-4 py-2.5">
                <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-[#f0883e]" />
                <p className="text-xs leading-relaxed text-[#f0883e]">{aiError}</p>
              </div>
            )}

            {/* bug list */}
            <ScrollArea className="h-[420px] flex-1">
              {lastFixes.length > 0 && <FixHistorySection changes={lastFixes} skipped={lastSkipped} />}
              <div className="space-y-3 p-4">
                {result.bugs.length === 0 ? (
                  <div className="flex flex-col items-center gap-2 py-12 text-center">
                    <ShieldCheck className="h-10 w-10 text-[#3fb950]" />
                    <p className="text-sm font-semibold text-[#3fb950]">
                      Tidak ada bug yang terdeteksi!
                    </p>
                    <p className="max-w-[300px] text-xs leading-relaxed text-[#8b949e]">
                      Mesin deteksi tidak menemukan pola berbahaya pada kode ini. Untuk hasil lebih
                      menyeluruh, coba aktifkan analisis AI mendalam.
                    </p>
                  </div>
                ) : (
                  result.bugs.map((bug, i) => (
                    <BugCard
                      key={bug.id}
                      bug={bug}
                      index={i}
                      onSelectLine={onSelectLine}
                      onAutoFixBug={onAutoFixBug}
                      fixing={fixing}
                    />
                  ))
                )}
              </div>
            </ScrollArea>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
