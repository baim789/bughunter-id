'use client'

import { forwardRef, useMemo, useRef } from 'react'
import { Button } from '@/components/ui/button'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import { ScanSearch, FileCode2, Eraser, Sparkles } from 'lucide-react'
import { LANGUAGE_LABELS } from '@/lib/types'

const LINE_HEIGHT = 24

interface CodeEditorProps {
  code: string
  onCodeChange: (code: string) => void
  language: string
  onLanguageChange: (lang: string) => void
  useAI: boolean
  onUseAIChange: (v: boolean) => void
  onAnalyze: () => void
  onLoadSample: () => void
  onClear: () => void
  analyzing: boolean
  /** lines to mark in the gutter (1-based) with severity colors */
  markedLines: Map<number, string>
}

export const CodeEditor = forwardRef<HTMLTextAreaElement, CodeEditorProps>(function CodeEditor(
  {
    code,
    onCodeChange,
    language,
    onLanguageChange,
    useAI,
    onUseAIChange,
    onAnalyze,
    onLoadSample,
    onClear,
    analyzing,
    markedLines,
  },
  ref,
) {
  const gutterRef = useRef<HTMLDivElement>(null)
  const lineCount = useMemo(() => Math.max(code.split('\n').length, 1), [code])

  const handleScroll = () => {
    if (ref && typeof ref !== 'function' && ref.current && gutterRef.current) {
      gutterRef.current.scrollTop = ref.current.scrollTop
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Tab') {
      e.preventDefault()
      const el = e.currentTarget
      const start = el.selectionStart
      const end = el.selectionEnd
      const next = code.slice(0, start) + '  ' + code.slice(end)
      onCodeChange(next)
      requestAnimationFrame(() => {
        el.selectionStart = el.selectionEnd = start + 2
      })
    }
  }

  return (
    <div className="flex h-full flex-col overflow-hidden rounded-xl border border-[#30363d] bg-[#0d1117]">
      {/* toolbar */}
      <div className="flex flex-wrap items-center gap-2 border-b border-[#30363d] bg-[#161b22] px-3 py-2.5">
        <div className="flex items-center gap-2 text-[#e6edf3]">
          <FileCode2 className="h-4 w-4 text-[#3fb950]" />
          <span className="text-sm font-semibold">Kode Sumber</span>
        </div>
        <div className="ml-auto flex flex-wrap items-center gap-2">
          <Select value={language} onValueChange={onLanguageChange}>
            <SelectTrigger
              size="sm"
              className="h-8 w-[190px] border-[#30363d] bg-[#0d1117] text-xs text-[#e6edf3]"
              aria-label="Pilih bahasa pemrograman"
            >
              <SelectValue placeholder="Pilih bahasa" />
            </SelectTrigger>
            <SelectContent className="border-[#30363d] bg-[#161b22] text-[#e6edf3]">
              <SelectItem value="auto">{LANGUAGE_LABELS.auto}</SelectItem>
              {Object.entries(LANGUAGE_LABELS)
                .filter(([k]) => k !== 'auto')
                .map(([k, label]) => (
                  <SelectItem key={k} value={k}>
                    {label}
                  </SelectItem>
                ))}
            </SelectContent>
          </Select>
          <Button
            size="sm"
            variant="outline"
            onClick={onLoadSample}
            className="h-8 border-[#30363d] bg-transparent text-xs text-[#8b949e] hover:bg-[#21262d] hover:text-[#e6edf3]"
          >
            Contoh Kode
          </Button>
          <Button
            size="sm"
            variant="outline"
            onClick={onClear}
            className="h-8 border-[#30363d] bg-transparent text-xs text-[#8b949e] hover:bg-[#21262d] hover:text-[#e6edf3]"
          >
            <Eraser className="h-3.5 w-3.5" />
            Bersihkan
          </Button>
        </div>
      </div>

      {/* editor area */}
      <div className="relative flex min-h-[280px] flex-1 overflow-hidden">
        <div
          ref={gutterRef}
          className="w-12 shrink-0 select-none overflow-hidden border-r border-[#30363d] bg-[#161b22] py-3 text-right font-mono text-[13px] leading-[24px] text-[#484f58]"
          aria-hidden="true"
        >
          {Array.from({ length: lineCount }, (_, i) => {
            const num = i + 1
            const color = markedLines.get(num)
            return (
              <div
                key={num}
                className="pr-2"
                style={color ? { color, fontWeight: 600 } : undefined}
              >
                {num}
              </div>
            )
          })}
        </div>
        <textarea
          ref={ref}
          value={code}
          onChange={e => onCodeChange(e.target.value)}
          onScroll={handleScroll}
          onKeyDown={handleKeyDown}
          spellCheck={false}
          autoCapitalize="off"
          autoCorrect="off"
          wrap="off"
          aria-label="Editor kode untuk dianalisis"
          placeholder={"Tempel kode di sini, lalu klik Pindai Bug...\n\nContoh:\nfunction login(user) {\n  if (user.password === '123') { ... }\n}"}
          className="min-h-[280px] flex-1 resize-none bg-[#0d1117] p-3 font-mono text-[13px] leading-[24px] text-[#e6edf3] outline-none placeholder:text-[#484f58]"
        />
      </div>

      {/* footer: AI toggle + analyze */}
      <div className="flex flex-wrap items-center gap-3 border-t border-[#30363d] bg-[#161b22] px-3 py-2.5">
        <div className="flex items-center gap-2">
          <Switch
            id="ai-toggle"
            checked={useAI}
            onCheckedChange={onUseAIChange}
            className="data-[state=checked]:bg-[#238636]"
          />
          <label
            htmlFor="ai-toggle"
            className="flex cursor-pointer items-center gap-1.5 text-xs text-[#8b949e]"
          >
            <Sparkles className="h-3.5 w-3.5 text-[#e3b341]" />
            Analisis AI mendalam (GLM)
          </label>
        </div>
        <span className="text-xs text-[#484f58]">
          {lineCount} baris · {code.length.toLocaleString('id-ID')} karakter
        </span>
        <Button
          onClick={onAnalyze}
          disabled={analyzing || !code.trim()}
          className="ml-auto h-9 gap-2 bg-[#238636] px-4 text-sm font-semibold text-white hover:bg-[#2ea043] disabled:opacity-50"
        >
          {analyzing ? (
            <>
              <span className="h-4 w-4 animate-spin rounded-full border-2 border-white/30 border-t-white" />
              Memindai...
            </>
          ) : (
            <>
              <ScanSearch className="h-4 w-4" />
              Pindai Bug
            </>
          )}
        </Button>
      </div>
    </div>
  )
})
