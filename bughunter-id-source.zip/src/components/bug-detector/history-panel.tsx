'use client'

import { motion } from 'framer-motion'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  History,
  Trash2,
  FolderOpen,
  FolderGit2,
  BarChart3,
  ScanSearch,
  Bug,
  Activity,
  Database,
  Sparkles,
} from 'lucide-react'
import type { HistoryItem, Stats } from '@/lib/types'
import { SEVERITY_META, healthVerdict } from '@/lib/severity'
import { LANGUAGE_LABELS } from '@/lib/types'

interface HistoryPanelProps {
  history: HistoryItem[]
  stats: Stats | null
  loading: boolean
  onLoadScan: (id: string) => void
  onLoadWorkspace: (id: string) => void
  onDeleteScan: (id: string, kind: string) => void
}

function formatDate(iso: string): string {
  return new Date(iso).toLocaleString('id-ID', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  })
}

function StatCard({
  icon: Icon,
  label,
  value,
  color,
}: {
  icon: React.ComponentType<{ className?: string; style?: React.CSSProperties }>
  label: string
  value: string | number
  color: string
}) {
  return (
    <div className="flex items-center gap-3 rounded-lg border border-[#30363d] bg-[#0d1117] px-4 py-3">
      <div
        className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg"
        style={{ backgroundColor: `${color}1a` }}
      >
        <Icon className="h-4.5 w-4.5" style={{ color }} />
      </div>
      <div className="min-w-0">
        <p className="truncate text-[11px] text-[#8b949e]">{label}</p>
        <p className="text-lg font-bold text-[#e6edf3]">{value}</p>
      </div>
    </div>
  )
}

function DistributionBars({
  items,
  colorFn,
}: {
  items: Array<{ label: string; value: number }>
  colorFn: (label: string) => string
}) {
  const max = Math.max(...items.map(i => i.value), 1)
  return (
    <div className="space-y-2.5">
      {items.map(item => (
        <div key={item.label}>
          <div className="mb-1 flex items-center justify-between text-xs">
            <span className="text-[#a8b3bf]">{item.label}</span>
            <span className="font-mono text-[#8b949e]">{item.value}</span>
          </div>
          <div className="h-2 overflow-hidden rounded-full bg-[#0d1117]">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${(item.value / max) * 100}%` }}
              transition={{ duration: 0.6, ease: 'easeOut' }}
              className="h-full rounded-full"
              style={{ backgroundColor: colorFn(item.label) }}
            />
          </div>
        </div>
      ))}
    </div>
  )
}

export function HistoryPanel({ history, stats, loading, onLoadScan, onLoadWorkspace, onDeleteScan }: HistoryPanelProps) {
  const langColor = (lang: string) => {
    const colors: Record<string, string> = {
      javascript: '#f0883e',
      python: '#3fb950',
      java: '#e3b341',
      php: '#8b949e',
      go: '#58a6ff',
    }
    return colors[lang] ?? '#8b949e'
  }

  return (
    <Card className="rounded-xl border-[#30363d] bg-[#161b22]">
      <CardContent className="p-0">
        <Tabs defaultValue="riwayat" className="gap-0">
          <div className="border-b border-[#30363d] px-4 pt-3">
            <TabsList className="h-9 bg-[#0d1117] p-1">
              <TabsTrigger
                value="riwayat"
                className="gap-1.5 px-3 text-xs data-[state=active]:bg-[#21262d] data-[state=active]:text-[#e6edf3]"
              >
                <History className="h-3.5 w-3.5" />
                Riwayat Pemindaian
              </TabsTrigger>
              <TabsTrigger
                value="statistik"
                className="gap-1.5 px-3 text-xs data-[state=active]:bg-[#21262d] data-[state=active]:text-[#e6edf3]"
              >
                <BarChart3 className="h-3.5 w-3.5" />
                Statistik
              </TabsTrigger>
            </TabsList>
          </div>

          {/* history tab */}
          <TabsContent value="riwayat" className="mt-0">
            {loading ? (
              <div className="flex items-center justify-center py-10 text-sm text-[#8b949e]">
                <ScanSearch className="mr-2 h-4 w-4 animate-spin text-[#3fb950]" />
                Memuat riwayat...
              </div>
            ) : history.length === 0 ? (
              <div className="flex flex-col items-center gap-2 py-10 text-center">
                <History className="h-8 w-8 text-[#30363d]" />
                <p className="text-sm text-[#8b949e]">Belum ada riwayat pemindaian</p>
                <p className="text-xs text-[#484f58]">
                  Setiap pemindaian yang kamu jalankan akan tercatat di sini
                </p>
              </div>
            ) : (
              <ScrollArea className="h-[340px]">
                <div className="divide-y divide-[#21262d]">
                  {history.map(item => {
                    const verdict = healthVerdict(item.healthScore)
                    const isWorkspace = item.kind === 'workspace'
                    return (
                      <div
                        key={item.id}
                        className="group flex flex-wrap items-center gap-3 px-4 py-3 transition-colors hover:bg-[#0d1117]"
                      >
                        <div className="min-w-0 flex-1">
                          <div className="flex flex-wrap items-center gap-2">
                            {isWorkspace ? (
                              <span
                                className="inline-flex items-center gap-1 rounded px-1.5 py-0.5 text-[10px] font-bold uppercase"
                                style={{ backgroundColor: '#58a6ff1a', color: '#58a6ff' }}
                              >
                                <FolderGit2 className="h-3 w-3" />
                                Workspace
                              </span>
                            ) : (
                              <span
                                className="rounded px-1.5 py-0.5 text-[10px] font-bold uppercase"
                                style={{
                                  backgroundColor: `${langColor(item.language)}1a`,
                                  color: langColor(item.language),
                                }}
                              >
                                {item.language === 'javascript' ? 'JS/TS' : item.language}
                              </span>
                            )}
                            <span className="max-w-full truncate text-xs text-[#8b949e]">
                              {item.preview || (isWorkspace ? '(workspace)' : '(kode kosong)')}
                            </span>
                          </div>
                          <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-[#484f58]">
                            <span>{formatDate(item.createdAt)}</span>
                            <span
                              className="inline-flex items-center gap-1"
                              style={{ color: item.criticalCount > 0 ? '#f85149' : undefined }}
                            >
                              <Bug className="h-3 w-3" />
                              {item.bugCount} bug
                            </span>
                            <span className="inline-flex items-center gap-1">
                              <Activity className="h-3 w-3" style={{ color: verdict.color }} />
                              skor {item.healthScore}
                            </span>
                            {item.aiEnabled && (
                              <span className="inline-flex items-center gap-1 text-[#e3b341]">
                                <Sparkles className="h-3 w-3" />
                                AI
                              </span>
                            )}
                          </div>
                        </div>
                        <div className="flex gap-1.5 opacity-60 transition-opacity group-hover:opacity-100">
                          {!isWorkspace && (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => onLoadScan(item.id)}
                              className="h-7 gap-1 border-[#30363d] bg-transparent px-2 text-[11px] text-[#8b949e] hover:bg-[#21262d] hover:text-[#e6edf3]"
                            >
                              <FolderOpen className="h-3 w-3" />
                              Muat
                            </Button>
                          )}
                          {isWorkspace && item.restoreable && (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => onLoadWorkspace(item.id)}
                              className="h-7 gap-1 border-[#58a6ff5c] bg-transparent px-2 text-[11px] text-[#58a6ff] hover:bg-[#58a6ff1a]"
                            >
                              <FolderOpen className="h-3 w-3" />
                              Muat
                            </Button>
                          )}
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => onDeleteScan(item.id, item.kind)}
                            className="h-7 gap-1 border-[#30363d] bg-transparent px-2 text-[11px] text-[#8b949e] hover:border-[#f8514955] hover:bg-[#f851491a] hover:text-[#f85149]"
                            aria-label={`Hapus riwayat ${item.id}`}
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                    )
                  })}
                </div>
              </ScrollArea>
            )}
          </TabsContent>

          {/* stats tab */}
          <TabsContent value="statistik" className="mt-0">
            {!stats || stats.totalScans === 0 ? (
              <div className="flex flex-col items-center gap-2 py-10 text-center">
                <BarChart3 className="h-8 w-8 text-[#30363d]" />
                <p className="text-sm text-[#8b949e]">Statistik akan muncul setelah pemindaian pertama</p>
              </div>
            ) : (
              <div className="grid gap-4 p-4 md:grid-cols-2">
                <div className="space-y-3">
                  <div className="grid grid-cols-2 gap-3">
                    <StatCard
                      icon={ScanSearch}
                      label="Total Pemindaian"
                      value={stats.totalScans}
                      color="#3fb950"
                    />
                    <StatCard
                      icon={Bug}
                      label="Total Bug Ditemukan"
                      value={stats.totalBugs}
                      color="#f85149"
                    />
                    <StatCard
                      icon={Activity}
                      label="Rata-rata Skor"
                      value={stats.avgHealth}
                      color="#e3b341"
                    />
                    <StatCard
                      icon={Database}
                      label="Bahasa Dipakai"
                      value={Object.keys(stats.byLanguage).length}
                      color="#8b949e"
                    />
                  </div>
                  <div className="rounded-lg border border-[#30363d] bg-[#0d1117] p-4">
                    <p className="mb-3 flex items-center gap-1.5 text-xs font-semibold text-[#e6edf3]">
                      <Bug className="h-3.5 w-3.5 text-[#f85149]" />
                      Distribusi Severity
                    </p>
                    <DistributionBars
                      items={(Object.keys(SEVERITY_META) as Array<keyof typeof SEVERITY_META>).map(
                        sev => ({
                          label: SEVERITY_META[sev].label,
                          value: stats.bySeverity[sev] ?? 0,
                        }),
                      )}
                      colorFn={label => {
                        const entry = Object.values(SEVERITY_META).find(m => m.label === label)
                        return entry?.color ?? '#8b949e'
                      }}
                    />
                  </div>
                </div>
                <div className="rounded-lg border border-[#30363d] bg-[#0d1117] p-4">
                  <p className="mb-3 flex items-center gap-1.5 text-xs font-semibold text-[#e6edf3]">
                    <Database className="h-3.5 w-3.5 text-[#3fb950]" />
                    Pemindaian per Bahasa
                  </p>
                  <DistributionBars
                    items={Object.entries(stats.byLanguage)
                      .sort((a, b) => b[1] - a[1])
                      .map(([lang, count]) => ({
                        label: LANGUAGE_LABELS[lang] ?? lang,
                        value: count,
                      }))}
                    colorFn={() => '#3fb950'}
                  />
                </div>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}
