'use client'

import { useMemo, useState } from 'react'
import { toast } from '@/hooks/use-toast'
import { Button } from '@/components/ui/button'
import { Checkbox } from '@/components/ui/checkbox'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Settings2, SlidersHorizontal } from 'lucide-react'
import { RULES } from '@/lib/detector/rules'
import { getDisabledRules, setDisabledRules } from '@/lib/rule-settings'

const LANG_LABEL: Record<string, string> = {
  javascript: 'JavaScript / TypeScript',
  python: 'Python',
  java: 'Java',
  php: 'PHP',
  go: 'Go',
}

/**
 * Dialog Pengaturan Aturan: pengguna bisa menonaktifkan aturan tertentu
 * (mis. aturan gaya yang dianggap terlalu rewel). Pilihan disimpan di
 * localStorage dan ikut dikirim ke setiap pemindaian (kedua mode).
 */
export function RulesSettings({ onChanged }: { onChanged?: () => void }) {
  const [open, setOpen] = useState(false)
  const [disabled, setDisabled] = useState<Set<string>>(new Set())

  // Muat pilihan tersimpan setiap kali dialog dibuka (bukan di effect render).
  const handleOpenChange = (next: boolean) => {
    setOpen(next)
    if (next) setDisabled(new Set(getDisabledRules()))
  }

  const totalRules = useMemo(() => Object.values(RULES).reduce((s, list) => s + list.length, 0), [])
  const activeCount = totalRules - disabled.size

  const toggle = (id: string) => {
    setDisabled(prev => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      setDisabledRules([...next]) // simpan langsung agar pilihan bertahan
      onChanged?.()
      return next
    })
  }

  const apply = (next: Set<string>) => {
    setDisabledRules([...next])
    setDisabled(next)
    onChanged?.()
  }

  const enableAll = () => {
    apply(new Set())
    toast({ title: 'Semua aturan diaktifkan kembali' })
  }

  const disableCategories = (category: string) => {
    const next = new Set(disabled)
    for (const list of Object.values(RULES)) {
      for (const r of list) if (r.category === category) next.add(r.id)
    }
    apply(next)
  }

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogTrigger asChild>
        <button
          type="button"
          className="inline-flex items-center gap-1.5 rounded-full border border-[#30363d] bg-[#0d1117] px-2.5 py-1 text-[11px] text-[#8b949e] transition-colors hover:border-[#3fb95055] hover:text-[#e6edf3]"
          aria-label="Buka pengaturan aturan"
        >
          <Settings2 className="h-3.5 w-3.5" />
          Aturan
        </button>
      </DialogTrigger>
      <DialogContent className="max-w-xl border-[#30363d] bg-[#161b22] text-[#e6edf3]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-sm">
            <SlidersHorizontal className="h-4 w-4 text-[#3fb950]" /> Pengaturan Aturan Deteksi
          </DialogTitle>
          <DialogDescription className="text-xs leading-relaxed text-[#8b949e]">
            Nonaktifkan aturan yang tidak relevan untuk proyek Anda (mis. aturan gaya/kualitas).
            Pilihan disimpan di browser ini dan dipakai di Editor Tunggal maupun Workspace.
            Aktif: <span className="font-semibold text-[#3fb950]">{activeCount}/{totalRules}</span> aturan.
          </DialogDescription>
        </DialogHeader>

        <div className="mb-2 flex flex-wrap gap-2">
          <Button size="sm" variant="outline" onClick={enableAll} className="h-7 gap-1 border-[#2ea04366] bg-[#23863633] text-xs text-[#3fb950] hover:bg-[#23863655]">
            Aktifkan Semua
          </Button>
          <div className="flex flex-wrap items-center gap-1.5 text-[11px] text-[#8b949e]">
            <span className="text-[#484f58]">Matikan kategori:</span>
            {['Kualitas Kode', 'Debugging'].map(cat => (
              <button
                key={cat}
                type="button"
                onClick={() => disableCategories(cat)}
                className="rounded border border-[#30363d] bg-[#0d1117] px-2 py-0.5 text-[10px] text-[#8b949e] transition-colors hover:border-[#f8514955] hover:text-[#f85149]"
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        <ScrollArea className="h-[380px] rounded-md border border-[#30363d] bg-[#0d1117]">
          <div className="p-3">
            {Object.entries(RULES).map(([lang, rules]) => {
              const langDisabled = rules.filter(r => disabled.has(r.id)).length
              return (
                <details key={lang} className="mb-2 rounded-md border border-[#21262d]" open={lang === 'javascript'}>
                  <summary className="flex cursor-pointer items-center justify-between px-3 py-2 text-xs font-semibold text-[#e6edf3] [&::-webkit-details-marker]:hidden">
                    <span>{LANG_LABEL[lang] ?? lang}</span>
                    <span className="text-[10px] font-normal text-[#484f58]">
                      {rules.length - langDisabled}/{rules.length} aktif
                    </span>
                  </summary>
                  <div className="space-y-1 border-t border-[#21262d] p-2">
                    {rules.map(rule => (
                      <label
                        key={rule.id}
                        className="flex cursor-pointer items-start gap-2 rounded px-2 py-1.5 hover:bg-[#161b22]"
                      >
                        <Checkbox
                          checked={!disabled.has(rule.id)}
                          onCheckedChange={() => toggle(rule.id)}
                          className="mt-0.5 border-[#30363d] data-[state=checked]:border-[#238636] data-[state=checked]:bg-[#238636]"
                        />
                        <span className="min-w-0">
                          <span className="block text-[11px] leading-snug text-[#e6edf3]">{rule.title}</span>
                          <span className="mt-0.5 block font-mono text-[10px] text-[#484f58]">
                            {rule.id} · {rule.category} · {rule.severity}
                          </span>
                        </span>
                      </label>
                    ))}
                  </div>
                </details>
              )
            })}
          </div>
        </ScrollArea>

        <p className="text-[10px] leading-relaxed text-[#484f58]">
          Tips: untuk mengecualikan satu baris saja, tulis komentar <span className="font-mono text-[#8b949e]">bughunter-ignore</span> di baris tersebut, atau <span className="font-mono text-[#8b949e]">bughunter-ignore-next-line</span> di baris sebelumnya.
        </p>
      </DialogContent>
    </Dialog>
  )
}
