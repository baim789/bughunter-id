'use client'

import { useEffect, useRef, useState } from 'react'
import { toast } from '@/hooks/use-toast'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  FolderGit2,
  FilePlus2,
  Upload,
  Trash2,
  ScanSearch,
  Wand2,
  Undo2,
  Download,
  FileCode2,
  Loader2,
  Network,
  ChevronRight,
  ShieldCheck,
  FileText,
  FileArchive,
  Wrench,
  Lightbulb,
  AlertTriangle,
} from 'lucide-react'
import {
  SEVERITY_META,
  healthVerdict,
} from '@/lib/severity'
import {
  type Severity,
  type Bug,
  type GuidedFixOption,
  type WorkspaceFileInput,
  type WorkspaceScanResult,
  type WorkspaceFixChange,
} from '@/lib/types'
import { WORKSPACE_SAMPLES } from '@/lib/samples'
import { getDisabledRules } from '@/lib/rule-settings'
import { downloadPdfReport } from '@/lib/report-client'

const MAX_FILE_BYTES = 200_000
const MAX_FILES = 200

interface WorkspacePanelProps {
  onScanned: () => void
  /** Permintaan muat ulang file dari riwayat (dengan stamp agar effect terpicu tiap klik). */
  loadRequest?: { files: WorkspaceFileInput[]; stamp: number } | null
}

export function WorkspacePanel({ onScanned, loadRequest }: WorkspacePanelProps) {
  const [files, setFiles] = useState<WorkspaceFileInput[]>([])
  const [selected, setSelected] = useState<string | null>(null)
  const [newFileName, setNewFileName] = useState('')
  const [results, setResults] = useState<WorkspaceScanResult | null>(null)
  const [scanning, setScanning] = useState(false)
  const [fixing, setFixing] = useState(false)
  const [downloading, setDownloading] = useState(false)
  const [canUndo, setCanUndo] = useState(false)
  const [lastFixSummary, setLastFixSummary] = useState<{ changes: WorkspaceFixChange[]; skipped: number } | null>(null)
  // perbaikan berpandu: temuan yang sedang dibuka dialog solusinya
  const [guidedTarget, setGuidedTarget] = useState<{ bug: Bug; fileName: string } | null>(null)
  const [guidedBusy, setGuidedBusy] = useState(false)
  const [sampleOpen, setSampleOpen] = useState(false)

  const preFixFilesRef = useRef<WorkspaceFileInput[]>([])
  const uploadRef = useRef<HTMLInputElement>(null)
  const zipRef = useRef<HTMLInputElement>(null)
  const [downloadingPdf, setDownloadingPdf] = useState(false)

  const selectedFile = files.find(f => f.name === selected) ?? null

  /* ---------- muat ulang dari riwayat ---------- */

  useEffect(() => {
    if (!loadRequest || loadRequest.files.length === 0) return
    setFiles(loadRequest.files)
    setSelected(loadRequest.files[0].name)
    setResults(null)
    setCanUndo(false)
    setLastFixSummary(null)
    preFixFilesRef.current = []
    toast({
      title: 'Workspace dimuat dari riwayat',
      description: `${loadRequest.files.length} file dikembalikan ke editor. Pindai ulang untuk melihat hasil terbaru.`,
    })
  }, [loadRequest])

  /* ---------- kelola file ---------- */

  const addFile = () => {
    if (files.length >= MAX_FILES) {
      toast({ title: `Maksimal ${MAX_FILES} file`, variant: 'destructive' })
      return
    }
    let name = newFileName.trim().replace(/\\/g, '/')
    if (!name) {
      let i = 1
      do {
        name = `file-${i}.js`
        i++
      } while (files.some(f => f.name === name))
    }
    if (files.some(f => f.name === name)) {
      toast({ title: 'Nama file sudah dipakai', description: name, variant: 'destructive' })
      return
    }
    setFiles(prev => [...prev, { name, code: '' }])
    setSelected(name)
    setResults(null)
    setCanUndo(false)
    setLastFixSummary(null)
    setNewFileName('')
  }

  const handleUpload = async (list: FileList | null) => {
    if (!list || list.length === 0) return
    const accepted: WorkspaceFileInput[] = []
    let skipped = 0
    for (const file of Array.from(list)) {
      if (file.size > MAX_FILE_BYTES) {
        skipped++
        continue
      }
      let code = ''
      try {
        code = await file.text()
      } catch {
        skipped++
        continue
      }
      let name = file.name.replace(/\\/g, '/')
      let n = 2
      const taken = new Set([...files.map(f => f.name), ...accepted.map(f => f.name)])
      while (taken.has(name)) {
        const dot = name.lastIndexOf('.')
        name = dot > 0 ? `${name.slice(0, dot)}-${n}${name.slice(dot)}` : `${name}-${n}`
        n++
      }
      accepted.push({ name, code })
    }
    if (accepted.length === 0) {
      toast({
        title: 'Tidak ada file yang bisa dimuat',
        description: `Ukuran maksimal per file ${(MAX_FILE_BYTES / 1000).toFixed(0)} ribu karakter.`,
        variant: 'destructive',
      })
      return
    }
    setFiles(prev => [...prev, ...accepted].slice(0, MAX_FILES))
    setSelected(accepted[0].name)
    setResults(null)
    setCanUndo(false)
    setLastFixSummary(null)
    toast({
      title: `${accepted.length} file dimuat ke workspace`,
      description: skipped > 0 ? `${skipped} file dilewati (terlalu besar atau tidak terbaca).` : 'Klik "Pindai Semua File" untuk mulai memeriksa.',
    })
  }

  /* ---------- unggah ZIP (struktur folder terjaga) ---------- */

  const handleZipUpload = async (file: File | null) => {
    if (!file) return
    setScanning(true)
    try {
      const form = new FormData()
      form.append('file', file)
      const res = await fetch('/api/workspace/upload-zip', { method: 'POST', body: form })
      const data = await res.json()
      if (!res.ok || !data.ok) {
        toast({ title: 'Gagal membuka ZIP', description: data.error, variant: 'destructive' })
        return
      }
      const incoming: WorkspaceFileInput[] = data.files
      const taken = new Set(files.map(f => f.name))
      const accepted: WorkspaceFileInput[] = []
      let renamed = 0
      for (const f of incoming) {
        let name = f.name
        let n = 2
        while (taken.has(name)) {
          const dot = name.lastIndexOf('.')
          name = dot > 0 ? `${name.slice(0, dot)}-${n}${name.slice(dot)}` : `${name}-${n}`
          n++
          renamed++
        }
        taken.add(name)
        accepted.push({ name, code: f.code })
      }
      const room = Math.max(0, MAX_FILES - files.length)
      const finalList = accepted.slice(0, room)
      if (finalList.length === 0) {
        toast({ title: 'Workspace penuh', description: `Maksimal ${MAX_FILES} file.`, variant: 'destructive' })
        return
      }
      setFiles(prev => [...prev, ...finalList])
      setSelected(finalList[0].name)
      setResults(null)
      setCanUndo(false)
      setLastFixSummary(null)
      const parts: string[] = [`${finalList.length} file dimuat (struktur folder terjaga)`]
      const info = data.info as { skippedBinary?: number; skippedJunk?: number; rootStripped?: string | null }
      if (info.rootStripped) parts.push(`folder akar "${info.rootStripped}" dibuang`)
      if (info.skippedBinary) parts.push(`${info.skippedBinary} berkas biner dilewati`)
      if (info.skippedJunk) parts.push(`${info.skippedJunk} sampah sistem dilewati`)
      if (renamed > 0) parts.push(`${renamed} nama diganti (duplikat)`)
      toast({ title: 'ZIP dimuat ke workspace', description: parts.join(' · ') })
    } catch {
      toast({ title: 'Gagal terhubung ke server', variant: 'destructive' })
    } finally {
      setScanning(false)
      if (zipRef.current) zipRef.current.value = ''
    }
  }

  const updateCode = (name: string, code: string) => {
    setFiles(prev => prev.map(f => (f.name === name ? { ...f, code } : f)))
    setCanUndo(false)
  }

  const removeFile = (name: string) => {
    setFiles(prev => prev.filter(f => f.name !== name))
    if (selected === name) setSelected(null)
    setResults(null)
    setCanUndo(false)
  }

  const clearWorkspace = () => {
    setFiles([])
    setSelected(null)
    setResults(null)
    setCanUndo(false)
    setLastFixSummary(null)
    if (uploadRef.current) uploadRef.current.value = ''
  }

  /* ---------- aksi utama ---------- */

  const scanAll = async (fileList?: WorkspaceFileInput[]) => {
    const target = fileList ?? files
    if (target.length === 0) {
      toast({ title: 'Workspace masih kosong', description: 'Tambah atau unggah file terlebih dahulu.', variant: 'destructive' })
      return
    }
    setScanning(true)
    try {
      const res = await fetch('/api/workspace/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ files: target, disabledRules: getDisabledRules() }),
      })
      const data = await res.json()
      if (!res.ok) {
        toast({ title: 'Pemindaian workspace gagal', description: data.error, variant: 'destructive' })
        return
      }
      setResults(data.scan as WorkspaceScanResult)
      toast({
        title: `Pemindaian selesai — ${data.scan.bugCount} bug di ${data.scan.fileCount} file`,
        description:
          data.scan.crossFileCount > 0
            ? `Termasuk ${data.scan.crossFileCount} temuan lintas file yang hanya terlihat saat file dianalisis bersama.`
            : 'Setiap file diperiksa 60+ aturan + keterkaitan antar file.',
      })
      onScanned()
    } catch {
      toast({ title: 'Gagal terhubung ke server', variant: 'destructive' })
    } finally {
      setScanning(false)
    }
  }

  const fixAll = async () => {
    if (fixing || scanning || files.length === 0) return
    setFixing(true)
    try {
      const res = await fetch('/api/workspace/fix', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ files }),
      })
      const data = await res.json()
      if (!res.ok || !data.ok) {
        toast({ title: 'Auto-fix workspace gagal', description: data.error, variant: 'destructive' })
        return
      }
      if (data.fixedCount === 0) {
        toast({
          title: 'Tidak ada perbaikan otomatis yang bisa diterapkan',
          description:
            data.skippedCount > 0
              ? `${data.skippedCount} temuan butuh keputusan manusia — lihat saran perbaikannya.`
              : 'Semua perbaikan yang tersedia sudah diterapkan.',
        })
        return
      }
      preFixFilesRef.current = files.map(f => ({ ...f }))
      const fixedFiles: WorkspaceFileInput[] = data.files.map((f: { name: string; fixedCode: string }) => ({
        name: f.name,
        code: f.fixedCode,
      }))
      setFiles(fixedFiles)
      setCanUndo(true)
      setLastFixSummary({
        changes: (data.files as Array<{ changes: WorkspaceFixChange[] }>).flatMap(f => f.changes),
        skipped: data.skippedCount as number,
      })
      toast({
        title: `${data.fixedCount} perbaikan diterapkan di seluruh workspace`,
        description: 'Semua file diperbarui dan dipindai ulang. Versi asli bisa dikembalikan kapan saja.',
      })
      await scanAll(fixedFiles)
    } catch {
      toast({ title: 'Gagal terhubung ke server', variant: 'destructive' })
    } finally {
      setFixing(false)
    }
  }

  const undoAll = async () => {
    if (preFixFilesRef.current.length === 0) return
    const restored = preFixFilesRef.current
    setFiles(restored)
    setCanUndo(false)
    setLastFixSummary(null)
    toast({ title: 'Kode asli dikembalikan', description: 'Semua perbaikan dibatalkan. Memindai ulang...' })
    await scanAll(restored)
  }

  /* ---------- perbaikan berpandu (lintas file) ---------- */

  const executeGuided = async (option: GuidedFixOption) => {
    if (!guidedTarget || guidedBusy) return
    setGuidedBusy(true)
    try {
      const res = await fetch('/api/workspace/guided-fix', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ files, actions: [option.action] }),
      })
      const data = await res.json()
      if (!res.ok || !data.ok) {
        toast({ title: 'Perbaikan berpandu gagal', description: data.error, variant: 'destructive' })
        return
      }
      const failed = (data.results as Array<{ ok: boolean; reason?: string }>).find(r => !r.ok)
      if (failed) {
        toast({ title: 'Aksi ditolak mesin', description: failed.reason, variant: 'destructive' })
        setGuidedTarget(null)
        return
      }
      const applied = (data.results as Array<{ ok: boolean; description?: string }>).find(r => r.ok)
      preFixFilesRef.current = files.map(f => ({ ...f }))
      const nextFiles: WorkspaceFileInput[] = data.files
      setFiles(nextFiles)
      setCanUndo(true)
      setGuidedTarget(null)
      toast({
        title: 'Perbaikan berpandu diterapkan',
        description:
          (applied?.description ?? 'Selesai.') +
          (data.addedFiles?.length > 0 ? ` Berkas baru: ${data.addedFiles.join(', ')}.` : ''),
      })
      await scanAll(nextFiles)
    } catch {
      toast({ title: 'Gagal terhubung ke server', variant: 'destructive' })
    } finally {
      setGuidedBusy(false)
    }
  }

  /* ---------- contoh workspace bug bandel ---------- */

  const loadSample = (key: string) => {
    const sample = WORKSPACE_SAMPLES[key]
    if (!sample) return
    preFixFilesRef.current = []
    setFiles(sample.files.map(f => ({ ...f })))
    setSelected(sample.files[0].name)
    setResults(null)
    setCanUndo(false)
    setLastFixSummary(null)
    setSampleOpen(false)
    toast({
      title: `Contoh "${sample.label}" dimuat`,
      description: 'Klik Pindai Semua File untuk melihat bug bandel lintas file, lalu coba tombol Perbaiki Berpandu pada temuan biru.',
    })
  }

  const downloadZip = async (mode: 'fixed' | 'original') => {
    if (downloading || files.length === 0) return
    setDownloading(true)
    try {
      const res = await fetch('/api/workspace/download', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ files, mode }),
      })
      if (!res.ok) {
        const data = await res.json().catch(() => ({}))
        toast({ title: 'Gagal membuat ZIP', description: data.error, variant: 'destructive' })
        return
      }
      const blob = await res.blob()
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `bughunter-workspace-${mode}.zip`
      document.body.appendChild(a)
      a.click()
      a.remove()
      URL.revokeObjectURL(url)
      toast({
        title: 'ZIP diunduh',
        description: mode === 'fixed' ? 'Berisi kode hasil perbaikan + laporan perbaikan.' : 'Berisi kode asli sebelum perbaikan.',
      })
    } catch {
      toast({ title: 'Gagal mengunduh', variant: 'destructive' })
    } finally {
      setDownloading(false)
    }
  }

  const downloadPdf = async () => {
    if (!results || downloadingPdf) return
    setDownloadingPdf(true)
    try {
      await downloadPdfReport(
        {
          kind: 'workspace',
          title: `Workspace ${files.length} berkas — ${results.fileCount} berkas dianalisis`,
          summary: {
            healthScore: results.healthScore,
            bugCount: results.bugCount,
            criticalCount: results.criticalCount,
            highCount: results.highCount,
            mediumCount: results.mediumCount,
            lowCount: results.lowCount,
            crossFileCount: results.crossFileCount,
            fileCount: results.fileCount,
            totalLines: results.totalLines,
          },
          files: results.files.map(r => ({
            name: r.name,
            language: r.language,
            healthScore: r.healthScore,
            bugCount: r.bugCount,
            bugs: r.bugs.map(b => ({
              severity: b.severity as Severity,
              line: b.line,
              category: b.category,
              title: b.title,
              description: b.description,
              suggestion: b.suggestion,
              crossFile: b.category === 'Lintas File',
            })),
          })),
        },
        'bughunter-laporan-workspace.pdf',
      )
      toast({ title: 'Laporan PDF diunduh', description: 'Siap dilampirkan ke laporan tim atau dokumentasi.' })
    } catch (err) {
      toast({
        title: 'Gagal membuat laporan PDF',
        description: err instanceof Error ? err.message : undefined,
        variant: 'destructive',
      })
    } finally {
      setDownloadingPdf(false)
    }
  }

  /* ---------- render ---------- */

  const fileColor = (name: string) => {
    const ext = name.split('.').pop()?.toLowerCase()
    const map: Record<string, string> = {
      js: '#f0883e', mjs: '#f0883e', cjs: '#f0883e', jsx: '#f0883e', ts: '#f0883e', tsx: '#f0883e',
      py: '#3fb950', java: '#e3b341', php: '#a371f7', go: '#58a6ff',
    }
    return map[ext ?? ''] ?? '#8b949e'
  }

  return (
    <Card className="rounded-xl border-[#30363d] bg-[#161b22]">
      <CardContent className="p-4 sm:p-5">
        {/* header + toolbar */}
        <div className="mb-4 flex flex-wrap items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg border border-[#58a6ff5c] bg-[#58a6ff1a]">
            <FolderGit2 className="h-5 w-5 text-[#58a6ff]" />
          </div>
          <div className="mr-auto">
            <h3 className="text-sm font-bold text-[#e6edf3]">Workspace Multi-File</h3>
            <p className="text-[11px] text-[#8b949e]">
              Unggah banyak file — dianalisis bersama termasuk keterkaitan antar file, lalu unduh hasil perbaikannya.
            </p>
          </div>
          <input
            value={newFileName}
            onChange={e => setNewFileName(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && addFile()}
            placeholder="nama-file.js"
            className="h-8 w-36 rounded-md border border-[#30363d] bg-[#0d1117] px-2 text-xs text-[#e6edf3] placeholder:text-[#484f58] focus:border-[#3fb95066] focus:outline-none"
            aria-label="Nama file baru"
          />
          <Button size="sm" variant="outline" onClick={addFile} className="h-8 gap-1 border-[#30363d] bg-transparent text-xs text-[#8b949e] hover:bg-[#21262d] hover:text-[#e6edf3]">
            <FilePlus2 className="h-3.5 w-3.5" /> Tambah
          </Button>
          <Button size="sm" variant="outline" onClick={() => uploadRef.current?.click()} className="h-8 gap-1 border-[#30363d] bg-transparent text-xs text-[#8b949e] hover:bg-[#21262d] hover:text-[#e6edf3]">
            <Upload className="h-3.5 w-3.5" /> Unggah File
          </Button>
          <input
            ref={uploadRef}
            type="file"
            multiple
            onChange={e => handleUpload(e.target.files)}
            className="hidden"
            aria-hidden="true"
          />
          <Button size="sm" variant="outline" onClick={() => zipRef.current?.click()} disabled={scanning} className="h-8 gap-1 border-[#30363d] bg-transparent text-xs text-[#8b949e] hover:bg-[#21262d] hover:text-[#e6edf3]">
            {scanning ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <FileArchive className="h-3.5 w-3.5" />} Unggah ZIP
          </Button>
          <input
            ref={zipRef}
            type="file"
            accept=".zip,application/zip,application/x-zip-compressed"
            onChange={e => handleZipUpload(e.target.files?.[0] ?? null)}
            className="hidden"
            aria-hidden="true"
          />
          <Button size="sm" variant="outline" onClick={() => setSampleOpen(true)} className="h-8 gap-1 border-[#f0883e5c] bg-[#f0883e1a] text-xs text-[#f0883e] hover:bg-[#f0883e33]">
            <Lightbulb className="h-3.5 w-3.5" /> Contoh Bug Bandel
          </Button>
          {files.length > 0 && (
            <Button size="sm" variant="outline" onClick={clearWorkspace} className="h-8 gap-1 border-[#30363d] bg-transparent text-xs text-[#8b949e] hover:border-[#f8514955] hover:bg-[#f851491a] hover:text-[#f85149]">
              <Trash2 className="h-3.5 w-3.5" /> Bersihkan
            </Button>
          )}
        </div>

        {files.length === 0 ? (
          <div className="flex flex-col items-center gap-3 rounded-lg border border-dashed border-[#30363d] bg-[#0d1117] py-12 text-center">
            <Upload className="h-10 w-10 text-[#30363d]" />
            <div>
              <p className="text-sm font-medium text-[#8b949e]">Belum ada file di workspace</p>
              <p className="mt-1 text-xs text-[#484f58]">
                Klik <span className="text-[#8b949e]">Unggah ZIP</span> (struktur folder terjaga),{' '}
                <span className="text-[#8b949e]">Unggah File</span> (banyak sekaligus), atau tambah manual.
                <br />
                Mendukung JS/TS, Python, Java, PHP, Go — file lain ikut terkemas di ZIP tanpa dianalisis.
              </p>
            </div>
            <div className="mt-2 flex flex-wrap items-center justify-center gap-2 px-4">
              {Object.entries(WORKSPACE_SAMPLES).map(([key, s]) => (
                <Button
                  key={key}
                  size="sm"
                  variant="outline"
                  onClick={() => loadSample(key)}
                  className="h-8 gap-1.5 border-[#f0883e5c] bg-[#f0883e1a] text-xs text-[#f0883e] hover:bg-[#f0883e33]"
                >
                  <Lightbulb className="h-3.5 w-3.5" /> {s.label}
                </Button>
              ))}
            </div>
          </div>
        ) : (
          <>
            <div className="grid gap-4 lg:grid-cols-[240px_1fr]">
              {/* daftar file */}
              <div className="rounded-lg border border-[#30363d] bg-[#0d1117]">
                <p className="border-b border-[#21262d] px-3 py-2 text-[11px] font-semibold uppercase tracking-wide text-[#484f58]">
                  File ({files.length})
                </p>
                <div className="max-h-64 overflow-y-auto">
                  {files.map(f => {
                    const r = results?.files.find(x => x.name === f.name)
                    return (
                      <button
                        key={f.name}
                        type="button"
                        onClick={() => setSelected(f.name)}
                        className={`flex w-full items-center gap-2 border-b border-[#21262d]/60 px-3 py-2 text-left transition-colors ${
                          selected === f.name ? 'bg-[#161b22]' : 'hover:bg-[#161b22]/60'
                        }`}
                      >
                        <FileCode2 className="h-3.5 w-3.5 shrink-0" style={{ color: fileColor(f.name) }} />
                        <span className="min-w-0 flex-1 truncate text-xs text-[#e6edf3]">{f.name}</span>
                        {r && r.bugCount > 0 && (
                          <span className="shrink-0 rounded px-1.5 text-[10px] font-bold" style={{ backgroundColor: `${SEVERITY_META[r.criticalCount > 0 ? 'critical' : r.highCount > 0 ? 'high' : 'medium'].color}1a`, color: SEVERITY_META[r.criticalCount > 0 ? 'critical' : r.highCount > 0 ? 'high' : 'medium'].color }}>
                            {r.bugCount}
                          </span>
                        )}
                        {r && r.bugCount === 0 && <ShieldCheck className="h-3.5 w-3.5 shrink-0 text-[#3fb950]" />}
                      </button>
                    )
                  })}
                </div>
              </div>

              {/* editor file terpilih */}
              <div className="rounded-lg border border-[#30363d] bg-[#0d1117]">
                <div className="flex items-center justify-between border-b border-[#21262d] px-3 py-2">
                  <span className="truncate font-mono text-xs text-[#8b949e]">
                    {selectedFile ? selectedFile.name : 'Pilih file di kiri'}
                  </span>
                  {selectedFile && (
                    <span className="shrink-0 text-[10px] text-[#484f58]">
                      {selectedFile.code.split('\n').length} baris
                    </span>
                  )}
                </div>
                <textarea
                  value={selectedFile?.code ?? ''}
                  onChange={e => selectedFile && updateCode(selectedFile.name, e.target.value)}
                  disabled={!selectedFile}
                  spellCheck={false}
                  placeholder={selectedFile ? '' : 'Pilih file dari daftar untuk mengedit isinya.'}
                  className="h-64 w-full resize-y bg-transparent p-3 font-mono text-xs leading-relaxed text-[#e6edf3] placeholder:text-[#484f58] focus:outline-none disabled:opacity-50"
                />
              </div>
            </div>

            {/* aksi */}
            <div className="mt-4 flex flex-wrap items-center gap-2">
              <Button size="sm" onClick={() => scanAll()} disabled={scanning || fixing} className="h-8 gap-1.5 bg-[#238636] text-xs text-white hover:bg-[#2ea043]">
                {scanning ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <ScanSearch className="h-3.5 w-3.5" />}
                {scanning ? 'Memindai...' : 'Pindai Semua File'}
              </Button>
              <Button size="sm" variant="outline" onClick={fixAll} disabled={scanning || fixing} className="h-8 gap-1.5 border-[#2ea04366] bg-[#23863633] text-xs text-[#3fb950] hover:bg-[#23863655] hover:text-[#4fd66a]">
                {fixing ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Wand2 className="h-3.5 w-3.5" />}
                Perbaiki Semua (Aman)
              </Button>
              {canUndo && (
                <Button size="sm" variant="outline" onClick={undoAll} disabled={scanning || fixing} className="h-8 gap-1.5 border-[#30363d] bg-transparent text-xs text-[#8b949e] hover:bg-[#21262d] hover:text-[#e6edf3]">
                  <Undo2 className="h-3.5 w-3.5" /> Kembalikan Kode Asli
                </Button>
              )}
              <div className="ml-auto flex flex-wrap gap-2">
                {results && (
                  <Button size="sm" variant="outline" onClick={downloadPdf} disabled={downloadingPdf} className="h-8 gap-1.5 border-[#58a6ff5c] bg-[#58a6ff1a] text-xs text-[#58a6ff] hover:bg-[#58a6ff33]">
                    {downloadingPdf ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <FileText className="h-3.5 w-3.5" />}
                    Unduh Laporan PDF
                  </Button>
                )}
                <Button size="sm" onClick={() => downloadZip('fixed')} disabled={downloading || files.length === 0} className="h-8 gap-1.5 bg-[#238636] text-xs text-white hover:bg-[#2ea043]">
                  {downloading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Download className="h-3.5 w-3.5" />}
                  Unduh ZIP Hasil Perbaikan
                </Button>
                <Button size="sm" variant="outline" onClick={() => downloadZip('original')} disabled={downloading || files.length === 0} className="h-8 gap-1.5 border-[#30363d] bg-transparent text-xs text-[#8b949e] hover:bg-[#21262d] hover:text-[#e6edf3]">
                  <Download className="h-3.5 w-3.5" /> ZIP Asli
                </Button>
              </div>
            </div>

            {/* ringkasan perbaikan terakhir */}
            {lastFixSummary && lastFixSummary.changes.length > 0 && (
              <div className="mt-4 rounded-lg border border-[#2ea04366] bg-[#23863614] p-3">
                <p className="mb-2 flex items-center gap-1.5 text-xs font-semibold text-[#3fb950]">
                  <Wand2 className="h-3.5 w-3.5" /> {lastFixSummary.changes.length} perbaikan otomatis diterapkan
                  {lastFixSummary.skipped > 0 && (
                    <span className="font-normal text-[#8b949e]">· {lastFixSummary.skipped} temuan butuh keputusan manusia</span>
                  )}
                </p>
                <div className="max-h-48 space-y-1.5 overflow-y-auto font-mono text-[11px]">
                  {lastFixSummary.changes.map((c, i) => (
                    <div key={`${c.file}-${c.line}-${i}`} className="rounded border border-[#21262d] bg-[#0d1117] p-2">
                      <p className="mb-1 font-sans text-[10px] text-[#8b949e]">
                        {c.file} · baris {c.line} · {c.ruleId}
                      </p>
                      <p className="whitespace-pre-wrap text-[#f85149]">− {c.before.trim()}</p>
                      <p className="whitespace-pre-wrap text-[#3fb950]">+ {c.after.trim()}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* hasil pemindaian */}
            {results && (
              <div className="mt-4 space-y-3">
                <div className="flex flex-wrap items-center gap-2 rounded-lg border border-[#30363d] bg-[#0d1117] p-3 text-xs">
                  <span className="font-semibold text-[#e6edf3]">{results.fileCount} file</span>
                  <span className="text-[#484f58]">·</span>
                  <span className="text-[#8b949e]">{results.totalLines} baris</span>
                  <span className="text-[#484f58]">·</span>
                  <span className={results.bugCount > 0 ? 'font-semibold text-[#f85149]' : 'text-[#3fb950]'}>
                    {results.bugCount} bug
                  </span>
                  {results.crossFileCount > 0 && (
                    <>
                      <span className="text-[#484f58]">·</span>
                      <Badge variant="outline" className="gap-1 border-[#58a6ff5c] bg-[#58a6ff1a] text-[10px] text-[#58a6ff]">
                        <Network className="h-3 w-3" /> {results.crossFileCount} lintas file
                      </Badge>
                    </>
                  )}
                  <span className="ml-auto inline-flex items-center gap-1.5">
                    <span className="text-[#484f58]">skor rata-rata</span>
                    <span className="font-bold" style={{ color: healthVerdict(results.healthScore).color }}>
                      {results.healthScore}
                    </span>
                  </span>
                </div>

                {results.files.map(r => {
                  const verdict = healthVerdict(r.healthScore)
                  return (
                    <details key={r.name} className="group rounded-lg border border-[#30363d] bg-[#0d1117]">
                      <summary className="flex cursor-pointer flex-wrap items-center gap-2 p-3 text-xs transition-colors hover:bg-[#161b22] [&::-webkit-details-marker]:hidden">
                        <ChevronRight className="h-3.5 w-3.5 text-[#484f58] transition-transform group-open:rotate-90" />
                        <FileCode2 className="h-3.5 w-3.5" style={{ color: fileColor(r.name) }} />
                        <span className="font-mono text-[#e6edf3]">{r.name}</span>
                        {!r.supported && (
                          <Badge variant="outline" className="border-[#30363d] text-[10px] text-[#484f58]">
                            tidak dianalisis
                          </Badge>
                        )}
                        {r.bugs.some(b => b.category === 'Lintas File') && (
                          <Badge variant="outline" className="gap-1 border-[#58a6ff5c] bg-[#58a6ff1a] text-[10px] text-[#58a6ff]">
                            <Network className="h-3 w-3" /> lintas file
                          </Badge>
                        )}
                        <span className="ml-auto flex items-center gap-3">
                          {r.bugCount > 0 ? (
                            <span className="font-semibold text-[#f85149]">{r.bugCount} bug</span>
                          ) : (
                            <span className="inline-flex items-center gap-1 text-[#3fb950]">
                              <ShieldCheck className="h-3.5 w-3.5" /> bersih
                            </span>
                          )}
                          <span style={{ color: verdict.color }}>skor {r.healthScore}</span>
                        </span>
                      </summary>
                      {r.bugs.length > 0 && (
                        <div className="space-y-2 border-t border-[#21262d] p-3">
                          {r.bugs.map(bug => {
                            const meta = SEVERITY_META[bug.severity as Severity]
                            const cross = bug.category === 'Lintas File'
                            return (
                              <div key={bug.id} className="rounded-md border-l-2 bg-[#161b22] p-2.5" style={{ borderColor: meta?.color }}>
                                <div className="mb-1 flex flex-wrap items-center gap-2 text-[10px]">
                                  <span className="rounded px-1.5 py-0.5 font-bold" style={{ backgroundColor: meta?.bg, color: meta?.color }}>
                                    {meta?.label}
                                  </span>
                                  {cross && (
                                    <span className="rounded border border-[#58a6ff5c] bg-[#58a6ff1a] px-1.5 py-0.5 font-bold text-[#58a6ff]">
                                      LINTAS FILE
                                    </span>
                                  )}
                                  <span className="rounded bg-[#21262d] px-1.5 py-0.5 font-mono text-[#8b949e]">baris {bug.line}</span>
                                  <span className="text-[#484f58]">{bug.category}</span>
                                </div>
                                <p className="text-xs font-medium text-[#e6edf3]">{bug.title}</p>
                                <p className="mt-1 text-[11px] leading-relaxed text-[#8b949e]">{bug.description}</p>
                                <p className="mt-1.5 text-[11px] leading-relaxed text-[#3fb950]">Saran: {bug.suggestion}</p>
                                {cross && bug.guidedFixes && bug.guidedFixes.length > 0 && (
                                  <div className="mt-2 flex flex-wrap items-center gap-1.5">
                                    <Button
                                      size="sm"
                                      variant="outline"
                                      onClick={() => setGuidedTarget({ bug, fileName: r.name })}
                                      className="h-7 gap-1.5 border-[#58a6ff5c] bg-[#58a6ff1a] text-[11px] text-[#58a6ff] hover:bg-[#58a6ff33]"
                                    >
                                      <Wrench className="h-3 w-3" />
                                      Perbaiki Berpandu ({bug.guidedFixes.length} solusi)
                                    </Button>
                                  </div>
                                )}
                              </div>
                            )
                          })}
                        </div>
                      )}
                    </details>
                  )
                })}

                <p className="text-center text-[10px] leading-relaxed text-[#484f58]">
                  Perbaikan otomatis hanya menyentuh kelas bug yang terbukti aman (== → ===, var → let, debugger,
                  catch kosong, except Python, == None). Temuan lintas file bisa diperbaiki lewat tombol
                  Perbaiki Berpandu — Anda memilih solusi, mesin mengeksekusi editnya secara deterministik.
                </p>
              </div>
            )}
          </>
        )}

        {/* dialog perbaikan berpandu */}
        <Dialog open={!!guidedTarget} onOpenChange={o => !o && setGuidedTarget(null)}>
          <DialogContent className="max-w-lg border-[#30363d] bg-[#161b22] text-[#e6edf3]">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2 text-sm">
                <Wrench className="h-4 w-4 text-[#58a6ff]" /> Pilih Solusi Perbaikan
              </DialogTitle>
              <DialogDescription className="text-xs text-[#8b949e]">
                {guidedTarget?.fileName} · baris {guidedTarget?.bug.line} — {guidedTarget?.bug.title}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-2">
              {guidedTarget?.bug.guidedFixes?.map(opt => (
                <button
                  key={opt.id}
                  type="button"
                  disabled={guidedBusy}
                  onClick={() => executeGuided(opt)}
                  className="w-full rounded-lg border border-[#30363d] bg-[#0d1117] p-3 text-left transition-colors hover:border-[#58a6ff66] hover:bg-[#161b22] disabled:opacity-50"
                >
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-semibold text-[#e6edf3]">{opt.label}</span>
                    {opt.safe ? (
                      <span className="rounded border border-[#2ea04366] bg-[#23863633] px-1.5 py-0.5 text-[9px] font-bold text-[#3fb950]">AMAN</span>
                    ) : (
                      <span className="inline-flex items-center gap-1 rounded border border-[#bb800966] bg-[#bb800933] px-1.5 py-0.5 text-[9px] font-bold text-[#e3b341]">
                        <AlertTriangle className="h-2.5 w-2.5" /> PERHATIAN
                      </span>
                    )}
                    {guidedBusy && <Loader2 className="ml-auto h-3.5 w-3.5 animate-spin text-[#8b949e]" />}
                  </div>
                  <p className="mt-1.5 text-[11px] leading-relaxed text-[#8b949e]">{opt.detail}</p>
                </button>
              ))}
            </div>
          </DialogContent>
        </Dialog>

        {/* dialog pilih contoh workspace */}
        <Dialog open={sampleOpen} onOpenChange={setSampleOpen}>
          <DialogContent className="max-w-lg border-[#30363d] bg-[#161b22] text-[#e6edf3]">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2 text-sm">
                <Lightbulb className="h-4 w-4 text-[#f0883e]" /> Muat Contoh Bug Bandel
              </DialogTitle>
              <DialogDescription className="text-xs text-[#8b949e]">
                Memilih contoh akan MENGGANTI isi workspace yang sekarang. Lalu klik Pindai Semua File.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-2">
              {Object.entries(WORKSPACE_SAMPLES).map(([key, s]) => (
                <button
                  key={key}
                  type="button"
                  onClick={() => loadSample(key)}
                  className="w-full rounded-lg border border-[#30363d] bg-[#0d1117] p-3 text-left transition-colors hover:border-[#f0883e66] hover:bg-[#161b22]"
                >
                  <p className="text-xs font-semibold text-[#e6edf3]">{s.label}</p>
                  <p className="mt-1 text-[11px] leading-relaxed text-[#8b949e]">{s.description}</p>
                </button>
              ))}
            </div>
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  )
}
