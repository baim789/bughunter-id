'use client'
/* Kerangka utama aplikasi: 3 kolom (Chat | Workspace | Terminal).
 * - Desktop: lebar tiap kolom bisa diperlebar/diperkecil lewat pegangan di
 *   antaranya (react-resizable-panels, posisi tersimpan otomatis).
 * - Mobile (<768px): tampil sebagai tab karena layar sempit. */

import { ChatPanel } from './chat-panel'
import { TerminalPanel } from './terminal-panel'
import { WorkspaceFilesPanel } from './workspace-files-panel'
import { useAgentStore } from '@/lib/agent-store'
import { useIsMobile } from '@/hooks/use-mobile'
import { Bot, FolderGit2, SquareTerminal } from 'lucide-react'
import { ResizableHandle, ResizablePanel, ResizablePanelGroup } from '@/components/ui/resizable'
import { cn } from '@/lib/utils'

function MobileWorkbench() {
  const tab = useAgentStore(s => s.mobileTab)
  const setTab = useAgentStore(s => s.setMobileTab)
  const terminals = useAgentStore(s => s.terminals)
  const files = useAgentStore(s => s.files)
  const running = terminals.filter(t => t.status === 'running').length

  const tabs = [
    { id: 'chat' as const, label: 'Chat', icon: Bot, badge: 0 },
    { id: 'workspace' as const, label: 'Workspace', icon: FolderGit2, badge: 0 },
    { id: 'terminal' as const, label: 'Terminal', icon: SquareTerminal, badge: running },
  ]

  return (
    <div className="flex h-full flex-col">
      <div className="flex shrink-0 border-b border-[#30363d] bg-[#161b22]">
        {tabs.map(t => (
          <button
            key={t.id}
            type="button"
            onClick={() => setTab(t.id)}
            aria-selected={tab === t.id}
            role="tab"
            className={cn(
              'relative flex flex-1 items-center justify-center gap-1.5 py-2.5 text-[12px] font-medium transition-colors',
              tab === t.id ? 'text-[#3fb950]' : 'text-[#8b949e]',
            )}
          >
            <t.icon className="h-4 w-4" />
            {t.label}
            {t.badge > 0 && (
              <span className="rounded-full bg-[#238636] px-1.5 text-[9.5px] font-bold text-white">{t.badge}</span>
            )}
            {tab === t.id && <span className="absolute inset-x-4 bottom-0 h-0.5 rounded-t bg-[#3fb950]" />}
          </button>
        ))}
      </div>
      <div className="min-h-0 flex-1">
        {tab === 'chat' && <ChatPanel />}
        {tab === 'workspace' && <WorkspaceFilesPanel />}
        {tab === 'terminal' && <TerminalPanel />}
      </div>
      <span className="sr-only">{files.length} berkas di workspace</span>
    </div>
  )
}

export function Workbench() {
  const isMobile = useIsMobile()

  if (isMobile) return <MobileWorkbench />

  return (
    <ResizablePanelGroup
      direction="horizontal"
      autoSaveId="bughunter-workbench-v1"
      className="h-full bg-[#0d1117]"
    >
      <ResizablePanel defaultSize={30} minSize={18} maxSize={55}>
        <ChatPanel />
      </ResizablePanel>
      <ResizableHandle
        withHandle
        className="w-1.5 bg-[#21262d] after:bg-[#30363d] hover:after:bg-[#3fb95088] data-[resize-handle-active]:bg-[#21262d] data-[resize-handle-active]:after:bg-[#3fb950]"
        aria-label="Atur lebar kolom Chat"
      />
      <ResizablePanel defaultSize={31} minSize={16} maxSize={55}>
        <WorkspaceFilesPanel />
      </ResizablePanel>
      <ResizableHandle
        withHandle
        className="w-1.5 bg-[#21262d] after:bg-[#30363d] hover:after:bg-[#3fb95088] data-[resize-handle-active]:bg-[#21262d] data-[resize-handle-active]:after:bg-[#3fb950]"
        aria-label="Atur lebar kolom Workspace"
      />
      <ResizablePanel minSize={22}>
        <TerminalPanel />
      </ResizablePanel>
    </ResizablePanelGroup>
  )
}
