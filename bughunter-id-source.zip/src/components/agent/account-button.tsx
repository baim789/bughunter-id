'use client'
/* Tombol akun di header: Masuk / Daftar / Keluar.
 * Sesi agen tersimpan menempel ke akun bila pengguna sedang masuk. */

import { useState } from 'react'
import { signIn, signOut, useSession } from 'next-auth/react'
import { LogIn, LogOut, UserRound } from 'lucide-react'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { useToast } from '@/hooks/use-toast'
import { useAgentStore } from '@/lib/agent-store'

export function AccountButton() {
  const { data: session, status } = useSession()
  const { toast } = useToast()
  const [open, setOpen] = useState(false)
  const [mode, setMode] = useState<'masuk' | 'daftar'>('masuk')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [name, setName] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const initRestore = useAgentStore(s => s.initRestore)
  const resetRestore = useAgentStore(s => s.resetRestoreCheck)

  const user = session?.user as { name?: string | null; email?: string | null } | undefined

  const submit = async () => {
    setError('')
    if (mode === 'daftar') {
      if (password.length < 8) {
        setError('Sandi minimal 8 karakter.')
        return
      }
      setBusy(true)
      try {
        const res = await fetch('/api/auth/register', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email, password, name }),
        })
        const data = await res.json().catch(() => ({}))
        if (!res.ok) {
          setError(String(data.error ?? 'Pendaftaran gagal.'))
          setBusy(false)
          return
        }
        const login = await signIn('credentials', { redirect: false, email, password })
        if (login?.error) {
          setError('Akun dibuat, tetapi masuk gagal — coba tombol Masuk.')
          setBusy(false)
          return
        }
        toast({ title: 'Akun siap', description: `Selamat datang, ${name || email}! Sesi kerja kini tersimpan di akunmu.` })
        setOpen(false)
        setTimeout(() => {
          resetRestoreCheckSafe()
        }, 300)
      } catch {
        setError('Gagal terhubung ke server.')
      }
      setBusy(false)
      return
    }
    // masuk
    setBusy(true)
    try {
      const login = await signIn('credentials', { redirect: false, email, password })
      if (login?.error) {
        setError('Email atau sandi salah (sandi minimal 8 karakter).')
        setBusy(false)
        return
      }
      toast({ title: 'Berhasil masuk', description: 'Sesi agen akan tersimpan di akunmu dan bisa dilanjutkan dari mana saja.' })
      setOpen(false)
      resetRestoreCheckSafe()
    } catch {
      setError('Gagal terhubung ke server.')
    }
    setBusy(false)
  }

  const resetRestoreCheckSafe = () => {
    // setelah masuk, tawarkan daftar sesi milik akun lewat chat
    resetRestore()
    setTimeout(() => void initRestore(), 500)
  }

  if (status === 'loading') {
    return (
      <span className="rounded-full border border-[#30363d] px-2.5 py-1 text-[11px] text-[#8b949e]">…</span>
    )
  }

  if (user) {
    return (
      <div className="flex items-center gap-1.5">
        <span className="inline-flex max-w-[160px] items-center gap-1.5 rounded-full border border-[#3fb9505c] bg-[#3fb9501a] px-2.5 py-1 text-[11px] text-[#3fb950]">
          <UserRound className="h-3.5 w-3.5 shrink-0" />
          <span className="truncate">{user.name || user.email}</span>
        </span>
        <button
          type="button"
          onClick={() => void signOut({ callbackUrl: '/' })}
          title="Keluar dari akun"
          className="rounded-md border border-[#30363d] p-1 text-[#8b949e] transition-colors hover:border-[#f8514966] hover:text-[#f85149]"
        >
          <LogOut className="h-3.5 w-3.5" />
        </button>
      </div>
    )
  }

  return (
    <Dialog open={open} onOpenChange={v => { setOpen(v); if (!v) setError('') }}>
      <DialogTrigger asChild>
        <Button
          size="sm"
          variant="outline"
          className="h-7 gap-1.5 border-[#30363d] bg-transparent px-2.5 text-[11px] text-[#e6edf3] hover:bg-[#21262d] hover:text-[#3fb950]"
        >
          <LogIn className="h-3.5 w-3.5" /> Masuk
        </Button>
      </DialogTrigger>
      <DialogContent className="border-[#30363d] bg-[#161b22] text-[#e6edf3] sm:max-w-[380px]">
        <DialogHeader>
          <DialogTitle className="text-[15px]">{mode === 'masuk' ? 'Masuk ke BugHunter ID' : 'Daftar akun baru'}</DialogTitle>
          <DialogDescription className="text-[12px] text-[#8b949e]">
            {mode === 'masuk'
              ? 'Masuk agar riwayat sesi kerja tersimpan di akunmu — bukan hanya di browser ini.'
              : 'Buat akun gratis: riwayat sesi, file workspace, dan hasil pemindaian menempel ke akunmu.'}
          </DialogDescription>
        </DialogHeader>

        <div className="flex gap-1 rounded-lg border border-[#30363d] p-1 text-[12px]">
          {(['masuk', 'daftar'] as const).map(m => (
            <button
              key={m}
              type="button"
              onClick={() => { setMode(m); setError('') }}
              className={`flex-1 rounded-md px-3 py-1.5 font-medium transition-colors ${mode === m ? 'bg-[#238636] text-white' : 'text-[#8b949e] hover:text-[#e6edf3]'}`}
            >
              {m === 'masuk' ? 'Masuk' : 'Daftar'}
            </button>
          ))}
        </div>

        <div className="grid gap-3">
          {mode === 'daftar' && (
            <div className="grid gap-1.5">
              <Label htmlFor="acct-name" className="text-[12px] text-[#8b949e]">Nama (opsional)</Label>
              <Input id="acct-name" value={name} onChange={e => setName(e.target.value)} placeholder="Nama tampilan"
                className="border-[#30363d] bg-[#0d1117] text-[13px]" maxLength={60} autoComplete="name" />
            </div>
          )}
          <div className="grid gap-1.5">
            <Label htmlFor="acct-email" className="text-[12px] text-[#8b949e]">Email</Label>
            <Input id="acct-email" type="email" value={email} onChange={e => setEmail(e.target.value)}
              placeholder="nama@contoh.id" className="border-[#30363d] bg-[#0d1117] text-[13px]" autoComplete="email" />
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="acct-pass" className="text-[12px] text-[#8b949e]">Sandi</Label>
            <Input id="acct-pass" type="password" value={password} onChange={e => setPassword(e.target.value)}
              onKeyDown={e => { if (e.key === 'Enter') void submit() }}
              placeholder={mode === 'daftar' ? 'Minimal 8 karakter' : 'Sandi akunmu'}
              className="border-[#30363d] bg-[#0d1117] text-[13px]"
              autoComplete={mode === 'daftar' ? 'new-password' : 'current-password'} />
          </div>
          {error && (
            <p role="alert" className="rounded-md border border-[#f8514966] bg-[#f851491a] px-2.5 py-1.5 text-[12px] text-[#f85149]">{error}</p>
          )}
          <Button type="button" disabled={busy || !email || !password} onClick={() => void submit()}
            className="bg-[#238636] text-[13px] text-white hover:bg-[#2ea043]">
            {busy ? 'Memproses…' : mode === 'masuk' ? 'Masuk' : 'Daftar & Masuk'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
