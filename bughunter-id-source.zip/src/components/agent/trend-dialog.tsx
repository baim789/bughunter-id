'use client'

/* Dialog Tren Kesehatan Kode: merangkum riwayat pemindaian workspace dari DB
 * (GET /api/stats/trend) menjadi ringkasan + grafik skor kesehatan vs jumlah
 * temuan. Saat masuk akun, tren hanya milik user tersebut; saat anonim, tren
 * pemindaian anonim. */

import { useCallback, useEffect, useState } from 'react'
import {
  Bar,
  CartesianGrid,
  ComposedChart,
  Line,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts'
import { Activity, FileCode2, Gauge, Loader2, ShieldAlert, TrendingUp, Zap } from 'lucide-react'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { cn } from '@/lib/utils'

interface TrendPoint {
  id: string
  at: string
  healthScore: number
  bugCount: number
  criticalCount: number
  highCount: number
  mediumCount: number
  lowCount: number
  crossFileCount: number
  fileCount: number
}

interface TrendResponse {
  scope: 'saya' | 'anonim'
  summary: {
    total: number
    shown: number
    avgHealth: number | null
    lastScore: number | null
    deltaScore: number | null
    lastBugs: number | null
    lastCritical: number | null
    lastCrossFile: number | null
  }
  points: TrendPoint[]
  error?: string
}

function fmtTime(iso: string): string {
  const d = new Date(iso)
  const p = (n: number) => String(n).padStart(2, '0')
  return `${p(d.getDate())}/${p(d.getMonth() + 1)} ${p(d.getHours())}:${p(d.getMinutes())}`
}

const SCORE_TONE = (s: number) =>
  s >= 80 ? 'text-[#3fb950]' : s >= 55 ? 'text-[#e3b341]' : 'text-[#f85149]'

export function TrendDialog() {
  const [open, setOpen] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [data, setData] = useState<TrendResponse | null>(null)

  const load = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const res = await fetch('/api/stats/trend', { cache: 'no-store' })
      const json = (await res.json()) as TrendResponse
      if (!res.ok) throw new Error(json.error ?? 'Gagal memuat tren.')
      setData(json)
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Gagal memuat tren.')
    } finally {
      setLoading(false)
    }
  }, [])

  // Muat data setiap kali dialog dibuka agar selalu segar.
  useEffect(() => {
    if (open) void load()
  }, [open, load])

  const s = data?.summary
  const chartData = (data?.points ?? []).map(p => ({ ...p, label: fmtTime(p.at) }))

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <button
          type="button"
          className="inline-flex items-center gap-1.5 rounded-full border border-[#30363d] bg-[#0d1117] px-2.5 py-1 text-[11px] text-[#8b949e] transition-colors hover:border-[#3fb95055] hover:text-[#e6edf3]"
          aria-label="Buka tren kesehatan kode"
        >
          <TrendingUp className="h-3.5 w-3.5" />
          Tren
        </button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl border-[#30363d] bg-[#161b22] text-[#e6edf3]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-sm">
            <TrendingUp className="h-4 w-4 text-[#3fb950]" /> Tren Kesehatan Kode
          </DialogTitle>
          <DialogDescription className="text-xs leading-relaxed text-[#8b949e]">
            Perkembangan skor kesehatan &amp; jumlah temuan dari riwayat pemindaian workspace
            {data?.scope === 'saya' ? ' pada akun Anda' : ' (mode anonim'}{data?.scope === 'anonim' ? ' — masuk akun agar tren terkait akun Anda)' : ')'}.
          </DialogDescription>
        </DialogHeader>

        {loading ? (
          <div className="flex h-56 items-center justify-center gap-2 text-sm text-[#8b949e]">
            <Loader2 className="h-4 w-4 animate-spin" /> Memuat tren…
          </div>
        ) : error ? (
          <div className="flex h-56 items-center justify-center gap-2 text-sm text-[#f85149]">
            <ShieldAlert className="h-4 w-4" /> {error}
          </div>
        ) : !s || s.shown === 0 ? (
          <div className="flex h-56 flex-col items-center justify-center gap-2 text-center text-sm text-[#8b949e]">
            <Activity className="h-5 w-5 text-[#484f58]" />
            Belum ada riwayat pemindaian untuk ditampilkan.
            <span className="text-xs">Jalankan &ldquo;pindai workspace&rdquo; terlebih dulu — setiap pemindaian tercatat di sini.</span>
          </div>
        ) : (
          <div className="space-y-3">
            {/* ringkasan */}
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
              <div className="rounded-lg border border-[#30363d] bg-[#0d1117] p-2.5">
                <div className="flex items-center gap-1 text-[10px] uppercase tracking-wide text-[#8b949e]"><FileCode2 className="h-3 w-3" /> Total pemindaian</div>
                <div className="mt-1 text-lg font-bold text-[#e6edf3]">{s.total}</div>
                <div className="text-[10px] text-[#8b949e]">{s.shown} terakhir ditampilkan</div>
              </div>
              <div className="rounded-lg border border-[#30363d] bg-[#0d1117] p-2.5">
                <div className="flex items-center gap-1 text-[10px] uppercase tracking-wide text-[#8b949e]"><Gauge className="h-3 w-3" /> Skor terakhir</div>
                <div className={cn('mt-1 text-lg font-bold', SCORE_TONE(s.lastScore ?? 100))}>
                  {s.lastScore ?? '—'}<span className="text-xs text-[#8b949e]">/100</span>
                </div>
                <div className="text-[10px] text-[#8b949e]">
                  {s.deltaScore === null ? '—' : s.deltaScore > 0 ? `▲ +${s.deltaScore} vs sebelumnya` : s.deltaScore < 0 ? `▼ ${s.deltaScore} vs sebelumnya` : 'stabil vs sebelumnya'}
                </div>
              </div>
              <div className="rounded-lg border border-[#30363d] bg-[#0d1117] p-2.5">
                <div className="flex items-center gap-1 text-[10px] uppercase tracking-wide text-[#8b949e]"><Activity className="h-3 w-3" /> Rata-rata skor</div>
                <div className="mt-1 text-lg font-bold text-[#e6edf3]">{s.avgHealth ?? '—'}<span className="text-xs text-[#8b949e]">/100</span></div>
                <div className="text-[10px] text-[#8b949e]">dari {s.shown} pemindaian</div>
              </div>
              <div className="rounded-lg border border-[#30363d] bg-[#0d1117] p-2.5">
                <div className="flex items-center gap-1 text-[10px] uppercase tracking-wide text-[#8b949e]"><Zap className="h-3 w-3" /> Temuan terakhir</div>
                <div className="mt-1 text-lg font-bold text-[#e3b341]">{s.lastBugs ?? '—'}</div>
                <div className="text-[10px] text-[#8b949e]">{s.lastCrossFile ?? 0} lintas file · {s.lastCritical ?? 0} kritis</div>
              </div>
            </div>

            {/* grafik */}
            <div className="rounded-lg border border-[#30363d] bg-[#0d1117] p-3">
              <div className="mb-1 flex items-center justify-between text-[10.5px] text-[#8b949e]">
                <span className="flex items-center gap-1.5">
                  <span className="inline-block h-1.5 w-4 rounded bg-[#3fb950]" /> Skor kesehatan
                  <span className="ml-2 inline-block h-2.5 w-2.5 rounded-sm bg-[#f851495c]" /> Temuan
                </span>
                <span>{s.shown} titik terakhir</span>
              </div>
              <div className="h-56 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <ComposedChart data={chartData} margin={{ top: 6, right: 2, bottom: 0, left: 2 }}>
                    <CartesianGrid stroke="#21262d" strokeDasharray="3 3" vertical={false} />
                    <XAxis dataKey="label" tick={{ fill: '#8b949e', fontSize: 10 }} tickLine={false} axisLine={{ stroke: '#30363d' }} interval="preserveStartEnd" minTickGap={28} />
                    <YAxis yAxisId="score" domain={[0, 100]} tick={{ fill: '#8b949e', fontSize: 10 }} tickLine={false} axisLine={false} width={28} />
                    <YAxis yAxisId="bugs" orientation="right" allowDecimals={false} tick={{ fill: '#8b949e', fontSize: 10 }} tickLine={false} axisLine={false} width={26} />
                    <Tooltip
                      contentStyle={{ background: '#161b22', border: '1px solid #30363d', borderRadius: 8, fontSize: 11, color: '#e6edf3' }}
                      labelStyle={{ color: '#8b949e' }}
                      cursor={{ stroke: '#30363d' }}
                    />
                    <Bar yAxisId="bugs" dataKey="bugCount" name="Temuan" fill="#f851495c" radius={[2, 2, 0, 0]} maxBarSize={22} />
                    <Line yAxisId="score" type="monotone" dataKey="healthScore" name="Skor kesehatan" stroke="#3fb950" strokeWidth={2} dot={{ r: 2.5, fill: '#3fb950' }} activeDot={{ r: 4 }} />
                  </ComposedChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}
