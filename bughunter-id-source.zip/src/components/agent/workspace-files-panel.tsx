'use client'
/* Kolom 2 — Workspace: menerima file yang diunggah lewat chat (atau lewat tombol
 * di panel ini), menampilkan daftar berkas + badge temuan, pratinjau kode dengan
 * penanda baris bermasalah, dan unduhan hasil kerja (per berkas / ZIP / PDF). */

import { useMemo, useRef, useState } from 'react'
import {
  ChevronDown,
  ChevronRight,
  Code2,
  FileArchive,
  FileCode2,
  FileDown,
  FileText,
  FolderGit2,
  MoreVertical,
  PackagePlus,
  Trash2,
  Upload,
  Workflow,
} from 'lucide-react'
import { useAgentStore } from '@/lib/agent-store'
import { MiniRing } from './mini-ring'
import { WORKSPACE_SAMPLES } from '@/lib/samples'
import { SEVERITY_META } from '@/lib/severity'
import type { Severity, WorkspaceFileInput } from '@/lib/types'
import { cn } from '@/lib/utils'

function langIcon(name: string) {
  const ext = name.split('.').pop()?.toLowerCase() ?? ''
  const color =
    ext === 'py'
      ? '#e3b341'
      : ext === 'json' || ext === 'txt' || ext === 'md'
        ? '#8b949e'
        : ext === 'java'
          ? '#f0883e'
          : ext === 'go'
            ? '#58a6ff'
            : '#3fb950'
  return <FileCode2 className="h-3.5 w-3.5 shrink-0" style={{ color }} />
}

function worstSeverity(counts: { criticalCount: number; highCount: number; mediumCount: number; lowCount: number }): Severity | null {
  if (counts.criticalCount > 0) return 'critical'
  if (counts.highCount > 0) return 'high'
  if (counts.mediumCount > 0) return 'medium'
  if (counts.lowCount > 0) return 'low'
  return null
}

function FilePreview({ file, markedLines }: { file: WorkspaceFileInput; markedLines: Map<number, string> }) {
  const lines = useMemo(() => file.code.split('\n'), [file.code])
  return (
    <div className="mt-1 max-h-64 overflow-auto rounded-lg border border-[#30363d] bg-[#0d1117]">
      <table className="w-full border-collapse font-mono text-[11px] leading-[1.6]">
        <tbody>
          {lines.map((ln, i) => {
            const n = i + 1
            const color = markedLines.get(n)
            return (
              <tr key={n} style={color ? { background: `${color}14` } : undefined}>
                <td className="w-10 select-none border-r border-[#21262d] px-2 text-right align-top text-[#484f58]">
                  {n}
                </td>
                <td className="whitespace-pre px-2 align-top text-[#c9d1d9]" style={color ? { boxShadow: `inset 2px 0 0 ${color}` } : undefined}>
                  {ln || ' '}
                </td>
              </tr>
            )
          })}
        </tbody>
      </table>
    </div>
  )
}

export function WorkspaceFilesPanel() {
  const files = useAgentStore(s => s.files)
  const scan = useAgentStore(s => s.scan)
  const busy = useAgentStore(s => s.busy)
  const addFiles = useAgentStore(s => s.addFiles)
  const loadSample = useAgentStore(s => s.loadSample)
  const clearWorkspace = useAgentStore(s => s.clearWorkspace)
  const dispatch = useAgentStore(s => s.dispatch)
  const handleFiles = useAgentStore(s => s.handleFiles)
  const [expanded, setExpanded] = useState<string | null>(null)
  const fileRef = useRef<HTMLInputElement>(null)
  const zipRef = useRef<HTMLInputElement>(null)

  const resultByName = useMemo(() => {
    const m = new Map<string, (typeof scan.files)[number]>()
    if (scan) for (const r of scan.files) m.set(r.name, r)
    return m
  }, [scan])

  const markedFor = (name: string) => {
    const m = new Map<number, string>()
    const r = resultByName.get(name)
    if (r) for (const b of r.bugs) if (!m.has(b.line)) m.set(b.line, SEVERITY_META[b.severity as Severity]?.color ?? '#f85149')
    return m
  }

  const downloadOne = (f: WorkspaceFileInput) => {
    const blob = new Blob([f.code], { type: 'text/plain;charset=utf-8' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = f.name.split('/').pop() ?? f.name
    document.body.appendChild(a)
    a.click()
    a.remove()
    URL.revokeObjectURL(url)
  }

  /** Unduh workflow GitHub Actions siap pakai (tanpa perlu hasil pemindaian). */
  const downloadCiWorkflow = async () => {
    try {
      const res = await fetch('/api/workspace/ci-workflow')
      if (!res.ok) throw new Error('gagal')
      const blob = await res.blob()
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = 'bughunter-ci.yml'
      document.body.appendChild(a)
      a.click()
      a.remove()
      URL.revokeObjectURL(url)
    } catch {
      window.alert('Gagal mengunduh workflow CI/CD. Coba lagi.')
    }
  }

  return (
    <section aria-label="Workspace berkas" className="flex h-full flex-col bg-[#0d1117]">
      <input
        ref={fileRef}
        type="file"
        multiple
        hidden
        onChange={e => {
          if (e.target.files?.length) void handleFiles(Array.from(e.target.files))
          e.target.value = ''
        }}
      />
      <input
        ref={zipRef}
        type="file"
        accept=".zip"
        hidden
        onChange={e => {
          if (e.target.files?.length) void handleFiles(Array.from(e.target.files))
          e.target.value = ''
        }}
      />

      {/* header kolom */}
      <div className="flex h-10 shrink-0 items-center gap-2 border-b border-[#30363d] bg-[#161b22] px-3">
        <FolderGit2 className="h-4 w-4 text-[#3fb950]" />
        <span className="text-[13px] font-semibold text-[#e6edf3]">Workspace</span>
        <span className="rounded-full border border-[#30363d] px-2 py-0.5 text-[10px] text-[#8b949e]">
          {files.length} berkas
        </span>
        <div className="ml-auto flex items-center gap-1">
          <button
            type="button"
            aria-label="Tambah berkas"
            title="Tambah berkas teks"
            disabled={busy}
            onClick={() => fileRef.current?.click()}
            className="flex h-7 w-7 items-center justify-center rounded-md border border-[#30363d] text-[#8b949e] transition-colors hover:border-[#3fb95066] hover:text-[#3fb950] disabled:opacity-40"
          >
            <PackagePlus className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            aria-label="Unggah ZIP"
            title="Unggah ZIP (struktur folder terjaga)"
            disabled={busy}
            onClick={() => zipRef.current?.click()}
            className="flex h-7 w-7 items-center justify-center rounded-md border border-[#30363d] text-[#8b949e] transition-colors hover:border-[#3fb95066] hover:text-[#3fb950] disabled:opacity-40"
          >
            <Upload className="h-3.5 w-3.5" />
          </button>
          <div className="relative">
            <details className="group">
              <summary
                className="flex h-7 w-7 cursor-pointer list-none items-center justify-center rounded-md border border-[#30363d] text-[#8b949e] transition-colors hover:border-[#3fb95066] hover:text-[#3fb950]"
                aria-label="Menu hasil kerja"
                title="Unduh hasil kerja"
              >
                <MoreVertical className="h-3.5 w-3.5" />
              </summary>
              <div className="absolute right-0 z-30 mt-1 w-60 rounded-lg border border-[#30363d] bg-[#161b22] p-1 shadow-xl">
                <button
                  type="button"
                  disabled={busy || files.length === 0}
                  onClick={() => void dispatch({ type: 'zip', mode: 'fixed' })}
                  className="flex w-full items-center gap-2 rounded-md px-2.5 py-1.5 text-left text-[12px] text-[#e6edf3] hover:bg-[#21262d] disabled:opacity-40"
                >
                  <FileArchive className="h-3.5 w-3.5 text-[#3fb950]" /> Unduh ZIP hasil kerja
                </button>
                <button
                  type="button"
                  disabled={busy || files.length === 0}
                  onClick={() => void dispatch({ type: 'zip', mode: 'original' })}
                  className="flex w-full items-center gap-2 rounded-md px-2.5 py-1.5 text-left text-[12px] text-[#e6edf3] hover:bg-[#21262d] disabled:opacity-40"
                >
                  <FileArchive className="h-3.5 w-3.5 text-[#8b949e]" /> Unduh ZIP kode asli
                </button>
                <button
                  type="button"
                  disabled={busy || !scan}
                  onClick={() => void dispatch({ type: 'pdf' })}
                  className="flex w-full items-center gap-2 rounded-md px-2.5 py-1.5 text-left text-[12px] text-[#e6edf3] hover:bg-[#21262d] disabled:opacity-40"
                >
                  <FileText className="h-3.5 w-3.5 text-[#e3b341]" /> Unduh laporan PDF
                </button>
                <button
                  type="button"
                  disabled={busy}
                  onClick={() => void downloadCiWorkflow()}
                  className="flex w-full items-center gap-2 rounded-md px-2.5 py-1.5 text-left text-[12px] text-[#e6edf3] hover:bg-[#21262d] disabled:opacity-40"
                >
                  <Workflow className="h-3.5 w-3.5 text-[#3fb950]" /> Unduh Workflow CI/CD (YAML)
                </button>
                <div className="my-1 border-t border-[#30363d]" />
                <button
                  type="button"
                  disabled={busy || files.length === 0}
                  onClick={clearWorkspace}
                  className="flex w-full items-center gap-2 rounded-md px-2.5 py-1.5 text-left text-[12px] text-[#f85149] hover:bg-[#f851491a] disabled:opacity-40"
                >
                  <Trash2 className="h-3.5 w-3.5" /> Kosongkan workspace
                </button>
              </div>
            </details>
          </div>
        </div>
      </div>

      {/* ringkasan pemindaian */}
      {scan && (
        <div className="flex shrink-0 items-center gap-3 border-b border-[#30363d] bg-[#0d1117] px-3 py-2">
          <div className="relative shrink-0">
            <MiniRing value={scan.healthScore} size={38} stroke={3.5} />
            <span className="absolute inset-0 flex items-center justify-center text-[9.5px] font-bold text-[#e6edf3]">
              {scan.healthScore}
            </span>
          </div>
          <div className="min-w-0 flex-1 text-[10.5px] leading-snug text-[#8b949e]">
            <p>
              Skor kesehatan <span className="font-semibold text-[#e6edf3]">{scan.healthScore}/100</span> ·{' '}
              {scan.bugCount} temuan
            </p>
            <p className="flex flex-wrap gap-x-2">
              {scan.crossFileCount > 0 && <span className="text-[#d2a8ff]">{scan.crossFileCount} lintas file</span>}
              {scan.criticalCount > 0 && <span className="text-[#f85149]">{scan.criticalCount} kritis</span>}
              {scan.highCount > 0 && <span className="text-[#f0883e]">{scan.highCount} tinggi</span>}
            </p>
          </div>
        </div>
      )}

      {/* daftar berkas */}
      <div className="min-h-0 flex-1 overflow-y-auto">
        {files.length === 0 ? (
          <div className="flex h-full flex-col items-center justify-center gap-3 px-6 text-center">
            <FolderGit2 className="h-8 w-8 text-[#30363d]" />
            <p className="text-[12.5px] font-medium text-[#484f58]">Workspace masih kosong</p>
            <p className="max-w-[260px] text-[11px] leading-relaxed text-[#484f58]">
              File yang kamu unggah lewat chat akan muncul di sini. Atau muat contoh proyek penuh bug bandel:
            </p>
            <div className="flex w-full max-w-[260px] flex-col gap-1.5">
              {Object.entries(WORKSPACE_SAMPLES).map(([key, s]) => (
                <button
                  key={key}
                  type="button"
                  disabled={busy}
                  onClick={() => loadSample(key)}
                  className="rounded-lg border border-[#30363d] bg-[#161b22] px-3 py-2 text-left text-[11.5px] text-[#e6edf3] transition-colors hover:border-[#3fb95066] disabled:opacity-40"
                >
                  <span className="block font-medium">{s.label}</span>
                  <span className="mt-0.5 block text-[10px] leading-snug text-[#8b949e]">{s.description}</span>
                </button>
              ))}
            </div>
          </div>
        ) : (
          <ul className="divide-y divide-[#21262d]">
            {files.map(f => {
              const r = resultByName.get(f.name)
              const sev = r ? worstSeverity(r) : null
              const bugCount = r?.bugCount ?? 0
              const isOpen = expanded === f.name
              return (
                <li key={f.name}>
                  <div
                    className={cn(
                      'flex items-center gap-1.5 px-2 py-1.5 transition-colors',
                      isOpen ? 'bg-[#161b22]' : 'hover:bg-[#161b22aa]',
                    )}
                  >
                    <button
                      type="button"
                      onClick={() => setExpanded(isOpen ? null : f.name)}
                      className="flex min-w-0 flex-1 items-center gap-1.5 text-left"
                      aria-expanded={isOpen}
                    >
                      {isOpen ? (
                        <ChevronDown className="h-3.5 w-3.5 shrink-0 text-[#8b949e]" />
                      ) : (
                        <ChevronRight className="h-3.5 w-3.5 shrink-0 text-[#484f58]" />
                      )}
                      {langIcon(f.name)}
                      <span className="truncate font-mono text-[12px] text-[#e6edf3]" title={f.name}>
                        {f.name}
                      </span>
                      {bugCount > 0 && sev && (
                        <span
                          className="ml-auto shrink-0 rounded-full border px-1.5 py-px text-[9.5px] font-bold"
                          style={{
                            color: SEVERITY_META[sev].color,
                            borderColor: SEVERITY_META[sev].border,
                            background: SEVERITY_META[sev].bg,
                          }}
                          title={`${bugCount} temuan`}
                        >
                          {bugCount}
                        </span>
                      )}
                      {r && r.category && bugCount === 0 && (
                        <span className="ml-auto shrink-0 rounded-full border border-[#2ea04366] bg-[#23863626] px-1.5 py-px text-[9.5px] text-[#3fb950]">
                          bersih
                        </span>
                      )}
                    </button>
                    <button
                      type="button"
                      aria-label={`Unduh ${f.name}`}
                      title="Unduh berkas ini"
                      onClick={() => downloadOne(f)}
                      className="flex h-6 w-6 shrink-0 items-center justify-center rounded-md text-[#484f58] transition-colors hover:bg-[#21262d] hover:text-[#3fb950]"
                    >
                      <FileDown className="h-3.5 w-3.5" />
                    </button>
                  </div>
                  {isOpen && (
                    <div className="px-2 pb-2">
                      <FilePreview file={f} markedLines={markedFor(f.name)} />
                      <p className="mt-1 flex items-center gap-1 text-[10px] text-[#484f58]">
                        <Code2 className="h-3 w-3" /> {f.code.split('\n').length} baris
                        {r ? ` · ${r.language} · skor ${r.healthScore}` : ' · belum dipindai'}
                      </p>
                    </div>
                  )}
                </li>
              )
            })}
          </ul>
        )}
      </div>
    </section>
  )
}
