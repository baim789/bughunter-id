'use client'
/* Kolom 3 — Terminal: tempat agen bekerja. Jumlah terminal fleksibel sesuai
 * kompleksitas bug — bug lintas file membuka beberapa terminal paralel,
 * satu per berkas/solusi yang dikerjakan bersamaan. */

import { useEffect, useRef } from 'react'
import { CheckCircle2, Loader2, SquareTerminal, Trash2, X, XCircle } from 'lucide-react'
import { useAgentStore, type Tone } from '@/lib/agent-store'
import { cn } from '@/lib/utils'

const TONE_CLASS: Record<Tone, string> = {
  cmd: 'font-semibold text-[#e6edf3]',
  ok: 'text-[#3fb950]',
  warn: 'text-[#e3b341]',
  err: 'text-[#f85149]',
  info: 'text-[#a8b3bf]',
  dim: 'text-[#484f58]',
}

function StatusIcon({ status }: { status: 'running' | 'done' | 'error' }) {
  if (status === 'running') return <Loader2 className="h-3 w-3 animate-spin text-[#e3b341]" />
  if (status === 'done') return <CheckCircle2 className="h-3 w-3 text-[#3fb950]" />
  return <XCircle className="h-3 w-3 text-[#f85149]" />
}

export function TerminalPanel() {
  const terminals = useAgentStore(s => s.terminals)
  const activeId = useAgentStore(s => s.activeTerminalId)
  const setActive = useAgentStore(s => s.setActiveTerminal)
  const closeTerminal = useAgentStore(s => s.closeTerminal)
  const clearFinished = useAgentStore(s => s.clearFinishedTerminals)
  const scrollRef = useRef<HTMLDivElement>(null)

  const active = terminals.find(t => t.id === activeId) ?? terminals[terminals.length - 1] ?? null
  const runningCount = terminals.filter(t => t.status === 'running').length
  const finishedCount = terminals.length - runningCount

  useEffect(() => {
    const el = scrollRef.current
    if (el) el.scrollTop = el.scrollHeight
  }, [active?.lines.length, active?.id])

  return (
    <section aria-label="Terminal kerja agen" className="flex h-full flex-col bg-[#0d1117]">
      {/* header kolom */}
      <div className="flex h-10 shrink-0 items-center gap-2 border-b border-[#30363d] bg-[#161b22] px-3">
        <SquareTerminal className="h-4 w-4 text-[#3fb950]" />
        <span className="text-[13px] font-semibold text-[#e6edf3]">Terminal</span>
        {runningCount > 1 && (
          <span className="inline-flex items-center gap-1 rounded-full border border-[#e3b34166] bg-[#e3b3411a] px-2 py-0.5 text-[10px] font-medium text-[#e3b341]">
            <Loader2 className="h-3 w-3 animate-spin" /> {runningCount} paralel
          </span>
        )}
        <div className="ml-auto flex items-center gap-1.5">
          {finishedCount > 0 && (
            <button
              type="button"
              onClick={clearFinished}
              title="Tutup terminal yang sudah selesai"
              className="inline-flex items-center gap-1 rounded-md border border-[#30363d] px-1.5 py-0.5 text-[10px] text-[#8b949e] transition-colors hover:border-[#f8514966] hover:text-[#f85149]"
            >
              <Trash2 className="h-3 w-3" /> bersihkan {finishedCount}
            </button>
          )}
          <span className="text-[10px] text-[#484f58]">{terminals.length} sesi</span>
        </div>
      </div>

      {/* tab terminal */}
      {terminals.length > 0 && (
        <div className="flex shrink-0 items-center gap-1 overflow-x-auto border-b border-[#30363d] bg-[#0d1117] px-2 py-1.5">
          {terminals.map(t => (
            <div
              key={t.id}
              className={cn(
                'group flex max-w-[220px] shrink-0 items-center gap-1.5 rounded-md border px-2 py-1 text-[11px] transition-colors',
                active?.id === t.id
                  ? 'border-[#3fb95066] bg-[#23863626] text-[#e6edf3]'
                  : 'border-[#30363d] bg-[#161b22] text-[#8b949e] hover:text-[#e6edf3]',
              )}
            >
              <button type="button" onClick={() => setActive(t.id)} className="flex min-w-0 items-center gap-1.5">
                <StatusIcon status={t.status} />
                <span className="truncate font-mono">{t.title}</span>
              </button>
              <button
                type="button"
                aria-label={`Tutup terminal ${t.title}`}
                onClick={() => closeTerminal(t.id)}
                className="rounded p-0.5 text-[#484f58] transition-colors hover:bg-[#f851491a] hover:text-[#f85149]"
              >
                <X className="h-3 w-3" />
              </button>
            </div>
          ))}
        </div>
      )}

      {/* isi terminal aktif */}
      {active ? (
        <div ref={scrollRef} className="min-h-0 flex-1 overflow-y-auto p-3">
          <div className="mb-2 flex items-center gap-2 text-[10.5px] text-[#484f58]">
            <StatusIcon status={active.status} />
            <span className="font-mono">
              {active.title}
              {active.subtitle ? ` — ${active.subtitle}` : ''}
            </span>
            <span className="ml-auto rounded border border-[#30363d] px-1.5 py-px">
              {active.status === 'running' ? 'BERJALAN' : active.status === 'done' ? 'SELESAI' : 'GAGAL'}
            </span>
          </div>
          <div className="font-mono text-[11.5px] leading-[1.7]">
            {active.lines.map((ln, i) => (
              <p key={i} className={cn('whitespace-pre-wrap break-words', TONE_CLASS[ln.tone])}>
                {ln.text}
              </p>
            ))}
            {active.status === 'running' && (
              <p className="mt-1 text-[#3fb950]">
                ▍<span className="animate-pulse" />
              </p>
            )}
          </div>
        </div>
      ) : (
        <div className="flex min-h-0 flex-1 flex-col items-center justify-center gap-2 px-6 text-center">
          <SquareTerminal className="h-8 w-8 text-[#30363d]" />
          <p className="text-[12.5px] font-medium text-[#484f58]">Belum ada sesi terminal</p>
          <p className="max-w-[280px] text-[11px] leading-relaxed text-[#484f58]">
            Terminal terbuka otomatis saat agen bekerja. Bug lintas file membuka beberapa terminal sekaligus —
            setiap berkas dikerjakan paralel oleh agen masing-masing.
          </p>
        </div>
      )}
    </section>
  )
}
