'use client'
/* Kolom 1 — Chat: percakapan pengguna dengan agen, unggah file (klip/seret),
 * notifikasi proses kerja sistem, dan tombol opsi persetujuan di dalam chat. */

import { useEffect, useRef, useState } from 'react'
import {
  Bot,
  Check,
  FileArchive,
  FileDiff,
  Loader2,
  MessageSquare,
  Paperclip,
  SendHorizonal,
  Sparkles,
  User,
} from 'lucide-react'
import { useAgentStore, PHASE_LABEL, type ChatMessage, type ChatOption, type DiffPreview } from '@/lib/agent-store'
import { MiniRing } from './mini-ring'
import { SEVERITY_META } from '@/lib/severity'
import type { Severity } from '@/lib/types'
import { cn } from '@/lib/utils'

const QUICK_CHIPS = ['Pindai workspace', 'Perbaiki semua bug aman', 'Jelaskan temuan teratas', 'Ekspor SARIF (CI/CD)', 'Unduh Workflow CI', 'Unduh laporan PDF', 'Bantuan']

function formatTime(ts: number) {
  try {
    return new Date(ts).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
  } catch {
    return ''
  }
}

function SeverityChip({ severity, count }: { severity: Severity; count: number }) {
  if (count === 0) return null
  const meta = SEVERITY_META[severity]
  return (
    <span
      className="inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[10.5px] font-medium"
      style={{ color: meta.color, borderColor: meta.border, background: meta.bg }}
    >
      {meta.label}: {count}
    </span>
  )
}

function OptionButtons({ msg }: { msg: ChatMessage }) {
  const chosen = useAgentStore(s => s.chosen)
  const chooseOption = useAgentStore(s => s.chooseOption)
  const busy = useAgentStore(s => s.busy)
  const picked = chosen[msg.id]
  return (
    <div className="mt-2 flex flex-col gap-1.5">
      {(msg.options ?? []).map(opt => {
        const isChosen = picked === opt.id
        const disabled = Boolean(picked) || (busy && !isChosen)
        return (
          <button
            key={opt.id}
            type="button"
            disabled={disabled}
            onClick={() => chooseOption(msg.id, opt.id)}
            className={cn(
              'flex w-full flex-col items-start gap-0.5 rounded-lg border px-3 py-2 text-left transition-colors',
              isChosen
                ? 'border-[#3fb95066] bg-[#23863626] ring-1 ring-[#3fb95044]'
                : 'border-[#30363d] bg-[#0d1117] hover:border-[#3fb95066] hover:bg-[#161b22]',
              disabled && !isChosen && 'pointer-events-none opacity-40',
            )}
          >
            <span className="flex flex-wrap items-center gap-2 text-[13px] font-medium text-[#e6edf3]">
              {isChosen && <Check className="h-3.5 w-3.5 shrink-0 text-[#3fb950]" />}
              {opt.label}
              {opt.badge && (
                <span
                  className={cn(
                    'rounded-full border px-1.5 py-px text-[9.5px] font-bold tracking-wide',
                    opt.badgeTone === 'safe' && 'border-[#2ea04366] bg-[#23863633] text-[#3fb950]',
                    opt.badgeTone === 'caution' && 'border-[#e3b34166] bg-[#e3b3411a] text-[#e3b341]',
                    (!opt.badgeTone || opt.badgeTone === 'info') && 'border-[#30363d] bg-[#161b22] text-[#8b949e]',
                  )}
                >
                  {opt.badge}
                </span>
              )}
            </span>
            {opt.detail && <span className="text-[11.5px] leading-snug text-[#8b949e]">{opt.detail}</span>}
          </button>
        )
      })}
    </div>
  )
}

/** Pratinjau diff per-berkas: blok monokrom hijau/merah ala terminal. */
function DiffBlock({ diff }: { diff: DiffPreview }) {
  return (
    <div className="mt-2 overflow-hidden rounded-lg border border-[#30363d]">
      <div className="flex items-center gap-2 border-b border-[#30363d] bg-[#161b22] px-2.5 py-1.5">
        <FileDiff className="h-3.5 w-3.5 shrink-0 text-[#8b949e]" />
        <span className="truncate font-mono text-[11px] text-[#e6edf3]">{diff.file}</span>
        {diff.isNew && <span className="rounded-full border border-[#3fb95066] bg-[#23863633] px-1.5 text-[9.5px] font-bold text-[#3fb950]">BARU</span>}
        <span className="ml-auto shrink-0 font-mono text-[10px]">
          <span className="text-[#3fb950]">+{diff.added}</span>{' '}
          <span className="text-[#f85149]">−{diff.removed}</span>
        </span>
      </div>
      <div className="max-h-64 overflow-y-auto bg-[#0d1117] font-mono text-[11px] leading-[1.6]">
        {diff.lines.map((ln, i) => (
          <div
            key={i}
            className={cn(
              'flex gap-2 whitespace-pre-wrap break-words px-2.5 py-px',
              ln.type === 'add' && 'bg-[#23863626] text-[#7ee787]',
              ln.type === 'del' && 'bg-[#f851491a] text-[#ffa198]',
              ln.type === 'ctx' && 'text-[#8b949e]',
            )}
          >
            <span className="w-8 shrink-0 select-none text-right text-[#484f58]">
              {ln.type === 'del' || ln.type === 'ctx' ? ln.oldNo ?? '' : ''}
            </span>
            <span className="w-8 shrink-0 select-none text-right text-[#484f58]">
              {ln.type === 'add' || ln.type === 'ctx' ? ln.newNo ?? '' : ''}
            </span>
            <span className="w-3 shrink-0 select-none text-[#484f58]">{ln.type === 'add' ? '+' : ln.type === 'del' ? '−' : ' '}</span>
            <span className="min-w-0 flex-1">{ln.text === '' ? ' ' : ln.text}</span>
          </div>
        ))}
      </div>
    </div>
  )
}

function MessageBubble({ msg }: { msg: ChatMessage }) {
  if (msg.role === 'user') {
    return (
      <div className="flex justify-end">
        <div className="max-w-[88%] rounded-2xl rounded-br-sm border border-[#2ea04366] bg-[#23863633] px-3 py-2">
          <p className="whitespace-pre-wrap break-words text-[13px] text-[#e6edf3]">{msg.text}</p>
          {msg.ts > 0 && <p className="mt-1 text-right text-[9.5px] text-[#3fb95088]">{formatTime(msg.ts)}</p>}
        </div>
      </div>
    )
  }

  const isError = msg.tone === 'error'
  const isAi = msg.via === 'ai'
  return (
    <div className="flex gap-2">
      <div
        className={cn(
          'mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-lg border',
          isError
            ? 'border-[#f8514966] bg-[#f851491a]'
            : isAi
              ? 'border-[#bc8cff66] bg-[#bc8cff1a]'
              : 'border-[#3fb9505c] bg-[#3fb9501a]',
        )}
      >
        {isAi ? (
          <Sparkles className="h-4 w-4 text-[#d2a8ff]" />
        ) : (
          <Bot className={cn('h-4 w-4', isError ? 'text-[#f85149]' : 'text-[#3fb950]')} />
        )}
      </div>
      <div className="min-w-0 max-w-[92%] flex-1">
        <div
          className={cn(
            'rounded-2xl rounded-tl-sm border px-3 py-2',
            isError
              ? 'border-[#f8514966] bg-[#f851490d]'
              : isAi
                ? 'border-[#bc8cff40] bg-[#bc8cff0d]'
                : 'border-[#30363d] bg-[#161b22]',
          )}
        >
          {isAi && (
            <p className="mb-1 flex items-center gap-1 text-[10px] font-semibold tracking-wide text-[#d2a8ff]">
              <Sparkles className="h-3 w-3" /> GLM AI
            </p>
          )}
          {msg.text && (
            <p className="whitespace-pre-wrap break-words text-[13px] leading-relaxed text-[#e6edf3]">{msg.text}</p>
          )}

          {msg.kind === 'summary' && msg.scan && (
            <div className="mt-2 flex items-center gap-3 rounded-lg border border-[#30363d] bg-[#0d1117] p-2.5">
              <div className="relative shrink-0">
                <MiniRing value={msg.scan.healthScore} size={46} />
                <span className="absolute inset-0 flex items-center justify-center text-[11px] font-bold text-[#e6edf3]">
                  {msg.scan.healthScore}
                </span>
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-[11px] text-[#8b949e]">
                  {msg.scan.fileCount} berkas dianalisis · {msg.scan.totalLines} baris
                </p>
                <div className="mt-1 flex flex-wrap gap-1">
                  <SeverityChip severity="critical" count={msg.scan.criticalCount} />
                  <SeverityChip severity="high" count={msg.scan.highCount} />
                  <SeverityChip severity="medium" count={msg.scan.mediumCount} />
                  <SeverityChip severity="low" count={msg.scan.lowCount} />
                  {msg.scan.crossFileCount > 0 && (
                    <span className="inline-flex items-center rounded-full border border-[#bc8cff66] bg-[#bc8cff1a] px-2 py-0.5 text-[10.5px] font-medium text-[#d2a8ff]">
                      Lintas file: {msg.scan.crossFileCount}
                    </span>
                  )}
                </div>
              </div>
            </div>
          )}

          {msg.kind === 'fix-summary' && msg.fix && (
            <div className="mt-2 rounded-lg border border-[#2ea04366] bg-[#2386361a] p-2.5">
              <p className="text-[12px] font-medium text-[#3fb950]">
                ✓ {msg.fix.applied} perbaikan otomatis diterapkan
                {msg.fix.skipped > 0 && <span className="text-[#e3b341]"> · {msg.fix.skipped} dilewati (butuh keputusan)</span>}
              </p>
              {msg.fix.files.length > 0 && (
                <p className="mt-1 break-words text-[11px] text-[#8b949e]">Berkas: {msg.fix.files.join(', ')}</p>
              )}
            </div>
          )}

          {msg.kind === 'diff' && (msg.diffs ?? []).map(d => <DiffBlock key={d.file} diff={d} />)}

          {msg.options && msg.options.length > 0 && <OptionButtons msg={msg} />}
        </div>
        {msg.ts > 0 && <p className="mt-1 text-[9.5px] text-[#484f58]">{formatTime(msg.ts)}</p>}
      </div>
    </div>
  )
}

export function ChatPanel() {
  const messages = useAgentStore(s => s.messages)
  const busy = useAgentStore(s => s.busy)
  const phase = useAgentStore(s => s.phase)
  const sendText = useAgentStore(s => s.sendText)
  const handleFiles = useAgentStore(s => s.handleFiles)
  const [input, setInput] = useState('')
  const [dragging, setDragging] = useState(false)
  const fileRef = useRef<HTMLInputElement>(null)
  const zipRef = useRef<HTMLInputElement>(null)
  const bottomRef = useRef<HTMLDivElement>(null)
  const taRef = useRef<HTMLTextAreaElement>(null)

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' })
  }, [messages.length, busy])

  const submit = () => {
    const text = input.trim()
    if (!text || busy) return
    setInput('')
    if (taRef.current) taRef.current.style.height = 'auto'
    void sendText(text)
  }

  const grow = () => {
    const el = taRef.current
    if (!el) return
    el.style.height = 'auto'
    el.style.height = `${Math.min(el.scrollHeight, 112)}px`
  }

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault()
    setDragging(false)
    if (e.dataTransfer.files.length > 0) void handleFiles(Array.from(e.dataTransfer.files))
  }

  return (
    <section
      aria-label="Chat dengan agen"
      className="flex h-full flex-col bg-[#0d1117]"
      onDragOver={e => {
        e.preventDefault()
        setDragging(true)
      }}
      onDragLeave={() => setDragging(false)}
      onDrop={onDrop}
    >
      {/* header kolom */}
      <div className="flex h-10 shrink-0 items-center gap-2 border-b border-[#30363d] bg-[#161b22] px-3">
        <MessageSquare className="h-4 w-4 text-[#3fb950]" />
        <span className="text-[13px] font-semibold text-[#e6edf3]">Chat</span>
        {busy ? (
          <span className="ml-auto inline-flex items-center gap-1 rounded-full border border-[#e3b34166] bg-[#e3b3411a] px-2 py-0.5 text-[10px] text-[#e3b341]">
            <Loader2 className="h-3 w-3 animate-spin" /> {PHASE_LABEL[phase]}
          </span>
        ) : (
          <span className="ml-auto rounded-full border border-[#30363d] px-2 py-0.5 text-[10px] text-[#8b949e]">
            {PHASE_LABEL[phase]}
          </span>
        )}
      </div>

      {/* daftar pesan */}
      <div className="min-h-0 flex-1 overflow-y-auto px-3 py-3">
        <div className="flex flex-col gap-3">
          {messages.map(msg => (
            <MessageBubble key={msg.id} msg={msg} />
          ))}
          {busy && (
            <div className="flex items-center gap-2 pl-9 text-[11px] text-[#484f58]">
              <Loader2 className="h-3 w-3 animate-spin" />
              agen sedang bekerja — pantau progresnya di terminal →
            </div>
          )}
          <div ref={bottomRef} />
        </div>
      </div>

      {/* chip pintasan */}
      {!busy && (
        <div className="flex shrink-0 flex-wrap gap-1.5 px-3 pb-2">
          {QUICK_CHIPS.map(chip => (
            <button
              key={chip}
              type="button"
              onClick={() => void sendText(chip)}
              className="rounded-full border border-[#30363d] bg-[#161b22] px-2.5 py-1 text-[11px] text-[#8b949e] transition-colors hover:border-[#3fb95066] hover:text-[#e6edf3]"
            >
              {chip}
            </button>
          ))}
        </div>
      )}

      {/* input */}
      <div className="shrink-0 border-t border-[#30363d] bg-[#161b22] p-2.5">
        <div className="flex items-end gap-1.5">
          <input
            ref={fileRef}
            type="file"
            multiple
            hidden
            onChange={e => {
              if (e.target.files?.length) void handleFiles(Array.from(e.target.files))
              e.target.value = ''
            }}
          />
          <input
            ref={zipRef}
            type="file"
            accept=".zip"
            hidden
            onChange={e => {
              if (e.target.files?.length) void handleFiles(Array.from(e.target.files))
              e.target.value = ''
            }}
          />
          <button
            type="button"
            aria-label="Lampirkan file"
            title="Lampirkan file (multi) / ZIP"
            disabled={busy}
            onClick={() => fileRef.current?.click()}
            className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-[#30363d] text-[#8b949e] transition-colors hover:border-[#3fb95066] hover:text-[#3fb950] disabled:opacity-40"
          >
            <Paperclip className="h-4 w-4" />
          </button>
          <textarea
            ref={taRef}
            rows={1}
            value={input}
            onChange={e => {
              setInput(e.target.value)
              grow()
            }}
            onKeyDown={e => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault()
                submit()
              }
            }}
            placeholder={busy ? 'Agen sedang bekerja…' : 'Tanya bebas atau perintah: "pindai", "perbaiki", "jelaskan temuan"…'}
            disabled={busy}
            className="max-h-28 min-h-[36px] flex-1 resize-none rounded-lg border border-[#30363d] bg-[#0d1117] px-3 py-2 text-[13px] text-[#e6edf3] placeholder:text-[#484f58] focus:border-[#3fb95066] focus:outline-none disabled:opacity-50"
          />
          <button
            type="button"
            aria-label="Kirim"
            onClick={submit}
            disabled={busy || !input.trim()}
            className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-[#238636] text-white transition-colors hover:bg-[#2ea043] disabled:cursor-not-allowed disabled:opacity-40"
          >
            <SendHorizonal className="h-4 w-4" />
          </button>
        </div>
        <p className="mt-1.5 flex items-center gap-2 text-[9.5px] text-[#484f58]">
          <User className="h-3 w-3" /> Enter = kirim · Shift+Enter = baris baru · seret file/ZIP ke sini
          <FileArchive className="h-3 w-3" aria-hidden="true" />
        </p>
      </div>

      {/* overlay seret */}
      {dragging && (
        <div className="pointer-events-none absolute inset-0 z-20 flex items-center justify-center border-2 border-dashed border-[#3fb95088] bg-[#0d1117cc]">
          <p className="rounded-lg border border-[#3fb95066] bg-[#161b22] px-4 py-2 text-sm text-[#3fb950]">
            Lepaskan file / ZIP di sini untuk mengunggah
          </p>
        </div>
      )}
    </section>
  )
}
