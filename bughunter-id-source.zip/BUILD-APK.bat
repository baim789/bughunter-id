@echo off
title Build APK - BugHunter ID
color 0A
cd /d "%~dp0"

if not exist "%~dp0package.json" (
    echo [ERROR] package.json tidak ditemukan di folder ini!
    echo Jalankan BUILD-APK.bat dari folder hasil ekstrak ZIP yang LANGSUNG berisi
    echo package.json, src, electron, dll. - satu tingkat dengan bat ini.
    echo Jangan pilih folder induknya.
    pause
    exit /b 1
)

:: ------------------------------------------------------------------
:: Build APK BugHunter ID (Capacitor). APK memuat aplikasi dari server PC,
:: jadi PC harus menjalankan "npm run start" saat APK dipakai.
:: Butuh: Android Studio terpasang (untuk cap open + build APK final).
:: ------------------------------------------------------------------

where node >nul 2>nul
if errorlevel 1 (
    echo [ERROR] Node.js belum terpasang. Unduh di https://nodejs.org ^(versi LTS^).
    pause
    exit /b 1
)

echo ===================================================
echo [1/5] npm install
echo ===================================================
call npm install
if errorlevel 1 goto ERROR_HANDLER

if not exist android (
    echo.
    echo ===================================================
    echo [2/5] npx cap add android  ^(sekali saja^)
    echo ===================================================
    call npx cap add android
    if errorlevel 1 goto ERROR_HANDLER
) else (
    echo.
    echo [2/5] Folder android sudah ada - lewati cap add
)

echo.
echo ===================================================
echo [3/5] npx cap sync android
echo ===================================================
call npx cap sync android
if errorlevel 1 goto ERROR_HANDLER

echo.
echo ===================================================
echo [4/5] node siapkan-android.js  ^(isi server.url + izin INTERNET^)
echo ===================================================
node siapkan-android.js
if errorlevel 1 goto ERROR_HANDLER

echo.
echo ===================================================
echo [5/5] Membuka Android Studio...
echo ===================================================
call npx cap open android
if errorlevel 1 goto ERROR_HANDLER

echo.
echo SELESAI! Di Android Studio: tekan Run (Shift+F10) untuk membangun & menjalankan APK.
echo PENTING: jalankan "npm run start" di PC agar APK bisa memuat aplikasi.
echo.
pause
exit /b 0

:ERROR_HANDLER
echo.
echo ===================================================
echo [ERROR] Proses APK gagal - periksa pesan di atas.
echo Solusi umum ada di PANDUAN-BUILD.md bagian "Masalah Umum".
echo ===================================================
pause
exit /b 1
