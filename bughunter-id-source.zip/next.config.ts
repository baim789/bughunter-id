import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "standalone",
  // Knob build (dipakai retry otomatis scripts/run-build.mjs di Windows):
  // BUGHUNTER_BUILD_CPUS=1 → worker build/pengumpulan data halaman serial, hemat RAM.
  ...(process.env.BUGHUNTER_BUILD_CPUS
    ? { experimental: { cpus: Math.max(1, Number(process.env.BUGHUNTER_BUILD_CPUS) || 1) } }
    : {}),
  /* config options here */
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  // Header keamanan dasar untuk semua respons (halaman + API).
  async headers() {
    return [
      {
        source: "/:path*",
        headers: [
          { key: "X-Content-Type-Options", value: "nosniff" },
          { key: "X-Frame-Options", value: "DENY" },
          { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
          {
            key: "Permissions-Policy",
            value: "camera=(), microphone=(), geolocation=()",
          },
        ],
      },
    ];
  },
};

export default nextConfig;
