/* BugHunter ID — layanan log terminal real-time.
 *
 * Dua server dalam satu proses:
 *  1. socket.io di port 3003 (path "/") — koneksi browser.
 *     Browser: io("/?XTransformPort=3003") → join room sesi browser.
 *  2. REST di port 3004 — Next.js mengirim progres kerja:
 *     POST http://127.0.0.1:3004/emit { room, events: [...] } (fire-and-forget).
 *
 * Event diteruskan ke room sebagai "agent-event":
 *   { kind: 'open',   term, title, subtitle }  → buka terminal baru
 *   { kind: 'line',   term, text, tone }       → tambah baris log
 *   { kind: 'status', term, status }           → ubah status terminal
 */

import { createServer, type IncomingMessage, type ServerResponse } from 'http'
import { Server, type Socket } from 'socket.io'

const SOCKET_PORT = Number(process.env.SOCKET_PORT || 3003)
const REST_PORT = Number(process.env.REST_PORT || 3004)
const ROOM_RE = /^[A-Za-z0-9_-]{4,64}$/

interface AgentEvent {
  kind: 'open' | 'line' | 'status'
  term: string
  title?: string
  subtitle?: string
  text?: string
  tone?: 'cmd' | 'ok' | 'warn' | 'err' | 'info' | 'dim'
  status?: 'running' | 'done' | 'error'
}

/* ---------- REST: /emit & /health (port 3004) ---------- */

const restServer = createServer((req: IncomingMessage, res: ServerResponse) => {
  const url = req.url ?? ''
  if (req.method === 'GET' && url.startsWith('/health')) {
    res.writeHead(200, { 'content-type': 'application/json' })
    res.end(JSON.stringify({ ok: true, clients: io.engine.clientsCount, uptime: process.uptime() }))
    return
  }
  if (req.method === 'POST' && url.startsWith('/emit')) {
    let body = ''
    let oversized = false
    req.on('data', (chunk: Buffer) => {
      body += chunk.toString('utf8')
      if (body.length > 256_000) {
        oversized = true
        req.destroy()
      }
    })
    req.on('end', () => {
      if (oversized) return
      try {
        const parsed = JSON.parse(body) as { room?: unknown; events?: unknown }
        const room = typeof parsed.room === 'string' ? parsed.room : ''
        if (!ROOM_RE.test(room)) {
          res.writeHead(400, { 'content-type': 'application/json' })
          res.end(JSON.stringify({ error: 'room tidak valid' }))
          return
        }
        const events = Array.isArray(parsed.events) ? parsed.events : []
        if (events.length > 300) {
          res.writeHead(400, { 'content-type': 'application/json' })
          res.end(JSON.stringify({ error: 'terlalu banyak event (maks 300)' }))
          return
        }
        let delivered = 0
        for (const raw of events.slice(0, 300)) {
          const ev = sanitizeEvent(raw)
          if (!ev) continue
          io.to(room).emit('agent-event', ev)
          delivered++
        }
        res.writeHead(200, { 'content-type': 'application/json' })
        res.end(
          JSON.stringify({
            ok: true,
            delivered,
            clientsInRoom: io.sockets.adapter.rooms.get(room)?.size ?? 0,
          }),
        )
      } catch {
        res.writeHead(400, { 'content-type': 'application/json' })
        res.end(JSON.stringify({ error: 'JSON tidak valid' }))
      }
    })
    return
  }
  res.writeHead(404, { 'content-type': 'application/json' })
  res.end(JSON.stringify({ error: 'tidak ditemukan' }))
})

/** Sanitasi event: hanya field terkontrol, batas panjang. */
function sanitizeEvent(raw: unknown): AgentEvent | null {
  if (!raw || typeof raw !== 'object') return null
  const e = raw as Record<string, unknown>
  const kind = e.kind
  const term = typeof e.term === 'string' ? e.term.slice(0, 48) : ''
  if ((kind !== 'open' && kind !== 'line' && kind !== 'status') || !term) return null
  const out: AgentEvent = { kind, term }
  if (typeof e.title === 'string') out.title = e.title.slice(0, 48)
  if (typeof e.subtitle === 'string') out.subtitle = e.subtitle.slice(0, 80)
  if (typeof e.text === 'string') out.text = e.text.slice(0, 600)
  const tones = ['cmd', 'ok', 'warn', 'err', 'info', 'dim']
  if (typeof e.tone === 'string' && tones.includes(e.tone)) out.tone = e.tone as AgentEvent['tone']
  if (e.status === 'running' || e.status === 'done' || e.status === 'error') out.status = e.status
  return out
}

/* ---------- socket.io (port 3003, path "/") ---------- */

const io = new Server(SOCKET_PORT, {
  // JANGAN ubah path — dipakai gateway Caddy untuk meneruskan ke port ini
  path: '/',
  cors: { origin: '*', methods: ['GET', 'POST'] },
  pingTimeout: 60000,
  pingInterval: 25000,
})

io.on('connection', (socket: Socket) => {
  socket.on('join', (room: unknown) => {
    if (typeof room === 'string' && ROOM_RE.test(room)) {
      void socket.join(room)
    }
  })
  socket.on('leave', (room: unknown) => {
    if (typeof room === 'string' && ROOM_RE.test(room)) {
      void socket.leave(room)
    }
  })
})

restServer.listen(REST_PORT, () => {
  console.log(`[agent-log] REST /emit & /health di port ${REST_PORT}`)
})
console.log(`[agent-log] socket.io siap di port ${SOCKET_PORT} (path "/")`)
