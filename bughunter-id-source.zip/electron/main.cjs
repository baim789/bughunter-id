/**
 * electron/main.cjs — proses utama aplikasi desktop BugHunter ID (Windows EXE).
 *
 * Cara kerja:
 *  1) Menyalin seed.db (skema SQLite) ke folder data pengguna (%APPDATA%/BugHunterID) bila belum ada.
 *  2) Menjalankan server produksi Next.js standalone sebagai proses anak
 *     (biner Electron dipakai sebagai Node via ELECTRON_RUN_AS_NODE=1).
 *  3) Menunggu server siap, lalu membuka jendela aplikasi ke http://127.0.0.1:<port>.
 *  4) Menutup server saat jendela ditutup. Satu instance saja (single-instance lock).
 *  Semua log server tersimpan di %APPDATA%/BugHunterID/server.log untuk diagnosis.
 */
const { app, BrowserWindow, dialog } = require('electron')
const { spawn } = require('child_process')
const http = require('http')
const net = require('net')
const fs = require('fs')
const path = require('path')

const APP_NAME = 'BugHunter ID'
const PORT_START = 3777
const READY_TIMEOUT_MS = 60_000

let serverProc = null
let quitting = false

/** Cari port IPv4 bebas mulai dari PORT_START (maks +50). */
function findFreePort(start) {
  return new Promise((resolve, reject) => {
    let port = start
    const tryOne = () => {
      const srv = net.createServer()
      srv.once('error', () => {
        port += 1
        if (port > start + 50) reject(new Error('Tidak ada port bebas di sekitar ' + start))
        else tryOne()
      })
      srv.once('listening', () => srv.close(() => resolve(port)))
      srv.listen(port, '127.0.0.1')
    }
    tryOne()
  })
}

/** Polling HTTP sampai server merespons (status < 500) atau timeout. */
function waitReady(port, timeoutMs) {
  const deadline = Date.now() + timeoutMs
  return new Promise((resolve, reject) => {
    const attempt = () => {
      if (quitting) return reject(new Error('Dibatalkan (aplikasi sedang keluar)'))
      const req = http.get({ host: '127.0.0.1', port, path: '/', timeout: 2500 }, (res) => {
        res.resume()
        if (res.statusCode && res.statusCode < 500) return resolve()
        retry()
      })
      req.on('timeout', () => {
        req.destroy()
        retry()
      })
      req.on('error', retry)
    }
    const retry = () => {
      if (Date.now() > deadline) return reject(new Error('Server tidak merespons dalam ' + timeoutMs / 1000 + ' detik'))
      setTimeout(attempt, 300)
    }
    attempt()
  })
}

/** Nyalakan server standalone; kembalikan { port } atau null (dengan dialog error). */
async function startServer() {
  let appDir, seedDb
  if (app.isPackaged) {
    appDir = path.join(process.resourcesPath, 'app')
    seedDb = path.join(process.resourcesPath, 'seed.db')
  } else {
    // Mode dev (`electron .` di folder proyek): pakai hasil `npm run build` lokal.
    const projRoot = app.getAppPath()
    appDir = path.join(projRoot, '.next', 'standalone')
    seedDb = path.join(projRoot, '.next', 'exe', 'seed.db')
  }

  const serverJs = path.join(appDir, 'server.js')
  if (!fs.existsSync(serverJs)) {
    dialog.showErrorBox(
      APP_NAME,
      'Berkas server aplikasi tidak ditemukan.\n\n' +
        'Buka folder proyek lalu jalankan:\n    npm install\n    npm run build\n\n' +
        'Setelah itu EXE/installer baru di folder dist-exe/ bisa dipakai.'
    )
    return null
  }

  // Basis data pengguna: salin seed.db sekali dijalankan pertama.
  const userData = app.getPath('userData')
  fs.mkdirSync(userData, { recursive: true })
  const dbPath = path.join(userData, 'bughunter-id.db')
  try {
    if (!fs.existsSync(dbPath) && fs.existsSync(seedDb)) fs.copyFileSync(seedDb, dbPath)
  } catch (e) {
    dialog.showErrorBox(APP_NAME, 'Gagal menyiapkan basis data: ' + (e && e.message))
    return null
  }

  let port
  try {
    port = await findFreePort(PORT_START)
  } catch (e) {
    dialog.showErrorBox(APP_NAME, 'Tidak menemukan port bebas: ' + (e && e.message))
    return null
  }

  const logPath = path.join(userData, 'server.log')
  const logStream = fs.createWriteStream(logPath, { flags: 'a' })
  logStream.write('\n=== ' + new Date().toISOString() + ' — memulai server di port ' + port + ' ===\n')

  const env = {
    ...process.env,
    ELECTRON_RUN_AS_NODE: '1',
    NODE_ENV: 'production',
    PORT: String(port),
    HOSTNAME: '127.0.0.1',
    NEXT_TELEMETRY_DISABLED: '1',
    DATABASE_URL: 'file:' + dbPath.split(path.sep).join('/'),
  }

  serverProc = spawn(process.execPath, [serverJs], {
    cwd: appDir,
    env,
    stdio: ['ignore', 'pipe', 'pipe'],
    windowsHide: true,
  })
  serverProc.stdout.on('data', (d) => logStream.write(d))
  serverProc.stderr.on('data', (d) => logStream.write('[stderr] ' + d))
  serverProc.on('exit', (code) => {
    logStream.end()
    if (!quitting) {
      dialog.showErrorBox(
        APP_NAME,
        'Server aplikasi berhenti mendadak (kode ' + code + ').\n\nLog: ' + logPath
      )
      app.quit()
    }
  })

  console.log('[main] server dimulai di port ' + port + ' — log: ' + logPath)
  return { port }
}

async function createWindow() {
  const inst = await startServer()
  if (!inst) return
  await waitReady(inst.port, READY_TIMEOUT_MS)

  const win = new BrowserWindow({
    width: 1440,
    height: 920,
    minWidth: 1024,
    minHeight: 700,
    autoHideMenuBar: true,
    title: APP_NAME,
    backgroundColor: '#0a0a0f',
    show: false,
  })
  win.once('ready-to-show', () => win.show())
  win.on('page-title-updated', (e) => e.preventDefault())
  await win.loadURL('http://127.0.0.1:' + inst.port + '/')
}

const gotLock = app.requestSingleInstanceLock()
if (!gotLock) {
  app.quit()
} else {
  app.on('second-instance', () => {
    const [win] = BrowserWindow.getAllWindows()
    if (win) {
      if (win.isMinimized()) win.restore()
      win.focus()
    }
  })

  app.whenReady()
    .then(createWindow)
    .catch((err) => {
      dialog.showErrorBox(APP_NAME, 'Gagal memulai aplikasi: ' + ((err && err.message) || err))
      app.exit(1)
    })

  app.on('window-all-closed', () => {
    quitting = true
    if (serverProc) try { serverProc.kill() } catch {}
    app.quit()
  })
  app.on('before-quit', () => {
    quitting = true
    if (serverProc) try { serverProc.kill() } catch {}
  })
}
