@echo off
title Build EXE - BugHunter ID
color 0A
cd /d "%~dp0"

if not exist "%~dp0package.json" (
    echo [ERROR] package.json tidak ditemukan di folder ini!
    echo Jalankan BUILD-EXE.bat dari folder hasil ekstrak ZIP yang LANGSUNG berisi
    echo package.json, src, electron, dll. - satu tingkat dengan bat ini.
    echo Jangan pilih folder induknya.
    pause
    exit /b 1
)

:: ------------------------------------------------------------------
:: Build EXE BugHunter ID (jalan otomatis di akhir npm run build).
:: Hasil akhir: folder dist-exe\ berisi
::   - BugHunterID-Portable-<versi>.exe  (tanpa instalasi, klik 2x langsung jalan)
::   - BugHunterID-Setup-<versi>.exe     (installer Windows)
:: ------------------------------------------------------------------

where node >nul 2>nul
if errorlevel 1 (
    echo [ERROR] Node.js belum terpasang. Unduh di https://nodejs.org ^(versi LTS^), lalu jalankan ulang.
    pause
    exit /b 1
)

echo ===================================================
echo [1/3] npm install  ^(sekali saja di awal; mengunduh Electron ~110 MB^)
echo ===================================================
call npm install
if errorlevel 1 goto ERROR_HANDLER

echo.
echo ===================================================
echo [2/3] npm run build  ^(build web + packaging EXE otomatis^)
echo ===================================================
call npm run build
if errorlevel 1 goto ERROR_HANDLER

echo.
echo ===================================================
echo [3/3] SELESAI! 
echo ===================================================
echo Hasil EXE ada di folder: %~dp0dist-exe
echo   - BugHunterID-Portable-*.exe  : klik 2x, langsung jalan tanpa instalasi
echo   - BugHunterID-Setup-*.exe     : installer Windows biasa
echo.
if exist "%~dp0dist-exe" start "" "%~dp0dist-exe"
echo Catatan: saat pertama dibuka, Windows SmartScreen bisa muncul karena EXE tidak
echo ditandatangani - pilih "More info" lalu "Run anyway". Lihat PANDUAN-BUILD.md.
echo.
pause
exit /b 0

:ERROR_HANDLER
echo.
echo ===================================================
echo [ERROR] Build gagal - periksa pesan di atas.
echo Solusi umum ada di PANDUAN-BUILD.md bagian "Masalah Umum".
echo ===================================================
pause
exit /b 1
